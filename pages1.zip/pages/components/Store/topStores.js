import Link from "next/link";
const TopStores = ({ storeInfo }) => {
  let Stores = [];  
  Stores = storeInfo;

  

  if(Stores){
  const LiElements = Stores.map((store, index) => (
    <li className="storeCard-Col" key={index}>
      {console.log(LogoCall)}
      <div className="storeCard storeCard-small">
        <Link href={`/${store.slug + "-" + store.slugType}`} as={`${store.slug + "-" + store.slugType}`}>
          <a>
            <img
              src={`/stores__logo/${store.slug}-logo-large.jpg`}
              onError={(e) => {
                e.target.onerror = null;
                e.target.src = "/img-notfound.jpg";
              }}
            />
          </a>
        </Link>
          <h5>
          <Link href={`/${store.slug + "-" + store.slugType}`} as={`${store.slug + "-" + store.slugType}`}>
              <a className="nav-link">{store.formatted_name}</a>
          </Link>
          </h5>
        
      </div>
    </li>
  ));
  return LiElements;
  }else{
    return '';
  }
};


const LogoCall = async (slug) => {
  const storeSlug = slug;
  const response = await fetch(
    `https://ofccode-api-sportybruh1990.vercel.app/api/front/${storeSlug}`
  );
  const getStoreIdRes = await response.json();
  const storeId = getStoreIdRes.affInfo__StoreId;
  const dataUrl =
    "https://export.admitad.com/en/webmaster/websites/1777052/coupons/export/?website=1777052&advcampaigns=" +
    storeId +
    "&region=00&code=eyq48w62bj&user=vishwajit82&format=csv&v=4";
  const res = await axios.get(dataUrl);
  const data = Papa.parse(res.data[1]);
  return {
    props: {
      storeInfo: getStoreIdRes,
    },
  };

}

export default TopStores;
