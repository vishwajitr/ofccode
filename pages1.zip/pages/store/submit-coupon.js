import React, { Component } from "react";
import axios from 'axios'
const SubmitCouponPage = (props) => {
    return (
      <section>
      <h1>Coming Soon</h1> 
      </section>
    );
}

export default SubmitCouponPage;
