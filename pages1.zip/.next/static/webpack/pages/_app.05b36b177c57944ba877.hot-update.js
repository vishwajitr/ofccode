webpackHotUpdate_N_E("pages/_app",{

/***/ "./pages/_app.js":
/*!***********************!*\
  !*** ./pages/_app.js ***!
  \***********************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var C_xampp_htdocs_ReactTuts_NextJS_ofccode_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/head */ "./node_modules/next/head.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_gtm_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-gtm-module */ "./node_modules/react-gtm-module/dist/index.js");
/* harmony import */ var react_gtm_module__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_gtm_module__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_Header__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./components/Header */ "./pages/components/Header.js");
/* harmony import */ var _components_Footer__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./components/Footer */ "./pages/components/Footer.js");
/* harmony import */ var _styles_global_scss__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../styles/global.scss */ "./styles/global.scss");
/* harmony import */ var _styles_global_scss__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_styles_global_scss__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _styles_Layout_scss__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../styles/Layout.scss */ "./styles/Layout.scss");
/* harmony import */ var _styles_Layout_scss__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_styles_Layout_scss__WEBPACK_IMPORTED_MODULE_8__);



var _jsxFileName = "C:\\xampp\\htdocs\\ReactTuts\\NextJS\\ofccode\\pages\\_app.js",
    _s = $RefreshSig$();

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { Object(C_xampp_htdocs_ReactTuts_NextJS_ofccode_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }








var tagManagerArgs = {
  gtmId: "GTM-WQDK67V"
};

if (true) {
  react_gtm_module__WEBPACK_IMPORTED_MODULE_4___default.a.initialize(tagManagerArgs);
}

function MyApp(_ref) {
  _s();

  var Component = _ref.Component,
      pageProps = _ref.pageProps;
  // Similar to componentDidMount and componentDidUpdate:
  Object(react__WEBPACK_IMPORTED_MODULE_2__["useEffect"])(function () {
    window.ao_subid = "moneylink"; // window.OneSignal = window.OneSignal || [];
    // const OneSignal = window.OneSignal;
    // OneSignal.push(()=> {
    //   OneSignal.init(
    //     {
    //       appId: "b0bdcbd7-4c41-46e8-89db-1984ea5e49e1", //STEP 9
    //       welcomeNotification: {
    //         "title": "One Signal",
    //         "message": "Thanks for subscribing!",
    //       }
    //   },
    //     //Automatically subscribe to the new_app_version tag
    //     OneSignal.sendTag("new_app_version", "new_app_version", tagsSent => {
    //       // Callback called when tag has finished sending
    //       console.log('new_app_version TAG SENT', tagsSent);
    //     })
    //   );
    // });
  });
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("div", {
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(next_head__WEBPACK_IMPORTED_MODULE_3___default.a, {
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("title", {
        children: "OffersCode.in | Coupons, Cashback, Offers and Promo Code"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 44,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("link", {
        rel: "icon",
        href: "/favicon.ico"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 45,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("meta", {
        charSet: "UTF-8"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 46,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("meta", {
        name: "viewport",
        content: "width=device-width, initial-scale=1.0"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 47,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("meta", {
        name: "keywords",
        content: "Coupons, Deals"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 48,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("meta", {
        name: "description",
        content: "Now SAVE MORE with OffersCode! Get the latest and up-to-date coupons, cashback offers on some of India\u2019s top online shopping sites like Amazon, Paytm, Snapdeal, Flipkart, Myntra and many more at OffersCode.in."
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 49,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("meta", {
        itemProp: "url",
        name: "url",
        content: "https://offersCode.in"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 53,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("link", {
        rel: "canonical",
        href: "https://offerscode.in/"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 56,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("meta", {
        property: "og:site_name",
        content: "offerscode.in"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 57,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("meta", {
        property: "og:type",
        content: "website"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 58,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("meta", {
        property: "og:title",
        content: "Offerscode.in"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 59,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("meta", {
        property: "og:url",
        content: "https://offerscode.in/"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 60,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("meta", {
        property: "og:description",
        content: "Now SAVE MORE with OffersCode! Get the latest and up-to-date coupons, cashback offers on some of India\u2019s top online shopping sites like Amazon, Paytm, Snapdeal, Flipkart, Myntra and many more at OffersCode.in."
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 61,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("meta", {
        property: "og:locale",
        content: "en_US"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 65,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("meta", {
        property: "og:image",
        content: "logo.jpg"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 66,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("meta", {
        property: "og:article:published_time",
        content: ""
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 67,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("meta", {
        name: "twitter:card",
        content: "summary_large_image"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 70,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("meta", {
        name: "twitter:description",
        content: "Now SAVE MORE with OffersCode! Get the latest and up-to-date coupons, cashback offers on some of India\u2019s top online shopping sites like Amazon, Paytm, Snapdeal, Flipkart, Myntra and many more at OffersCode.in."
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 71,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("meta", {
        name: "twitter:title",
        content: "offerscode.in"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 75,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("meta", {
        name: "twitter:site",
        content: "@offerscodein"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 76,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("meta", {
        name: "twitter:creator",
        content: "@offerscodein"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 77,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("meta", {
        itemProp: "name",
        content: "offerscode.in"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 80,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("meta", {
        itemProp: "description",
        content: "Now SAVE MORE with OffersCode! Get the latest and up-to-date coupons, cashback offers on some of India\u2019s top online shopping sites like Amazon, Paytm, Snapdeal, Flipkart, Myntra and many more at OffersCode.in."
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 81,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("meta", {
        itemProp: "image",
        content: "logo.jpg"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 85,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("script", {
        src: "//js.mamydirect.com/js/?h=j528d0OH",
        type: "text/javascript",
        async: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 90,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("script", {
        async: true,
        src: "https://www.googletagmanager.com/gtag/js?id=G-RVN1V7NSW4"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 95,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("script", {
        "data-ad-client": "ca-pub-1481948700257830",
        async: true,
        src: "https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 99,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 43,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(_components_Header__WEBPACK_IMPORTED_MODULE_5__["default"], {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 106,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("div", {
      className: "container",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("div", {
        className: "oedx__728x90",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("amp-ad", {
          width: "100vw",
          height: "320",
          type: "adsense",
          "data-ad-client": "ca-pub-1481948700257830",
          "data-ad-slot": "9124523232",
          "data-auto-format": "rspv",
          "data-full-width": "",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("div", {
            overflow: ""
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 118,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 109,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 108,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 107,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("div", {
      className: "container main-container",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(Component, _objectSpread({}, pageProps), void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 123,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 122,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("div", {
      className: "container",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("div", {
        className: "oedx__728x90",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("amp-ad", {
          width: "100vw",
          height: "320",
          type: "adsense",
          "data-ad-client": "ca-pub-1481948700257830",
          "data-ad-slot": "3819213905",
          "data-auto-format": "rspv",
          "data-full-width": "",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("div", {
            overflow: ""
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 136,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 127,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 126,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 125,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(_components_Footer__WEBPACK_IMPORTED_MODULE_6__["default"], {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 140,
      columnNumber: 7
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 42,
    columnNumber: 5
  }, this);
}

_s(MyApp, "OD7bBpZva5O2jO+Puf00hKivP7c=");

_c = MyApp;
/* harmony default export */ __webpack_exports__["default"] = (MyApp);

var _c;

$RefreshReg$(_c, "MyApp");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvX2FwcC5qcyJdLCJuYW1lcyI6WyJ0YWdNYW5hZ2VyQXJncyIsImd0bUlkIiwiVGFnTWFuYWdlciIsImluaXRpYWxpemUiLCJNeUFwcCIsIkNvbXBvbmVudCIsInBhZ2VQcm9wcyIsInVzZUVmZmVjdCIsIndpbmRvdyIsImFvX3N1YmlkIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQU1BLGNBQWMsR0FBRztBQUNyQkMsT0FBSyxFQUFFO0FBRGMsQ0FBdkI7O0FBR0EsVUFBcUI7QUFDbkJDLHlEQUFVLENBQUNDLFVBQVgsQ0FBc0JILGNBQXRCO0FBQ0Q7O0FBRUQsU0FBU0ksS0FBVCxPQUF5QztBQUFBOztBQUFBLE1BQXhCQyxTQUF3QixRQUF4QkEsU0FBd0I7QUFBQSxNQUFiQyxTQUFhLFFBQWJBLFNBQWE7QUFDdkM7QUFDQUMseURBQVMsQ0FBQyxZQUFNO0FBQ2RDLFVBQU0sQ0FBQ0MsUUFBUCxHQUFrQixXQUFsQixDQURjLENBR2Q7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0QsR0F0QlEsQ0FBVDtBQXdCQSxzQkFDRTtBQUFBLDRCQUNFLHFFQUFDLGdEQUFEO0FBQUEsOEJBQ0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FERixlQUVFO0FBQU0sV0FBRyxFQUFDLE1BQVY7QUFBaUIsWUFBSSxFQUFDO0FBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FGRixlQUdFO0FBQU0sZUFBTyxFQUFDO0FBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUhGLGVBSUU7QUFBTSxZQUFJLEVBQUMsVUFBWDtBQUFzQixlQUFPLEVBQUM7QUFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUpGLGVBS0U7QUFBTSxZQUFJLEVBQUMsVUFBWDtBQUFzQixlQUFPLEVBQUM7QUFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUxGLGVBTUU7QUFDRSxZQUFJLEVBQUMsYUFEUDtBQUVFLGVBQU8sRUFBQztBQUZWO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FORixlQVVFO0FBQU0sZ0JBQVEsRUFBQyxLQUFmO0FBQXFCLFlBQUksRUFBQyxLQUExQjtBQUFnQyxlQUFPLEVBQUM7QUFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVZGLGVBYUU7QUFBTSxXQUFHLEVBQUMsV0FBVjtBQUFzQixZQUFJLEVBQUM7QUFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWJGLGVBY0U7QUFBTSxnQkFBUSxFQUFDLGNBQWY7QUFBOEIsZUFBTyxFQUFDO0FBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FkRixlQWVFO0FBQU0sZ0JBQVEsRUFBQyxTQUFmO0FBQXlCLGVBQU8sRUFBQztBQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGNBZkYsZUFnQkU7QUFBTSxnQkFBUSxFQUFDLFVBQWY7QUFBMEIsZUFBTyxFQUFDO0FBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FoQkYsZUFpQkU7QUFBTSxnQkFBUSxFQUFDLFFBQWY7QUFBd0IsZUFBTyxFQUFDO0FBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FqQkYsZUFrQkU7QUFDRSxnQkFBUSxFQUFDLGdCQURYO0FBRUUsZUFBTyxFQUFDO0FBRlY7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWxCRixlQXNCRTtBQUFNLGdCQUFRLEVBQUMsV0FBZjtBQUEyQixlQUFPLEVBQUM7QUFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQXRCRixlQXVCRTtBQUFNLGdCQUFRLEVBQUMsVUFBZjtBQUEwQixlQUFPLEVBQUM7QUFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQXZCRixlQXdCRTtBQUFNLGdCQUFRLEVBQUMsMkJBQWY7QUFBMkMsZUFBTyxFQUFDO0FBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0F4QkYsZUEyQkU7QUFBTSxZQUFJLEVBQUMsY0FBWDtBQUEwQixlQUFPLEVBQUM7QUFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQTNCRixlQTRCRTtBQUNFLFlBQUksRUFBQyxxQkFEUDtBQUVFLGVBQU8sRUFBQztBQUZWO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0E1QkYsZUFnQ0U7QUFBTSxZQUFJLEVBQUMsZUFBWDtBQUEyQixlQUFPLEVBQUM7QUFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWhDRixlQWlDRTtBQUFNLFlBQUksRUFBQyxjQUFYO0FBQTBCLGVBQU8sRUFBQztBQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGNBakNGLGVBa0NFO0FBQU0sWUFBSSxFQUFDLGlCQUFYO0FBQTZCLGVBQU8sRUFBQztBQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGNBbENGLGVBcUNFO0FBQU0sZ0JBQVEsRUFBQyxNQUFmO0FBQXNCLGVBQU8sRUFBQztBQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBckNGLGVBc0NFO0FBQ0UsZ0JBQVEsRUFBQyxhQURYO0FBRUUsZUFBTyxFQUFDO0FBRlY7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQXRDRixlQTBDRTtBQUFNLGdCQUFRLEVBQUMsT0FBZjtBQUF1QixlQUFPLEVBQUM7QUFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQTFDRixlQStDRTtBQUNFLFdBQUcsRUFBQyxvQ0FETjtBQUVFLFlBQUksRUFBQyxpQkFGUDtBQUdFLGFBQUs7QUFIUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBL0NGLGVBb0RFO0FBQ0UsYUFBSyxNQURQO0FBRUUsV0FBRyxFQUFDO0FBRk47QUFBQTtBQUFBO0FBQUE7QUFBQSxjQXBERixlQXdERTtBQUNFLDBCQUFlLHlCQURqQjtBQUVFLGFBQUssTUFGUDtBQUdFLFdBQUcsRUFBQztBQUhOO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0F4REY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREYsZUFnRUUscUVBQUMsMERBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQWhFRixlQWlFRTtBQUFLLGVBQVMsRUFBQyxXQUFmO0FBQUEsNkJBQ0U7QUFBSyxpQkFBUyxFQUFDLGNBQWY7QUFBQSwrQkFDRTtBQUNFLGVBQUssRUFBQyxPQURSO0FBRUUsZ0JBQU0sRUFBQyxLQUZUO0FBR0UsY0FBSSxFQUFDLFNBSFA7QUFJRSw0QkFBZSx5QkFKakI7QUFLRSwwQkFBYSxZQUxmO0FBTUUsOEJBQWlCLE1BTm5CO0FBT0UsNkJBQWdCLEVBUGxCO0FBQUEsaUNBU0U7QUFBSyxvQkFBUSxFQUFDO0FBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQWpFRixlQWdGRTtBQUFLLGVBQVMsRUFBQywwQkFBZjtBQUFBLDZCQUNFLHFFQUFDLFNBQUQsb0JBQWVILFNBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFoRkYsZUFtRkU7QUFBSyxlQUFTLEVBQUMsV0FBZjtBQUFBLDZCQUNFO0FBQUssaUJBQVMsRUFBQyxjQUFmO0FBQUEsK0JBQ0U7QUFDRSxlQUFLLEVBQUMsT0FEUjtBQUVFLGdCQUFNLEVBQUMsS0FGVDtBQUdFLGNBQUksRUFBQyxTQUhQO0FBSUUsNEJBQWUseUJBSmpCO0FBS0UsMEJBQWEsWUFMZjtBQU1FLDhCQUFpQixNQU5uQjtBQU9FLDZCQUFnQixFQVBsQjtBQUFBLGlDQVNFO0FBQUssb0JBQVEsRUFBQztBQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFURjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFuRkYsZUFrR0UscUVBQUMsMERBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQWxHRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFERjtBQXNHRDs7R0FoSVFGLEs7O0tBQUFBLEs7QUFrSU1BLG9FQUFmIiwiZmlsZSI6InN0YXRpYy93ZWJwYWNrL3BhZ2VzL19hcHAuMDViMzZiMTc3YzU3OTQ0YmE4NzcuaG90LXVwZGF0ZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBIZWFkIGZyb20gXCJuZXh0L2hlYWRcIjtcclxuaW1wb3J0IFRhZ01hbmFnZXIgZnJvbSBcInJlYWN0LWd0bS1tb2R1bGVcIjtcclxuaW1wb3J0IE5hdmJhciBmcm9tIFwiLi9jb21wb25lbnRzL0hlYWRlclwiO1xyXG5pbXBvcnQgRm9vdGVyIGZyb20gXCIuL2NvbXBvbmVudHMvRm9vdGVyXCI7XHJcbmltcG9ydCBcIi4uL3N0eWxlcy9nbG9iYWwuc2Nzc1wiO1xyXG5pbXBvcnQgXCIuLi9zdHlsZXMvTGF5b3V0LnNjc3NcIjtcclxuY29uc3QgdGFnTWFuYWdlckFyZ3MgPSB7XHJcbiAgZ3RtSWQ6IFwiR1RNLVdRREs2N1ZcIixcclxufTtcclxuaWYgKHByb2Nlc3MuYnJvd3Nlcikge1xyXG4gIFRhZ01hbmFnZXIuaW5pdGlhbGl6ZSh0YWdNYW5hZ2VyQXJncyk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIE15QXBwKHsgQ29tcG9uZW50LCBwYWdlUHJvcHMgfSkge1xyXG4gIC8vIFNpbWlsYXIgdG8gY29tcG9uZW50RGlkTW91bnQgYW5kIGNvbXBvbmVudERpZFVwZGF0ZTpcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgd2luZG93LmFvX3N1YmlkID0gXCJtb25leWxpbmtcIjtcclxuXHJcbiAgICAvLyB3aW5kb3cuT25lU2lnbmFsID0gd2luZG93Lk9uZVNpZ25hbCB8fCBbXTtcclxuICAgIC8vIGNvbnN0IE9uZVNpZ25hbCA9IHdpbmRvdy5PbmVTaWduYWw7XHJcblxyXG4gICAgLy8gT25lU2lnbmFsLnB1c2goKCk9PiB7XHJcbiAgICAvLyAgIE9uZVNpZ25hbC5pbml0KFxyXG4gICAgLy8gICAgIHtcclxuICAgIC8vICAgICAgIGFwcElkOiBcImIwYmRjYmQ3LTRjNDEtNDZlOC04OWRiLTE5ODRlYTVlNDllMVwiLCAvL1NURVAgOVxyXG4gICAgLy8gICAgICAgd2VsY29tZU5vdGlmaWNhdGlvbjoge1xyXG4gICAgLy8gICAgICAgICBcInRpdGxlXCI6IFwiT25lIFNpZ25hbFwiLFxyXG4gICAgLy8gICAgICAgICBcIm1lc3NhZ2VcIjogXCJUaGFua3MgZm9yIHN1YnNjcmliaW5nIVwiLFxyXG4gICAgLy8gICAgICAgfVxyXG4gICAgLy8gICB9LFxyXG4gICAgLy8gICAgIC8vQXV0b21hdGljYWxseSBzdWJzY3JpYmUgdG8gdGhlIG5ld19hcHBfdmVyc2lvbiB0YWdcclxuICAgIC8vICAgICBPbmVTaWduYWwuc2VuZFRhZyhcIm5ld19hcHBfdmVyc2lvblwiLCBcIm5ld19hcHBfdmVyc2lvblwiLCB0YWdzU2VudCA9PiB7XHJcbiAgICAvLyAgICAgICAvLyBDYWxsYmFjayBjYWxsZWQgd2hlbiB0YWcgaGFzIGZpbmlzaGVkIHNlbmRpbmdcclxuICAgIC8vICAgICAgIGNvbnNvbGUubG9nKCduZXdfYXBwX3ZlcnNpb24gVEFHIFNFTlQnLCB0YWdzU2VudCk7XHJcbiAgICAvLyAgICAgfSlcclxuICAgIC8vICAgKTtcclxuICAgIC8vIH0pO1xyXG4gIH0pO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdj5cclxuICAgICAgPEhlYWQ+XHJcbiAgICAgICAgPHRpdGxlPk9mZmVyc0NvZGUuaW4gfCBDb3Vwb25zLCBDYXNoYmFjaywgT2ZmZXJzIGFuZCBQcm9tbyBDb2RlPC90aXRsZT5cclxuICAgICAgICA8bGluayByZWw9XCJpY29uXCIgaHJlZj1cIi9mYXZpY29uLmljb1wiIC8+XHJcbiAgICAgICAgPG1ldGEgY2hhclNldD1cIlVURi04XCIgLz5cclxuICAgICAgICA8bWV0YSBuYW1lPVwidmlld3BvcnRcIiBjb250ZW50PVwid2lkdGg9ZGV2aWNlLXdpZHRoLCBpbml0aWFsLXNjYWxlPTEuMFwiIC8+XHJcbiAgICAgICAgPG1ldGEgbmFtZT1cImtleXdvcmRzXCIgY29udGVudD1cIkNvdXBvbnMsIERlYWxzXCIgLz5cclxuICAgICAgICA8bWV0YVxyXG4gICAgICAgICAgbmFtZT1cImRlc2NyaXB0aW9uXCJcclxuICAgICAgICAgIGNvbnRlbnQ9XCJOb3cgU0FWRSBNT1JFIHdpdGggT2ZmZXJzQ29kZSEgR2V0IHRoZSBsYXRlc3QgYW5kIHVwLXRvLWRhdGUgY291cG9ucywgY2FzaGJhY2sgb2ZmZXJzIG9uIHNvbWUgb2YgSW5kaWHigJlzIHRvcCBvbmxpbmUgc2hvcHBpbmcgc2l0ZXMgbGlrZSBBbWF6b24sIFBheXRtLCBTbmFwZGVhbCwgRmxpcGthcnQsIE15bnRyYSBhbmQgbWFueSBtb3JlIGF0IE9mZmVyc0NvZGUuaW4uXCJcclxuICAgICAgICAvPlxyXG4gICAgICAgIDxtZXRhIGl0ZW1Qcm9wPVwidXJsXCIgbmFtZT1cInVybFwiIGNvbnRlbnQ9XCJodHRwczovL29mZmVyc0NvZGUuaW5cIiAvPlxyXG5cclxuICAgICAgICB7LyogPCEtLSBPcGVuIEdyYXBoIE1ldGEgdGFncyAtLT4gKi99XHJcbiAgICAgICAgPGxpbmsgcmVsPVwiY2Fub25pY2FsXCIgaHJlZj1cImh0dHBzOi8vb2ZmZXJzY29kZS5pbi9cIiAvPlxyXG4gICAgICAgIDxtZXRhIHByb3BlcnR5PVwib2c6c2l0ZV9uYW1lXCIgY29udGVudD1cIm9mZmVyc2NvZGUuaW5cIiAvPlxyXG4gICAgICAgIDxtZXRhIHByb3BlcnR5PVwib2c6dHlwZVwiIGNvbnRlbnQ9XCJ3ZWJzaXRlXCIgLz5cclxuICAgICAgICA8bWV0YSBwcm9wZXJ0eT1cIm9nOnRpdGxlXCIgY29udGVudD1cIk9mZmVyc2NvZGUuaW5cIiAvPlxyXG4gICAgICAgIDxtZXRhIHByb3BlcnR5PVwib2c6dXJsXCIgY29udGVudD1cImh0dHBzOi8vb2ZmZXJzY29kZS5pbi9cIiAvPlxyXG4gICAgICAgIDxtZXRhXHJcbiAgICAgICAgICBwcm9wZXJ0eT1cIm9nOmRlc2NyaXB0aW9uXCJcclxuICAgICAgICAgIGNvbnRlbnQ9XCJOb3cgU0FWRSBNT1JFIHdpdGggT2ZmZXJzQ29kZSEgR2V0IHRoZSBsYXRlc3QgYW5kIHVwLXRvLWRhdGUgY291cG9ucywgY2FzaGJhY2sgb2ZmZXJzIG9uIHNvbWUgb2YgSW5kaWHigJlzIHRvcCBvbmxpbmUgc2hvcHBpbmcgc2l0ZXMgbGlrZSBBbWF6b24sIFBheXRtLCBTbmFwZGVhbCwgRmxpcGthcnQsIE15bnRyYSBhbmQgbWFueSBtb3JlIGF0IE9mZmVyc0NvZGUuaW4uXCJcclxuICAgICAgICAvPlxyXG4gICAgICAgIDxtZXRhIHByb3BlcnR5PVwib2c6bG9jYWxlXCIgY29udGVudD1cImVuX1VTXCIgLz5cclxuICAgICAgICA8bWV0YSBwcm9wZXJ0eT1cIm9nOmltYWdlXCIgY29udGVudD1cImxvZ28uanBnXCIgLz5cclxuICAgICAgICA8bWV0YSBwcm9wZXJ0eT1cIm9nOmFydGljbGU6cHVibGlzaGVkX3RpbWVcIiBjb250ZW50PVwiXCIgLz5cclxuXHJcbiAgICAgICAgey8qIDwhLS0gdHdpdHRlciBNZXRhIHRhZ3MgLS0+ICovfVxyXG4gICAgICAgIDxtZXRhIG5hbWU9XCJ0d2l0dGVyOmNhcmRcIiBjb250ZW50PVwic3VtbWFyeV9sYXJnZV9pbWFnZVwiIC8+XHJcbiAgICAgICAgPG1ldGFcclxuICAgICAgICAgIG5hbWU9XCJ0d2l0dGVyOmRlc2NyaXB0aW9uXCJcclxuICAgICAgICAgIGNvbnRlbnQ9XCJOb3cgU0FWRSBNT1JFIHdpdGggT2ZmZXJzQ29kZSEgR2V0IHRoZSBsYXRlc3QgYW5kIHVwLXRvLWRhdGUgY291cG9ucywgY2FzaGJhY2sgb2ZmZXJzIG9uIHNvbWUgb2YgSW5kaWHigJlzIHRvcCBvbmxpbmUgc2hvcHBpbmcgc2l0ZXMgbGlrZSBBbWF6b24sIFBheXRtLCBTbmFwZGVhbCwgRmxpcGthcnQsIE15bnRyYSBhbmQgbWFueSBtb3JlIGF0IE9mZmVyc0NvZGUuaW4uXCJcclxuICAgICAgICAvPlxyXG4gICAgICAgIDxtZXRhIG5hbWU9XCJ0d2l0dGVyOnRpdGxlXCIgY29udGVudD1cIm9mZmVyc2NvZGUuaW5cIiAvPlxyXG4gICAgICAgIDxtZXRhIG5hbWU9XCJ0d2l0dGVyOnNpdGVcIiBjb250ZW50PVwiQG9mZmVyc2NvZGVpblwiIC8+XHJcbiAgICAgICAgPG1ldGEgbmFtZT1cInR3aXR0ZXI6Y3JlYXRvclwiIGNvbnRlbnQ9XCJAb2ZmZXJzY29kZWluXCIgLz5cclxuXHJcbiAgICAgICAgey8qIDwhLS0gU3RhbmRhcmQgTWV0YSB0YWdzIC0tPiAqL31cclxuICAgICAgICA8bWV0YSBpdGVtUHJvcD1cIm5hbWVcIiBjb250ZW50PVwib2ZmZXJzY29kZS5pblwiIC8+XHJcbiAgICAgICAgPG1ldGFcclxuICAgICAgICAgIGl0ZW1Qcm9wPVwiZGVzY3JpcHRpb25cIlxyXG4gICAgICAgICAgY29udGVudD1cIk5vdyBTQVZFIE1PUkUgd2l0aCBPZmZlcnNDb2RlISBHZXQgdGhlIGxhdGVzdCBhbmQgdXAtdG8tZGF0ZSBjb3Vwb25zLCBjYXNoYmFjayBvZmZlcnMgb24gc29tZSBvZiBJbmRpYeKAmXMgdG9wIG9ubGluZSBzaG9wcGluZyBzaXRlcyBsaWtlIEFtYXpvbiwgUGF5dG0sIFNuYXBkZWFsLCBGbGlwa2FydCwgTXludHJhIGFuZCBtYW55IG1vcmUgYXQgT2ZmZXJzQ29kZS5pbi5cIlxyXG4gICAgICAgIC8+XHJcbiAgICAgICAgPG1ldGEgaXRlbVByb3A9XCJpbWFnZVwiIGNvbnRlbnQ9XCJsb2dvLmpwZ1wiIC8+XHJcblxyXG4gICAgICAgIHsvKiA8c2NyaXB0PlxyXG4gICAgICAgIHdpbmRvdy5hb19zdWJpZCA9IFwibW9uZXlsaW5rXCI7XHJcbiAgICAgICAgPC9zY3JpcHQ+ICovfVxyXG4gICAgICAgIDxzY3JpcHRcclxuICAgICAgICAgIHNyYz1cIi8vanMubWFteWRpcmVjdC5jb20vanMvP2g9ajUyOGQwT0hcIlxyXG4gICAgICAgICAgdHlwZT1cInRleHQvamF2YXNjcmlwdFwiXHJcbiAgICAgICAgICBhc3luY1xyXG4gICAgICAgID48L3NjcmlwdD5cclxuICAgICAgICA8c2NyaXB0XHJcbiAgICAgICAgICBhc3luY1xyXG4gICAgICAgICAgc3JjPVwiaHR0cHM6Ly93d3cuZ29vZ2xldGFnbWFuYWdlci5jb20vZ3RhZy9qcz9pZD1HLVJWTjFWN05TVzRcIlxyXG4gICAgICAgID48L3NjcmlwdD5cclxuICAgICAgICA8c2NyaXB0XHJcbiAgICAgICAgICBkYXRhLWFkLWNsaWVudD1cImNhLXB1Yi0xNDgxOTQ4NzAwMjU3ODMwXCJcclxuICAgICAgICAgIGFzeW5jXHJcbiAgICAgICAgICBzcmM9XCJodHRwczovL3BhZ2VhZDIuZ29vZ2xlc3luZGljYXRpb24uY29tL3BhZ2VhZC9qcy9hZHNieWdvb2dsZS5qc1wiXHJcbiAgICAgICAgPjwvc2NyaXB0PlxyXG4gICAgICAgIHsvKiA8c2NyaXB0IHNyYz1cImh0dHBzOi8vY2RuLm9uZXNpZ25hbC5jb20vc2Rrcy9PbmVTaWduYWxTREsuanNcIiBhc3luYz1cIlwiPjwvc2NyaXB0PiAqL31cclxuICAgICAgPC9IZWFkPlxyXG4gICAgICA8TmF2YmFyIC8+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFpbmVyXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvZWR4X183Mjh4OTBcIj5cclxuICAgICAgICAgIDxhbXAtYWRcclxuICAgICAgICAgICAgd2lkdGg9XCIxMDB2d1wiXHJcbiAgICAgICAgICAgIGhlaWdodD1cIjMyMFwiXHJcbiAgICAgICAgICAgIHR5cGU9XCJhZHNlbnNlXCJcclxuICAgICAgICAgICAgZGF0YS1hZC1jbGllbnQ9XCJjYS1wdWItMTQ4MTk0ODcwMDI1NzgzMFwiXHJcbiAgICAgICAgICAgIGRhdGEtYWQtc2xvdD1cIjkxMjQ1MjMyMzJcIlxyXG4gICAgICAgICAgICBkYXRhLWF1dG8tZm9ybWF0PVwicnNwdlwiXHJcbiAgICAgICAgICAgIGRhdGEtZnVsbC13aWR0aD1cIlwiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxkaXYgb3ZlcmZsb3c9XCJcIj48L2Rpdj5cclxuICAgICAgICAgIDwvYW1wLWFkPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb250YWluZXIgbWFpbi1jb250YWluZXJcIj5cclxuICAgICAgICA8Q29tcG9uZW50IHsuLi5wYWdlUHJvcHN9IC8+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbnRhaW5lclwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwib2VkeF9fNzI4eDkwXCI+XHJcbiAgICAgICAgICA8YW1wLWFkXHJcbiAgICAgICAgICAgIHdpZHRoPVwiMTAwdndcIlxyXG4gICAgICAgICAgICBoZWlnaHQ9XCIzMjBcIlxyXG4gICAgICAgICAgICB0eXBlPVwiYWRzZW5zZVwiXHJcbiAgICAgICAgICAgIGRhdGEtYWQtY2xpZW50PVwiY2EtcHViLTE0ODE5NDg3MDAyNTc4MzBcIlxyXG4gICAgICAgICAgICBkYXRhLWFkLXNsb3Q9XCIzODE5MjEzOTA1XCJcclxuICAgICAgICAgICAgZGF0YS1hdXRvLWZvcm1hdD1cInJzcHZcIlxyXG4gICAgICAgICAgICBkYXRhLWZ1bGwtd2lkdGg9XCJcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8ZGl2IG92ZXJmbG93PVwiXCI+PC9kaXY+XHJcbiAgICAgICAgICA8L2FtcC1hZD5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIDxGb290ZXIgLz5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IE15QXBwO1xyXG4iXSwic291cmNlUm9vdCI6IiJ9