webpackHotUpdate_N_E("pages/index",{

/***/ "./pages/components/Store/topStores.js":
/*!*********************************************!*\
  !*** ./pages/components/Store/topStores.js ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var C_xampp_htdocs_ReactTuts_NextJS_ofccode_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var C_xampp_htdocs_ReactTuts_NextJS_ofccode_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(C_xampp_htdocs_ReactTuts_NextJS_ofccode_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var C_xampp_htdocs_ReactTuts_NextJS_ofccode_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);




var _jsxFileName = "C:\\xampp\\htdocs\\ReactTuts\\NextJS\\ofccode\\pages\\components\\Store\\topStores.js",
    _this = undefined;



var TopStores = function TopStores(_ref) {
  var storeInfo = _ref.storeInfo;
  var Stores = [];
  Stores = storeInfo;

  if (Stores) {
    var LiElements = Stores.map(function (store, index) {
      return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("li", {
        className: "storeCard-Col",
        children: [console.log(LogoCall), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("div", {
          className: "storeCard storeCard-small",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_3___default.a, {
            href: "/".concat(store.slug + "-" + store.slugType),
            as: "".concat(store.slug + "-" + store.slugType),
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("a", {
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("img", {
                src: "/stores__logo/".concat(store.slug, "-logo-large.jpg"),
                onError: function onError(e) {
                  e.target.onerror = null;
                  e.target.src = "/img-notfound.jpg";
                }
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 15,
                columnNumber: 13
              }, _this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 14,
              columnNumber: 11
            }, _this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 13,
            columnNumber: 9
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("h5", {
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_3___default.a, {
              href: "/".concat(store.slug + "-" + store.slugType),
              as: "".concat(store.slug + "-" + store.slugType),
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("a", {
                className: "nav-link",
                children: store.formatted_name
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 26,
                columnNumber: 15
              }, _this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 25,
              columnNumber: 11
            }, _this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 24,
            columnNumber: 11
          }, _this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 12,
          columnNumber: 7
        }, _this)]
      }, index, true, {
        fileName: _jsxFileName,
        lineNumber: 10,
        columnNumber: 5
      }, _this);
    });
    return LiElements;
  } else {
    return '';
  }
};

_c = TopStores;

var LogoCall = /*#__PURE__*/function () {
  var _ref2 = Object(C_xampp_htdocs_ReactTuts_NextJS_ofccode_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__["default"])( /*#__PURE__*/C_xampp_htdocs_ReactTuts_NextJS_ofccode_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee(slug) {
    var storeSlug, response, getStoreIdRes, storeId, dataUrl, res, data;
    return C_xampp_htdocs_ReactTuts_NextJS_ofccode_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            storeSlug = slug;
            _context.next = 3;
            return fetch("https://ofccode-api-sportybruh1990.vercel.app/api/front/".concat(storeSlug));

          case 3:
            response = _context.sent;
            _context.next = 6;
            return response.json();

          case 6:
            getStoreIdRes = _context.sent;
            storeId = getStoreIdRes.affInfo__StoreId;
            dataUrl = "https://export.admitad.com/en/webmaster/websites/1777052/coupons/export/?website=1777052&advcampaigns=" + storeId + "&region=00&code=eyq48w62bj&user=vishwajit82&format=csv&v=4";
            _context.next = 11;
            return axios.get(dataUrl);

          case 11:
            res = _context.sent;
            data = Papa.parse(res.data[1]);
            return _context.abrupt("return", {
              props: {
                storeInfo: getStoreIdRes
              }
            });

          case 14:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));

  return function LogoCall(_x) {
    return _ref2.apply(this, arguments);
  };
}();

_c2 = LogoCall;
/* harmony default export */ __webpack_exports__["default"] = (TopStores);

var _c, _c2;

$RefreshReg$(_c, "TopStores");
$RefreshReg$(_c2, "LogoCall");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvY29tcG9uZW50cy9TdG9yZS90b3BTdG9yZXMuanMiXSwibmFtZXMiOlsiVG9wU3RvcmVzIiwic3RvcmVJbmZvIiwiU3RvcmVzIiwiTGlFbGVtZW50cyIsIm1hcCIsInN0b3JlIiwiaW5kZXgiLCJjb25zb2xlIiwibG9nIiwiTG9nb0NhbGwiLCJzbHVnIiwic2x1Z1R5cGUiLCJlIiwidGFyZ2V0Iiwib25lcnJvciIsInNyYyIsImZvcm1hdHRlZF9uYW1lIiwic3RvcmVTbHVnIiwiZmV0Y2giLCJyZXNwb25zZSIsImpzb24iLCJnZXRTdG9yZUlkUmVzIiwic3RvcmVJZCIsImFmZkluZm9fX1N0b3JlSWQiLCJkYXRhVXJsIiwiYXhpb3MiLCJnZXQiLCJyZXMiLCJkYXRhIiwiUGFwYSIsInBhcnNlIiwicHJvcHMiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTs7QUFDQSxJQUFNQSxTQUFTLEdBQUcsU0FBWkEsU0FBWSxPQUFtQjtBQUFBLE1BQWhCQyxTQUFnQixRQUFoQkEsU0FBZ0I7QUFDbkMsTUFBSUMsTUFBTSxHQUFHLEVBQWI7QUFDQUEsUUFBTSxHQUFHRCxTQUFUOztBQUlBLE1BQUdDLE1BQUgsRUFBVTtBQUNWLFFBQU1DLFVBQVUsR0FBR0QsTUFBTSxDQUFDRSxHQUFQLENBQVcsVUFBQ0MsS0FBRCxFQUFRQyxLQUFSO0FBQUEsMEJBQzVCO0FBQUksaUJBQVMsRUFBQyxlQUFkO0FBQUEsbUJBQ0dDLE9BQU8sQ0FBQ0MsR0FBUixDQUFZQyxRQUFaLENBREgsZUFFRTtBQUFLLG1CQUFTLEVBQUMsMkJBQWY7QUFBQSxrQ0FDRSxxRUFBQyxnREFBRDtBQUFNLGdCQUFJLGFBQU1KLEtBQUssQ0FBQ0ssSUFBTixHQUFhLEdBQWIsR0FBbUJMLEtBQUssQ0FBQ00sUUFBL0IsQ0FBVjtBQUFxRCxjQUFFLFlBQUtOLEtBQUssQ0FBQ0ssSUFBTixHQUFhLEdBQWIsR0FBbUJMLEtBQUssQ0FBQ00sUUFBOUIsQ0FBdkQ7QUFBQSxtQ0FDRTtBQUFBLHFDQUNFO0FBQ0UsbUJBQUcsMEJBQW1CTixLQUFLLENBQUNLLElBQXpCLG9CQURMO0FBRUUsdUJBQU8sRUFBRSxpQkFBQ0UsQ0FBRCxFQUFPO0FBQ2RBLG1CQUFDLENBQUNDLE1BQUYsQ0FBU0MsT0FBVCxHQUFtQixJQUFuQjtBQUNBRixtQkFBQyxDQUFDQyxNQUFGLENBQVNFLEdBQVQsR0FBZSxtQkFBZjtBQUNEO0FBTEg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURGLGVBWUk7QUFBQSxtQ0FDQSxxRUFBQyxnREFBRDtBQUFNLGtCQUFJLGFBQU1WLEtBQUssQ0FBQ0ssSUFBTixHQUFhLEdBQWIsR0FBbUJMLEtBQUssQ0FBQ00sUUFBL0IsQ0FBVjtBQUFxRCxnQkFBRSxZQUFLTixLQUFLLENBQUNLLElBQU4sR0FBYSxHQUFiLEdBQW1CTCxLQUFLLENBQUNNLFFBQTlCLENBQXZEO0FBQUEscUNBQ0k7QUFBRyx5QkFBUyxFQUFDLFVBQWI7QUFBQSwwQkFBeUJOLEtBQUssQ0FBQ1c7QUFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFEQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVpKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFGRjtBQUFBLFNBQW1DVixLQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRDRCO0FBQUEsS0FBWCxDQUFuQjtBQXdCQSxXQUFPSCxVQUFQO0FBQ0MsR0ExQkQsTUEwQks7QUFDSCxXQUFPLEVBQVA7QUFDRDtBQUNGLENBbkNEOztLQUFNSCxTOztBQXNDTixJQUFNUyxRQUFRO0FBQUEsdVNBQUcsaUJBQU9DLElBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ1RPLHFCQURTLEdBQ0dQLElBREg7QUFBQTtBQUFBLG1CQUVRUSxLQUFLLG1FQUNpQ0QsU0FEakMsRUFGYjs7QUFBQTtBQUVURSxvQkFGUztBQUFBO0FBQUEsbUJBS2FBLFFBQVEsQ0FBQ0MsSUFBVCxFQUxiOztBQUFBO0FBS1RDLHlCQUxTO0FBTVRDLG1CQU5TLEdBTUNELGFBQWEsQ0FBQ0UsZ0JBTmY7QUFPVEMsbUJBUFMsR0FRYiwyR0FDQUYsT0FEQSxHQUVBLDREQVZhO0FBQUE7QUFBQSxtQkFXR0csS0FBSyxDQUFDQyxHQUFOLENBQVVGLE9BQVYsQ0FYSDs7QUFBQTtBQVdURyxlQVhTO0FBWVRDLGdCQVpTLEdBWUZDLElBQUksQ0FBQ0MsS0FBTCxDQUFXSCxHQUFHLENBQUNDLElBQUosQ0FBUyxDQUFULENBQVgsQ0FaRTtBQUFBLDZDQWFSO0FBQ0xHLG1CQUFLLEVBQUU7QUFDTDlCLHlCQUFTLEVBQUVvQjtBQUROO0FBREYsYUFiUTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxHQUFIOztBQUFBLGtCQUFSWixRQUFRO0FBQUE7QUFBQTtBQUFBLEdBQWQ7O01BQU1BLFE7QUFxQlNULHdFQUFmIiwiZmlsZSI6InN0YXRpYy93ZWJwYWNrL3BhZ2VzL2luZGV4LjE3MDNlZTkyNThiMzJhZGU2NTZjLmhvdC11cGRhdGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgTGluayBmcm9tIFwibmV4dC9saW5rXCI7XHJcbmNvbnN0IFRvcFN0b3JlcyA9ICh7IHN0b3JlSW5mbyB9KSA9PiB7XHJcbiAgbGV0IFN0b3JlcyA9IFtdOyAgXHJcbiAgU3RvcmVzID0gc3RvcmVJbmZvO1xyXG5cclxuICBcclxuXHJcbiAgaWYoU3RvcmVzKXtcclxuICBjb25zdCBMaUVsZW1lbnRzID0gU3RvcmVzLm1hcCgoc3RvcmUsIGluZGV4KSA9PiAoXHJcbiAgICA8bGkgY2xhc3NOYW1lPVwic3RvcmVDYXJkLUNvbFwiIGtleT17aW5kZXh9PlxyXG4gICAgICB7Y29uc29sZS5sb2coTG9nb0NhbGwpfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInN0b3JlQ2FyZCBzdG9yZUNhcmQtc21hbGxcIj5cclxuICAgICAgICA8TGluayBocmVmPXtgLyR7c3RvcmUuc2x1ZyArIFwiLVwiICsgc3RvcmUuc2x1Z1R5cGV9YH0gYXM9e2Ake3N0b3JlLnNsdWcgKyBcIi1cIiArIHN0b3JlLnNsdWdUeXBlfWB9PlxyXG4gICAgICAgICAgPGE+XHJcbiAgICAgICAgICAgIDxpbWdcclxuICAgICAgICAgICAgICBzcmM9e2Avc3RvcmVzX19sb2dvLyR7c3RvcmUuc2x1Z30tbG9nby1sYXJnZS5qcGdgfVxyXG4gICAgICAgICAgICAgIG9uRXJyb3I9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBlLnRhcmdldC5vbmVycm9yID0gbnVsbDtcclxuICAgICAgICAgICAgICAgIGUudGFyZ2V0LnNyYyA9IFwiL2ltZy1ub3Rmb3VuZC5qcGdcIjtcclxuICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC9hPlxyXG4gICAgICAgIDwvTGluaz5cclxuICAgICAgICAgIDxoNT5cclxuICAgICAgICAgIDxMaW5rIGhyZWY9e2AvJHtzdG9yZS5zbHVnICsgXCItXCIgKyBzdG9yZS5zbHVnVHlwZX1gfSBhcz17YCR7c3RvcmUuc2x1ZyArIFwiLVwiICsgc3RvcmUuc2x1Z1R5cGV9YH0+XHJcbiAgICAgICAgICAgICAgPGEgY2xhc3NOYW1lPVwibmF2LWxpbmtcIj57c3RvcmUuZm9ybWF0dGVkX25hbWV9PC9hPlxyXG4gICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgPC9oNT5cclxuICAgICAgICBcclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2xpPlxyXG4gICkpO1xyXG4gIHJldHVybiBMaUVsZW1lbnRzO1xyXG4gIH1lbHNle1xyXG4gICAgcmV0dXJuICcnO1xyXG4gIH1cclxufTtcclxuXHJcblxyXG5jb25zdCBMb2dvQ2FsbCA9IGFzeW5jIChzbHVnKSA9PiB7XHJcbiAgY29uc3Qgc3RvcmVTbHVnID0gc2x1ZztcclxuICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKFxyXG4gICAgYGh0dHBzOi8vb2ZjY29kZS1hcGktc3BvcnR5YnJ1aDE5OTAudmVyY2VsLmFwcC9hcGkvZnJvbnQvJHtzdG9yZVNsdWd9YFxyXG4gICk7XHJcbiAgY29uc3QgZ2V0U3RvcmVJZFJlcyA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcclxuICBjb25zdCBzdG9yZUlkID0gZ2V0U3RvcmVJZFJlcy5hZmZJbmZvX19TdG9yZUlkO1xyXG4gIGNvbnN0IGRhdGFVcmwgPVxyXG4gICAgXCJodHRwczovL2V4cG9ydC5hZG1pdGFkLmNvbS9lbi93ZWJtYXN0ZXIvd2Vic2l0ZXMvMTc3NzA1Mi9jb3Vwb25zL2V4cG9ydC8/d2Vic2l0ZT0xNzc3MDUyJmFkdmNhbXBhaWducz1cIiArXHJcbiAgICBzdG9yZUlkICtcclxuICAgIFwiJnJlZ2lvbj0wMCZjb2RlPWV5cTQ4dzYyYmomdXNlcj12aXNod2FqaXQ4MiZmb3JtYXQ9Y3N2JnY9NFwiO1xyXG4gIGNvbnN0IHJlcyA9IGF3YWl0IGF4aW9zLmdldChkYXRhVXJsKTtcclxuICBjb25zdCBkYXRhID0gUGFwYS5wYXJzZShyZXMuZGF0YVsxXSk7XHJcbiAgcmV0dXJuIHtcclxuICAgIHByb3BzOiB7XHJcbiAgICAgIHN0b3JlSW5mbzogZ2V0U3RvcmVJZFJlcyxcclxuICAgIH0sXHJcbiAgfTtcclxuXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IFRvcFN0b3JlcztcclxuIl0sInNvdXJjZVJvb3QiOiIifQ==