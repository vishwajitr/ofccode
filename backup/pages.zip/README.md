This is a starter template for [Learn Next.js](https://nextjs.org/learn).


//todo
http://localhost:3000/categories/food-nutrition - done
redesign page cat parent - http://localhost:3000/categories



flipakart
cate prod page link to be work
product/cat-prod1


#meta tags

