import React, { Component } from "react";
import axios from "axios";
const AboutPage = (props) => {
  return (
    <section>
      <h2>Contact Us</h2>
      <p>
      Kindly get in touch with us at <a href="mailto:contact@offerscode.in">contact@offerscode.in</a></p>
    </section>
  );
};



export default AboutPage;
