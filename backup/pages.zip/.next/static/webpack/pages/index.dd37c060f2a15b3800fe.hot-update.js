webpackHotUpdate_N_E("pages/index",{

/***/ "./pages/index.js":
/*!************************!*\
  !*** ./pages/index.js ***!
  \************************/
/*! exports provided: __N_SSP, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__N_SSP", function() { return __N_SSP; });
/* harmony import */ var C_xampp_htdocs_ReactTuts_NextJS_ofccode_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pages_search_index__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../pages/search/index */ "./pages/search/index.js");
/* harmony import */ var _components_Store_topStores__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./components/Store/topStores */ "./pages/components/Store/topStores.js");
/* harmony import */ var _components_OffersPageContent__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./components/OffersPageContent */ "./pages/components/OffersPageContent.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_6__);



var _jsxFileName = "C:\\xampp\\htdocs\\ReactTuts\\NextJS\\ofccode\\pages\\index.js",
    _this = undefined;

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { Object(C_xampp_htdocs_ReactTuts_NextJS_ofccode_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }







var TopOffers = function TopOffers(_ref) {
  var cuelinksOffers = _ref.cuelinksOffers;
  var topOffers = [];
  topOffers = cuelinksOffers;

  if (topOffers) {
    var LiElements = topOffers.map(function (offer, index) {
      return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("li", {
        className: "",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("div", {
          className: "",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("a", {
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("img", {
              src: "".concat(offer.Image_URL),
              onError: function onError(e) {
                e.target.onerror = null;
                e.target.src = "/img-notfound.jpg";
              },
              width: "200"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 18,
              columnNumber: 13
            }, _this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 17,
            columnNumber: 11
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("h5", {
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_6___default.a, {
              href: offer.URL,
              as: offer.URL,
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("a", {
                className: "nav-link",
                target: "_blank",
                rel: "nofollow",
                children: offer.Title
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 30,
                columnNumber: 13
              }, _this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 29,
              columnNumber: 9
            }, _this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 28,
            columnNumber: 11
          }, _this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 15,
          columnNumber: 7
        }, _this)
      }, index, false, {
        fileName: _jsxFileName,
        lineNumber: 14,
        columnNumber: 5
      }, _this);
    });
    return LiElements;
  } else {
    return '';
  }
};

_c = TopOffers;

var Index = function Index(props) {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("div", {
    className: "container",
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("div", {
      className: "search__wrapper",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(_pages_search_index__WEBPACK_IMPORTED_MODULE_3__["default"], {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 47,
        columnNumber: 9
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 46,
      columnNumber: 7
    }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("div", {
      className: "topStores__wrapper",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("h3", {
        children: "Top Stores"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 50,
        columnNumber: 9
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("ul", {
        className: "topStores__Ul",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(_components_Store_topStores__WEBPACK_IMPORTED_MODULE_4__["default"], {
          storeInfo: props.storeInfo
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 54,
          columnNumber: 39
        }, _this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 54,
        columnNumber: 9
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("br", {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 55,
        columnNumber: 9
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("hr", {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 56,
        columnNumber: 9
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("br", {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 57,
        columnNumber: 9
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("h3", {
        children: "Trending Offers"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 58,
        columnNumber: 9
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(_components_OffersPageContent__WEBPACK_IMPORTED_MODULE_5__["default"], _objectSpread(_objectSpread({}, props), {}, {
        limit: 10
      }), void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 59,
        columnNumber: 9
      }, _this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 49,
      columnNumber: 7
    }, _this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 45,
    columnNumber: 5
  }, _this);
};

_c2 = Index;
;
var __N_SSP = true;
/* harmony default export */ __webpack_exports__["default"] = (Index);

var _c, _c2;

$RefreshReg$(_c, "TopOffers");
$RefreshReg$(_c2, "Index");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvaW5kZXguanMiXSwibmFtZXMiOlsiVG9wT2ZmZXJzIiwiY3VlbGlua3NPZmZlcnMiLCJ0b3BPZmZlcnMiLCJMaUVsZW1lbnRzIiwibWFwIiwib2ZmZXIiLCJpbmRleCIsIkltYWdlX1VSTCIsImUiLCJ0YXJnZXQiLCJvbmVycm9yIiwic3JjIiwiVVJMIiwiVGl0bGUiLCJJbmRleCIsInByb3BzIiwic3RvcmVJbmZvIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7O0FBR0EsSUFBTUEsU0FBUyxHQUFHLFNBQVpBLFNBQVksT0FBd0I7QUFBQSxNQUFyQkMsY0FBcUIsUUFBckJBLGNBQXFCO0FBQ3hDLE1BQUlDLFNBQVMsR0FBRyxFQUFoQjtBQUNBQSxXQUFTLEdBQUdELGNBQVo7O0FBQ0EsTUFBR0MsU0FBSCxFQUFhO0FBQ2IsUUFBTUMsVUFBVSxHQUFHRCxTQUFTLENBQUNFLEdBQVYsQ0FBYyxVQUFDQyxLQUFELEVBQVFDLEtBQVI7QUFBQSwwQkFDL0I7QUFBSSxpQkFBUyxFQUFDLEVBQWQ7QUFBQSwrQkFDRTtBQUFLLG1CQUFTLEVBQUMsRUFBZjtBQUFBLGtDQUVJO0FBQUEsbUNBQ0U7QUFDRSxpQkFBRyxZQUFLRCxLQUFLLENBQUNFLFNBQVgsQ0FETDtBQUVFLHFCQUFPLEVBQUUsaUJBQUNDLENBQUQsRUFBTztBQUNkQSxpQkFBQyxDQUFDQyxNQUFGLENBQVNDLE9BQVQsR0FBbUIsSUFBbkI7QUFDQUYsaUJBQUMsQ0FBQ0MsTUFBRixDQUFTRSxHQUFULEdBQWUsbUJBQWY7QUFDRCxlQUxIO0FBTUUsbUJBQUssRUFBQztBQU5SO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUZKLGVBYUk7QUFBQSxtQ0FDRixxRUFBQyxnREFBRDtBQUFNLGtCQUFJLEVBQUVOLEtBQUssQ0FBQ08sR0FBbEI7QUFBdUIsZ0JBQUUsRUFBRVAsS0FBSyxDQUFDTyxHQUFqQztBQUFBLHFDQUNJO0FBQUcseUJBQVMsRUFBQyxVQUFiO0FBQXdCLHNCQUFNLEVBQUMsUUFBL0I7QUFBd0MsbUJBQUcsRUFBQyxVQUE1QztBQUFBLDBCQUF3RFAsS0FBSyxDQUFDUTtBQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBYko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREYsU0FBc0JQLEtBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFEK0I7QUFBQSxLQUFkLENBQW5CO0FBdUJBLFdBQU9ILFVBQVA7QUFDQyxHQXpCRCxNQXlCSztBQUNILFdBQU8sRUFBUDtBQUNEO0FBQ0YsQ0EvQkQ7O0tBQU1ILFM7O0FBa0NOLElBQU1jLEtBQUssR0FBRyxTQUFSQSxLQUFRLENBQUNDLEtBQUQsRUFBVztBQUN2QixzQkFDRTtBQUFLLGFBQVMsRUFBQyxXQUFmO0FBQUEsNEJBQ0U7QUFBSyxlQUFTLEVBQUMsaUJBQWY7QUFBQSw2QkFDRSxxRUFBQywyREFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQURGLGVBSUU7QUFBSyxlQUFTLEVBQUMsb0JBQWY7QUFBQSw4QkFDRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGLGVBS0U7QUFBSSxpQkFBUyxFQUFDLGVBQWQ7QUFBQSwrQkFBOEIscUVBQUMsbUVBQUQ7QUFBVyxtQkFBUyxFQUFFQSxLQUFLLENBQUNDO0FBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUxGLGVBTUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU5GLGVBT0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVBGLGVBUUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVJGLGVBU0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFURixlQVVFLHFFQUFDLHFFQUFELGtDQUF1QkQsS0FBdkI7QUFBOEIsYUFBSyxFQUFFO0FBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FERjtBQW1CRCxDQXBCRDs7TUFBTUQsSztBQW9ETDs7QUFFY0Esb0VBQWYiLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvaW5kZXguZGQzN2MwNjBmMmExNWIzODAwZmUuaG90LXVwZGF0ZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBheGlvcyBmcm9tIFwiYXhpb3NcIjtcclxuaW1wb3J0IFNlYXJjaCBmcm9tIFwiLi4vcGFnZXMvc2VhcmNoL2luZGV4XCI7XHJcbmltcG9ydCBUb3BTdG9yZXMgZnJvbSBcIi4vY29tcG9uZW50cy9TdG9yZS90b3BTdG9yZXNcIjtcclxuaW1wb3J0IE9mZmVyc1BhZ2VDb250ZW50IGZyb20gJy4vY29tcG9uZW50cy9PZmZlcnNQYWdlQ29udGVudCdcclxuaW1wb3J0IF8gZnJvbSAnbG9kYXNoJztcclxuaW1wb3J0IExpbmsgZnJvbSBcIm5leHQvbGlua1wiO1xyXG5cclxuXHJcbmNvbnN0IFRvcE9mZmVycyA9ICh7IGN1ZWxpbmtzT2ZmZXJzIH0pID0+IHtcclxuICBsZXQgdG9wT2ZmZXJzID0gW107ICBcclxuICB0b3BPZmZlcnMgPSBjdWVsaW5rc09mZmVycztcclxuICBpZih0b3BPZmZlcnMpe1xyXG4gIGNvbnN0IExpRWxlbWVudHMgPSB0b3BPZmZlcnMubWFwKChvZmZlciwgaW5kZXgpID0+IChcclxuICAgIDxsaSBjbGFzc05hbWU9XCJcIiBrZXk9e2luZGV4fT5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJcIj5cclxuICAgICAgey8qIDxMaW5rIGhyZWY9XCIke29mZmVyLlVSTH1cIiBhcz17YCR7b2ZmZXIuVVJMfWB9PiAqL31cclxuICAgICAgICAgIDxhPlxyXG4gICAgICAgICAgICA8aW1nXHJcbiAgICAgICAgICAgICAgc3JjPXtgJHtvZmZlci5JbWFnZV9VUkx9YH1cclxuICAgICAgICAgICAgICBvbkVycm9yPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgZS50YXJnZXQub25lcnJvciA9IG51bGw7XHJcbiAgICAgICAgICAgICAgICBlLnRhcmdldC5zcmMgPSBcIi9pbWctbm90Zm91bmQuanBnXCI7XHJcbiAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICB3aWR0aD1cIjIwMFwiXHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8L2E+XHJcbiAgICAgICAgey8qIDwvTGluaz4gKi99XHJcbiAgICAgICAgICA8aDU+XHJcbiAgICAgICAgPExpbmsgaHJlZj17b2ZmZXIuVVJMfSBhcz17b2ZmZXIuVVJMfT5cclxuICAgICAgICAgICAgPGEgY2xhc3NOYW1lPVwibmF2LWxpbmtcIiB0YXJnZXQ9XCJfYmxhbmtcIiByZWw9XCJub2ZvbGxvd1wiPntvZmZlci5UaXRsZX08L2E+XHJcbiAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgPC9oNT5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2xpPlxyXG4gICkpO1xyXG4gIHJldHVybiBMaUVsZW1lbnRzO1xyXG4gIH1lbHNle1xyXG4gICAgcmV0dXJuICcnO1xyXG4gIH1cclxufTtcclxuXHJcblxyXG5jb25zdCBJbmRleCA9IChwcm9wcykgPT4ge1xyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbnRhaW5lclwiPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInNlYXJjaF9fd3JhcHBlclwiPlxyXG4gICAgICAgIDxTZWFyY2ggLz5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwidG9wU3RvcmVzX193cmFwcGVyXCI+XHJcbiAgICAgICAgPGgzPlxyXG4gICAgICAgICAgVG9wIFN0b3Jlc1xyXG4gICAgICAgIDwvaDM+XHJcblxyXG4gICAgICAgIDx1bCBjbGFzc05hbWU9XCJ0b3BTdG9yZXNfX1VsXCI+PFRvcFN0b3JlcyBzdG9yZUluZm89e3Byb3BzLnN0b3JlSW5mb30gLz48L3VsPlxyXG4gICAgICAgIDxici8+XHJcbiAgICAgICAgPGhyLz5cclxuICAgICAgICA8YnIvPlxyXG4gICAgICAgIDxoMz5UcmVuZGluZyBPZmZlcnM8L2gzPiAgXHJcbiAgICAgICAgPE9mZmVyc1BhZ2VDb250ZW50IHsuLi5wcm9wc30gbGltaXQ9ezEwfS8+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0U2VydmVyU2lkZVByb3BzKCkge1xyXG4gIGxldCByZXNwb25zZSA9IGF3YWl0IGZldGNoKFxyXG4gICAgYGh0dHBzOi8vb2ZjY29kZS1hcGktc3BvcnR5YnJ1aDE5OTAudmVyY2VsLmFwcC9hcGkvZnJvbnRgXHJcbiAgKTtcclxuICBsZXQgZ2V0U3RvcmVJZFJlcyA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTsgIFxyXG4gIGxldCBzZWxlY3RlZFN0b3Jlc0FyciAgPSBbMTU0ODEsIDE1NTQyLCAxNDcxOSwgMjM5NjEsIDIzODI1LCAxNTU5MSwxNDI5MSwyMTM2MSwyMjk5OCwyMzQzMywyMjAxMl07XHJcbiAgbGV0IEZpbmFsRGF0YSA9IFtdOyBcclxuICB2YXIgc2VsZWN0ZWRTdG9yZXMgPSBfLm1hcChzZWxlY3RlZFN0b3Jlc0FyciwgZnVuY3Rpb24oc3RvcmVJZCwgSW5kZXgpIHtcclxuICAgICBsZXQgZmlsdGVyZWREYXRhID0gZ2V0U3RvcmVJZFJlcy5maWx0ZXIoKHN0b3JlKSA9PiAoc3RvcmUuYWZmSW5mb19fU3RvcmVJZCA9PSBzdG9yZUlkKSk7XHJcbiAgICAgIEZpbmFsRGF0YVtJbmRleF0gPSBmaWx0ZXJlZERhdGFbMF07XHJcbiAgfSk7XHJcbiAgXHJcbiAgZ2V0U3RvcmVJZFJlcyA9IEZpbmFsRGF0YS5maWx0ZXIoKHN0b3JlKSA9PiAoc3RvcmUuc2l0ZV9fU3RvcmVFbmFibGVkID09IDEpKTtcclxuXHJcblxyXG5cclxuICBsZXQgY2xpbmtzUmVzID0gYXdhaXQgZmV0Y2goXHJcbiAgICBgaHR0cHM6Ly9vZmNjb2RlLWFwaS1zcG9ydHlicnVoMTk5MC52ZXJjZWwuYXBwL2FwaS9mcm9udC9jdWVsaW5rcy9vZmZlcnNgXHJcbiAgKTtcclxuICBsZXQgY3VlbGlua3NPZmZlcnMgPSBhd2FpdCBjbGlua3NSZXMuanNvbigpOyAgXHJcbiAgXHJcblxyXG5cclxuICByZXR1cm4ge1xyXG4gICAgcHJvcHM6IHtcclxuICAgICAgc3RvcmVJbmZvOiBnZXRTdG9yZUlkUmVzLFxyXG4gICAgICBjdWVsaW5rc09mZmVycyA6IGN1ZWxpbmtzT2ZmZXJzXHJcbiAgICB9LFxyXG4gIH07XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBJbmRleDtcclxuIl0sInNvdXJjZVJvb3QiOiIifQ==