webpackHotUpdate_N_E("pages/store/[slug]",{

/***/ "./pages/store/[slug]/index.js":
/*!*************************************!*\
  !*** ./pages/store/[slug]/index.js ***!
  \*************************************/
/*! exports provided: __N_SSP, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__N_SSP", function() { return __N_SSP; });
/* harmony import */ var C_xampp_htdocs_ReactTuts_NextJS_ofccode_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/router */ "./node_modules/next/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! next */ "next");
/* harmony import */ var next__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! lodash */ "./node_modules/lodash/lodash.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _components_Content__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../components/Content */ "./pages/components/Content.js");
/* harmony import */ var _components_OffersPageContent__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../components/OffersPageContent */ "./pages/components/OffersPageContent.js");



var _jsxFileName = "C:\\xampp\\htdocs\\ReactTuts\\NextJS\\ofccode\\pages\\store\\[slug]\\index.js",
    _this = undefined;

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { Object(C_xampp_htdocs_ReactTuts_NextJS_ofccode_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }










var getParsedDate = function getParsedDate() {
  var d = new Date();
  var month = new Array();
  month[0] = "January";
  month[1] = "February";
  month[2] = "March";
  month[3] = "April";
  month[4] = "May";
  month[5] = "June";
  month[6] = "July";
  month[7] = "August";
  month[8] = "September";
  month[9] = "October";
  month[10] = "November";
  month[11] = "December";
  return month[d.getMonth()];
};

var StorePage = function StorePage(props) {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("div", {
    children: props.cuelinksOffers.length > 0 ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("div", {
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("hr", {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 51,
        columnNumber: 10
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(_components_OffersPageContent__WEBPACK_IMPORTED_MODULE_8__["default"], _objectSpread(_objectSpread({}, props), {}, {
        headerTag1: "Trending Offers from Top Stores ",
        description: 'We are please to provide some trending offers from other stores if you have habbit of saving while doing online shopping this is best place for you'
      }), void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 52,
        columnNumber: 10
      }, _this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 50,
      columnNumber: 8
    }, _this) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("div", {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 60,
      columnNumber: 10
    }, _this)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 32,
    columnNumber: 5
  }, _this);
};

_c = StorePage;
var __N_SSP = true;
/* harmony default export */ __webpack_exports__["default"] = (StorePage);

var _c;

$RefreshReg$(_c, "StorePage");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvc3RvcmUvW3NsdWddL2luZGV4LmpzIl0sIm5hbWVzIjpbImdldFBhcnNlZERhdGUiLCJkIiwiRGF0ZSIsIm1vbnRoIiwiQXJyYXkiLCJnZXRNb250aCIsIlN0b3JlUGFnZSIsInByb3BzIiwiY3VlbGlua3NPZmZlcnMiLCJsZW5ndGgiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBOztBQUdBLElBQU1BLGFBQWEsR0FBRyxTQUFoQkEsYUFBZ0IsR0FBTTtBQUMxQixNQUFJQyxDQUFDLEdBQUcsSUFBSUMsSUFBSixFQUFSO0FBQ0EsTUFBSUMsS0FBSyxHQUFHLElBQUlDLEtBQUosRUFBWjtBQUNBRCxPQUFLLENBQUMsQ0FBRCxDQUFMLEdBQVcsU0FBWDtBQUNBQSxPQUFLLENBQUMsQ0FBRCxDQUFMLEdBQVcsVUFBWDtBQUNBQSxPQUFLLENBQUMsQ0FBRCxDQUFMLEdBQVcsT0FBWDtBQUNBQSxPQUFLLENBQUMsQ0FBRCxDQUFMLEdBQVcsT0FBWDtBQUNBQSxPQUFLLENBQUMsQ0FBRCxDQUFMLEdBQVcsS0FBWDtBQUNBQSxPQUFLLENBQUMsQ0FBRCxDQUFMLEdBQVcsTUFBWDtBQUNBQSxPQUFLLENBQUMsQ0FBRCxDQUFMLEdBQVcsTUFBWDtBQUNBQSxPQUFLLENBQUMsQ0FBRCxDQUFMLEdBQVcsUUFBWDtBQUNBQSxPQUFLLENBQUMsQ0FBRCxDQUFMLEdBQVcsV0FBWDtBQUNBQSxPQUFLLENBQUMsQ0FBRCxDQUFMLEdBQVcsU0FBWDtBQUNBQSxPQUFLLENBQUMsRUFBRCxDQUFMLEdBQVksVUFBWjtBQUNBQSxPQUFLLENBQUMsRUFBRCxDQUFMLEdBQVksVUFBWjtBQUNBLFNBQU9BLEtBQUssQ0FBQ0YsQ0FBQyxDQUFDSSxRQUFGLEVBQUQsQ0FBWjtBQUNELENBaEJEOztBQWtCQSxJQUFNQyxTQUFTLEdBQUcsU0FBWkEsU0FBWSxDQUFDQyxLQUFELEVBQVc7QUFDM0Isc0JBQ0U7QUFBQSxjQWlCS0EsS0FBSyxDQUFDQyxjQUFOLENBQXFCQyxNQUFyQixHQUE4QixDQUEvQixnQkFDRDtBQUFBLDhCQUNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERixlQUVFLHFFQUFDLHFFQUFELGtDQUNLRixLQURMO0FBRUMsa0JBQVUsRUFDUixrQ0FISDtBQUtDLG1CQUFXLEVBQUU7QUFMZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBREMsZ0JBV0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQTVCTDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBREY7QUFpQ0QsQ0FsQ0Q7O0tBQU1ELFM7O0FBd0VTQSx3RUFBZiIsImZpbGUiOiJzdGF0aWMvd2VicGFjay9wYWdlcy9zdG9yZS9bc2x1Z10uN2E5MzQ2ZTM4NDMyZDlkZDcxMzAuaG90LXVwZGF0ZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyBDb21wb25lbnQgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSBcIm5leHQvcm91dGVyXCI7XHJcbmltcG9ydCBHZXRTZXJ2ZXJTaWRlUHJvcHMgZnJvbSBcIm5leHRcIjtcclxuaW1wb3J0IE5leHRQYWdlIGZyb20gXCJuZXh0XCI7XHJcbmltcG9ydCBMaW5rIGZyb20gXCJuZXh0L2xpbmtcIjtcclxuaW1wb3J0IGF4aW9zIGZyb20gXCJheGlvc1wiO1xyXG5pbXBvcnQgXyBmcm9tIFwibG9kYXNoXCI7XHJcbmltcG9ydCBDb250ZW50IGZyb20gXCIuLi8uLi9jb21wb25lbnRzL0NvbnRlbnRcIjtcclxuaW1wb3J0IE9mZmVyc1BhZ2VDb250ZW50IGZyb20gJy4uLy4uL2NvbXBvbmVudHMvT2ZmZXJzUGFnZUNvbnRlbnQnXHJcbnZhciBQYXBhID0gcmVxdWlyZShcInBhcGFwYXJzZVwiKTtcclxuXHJcbmNvbnN0IGdldFBhcnNlZERhdGUgPSAoKSA9PiB7XHJcbiAgdmFyIGQgPSBuZXcgRGF0ZSgpO1xyXG4gIHZhciBtb250aCA9IG5ldyBBcnJheSgpO1xyXG4gIG1vbnRoWzBdID0gXCJKYW51YXJ5XCI7XHJcbiAgbW9udGhbMV0gPSBcIkZlYnJ1YXJ5XCI7XHJcbiAgbW9udGhbMl0gPSBcIk1hcmNoXCI7XHJcbiAgbW9udGhbM10gPSBcIkFwcmlsXCI7XHJcbiAgbW9udGhbNF0gPSBcIk1heVwiO1xyXG4gIG1vbnRoWzVdID0gXCJKdW5lXCI7XHJcbiAgbW9udGhbNl0gPSBcIkp1bHlcIjtcclxuICBtb250aFs3XSA9IFwiQXVndXN0XCI7XHJcbiAgbW9udGhbOF0gPSBcIlNlcHRlbWJlclwiO1xyXG4gIG1vbnRoWzldID0gXCJPY3RvYmVyXCI7XHJcbiAgbW9udGhbMTBdID0gXCJOb3ZlbWJlclwiO1xyXG4gIG1vbnRoWzExXSA9IFwiRGVjZW1iZXJcIjtcclxuICByZXR1cm4gbW9udGhbZC5nZXRNb250aCgpXTtcclxufTtcclxuXHJcbmNvbnN0IFN0b3JlUGFnZSA9IChwcm9wcykgPT4geyAgXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXY+XHJcbiAgICAgIHsvKiA8Q29udGVudFxyXG4gICAgICAgIHsuLi5wcm9wc31cclxuICAgICAgICBoZWFkZXJUYWcxPXtcclxuICAgICAgICAgIHByb3BzLnN0b3JlSW5mby5mb3JtYXR0ZWRfbmFtZSArXHJcbiAgICAgICAgICBcIiBDb3Vwb25zIEFuZCBEaXNjb3VudCBDb2RlcyBGb3IgXCIgK1xyXG4gICAgICAgICAgZ2V0UGFyc2VkRGF0ZSgpICtcclxuICAgICAgICAgIFwiIDIwMjFcIlxyXG4gICAgICAgIH1cclxuICAgICAgICBoZWFkZXJUYWcyPXtcclxuICAgICAgICAgIFwiTGF0ZXN0IFwiICtcclxuICAgICAgICAgIHByb3BzLnN0b3JlSW5mby5mb3JtYXR0ZWRfbmFtZSArXHJcbiAgICAgICAgICBcIiBDb3Vwb24gQ29kZXMsIERpc2NvdW50IE9mZmVycyAmIFByb21vdGlvbmFsIERlYWxzXCJcclxuICAgICAgICB9XHJcbiAgICAgICAgZGVzY3JpcHRpb249e3Byb3BzLnN0b3JlSW5mby5tZXRhSW5mb19fZGVzY31cclxuICAgICAgLz4gKi99XHJcbiAgICAgICAgXHJcbiAgICAgICB7KHByb3BzLmN1ZWxpbmtzT2ZmZXJzLmxlbmd0aCA+IDAgKSA/IFxyXG4gICAgICAgPGRpdj5cclxuICAgICAgICAgPGhyLz5cclxuICAgICAgICAgPE9mZmVyc1BhZ2VDb250ZW50XHJcbiAgICAgICAgICB7Li4ucHJvcHN9XHJcbiAgICAgICAgICBoZWFkZXJUYWcxPXtcclxuICAgICAgICAgICAgXCJUcmVuZGluZyBPZmZlcnMgZnJvbSBUb3AgU3RvcmVzIFwiXHJcbiAgICAgICAgICB9ICAgICAgIFxyXG4gICAgICAgICAgZGVzY3JpcHRpb249eydXZSBhcmUgcGxlYXNlIHRvIHByb3ZpZGUgc29tZSB0cmVuZGluZyBvZmZlcnMgZnJvbSBvdGhlciBzdG9yZXMgaWYgeW91IGhhdmUgaGFiYml0IG9mIHNhdmluZyB3aGlsZSBkb2luZyBvbmxpbmUgc2hvcHBpbmcgdGhpcyBpcyBiZXN0IHBsYWNlIGZvciB5b3UnfVxyXG4gICAgICAgIC8+XHJcbiAgICAgICA8L2Rpdj5cclxuICAgICAgIDogPGRpdj48L2Rpdj59IFxyXG4gICAgICAgXHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFNlcnZlclNpZGVQcm9wcyh7IHBhcmFtcyB9KSB7XHJcbiAgY29uc3Qgc3RvcmVTbHVnID0gcGFyYW1zLnNsdWc7XHJcbiAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChcclxuICAgIGBodHRwczovL29mY2NvZGUtYXBpLWdpdC1tYWluLXNwb3J0eWJydWgxOTkwLnZlcmNlbC5hcHAvYXBpL2Zyb250L3NlYXJjaC9zdG9yZV9fYnlfX3NsdWc/cT0ke3N0b3JlU2x1Z31gXHJcbiAgKTtcclxuICBjb25zdCBnZXRTdG9yZUlkUmVzID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xyXG4gIC8vIGNvbnNvbGUubG9nKGdldFN0b3JlSWRSZXMpXHJcbiAgY29uc3Qgc3RvcmVJZCA9IGdldFN0b3JlSWRSZXMuYWZmSW5mb19fU3RvcmVJZDtcclxuICBjb25zdCBkYXRhVXJsID1cclxuICAgIFwiaHR0cHM6Ly9leHBvcnQuYWRtaXRhZC5jb20vZW4vd2VibWFzdGVyL3dlYnNpdGVzLzE3NzcwNTIvY291cG9ucy9leHBvcnQvP3dlYnNpdGU9MTc3NzA1MiZhZHZjYW1wYWlnbnM9XCIgK1xyXG4gICAgc3RvcmVJZCArXHJcbiAgICBcIiZyZWdpb249MDAmY29kZT1leXE0OHc2MmJqJnVzZXI9dmlzaHdhaml0ODImZm9ybWF0PWNzdiZ2PTRcIjtcclxuICBjb25zdCByZXMgPSBhd2FpdCBheGlvcy5nZXQoZGF0YVVybCk7XHJcbiAgY29uc3QgZGF0YSA9IFBhcGEucGFyc2UocmVzLmRhdGEpO1xyXG5cclxuXHJcbiAgLy8gbGV0IGNsaW5rc1JlcyA9IGF3YWl0IGZldGNoKFxyXG4gIC8vICAgYGh0dHBzOi8vb2ZjY29kZS1hcGktZ2l0LW1haW4tc3BvcnR5YnJ1aDE5OTAudmVyY2VsLmFwcC9hcGkvZnJvbnQvY3VlbHMvb2ZmZXJzYFxyXG4gIC8vICk7XHJcbiAgLy8gbGV0IGN1ZWxpbmtzT2ZmZXJzID0gYXdhaXQgY2xpbmtzUmVzLmpzb24oKTsgIFxyXG5cclxuICBsZXQgY2xpbmtzUmVzID0gYXdhaXQgZmV0Y2goXHJcbiAgICBgaHR0cDovL2xvY2FsaG9zdDozMDAyL2FwaS9mcm9udC9zZWFyY2gvb2ZmZXJzX19ieV9fcXVlcnk/cT0ke3N0b3JlU2x1Z31gXHJcbiAgKTtcclxuICBsZXQgY3VlbGlua3NPZmZlcnMgPSBhd2FpdCBjbGlua3NSZXMuanNvbigpOyAgXHJcbiAgICBcclxuXHJcbiAgcmV0dXJuIHtcclxuICAgIHByb3BzOiB7XHJcbiAgICAgIHN0b3JlSW5mbzogZ2V0U3RvcmVJZFJlcyxcclxuICAgICAgY291cG9uc0RhdGExOiBkYXRhLFxyXG4gICAgICBjdWVsaW5rc09mZmVyczogY3VlbGlua3NPZmZlcnMucmVzdWx0cyxcclxuICAgIH0sXHJcbiAgfTtcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgU3RvcmVQYWdlO1xyXG4iXSwic291cmNlUm9vdCI6IiJ9