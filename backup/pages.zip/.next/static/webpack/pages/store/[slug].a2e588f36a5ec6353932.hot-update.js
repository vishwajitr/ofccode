webpackHotUpdate_N_E("pages/store/[slug]",{

/***/ "./pages/components/Cards/Card.js":
/*!****************************************!*\
  !*** ./pages/components/Cards/Card.js ***!
  \****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/head */ "./node_modules/next/head.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/router */ "./node_modules/next/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! lodash */ "./node_modules/lodash/lodash.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_6__);


var _jsxFileName = "C:\\xampp\\htdocs\\ReactTuts\\NextJS\\ofccode\\pages\\components\\Cards\\Card.js",
    _this = undefined,
    _s = $RefreshSig$();








var getParsedDate = function getParsedDate(date) {
  return moment__WEBPACK_IMPORTED_MODULE_5___default()(date).startOf("hour").fromNow();
};

var Card = function Card(props) {
  _s();

  var router = Object(next_router__WEBPACK_IMPORTED_MODULE_3__["useRouter"])();
  var slug = router.query.slug; // Similar to componentDidMount and componentDidUpdate:

  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(function () {
    // <!-- other head elements from your page -->
    (function (g, o) {
      g[o] = g[o] || function () {
        (g[o]["q"] = g[o]["q"] || []).push(arguments);
      }, g[o]["t"] = 1 * new Date();
    })(window, "_googCsa");

    var pageOptions = {
      pubId: "pub-9616389000213823",
      // Make sure this the correct client ID!
      query: slug,
      adPage: 10,
      channel: "searchchnm"
    };
    var adblock1 = {
      container: "afscontainer1",
      linkTarget: "_blank",
      type: "ads",
      columns: 1,
      horizontalAlignment: "left",
      resultsPageQueryParam: "query",
      styleId: "6940738649",
      adLoadedCallback: null
    };
    var adblock2 = {
      container: "afscontainer2",
      linkTarget: "_blank",
      type: "ads",
      columns: 1,
      horizontalAlignment: "left",
      resultsPageQueryParam: "query",
      styleId: "6940738649",
      adLoadedCallback: null
    };

    _googCsa("ads", pageOptions, adblock1, adblock2);
  });
  var couponsData = props.couponsData1 ? props.couponsData1.data : {};
  var store__logo = props.storeInfo ? props.storeInfo.slug : {};
  var store__name = props.storeInfo ? props.storeInfo.formatted_name : {};

  if (couponsData.length > 2) {
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("section", {
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_head__WEBPACK_IMPORTED_MODULE_2___default.a, {
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("script", {
          async: "async",
          src: "https://www.google.com/adsense/search/ads.js"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 68,
          columnNumber: 11
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("script", {
          async: true,
          src: "https://cse.google.com/cse.js?cx=39bed8f3de88a4885"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 72,
          columnNumber: 11
        }, _this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 67,
        columnNumber: 9
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "clearfix",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            id: "afscontainer1"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 79,
            columnNumber: 13
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 80,
            columnNumber: 13
          }, _this), lodash__WEBPACK_IMPORTED_MODULE_4___default.a.map(couponsData, function (value, key) {
            // console.log(value);
            var discount = value[18];
            var promocodeCard = false;

            if (key > 0 && value[0] !== "") {
              if (value[8] == "promocode") {
                promocodeCard = true;
              }

              return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: key,
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                    className: "deal__card",
                    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                      className: "deal__discount",
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                        className: "deal__info",
                        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
                            src: "stores__logo/" + store__name + "-logo-small.jpg",
                            onError: function onError(e) {
                              e.target.onerror = null;
                              e.target.src = "/img-notfound.jpg";
                            },
                            alt: value[1]
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 97,
                            columnNumber: 31
                          }, _this), " "]
                        }, void 0, true, {
                          fileName: _jsxFileName,
                          lineNumber: 96,
                          columnNumber: 29
                        }, _this)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 95,
                        columnNumber: 27
                      }, _this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 94,
                      columnNumber: 25
                    }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                      className: "deal__desc",
                      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                        className: "deal__desc-type"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 113,
                        columnNumber: 27
                      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                        className: "deal__desc-title",
                        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                          href: value[11],
                          "data-url": value[10],
                          "data-promocode": value[9],
                          "data-species": value[8],
                          "data-promolink": value[10],
                          "data-func": "getPromoCode",
                          "data-website": value[2],
                          target: "_blank",
                          title: "OffersCode.in - Promo code for " + store__name + " deal " + value[1],
                          rel: "nofollow",
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h3", {
                            children: value[1]
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 132,
                            columnNumber: 31
                          }, _this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 115,
                          columnNumber: 29
                        }, _this)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 114,
                        columnNumber: 27
                      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                        className: "deal__desc-meta",
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                          className: "deal__desc-meta-lastused",
                          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
                            className: "fa fa-users"
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 137,
                            columnNumber: 31
                          }, _this), "\xA0", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("b", {
                            children: Math.floor(Math.random() * 200) + 11
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 138,
                            columnNumber: 31
                          }, _this), " ", "People Used Today"]
                        }, void 0, true, {
                          fileName: _jsxFileName,
                          lineNumber: 136,
                          columnNumber: 29
                        }, _this), "\xA0|\xA0", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                          children: value[15]
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 142,
                          columnNumber: 29
                        }, _this)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 135,
                        columnNumber: 27
                      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                        className: "deal__cta",
                        children: [promocodeCard ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                          href: value[11],
                          "data-url": value[10],
                          "data-promocode": value[9],
                          "data-species": value[8],
                          "data-promolink": value[10],
                          "data-func": "getPromoCode",
                          className: "getPromoCode",
                          "data-website": value[2],
                          target: "_blank",
                          title: "OffersCode.in - Promo code for " + store__name + " deal " + value[1],
                          rel: "nofollow",
                          children: value[9]
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 147,
                          columnNumber: 31
                        }, _this) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_6___default.a, {
                            href: value[11],
                            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                              // href={`/goto`}
                              "data-url": value[10],
                              "data-promocode": value[9],
                              "data-species": value[8],
                              "data-promolink": value[10],
                              "data-func": "getDeal",
                              className: "getDeal",
                              "data-website": value[2],
                              target: "_blank" // gotoLink = {value[11]}
                              ,
                              rel: "nofollow",
                              children: "Get Deal"
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 170,
                              columnNumber: 35
                            }, _this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 169,
                            columnNumber: 33
                          }, _this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 168,
                          columnNumber: 31
                        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                          className: "deal__cta-meta",
                          children: value[13] !== "None" ? "Expiring In " + getParsedDate(value[13]) : ""
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 188,
                          columnNumber: 29
                        }, _this)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 145,
                        columnNumber: 27
                      }, _this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 112,
                      columnNumber: 25
                    }, _this)]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 93,
                    columnNumber: 23
                  }, _this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 92,
                  columnNumber: 21
                }, _this)
              }, key, false, {
                fileName: _jsxFileName,
                lineNumber: 91,
                columnNumber: 19
              }, _this);
            }
          }), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            id: "afscontainer2"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 215,
            columnNumber: 13
          }, _this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 78,
          columnNumber: 11
        }, _this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 77,
        columnNumber: 9
      }, _this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 66,
      columnNumber: 7
    }, _this);
  } else {
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 224,
        columnNumber: 9
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 225,
        columnNumber: 9
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 226,
        columnNumber: 9
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h3", {
        children: "No New Deals Or Coupons Found"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 227,
        columnNumber: 9
      }, _this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 223,
      columnNumber: 7
    }, _this);
  }
};

_s(Card, "vQduR7x+OPXj6PSmJyFnf+hU7bg=", false, function () {
  return [next_router__WEBPACK_IMPORTED_MODULE_3__["useRouter"]];
});

_c = Card;
/* harmony default export */ __webpack_exports__["default"] = (Card);

var _c;

$RefreshReg$(_c, "Card");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvY29tcG9uZW50cy9DYXJkcy9DYXJkLmpzIl0sIm5hbWVzIjpbImdldFBhcnNlZERhdGUiLCJkYXRlIiwiTW9tZW50Iiwic3RhcnRPZiIsImZyb21Ob3ciLCJDYXJkIiwicHJvcHMiLCJyb3V0ZXIiLCJ1c2VSb3V0ZXIiLCJzbHVnIiwicXVlcnkiLCJ1c2VFZmZlY3QiLCJnIiwibyIsInB1c2giLCJhcmd1bWVudHMiLCJEYXRlIiwid2luZG93IiwicGFnZU9wdGlvbnMiLCJwdWJJZCIsImFkUGFnZSIsImNoYW5uZWwiLCJhZGJsb2NrMSIsImNvbnRhaW5lciIsImxpbmtUYXJnZXQiLCJ0eXBlIiwiY29sdW1ucyIsImhvcml6b250YWxBbGlnbm1lbnQiLCJyZXN1bHRzUGFnZVF1ZXJ5UGFyYW0iLCJzdHlsZUlkIiwiYWRMb2FkZWRDYWxsYmFjayIsImFkYmxvY2syIiwiX2dvb2dDc2EiLCJjb3Vwb25zRGF0YSIsImNvdXBvbnNEYXRhMSIsImRhdGEiLCJzdG9yZV9fbG9nbyIsInN0b3JlSW5mbyIsInN0b3JlX19uYW1lIiwiZm9ybWF0dGVkX25hbWUiLCJsZW5ndGgiLCJfIiwibWFwIiwidmFsdWUiLCJrZXkiLCJkaXNjb3VudCIsInByb21vY29kZUNhcmQiLCJlIiwidGFyZ2V0Iiwib25lcnJvciIsInNyYyIsIk1hdGgiLCJmbG9vciIsInJhbmRvbSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxJQUFNQSxhQUFhLEdBQUcsU0FBaEJBLGFBQWdCLENBQUNDLElBQUQsRUFBVTtBQUM5QixTQUFPQyw2Q0FBTSxDQUFDRCxJQUFELENBQU4sQ0FBYUUsT0FBYixDQUFxQixNQUFyQixFQUE2QkMsT0FBN0IsRUFBUDtBQUNELENBRkQ7O0FBSUEsSUFBTUMsSUFBSSxHQUFHLFNBQVBBLElBQU8sQ0FBQ0MsS0FBRCxFQUFXO0FBQUE7O0FBQ3RCLE1BQU1DLE1BQU0sR0FBR0MsNkRBQVMsRUFBeEI7QUFEc0IsTUFFZEMsSUFGYyxHQUVMRixNQUFNLENBQUNHLEtBRkYsQ0FFZEQsSUFGYyxFQUd0Qjs7QUFDQUUseURBQVMsQ0FBQyxZQUFNO0FBQ2Q7QUFFQSxLQUFDLFVBQVVDLENBQVYsRUFBYUMsQ0FBYixFQUFnQjtBQUNkRCxPQUFDLENBQUNDLENBQUQsQ0FBRCxHQUNDRCxDQUFDLENBQUNDLENBQUQsQ0FBRCxJQUNBLFlBQVk7QUFDVixTQUFDRCxDQUFDLENBQUNDLENBQUQsQ0FBRCxDQUFLLEdBQUwsSUFBWUQsQ0FBQyxDQUFDQyxDQUFELENBQUQsQ0FBSyxHQUFMLEtBQWEsRUFBMUIsRUFBOEJDLElBQTlCLENBQW1DQyxTQUFuQztBQUNELE9BSkgsRUFLR0gsQ0FBQyxDQUFDQyxDQUFELENBQUQsQ0FBSyxHQUFMLElBQVksSUFBSSxJQUFJRyxJQUFKLEVBTG5CO0FBTUQsS0FQRCxFQU9HQyxNQVBILEVBT1csVUFQWDs7QUFTQSxRQUFJQyxXQUFXLEdBQUc7QUFDaEJDLFdBQUssRUFBRSxzQkFEUztBQUNlO0FBQy9CVCxXQUFLLEVBQUVELElBRlM7QUFHaEJXLFlBQU0sRUFBRSxFQUhRO0FBSWhCQyxhQUFPLEVBQUU7QUFKTyxLQUFsQjtBQU9BLFFBQUlDLFFBQVEsR0FBRztBQUNiQyxlQUFTLEVBQUMsZUFERztBQUViQyxnQkFBVSxFQUFDLFFBRkU7QUFHYkMsVUFBSSxFQUFDLEtBSFE7QUFJYkMsYUFBTyxFQUFDLENBSks7QUFLYkMseUJBQW1CLEVBQUMsTUFMUDtBQU1iQywyQkFBcUIsRUFBQyxPQU5UO0FBT2JDLGFBQU8sRUFBQyxZQVBLO0FBUWJDLHNCQUFnQixFQUFDO0FBUkosS0FBZjtBQVdBLFFBQUlDLFFBQVEsR0FBRztBQUNiUixlQUFTLEVBQUMsZUFERztBQUViQyxnQkFBVSxFQUFDLFFBRkU7QUFHYkMsVUFBSSxFQUFDLEtBSFE7QUFJYkMsYUFBTyxFQUFDLENBSks7QUFLYkMseUJBQW1CLEVBQUMsTUFMUDtBQU1iQywyQkFBcUIsRUFBQyxPQU5UO0FBT2JDLGFBQU8sRUFBQyxZQVBLO0FBUWJDLHNCQUFnQixFQUFDO0FBUkosS0FBZjs7QUFXQUUsWUFBUSxDQUFDLEtBQUQsRUFBUWQsV0FBUixFQUFxQkksUUFBckIsRUFBK0JTLFFBQS9CLENBQVI7QUFDRCxHQTFDUSxDQUFUO0FBNENBLE1BQU1FLFdBQVcsR0FBRzNCLEtBQUssQ0FBQzRCLFlBQU4sR0FBcUI1QixLQUFLLENBQUM0QixZQUFOLENBQW1CQyxJQUF4QyxHQUErQyxFQUFuRTtBQUNBLE1BQU1DLFdBQVcsR0FBRzlCLEtBQUssQ0FBQytCLFNBQU4sR0FBa0IvQixLQUFLLENBQUMrQixTQUFOLENBQWdCNUIsSUFBbEMsR0FBeUMsRUFBN0Q7QUFDQSxNQUFNNkIsV0FBVyxHQUFHaEMsS0FBSyxDQUFDK0IsU0FBTixHQUFrQi9CLEtBQUssQ0FBQytCLFNBQU4sQ0FBZ0JFLGNBQWxDLEdBQW1ELEVBQXZFOztBQUVBLE1BQUlOLFdBQVcsQ0FBQ08sTUFBWixHQUFxQixDQUF6QixFQUE0QjtBQUMxQix3QkFDRTtBQUFBLDhCQUNFLHFFQUFDLGdEQUFEO0FBQUEsZ0NBQ0U7QUFDRSxlQUFLLEVBQUMsT0FEUjtBQUVFLGFBQUcsRUFBQztBQUZOO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREYsZUFLRTtBQUNFLGVBQUssTUFEUDtBQUVFLGFBQUcsRUFBQztBQUZOO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREYsZUFXRTtBQUFBLCtCQUNFO0FBQUssbUJBQVMsRUFBQyxVQUFmO0FBQUEsa0NBQ0U7QUFBSyxjQUFFLEVBQUM7QUFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURGLGVBRUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFGRixFQUdHQyw2Q0FBQyxDQUFDQyxHQUFGLENBQU1ULFdBQU4sRUFBbUIsVUFBQ1UsS0FBRCxFQUFRQyxHQUFSLEVBQWdCO0FBQ2xDO0FBQ0EsZ0JBQU1DLFFBQVEsR0FBR0YsS0FBSyxDQUFDLEVBQUQsQ0FBdEI7QUFDQSxnQkFBSUcsYUFBYSxHQUFHLEtBQXBCOztBQUVBLGdCQUFJRixHQUFHLEdBQUcsQ0FBTixJQUFXRCxLQUFLLENBQUMsQ0FBRCxDQUFMLEtBQWEsRUFBNUIsRUFBZ0M7QUFDOUIsa0JBQUlBLEtBQUssQ0FBQyxDQUFELENBQUwsSUFBWSxXQUFoQixFQUE2QjtBQUMzQkcsNkJBQWEsR0FBRyxJQUFoQjtBQUNEOztBQUNELGtDQUNFO0FBQWUseUJBQVMsRUFBRUYsR0FBMUI7QUFBQSx1Q0FDRTtBQUFLLDJCQUFTLEVBQUMsRUFBZjtBQUFBLHlDQUNFO0FBQUssNkJBQVMsRUFBQyxZQUFmO0FBQUEsNENBQ0U7QUFBSywrQkFBUyxFQUFDLGdCQUFmO0FBQUEsNkNBQ0U7QUFBSyxpQ0FBUyxFQUFDLFlBQWY7QUFBQSwrQ0FDRTtBQUFBLGtEQUNFO0FBQ0UsK0JBQUcsRUFDRCxrQkFDQU4sV0FEQSxvQkFGSjtBQU1FLG1DQUFPLEVBQUUsaUJBQUNTLENBQUQsRUFBTztBQUNkQSwrQkFBQyxDQUFDQyxNQUFGLENBQVNDLE9BQVQsR0FBbUIsSUFBbkI7QUFDQUYsK0JBQUMsQ0FBQ0MsTUFBRixDQUFTRSxHQUFULEdBQWUsbUJBQWY7QUFDRCw2QkFUSDtBQVVFLCtCQUFHLEVBQUVQLEtBQUssQ0FBQyxDQUFEO0FBVlo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FERixFQVlLLEdBWkw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBREYsZUFtQkU7QUFBSywrQkFBUyxFQUFDLFlBQWY7QUFBQSw4Q0FDRTtBQUFLLGlDQUFTLEVBQUM7QUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQURGLGVBRUU7QUFBSyxpQ0FBUyxFQUFDLGtCQUFmO0FBQUEsK0NBQ0U7QUFDRSw4QkFBSSxFQUFFQSxLQUFLLENBQUMsRUFBRCxDQURiO0FBRUUsc0NBQVVBLEtBQUssQ0FBQyxFQUFELENBRmpCO0FBR0UsNENBQWdCQSxLQUFLLENBQUMsQ0FBRCxDQUh2QjtBQUlFLDBDQUFjQSxLQUFLLENBQUMsQ0FBRCxDQUpyQjtBQUtFLDRDQUFnQkEsS0FBSyxDQUFDLEVBQUQsQ0FMdkI7QUFNRSx1Q0FBVSxjQU5aO0FBT0UsMENBQWNBLEtBQUssQ0FBQyxDQUFELENBUHJCO0FBUUUsZ0NBQU0sRUFBQyxRQVJUO0FBU0UsK0JBQUssRUFDSCxvQ0FDQUwsV0FEQSxjQUdBSyxLQUFLLENBQUMsQ0FBRCxDQWJUO0FBZUUsNkJBQUcsRUFBQyxVQWZOO0FBQUEsaURBaUJFO0FBQUEsc0NBQUtBLEtBQUssQ0FBQyxDQUFEO0FBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFGRixlQXVCRTtBQUFLLGlDQUFTLEVBQUMsaUJBQWY7QUFBQSxnREFDRTtBQUFNLG1DQUFTLEVBQUMsMEJBQWhCO0FBQUEsa0RBQ0U7QUFBRyxxQ0FBUyxFQUFDO0FBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FERix1QkFFRTtBQUFBLHNDQUFJUSxJQUFJLENBQUNDLEtBQUwsQ0FBV0QsSUFBSSxDQUFDRSxNQUFMLEtBQWdCLEdBQTNCLElBQWtDO0FBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBRkYsRUFFZ0QsR0FGaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQURGLDRCQU9FO0FBQUEsb0NBQU9WLEtBQUssQ0FBQyxFQUFEO0FBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBdkJGLGVBaUNFO0FBQUssaUNBQVMsRUFBQyxXQUFmO0FBQUEsbUNBQ0dHLGFBQWEsZ0JBQ1o7QUFDRSw4QkFBSSxFQUFFSCxLQUFLLENBQUMsRUFBRCxDQURiO0FBRUUsc0NBQVVBLEtBQUssQ0FBQyxFQUFELENBRmpCO0FBR0UsNENBQWdCQSxLQUFLLENBQUMsQ0FBRCxDQUh2QjtBQUlFLDBDQUFjQSxLQUFLLENBQUMsQ0FBRCxDQUpyQjtBQUtFLDRDQUFnQkEsS0FBSyxDQUFDLEVBQUQsQ0FMdkI7QUFNRSx1Q0FBVSxjQU5aO0FBT0UsbUNBQVMsRUFBQyxjQVBaO0FBUUUsMENBQWNBLEtBQUssQ0FBQyxDQUFELENBUnJCO0FBU0UsZ0NBQU0sRUFBQyxRQVRUO0FBVUUsK0JBQUssRUFDSCxvQ0FDQUwsV0FEQSxjQUdBSyxLQUFLLENBQUMsQ0FBRCxDQWRUO0FBZ0JFLDZCQUFHLEVBQUMsVUFoQk47QUFBQSxvQ0FrQkdBLEtBQUssQ0FBQyxDQUFEO0FBbEJSO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBRFksZ0JBc0JaO0FBQUEsaURBQ0UscUVBQUMsZ0RBQUQ7QUFBTSxnQ0FBSSxFQUFFQSxLQUFLLENBQUMsRUFBRCxDQUFqQjtBQUFBLG1EQUNFO0FBQ0U7QUFDQSwwQ0FBVUEsS0FBSyxDQUFDLEVBQUQsQ0FGakI7QUFHRSxnREFBZ0JBLEtBQUssQ0FBQyxDQUFELENBSHZCO0FBSUUsOENBQWNBLEtBQUssQ0FBQyxDQUFELENBSnJCO0FBS0UsZ0RBQWdCQSxLQUFLLENBQUMsRUFBRCxDQUx2QjtBQU1FLDJDQUFVLFNBTlo7QUFPRSx1Q0FBUyxFQUFDLFNBUFo7QUFRRSw4Q0FBY0EsS0FBSyxDQUFDLENBQUQsQ0FSckI7QUFTRSxvQ0FBTSxFQUFDLFFBVFQsQ0FVRTtBQVZGO0FBV0UsaUNBQUcsRUFBQyxVQVhOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBdkJKLGVBMkNFO0FBQU0sbUNBQVMsRUFBQyxnQkFBaEI7QUFBQSxvQ0FDR0EsS0FBSyxDQUFDLEVBQUQsQ0FBTCxLQUFjLE1BQWQsR0FDRyxpQkFBaUIzQyxhQUFhLENBQUMyQyxLQUFLLENBQUMsRUFBRCxDQUFOLENBRGpDLEdBRUc7QUFITjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQTNDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBakNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFuQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGLGlCQUFVQyxHQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBREY7QUEySEQ7QUFDRixXQXJJQSxDQUhILGVBeUlFO0FBQUssY0FBRSxFQUFDO0FBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF6SUY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQURGO0FBNEpELEdBN0pELE1BNkpPO0FBQ0wsd0JBQ0U7QUFBQSw4QkFDRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREYsZUFFRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRkYsZUFHRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBSEYsZUFJRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQURGO0FBUUQ7QUFDRixDQTNORDs7R0FBTXZDLEk7VUFDV0cscUQ7OztLQURYSCxJO0FBNk5TQSxtRUFBZiIsImZpbGUiOiJzdGF0aWMvd2VicGFjay9wYWdlcy9zdG9yZS9bc2x1Z10uYTJlNTg4ZjM2YTVlYzYzNTM5MzIuaG90LXVwZGF0ZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyBDb21wb25lbnQsIHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IEhlYWQgZnJvbSBcIm5leHQvaGVhZFwiO1xyXG5pbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tIFwibmV4dC9yb3V0ZXJcIjtcclxuaW1wb3J0IF8gZnJvbSBcImxvZGFzaFwiO1xyXG5pbXBvcnQgTW9tZW50IGZyb20gXCJtb21lbnRcIjtcclxuaW1wb3J0IExpbmsgZnJvbSBcIm5leHQvbGlua1wiO1xyXG5cclxuY29uc3QgZ2V0UGFyc2VkRGF0ZSA9IChkYXRlKSA9PiB7XHJcbiAgcmV0dXJuIE1vbWVudChkYXRlKS5zdGFydE9mKFwiaG91clwiKS5mcm9tTm93KCk7XHJcbn07XHJcblxyXG5jb25zdCBDYXJkID0gKHByb3BzKSA9PiB7XHJcbiAgY29uc3Qgcm91dGVyID0gdXNlUm91dGVyKCk7XHJcbiAgY29uc3QgeyBzbHVnIH0gPSByb3V0ZXIucXVlcnk7XHJcbiAgLy8gU2ltaWxhciB0byBjb21wb25lbnREaWRNb3VudCBhbmQgY29tcG9uZW50RGlkVXBkYXRlOlxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICAvLyA8IS0tIG90aGVyIGhlYWQgZWxlbWVudHMgZnJvbSB5b3VyIHBhZ2UgLS0+XHJcblxyXG4gICAgKGZ1bmN0aW9uIChnLCBvKSB7XHJcbiAgICAgIChnW29dID1cclxuICAgICAgICBnW29dIHx8XHJcbiAgICAgICAgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgKGdbb11bXCJxXCJdID0gZ1tvXVtcInFcIl0gfHwgW10pLnB1c2goYXJndW1lbnRzKTtcclxuICAgICAgICB9KSxcclxuICAgICAgICAoZ1tvXVtcInRcIl0gPSAxICogbmV3IERhdGUoKSk7XHJcbiAgICB9KSh3aW5kb3csIFwiX2dvb2dDc2FcIik7XHJcblxyXG4gICAgdmFyIHBhZ2VPcHRpb25zID0ge1xyXG4gICAgICBwdWJJZDogXCJwdWItOTYxNjM4OTAwMDIxMzgyM1wiLCAvLyBNYWtlIHN1cmUgdGhpcyB0aGUgY29ycmVjdCBjbGllbnQgSUQhXHJcbiAgICAgIHF1ZXJ5OiBzbHVnLFxyXG4gICAgICBhZFBhZ2U6IDEwLFxyXG4gICAgICBjaGFubmVsOiBcInNlYXJjaGNobm1cIixcclxuICAgIH07XHJcblxyXG4gICAgdmFyIGFkYmxvY2sxID0ge1xyXG4gICAgICBjb250YWluZXI6XCJhZnNjb250YWluZXIxXCIsXHJcbiAgICAgIGxpbmtUYXJnZXQ6XCJfYmxhbmtcIixcclxuICAgICAgdHlwZTpcImFkc1wiLFxyXG4gICAgICBjb2x1bW5zOjEsXHJcbiAgICAgIGhvcml6b250YWxBbGlnbm1lbnQ6XCJsZWZ0XCIsXHJcbiAgICAgIHJlc3VsdHNQYWdlUXVlcnlQYXJhbTpcInF1ZXJ5XCIsXHJcbiAgICAgIHN0eWxlSWQ6XCI2OTQwNzM4NjQ5XCIsXHJcbiAgICAgIGFkTG9hZGVkQ2FsbGJhY2s6bnVsbFxyXG4gICAgfTtcclxuXHJcbiAgICB2YXIgYWRibG9jazIgPSB7XHJcbiAgICAgIGNvbnRhaW5lcjpcImFmc2NvbnRhaW5lcjJcIixcclxuICAgICAgbGlua1RhcmdldDpcIl9ibGFua1wiLFxyXG4gICAgICB0eXBlOlwiYWRzXCIsXHJcbiAgICAgIGNvbHVtbnM6MSxcclxuICAgICAgaG9yaXpvbnRhbEFsaWdubWVudDpcImxlZnRcIixcclxuICAgICAgcmVzdWx0c1BhZ2VRdWVyeVBhcmFtOlwicXVlcnlcIixcclxuICAgICAgc3R5bGVJZDpcIjY5NDA3Mzg2NDlcIixcclxuICAgICAgYWRMb2FkZWRDYWxsYmFjazpudWxsXHJcbiAgICB9O1xyXG5cclxuICAgIF9nb29nQ3NhKFwiYWRzXCIsIHBhZ2VPcHRpb25zLCBhZGJsb2NrMSwgYWRibG9jazIpO1xyXG4gIH0pO1xyXG5cclxuICBjb25zdCBjb3Vwb25zRGF0YSA9IHByb3BzLmNvdXBvbnNEYXRhMSA/IHByb3BzLmNvdXBvbnNEYXRhMS5kYXRhIDoge307XHJcbiAgY29uc3Qgc3RvcmVfX2xvZ28gPSBwcm9wcy5zdG9yZUluZm8gPyBwcm9wcy5zdG9yZUluZm8uc2x1ZyA6IHt9O1xyXG4gIGNvbnN0IHN0b3JlX19uYW1lID0gcHJvcHMuc3RvcmVJbmZvID8gcHJvcHMuc3RvcmVJbmZvLmZvcm1hdHRlZF9uYW1lIDoge307XHJcblxyXG4gIGlmIChjb3Vwb25zRGF0YS5sZW5ndGggPiAyKSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8c2VjdGlvbj5cclxuICAgICAgICA8SGVhZD5cclxuICAgICAgICAgIDxzY3JpcHRcclxuICAgICAgICAgICAgYXN5bmM9XCJhc3luY1wiXHJcbiAgICAgICAgICAgIHNyYz1cImh0dHBzOi8vd3d3Lmdvb2dsZS5jb20vYWRzZW5zZS9zZWFyY2gvYWRzLmpzXCJcclxuICAgICAgICAgID48L3NjcmlwdD5cclxuICAgICAgICAgIDxzY3JpcHRcclxuICAgICAgICAgICAgYXN5bmNcclxuICAgICAgICAgICAgc3JjPVwiaHR0cHM6Ly9jc2UuZ29vZ2xlLmNvbS9jc2UuanM/Y3g9MzliZWQ4ZjNkZTg4YTQ4ODVcIlxyXG4gICAgICAgICAgPjwvc2NyaXB0PlxyXG4gICAgICAgIDwvSGVhZD5cclxuICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjbGVhcmZpeFwiPlxyXG4gICAgICAgICAgICA8ZGl2IGlkPVwiYWZzY29udGFpbmVyMVwiPjwvZGl2PlxyXG4gICAgICAgICAgICA8YnIvPlxyXG4gICAgICAgICAgICB7Xy5tYXAoY291cG9uc0RhdGEsICh2YWx1ZSwga2V5KSA9PiB7XHJcbiAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2codmFsdWUpO1xyXG4gICAgICAgICAgICAgIGNvbnN0IGRpc2NvdW50ID0gdmFsdWVbMThdO1xyXG4gICAgICAgICAgICAgIGxldCBwcm9tb2NvZGVDYXJkID0gZmFsc2U7XHJcblxyXG4gICAgICAgICAgICAgIGlmIChrZXkgPiAwICYmIHZhbHVlWzBdICE9PSBcIlwiKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodmFsdWVbOF0gPT0gXCJwcm9tb2NvZGVcIikge1xyXG4gICAgICAgICAgICAgICAgICBwcm9tb2NvZGVDYXJkID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtrZXl9IGNsYXNzTmFtZT17a2V5fT5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkZWFsX19jYXJkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZGVhbF9fZGlzY291bnRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRlYWxfX2luZm9cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbWdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzcmM9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYHN0b3Jlc19fbG9nby9gICtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0b3JlX19uYW1lICtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGAtbG9nby1zbWFsbC5qcGdgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uRXJyb3I9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlLnRhcmdldC5vbmVycm9yID0gbnVsbDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGUudGFyZ2V0LnNyYyA9IFwiL2ltZy1ub3Rmb3VuZC5qcGdcIjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFsdD17dmFsdWVbMV19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRlYWxfX2Rlc2NcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRlYWxfX2Rlc2MtdHlwZVwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZGVhbF9fZGVzYy10aXRsZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGFcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaHJlZj17dmFsdWVbMTFdfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhLXVybD17dmFsdWVbMTBdfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhLXByb21vY29kZT17dmFsdWVbOV19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGEtc3BlY2llcz17dmFsdWVbOF19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGEtcHJvbW9saW5rPXt2YWx1ZVsxMF19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGEtZnVuYz1cImdldFByb21vQ29kZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGEtd2Vic2l0ZT17dmFsdWVbMl19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRhcmdldD1cIl9ibGFua1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBgT2ZmZXJzQ29kZS5pbiAtIFByb21vIGNvZGUgZm9yIGAgK1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0b3JlX19uYW1lICtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBgIGRlYWwgYCArXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWVbMV1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWw9XCJub2ZvbGxvd1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMz57dmFsdWVbMV19PC9oMz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRlYWxfX2Rlc2MtbWV0YVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZGVhbF9fZGVzYy1tZXRhLWxhc3R1c2VkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpIGNsYXNzTmFtZT1cImZhIGZhLXVzZXJzXCI+PC9pPiZuYnNwO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Yj57TWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogMjAwKSArIDExfTwvYj57XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFBlb3BsZSBVc2VkIFRvZGF5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAmbmJzcDt8Jm5ic3A7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57dmFsdWVbMTVdfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkZWFsX19jdGFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtwcm9tb2NvZGVDYXJkID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhyZWY9e3ZhbHVlWzExXX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhLXVybD17dmFsdWVbMTBdfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGEtcHJvbW9jb2RlPXt2YWx1ZVs5XX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhLXNwZWNpZXM9e3ZhbHVlWzhdfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGEtcHJvbW9saW5rPXt2YWx1ZVsxMF19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YS1mdW5jPVwiZ2V0UHJvbW9Db2RlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJnZXRQcm9tb0NvZGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGEtd2Vic2l0ZT17dmFsdWVbMl19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGFyZ2V0PVwiX2JsYW5rXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBgT2ZmZXJzQ29kZS5pbiAtIFByb21vIGNvZGUgZm9yIGAgK1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RvcmVfX25hbWUgK1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYCBkZWFsIGAgK1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWVbMV1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVsPVwibm9mb2xsb3dcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3ZhbHVlWzldfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rIGhyZWY9e3ZhbHVlWzExXX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBocmVmPXtgL2dvdG9gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhLXVybD17dmFsdWVbMTBdfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhLXByb21vY29kZT17dmFsdWVbOV19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGEtc3BlY2llcz17dmFsdWVbOF19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGEtcHJvbW9saW5rPXt2YWx1ZVsxMF19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGEtZnVuYz1cImdldERlYWxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJnZXREZWFsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YS13ZWJzaXRlPXt2YWx1ZVsyXX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGFyZ2V0PVwiX2JsYW5rXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gZ290b0xpbmsgPSB7dmFsdWVbMTFdfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWw9XCJub2ZvbGxvd1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEdldCBEZWFsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJkZWFsX19jdGEtbWV0YVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dmFsdWVbMTNdICE9PSBcIk5vbmVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJFeHBpcmluZyBJbiBcIiArIGdldFBhcnNlZERhdGUodmFsdWVbMTNdKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogPGFcclxuICAgICAgICAgICAgICAgICAgICAgICAgIGhyZWY9e3ZhbHVlWzExXX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhLXVybD17dmFsdWVbMTBdfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGEtcHJvbW9jb2RlPXt2YWx1ZVs5XX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhLXNwZWNpZXM9e3ZhbHVlWzhdfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGEtcHJvbW9saW5rPXt2YWx1ZVsxMF19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YS1mdW5jPVwic2hvd0RlYWxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGEtd2Vic2l0ZT17dmFsdWVbMl19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdGFyZ2V0PVwiX2JsYW5rXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIEdldCBEZWFsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYT4gKi99XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiA8ZGl2Pnt2YWx1ZVs0XX08L2Rpdj4gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICA8ZGl2IGlkPVwiYWZzY29udGFpbmVyMlwiPjwvZGl2PlxyXG4gICAgICAgICAgIFxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvc2VjdGlvbj5cclxuICAgICk7XHJcbiAgfSBlbHNlIHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxkaXY+XHJcbiAgICAgICAgPGJyIC8+XHJcbiAgICAgICAgPGJyIC8+XHJcbiAgICAgICAgPGJyIC8+XHJcbiAgICAgICAgPGgzPk5vIE5ldyBEZWFscyBPciBDb3Vwb25zIEZvdW5kPC9oMz5cclxuICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG4gIH1cclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IENhcmQ7XHJcbiJdLCJzb3VyY2VSb290IjoiIn0=