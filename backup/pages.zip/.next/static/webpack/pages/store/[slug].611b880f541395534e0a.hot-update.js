webpackHotUpdate_N_E("pages/store/[slug]",{

/***/ "./pages/store/[slug]/index.js":
/*!*************************************!*\
  !*** ./pages/store/[slug]/index.js ***!
  \*************************************/
/*! exports provided: __N_SSP, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__N_SSP", function() { return __N_SSP; });
/* harmony import */ var C_xampp_htdocs_ReactTuts_NextJS_ofccode_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/router */ "./node_modules/next/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! next */ "next");
/* harmony import */ var next__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! lodash */ "./node_modules/lodash/lodash.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _components_Content__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../components/Content */ "./pages/components/Content.js");
/* harmony import */ var _components_OffersPageContent__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../components/OffersPageContent */ "./pages/components/OffersPageContent.js");



var _jsxFileName = "C:\\xampp\\htdocs\\ReactTuts\\NextJS\\ofccode\\pages\\store\\[slug]\\index.js",
    _this = undefined;

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { Object(C_xampp_htdocs_ReactTuts_NextJS_ofccode_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }










var getParsedDate = function getParsedDate() {
  var d = new Date();
  var month = new Array();
  month[0] = "January";
  month[1] = "February";
  month[2] = "March";
  month[3] = "April";
  month[4] = "May";
  month[5] = "June";
  month[6] = "July";
  month[7] = "August";
  month[8] = "September";
  month[9] = "October";
  month[10] = "November";
  month[11] = "December";
  return month[d.getMonth()];
};

var StorePage = function StorePage(props) {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("div", {
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(_components_Content__WEBPACK_IMPORTED_MODULE_7__["default"], _objectSpread(_objectSpread({}, props), {}, {
      headerTag1: props.storeInfo.formatted_name + " Coupons And Discount Codes For " + getParsedDate() + " 2021",
      headerTag2: "Latest " + props.storeInfo.formatted_name + " Coupon Codes, Discount Offers & Promotional Deals",
      description: props.storeInfo.metaInfo__desc
    }), void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 33,
      columnNumber: 7
    }, _this), props.cuelinksOffers.length > 0 ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("div", {
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(_components_OffersPageContent__WEBPACK_IMPORTED_MODULE_8__["default"], _objectSpread(_objectSpread({}, props), {}, {
        headerTag1: "Trending Offers from Top Stores ",
        description: 'We are please to provide some trending offers from other stores if you have habbit of saving while doing online shopping this is best place for you'
      }), void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 51,
        columnNumber: 10
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 50,
      columnNumber: 8
    }, _this) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("div", {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 59,
      columnNumber: 10
    }, _this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 32,
    columnNumber: 5
  }, _this);
};

_c = StorePage;
var __N_SSP = true;
/* harmony default export */ __webpack_exports__["default"] = (StorePage);

var _c;

$RefreshReg$(_c, "StorePage");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvc3RvcmUvW3NsdWddL2luZGV4LmpzIl0sIm5hbWVzIjpbImdldFBhcnNlZERhdGUiLCJkIiwiRGF0ZSIsIm1vbnRoIiwiQXJyYXkiLCJnZXRNb250aCIsIlN0b3JlUGFnZSIsInByb3BzIiwic3RvcmVJbmZvIiwiZm9ybWF0dGVkX25hbWUiLCJtZXRhSW5mb19fZGVzYyIsImN1ZWxpbmtzT2ZmZXJzIiwibGVuZ3RoIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTs7QUFHQSxJQUFNQSxhQUFhLEdBQUcsU0FBaEJBLGFBQWdCLEdBQU07QUFDMUIsTUFBSUMsQ0FBQyxHQUFHLElBQUlDLElBQUosRUFBUjtBQUNBLE1BQUlDLEtBQUssR0FBRyxJQUFJQyxLQUFKLEVBQVo7QUFDQUQsT0FBSyxDQUFDLENBQUQsQ0FBTCxHQUFXLFNBQVg7QUFDQUEsT0FBSyxDQUFDLENBQUQsQ0FBTCxHQUFXLFVBQVg7QUFDQUEsT0FBSyxDQUFDLENBQUQsQ0FBTCxHQUFXLE9BQVg7QUFDQUEsT0FBSyxDQUFDLENBQUQsQ0FBTCxHQUFXLE9BQVg7QUFDQUEsT0FBSyxDQUFDLENBQUQsQ0FBTCxHQUFXLEtBQVg7QUFDQUEsT0FBSyxDQUFDLENBQUQsQ0FBTCxHQUFXLE1BQVg7QUFDQUEsT0FBSyxDQUFDLENBQUQsQ0FBTCxHQUFXLE1BQVg7QUFDQUEsT0FBSyxDQUFDLENBQUQsQ0FBTCxHQUFXLFFBQVg7QUFDQUEsT0FBSyxDQUFDLENBQUQsQ0FBTCxHQUFXLFdBQVg7QUFDQUEsT0FBSyxDQUFDLENBQUQsQ0FBTCxHQUFXLFNBQVg7QUFDQUEsT0FBSyxDQUFDLEVBQUQsQ0FBTCxHQUFZLFVBQVo7QUFDQUEsT0FBSyxDQUFDLEVBQUQsQ0FBTCxHQUFZLFVBQVo7QUFDQSxTQUFPQSxLQUFLLENBQUNGLENBQUMsQ0FBQ0ksUUFBRixFQUFELENBQVo7QUFDRCxDQWhCRDs7QUFrQkEsSUFBTUMsU0FBUyxHQUFHLFNBQVpBLFNBQVksQ0FBQ0MsS0FBRCxFQUFXO0FBQzNCLHNCQUNFO0FBQUEsNEJBQ0UscUVBQUMsMkRBQUQsa0NBQ01BLEtBRE47QUFFRSxnQkFBVSxFQUNSQSxLQUFLLENBQUNDLFNBQU4sQ0FBZ0JDLGNBQWhCLEdBQ0Esa0NBREEsR0FFQVQsYUFBYSxFQUZiLEdBR0EsT0FOSjtBQVFFLGdCQUFVLEVBQ1IsWUFDQU8sS0FBSyxDQUFDQyxTQUFOLENBQWdCQyxjQURoQixHQUVBLG9EQVhKO0FBYUUsaUJBQVcsRUFBRUYsS0FBSyxDQUFDQyxTQUFOLENBQWdCRTtBQWIvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBREYsRUFpQktILEtBQUssQ0FBQ0ksY0FBTixDQUFxQkMsTUFBckIsR0FBOEIsQ0FBL0IsZ0JBQ0Q7QUFBQSw2QkFDRSxxRUFBQyxxRUFBRCxrQ0FDS0wsS0FETDtBQUVDLGtCQUFVLEVBQ1Isa0NBSEg7QUFLQyxtQkFBVyxFQUFFO0FBTGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFEQyxnQkFVQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBM0JMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQURGO0FBZ0NELENBakNEOztLQUFNRCxTOztBQXVFU0Esd0VBQWYiLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvc3RvcmUvW3NsdWddLjYxMWI4ODBmNTQxMzk1NTM0ZTBhLmhvdC11cGRhdGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgQ29tcG9uZW50IH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gXCJuZXh0L3JvdXRlclwiO1xyXG5pbXBvcnQgR2V0U2VydmVyU2lkZVByb3BzIGZyb20gXCJuZXh0XCI7XHJcbmltcG9ydCBOZXh0UGFnZSBmcm9tIFwibmV4dFwiO1xyXG5pbXBvcnQgTGluayBmcm9tIFwibmV4dC9saW5rXCI7XHJcbmltcG9ydCBheGlvcyBmcm9tIFwiYXhpb3NcIjtcclxuaW1wb3J0IF8gZnJvbSBcImxvZGFzaFwiO1xyXG5pbXBvcnQgQ29udGVudCBmcm9tIFwiLi4vLi4vY29tcG9uZW50cy9Db250ZW50XCI7XHJcbmltcG9ydCBPZmZlcnNQYWdlQ29udGVudCBmcm9tICcuLi8uLi9jb21wb25lbnRzL09mZmVyc1BhZ2VDb250ZW50J1xyXG52YXIgUGFwYSA9IHJlcXVpcmUoXCJwYXBhcGFyc2VcIik7XHJcblxyXG5jb25zdCBnZXRQYXJzZWREYXRlID0gKCkgPT4ge1xyXG4gIHZhciBkID0gbmV3IERhdGUoKTtcclxuICB2YXIgbW9udGggPSBuZXcgQXJyYXkoKTtcclxuICBtb250aFswXSA9IFwiSmFudWFyeVwiO1xyXG4gIG1vbnRoWzFdID0gXCJGZWJydWFyeVwiO1xyXG4gIG1vbnRoWzJdID0gXCJNYXJjaFwiO1xyXG4gIG1vbnRoWzNdID0gXCJBcHJpbFwiO1xyXG4gIG1vbnRoWzRdID0gXCJNYXlcIjtcclxuICBtb250aFs1XSA9IFwiSnVuZVwiO1xyXG4gIG1vbnRoWzZdID0gXCJKdWx5XCI7XHJcbiAgbW9udGhbN10gPSBcIkF1Z3VzdFwiO1xyXG4gIG1vbnRoWzhdID0gXCJTZXB0ZW1iZXJcIjtcclxuICBtb250aFs5XSA9IFwiT2N0b2JlclwiO1xyXG4gIG1vbnRoWzEwXSA9IFwiTm92ZW1iZXJcIjtcclxuICBtb250aFsxMV0gPSBcIkRlY2VtYmVyXCI7XHJcbiAgcmV0dXJuIG1vbnRoW2QuZ2V0TW9udGgoKV07XHJcbn07XHJcblxyXG5jb25zdCBTdG9yZVBhZ2UgPSAocHJvcHMpID0+IHsgIFxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2PlxyXG4gICAgICA8Q29udGVudFxyXG4gICAgICAgIHsuLi5wcm9wc31cclxuICAgICAgICBoZWFkZXJUYWcxPXtcclxuICAgICAgICAgIHByb3BzLnN0b3JlSW5mby5mb3JtYXR0ZWRfbmFtZSArXHJcbiAgICAgICAgICBcIiBDb3Vwb25zIEFuZCBEaXNjb3VudCBDb2RlcyBGb3IgXCIgK1xyXG4gICAgICAgICAgZ2V0UGFyc2VkRGF0ZSgpICtcclxuICAgICAgICAgIFwiIDIwMjFcIlxyXG4gICAgICAgIH1cclxuICAgICAgICBoZWFkZXJUYWcyPXtcclxuICAgICAgICAgIFwiTGF0ZXN0IFwiICtcclxuICAgICAgICAgIHByb3BzLnN0b3JlSW5mby5mb3JtYXR0ZWRfbmFtZSArXHJcbiAgICAgICAgICBcIiBDb3Vwb24gQ29kZXMsIERpc2NvdW50IE9mZmVycyAmIFByb21vdGlvbmFsIERlYWxzXCJcclxuICAgICAgICB9XHJcbiAgICAgICAgZGVzY3JpcHRpb249e3Byb3BzLnN0b3JlSW5mby5tZXRhSW5mb19fZGVzY31cclxuICAgICAgLz5cclxuICAgICAgICBcclxuICAgICAgIHsocHJvcHMuY3VlbGlua3NPZmZlcnMubGVuZ3RoID4gMCApID8gXHJcbiAgICAgICA8ZGl2PlxyXG4gICAgICAgICA8T2ZmZXJzUGFnZUNvbnRlbnRcclxuICAgICAgICAgIHsuLi5wcm9wc31cclxuICAgICAgICAgIGhlYWRlclRhZzE9e1xyXG4gICAgICAgICAgICBcIlRyZW5kaW5nIE9mZmVycyBmcm9tIFRvcCBTdG9yZXMgXCJcclxuICAgICAgICAgIH0gICAgICAgXHJcbiAgICAgICAgICBkZXNjcmlwdGlvbj17J1dlIGFyZSBwbGVhc2UgdG8gcHJvdmlkZSBzb21lIHRyZW5kaW5nIG9mZmVycyBmcm9tIG90aGVyIHN0b3JlcyBpZiB5b3UgaGF2ZSBoYWJiaXQgb2Ygc2F2aW5nIHdoaWxlIGRvaW5nIG9ubGluZSBzaG9wcGluZyB0aGlzIGlzIGJlc3QgcGxhY2UgZm9yIHlvdSd9XHJcbiAgICAgICAgLz5cclxuICAgICAgIDwvZGl2PlxyXG4gICAgICAgOiA8ZGl2PjwvZGl2Pn0gXHJcbiAgICAgICBcclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0U2VydmVyU2lkZVByb3BzKHsgcGFyYW1zIH0pIHtcclxuICBjb25zdCBzdG9yZVNsdWcgPSBwYXJhbXMuc2x1ZztcclxuICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKFxyXG4gICAgYGh0dHBzOi8vb2ZjY29kZS1hcGktZ2l0LW1haW4tc3BvcnR5YnJ1aDE5OTAudmVyY2VsLmFwcC9hcGkvZnJvbnQvc2VhcmNoL3N0b3JlX19ieV9fc2x1Zz9xPSR7c3RvcmVTbHVnfWBcclxuICApO1xyXG4gIGNvbnN0IGdldFN0b3JlSWRSZXMgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XHJcbiAgLy8gY29uc29sZS5sb2coZ2V0U3RvcmVJZFJlcylcclxuICBjb25zdCBzdG9yZUlkID0gZ2V0U3RvcmVJZFJlcy5hZmZJbmZvX19TdG9yZUlkO1xyXG4gIGNvbnN0IGRhdGFVcmwgPVxyXG4gICAgXCJodHRwczovL2V4cG9ydC5hZG1pdGFkLmNvbS9lbi93ZWJtYXN0ZXIvd2Vic2l0ZXMvMTc3NzA1Mi9jb3Vwb25zL2V4cG9ydC8/d2Vic2l0ZT0xNzc3MDUyJmFkdmNhbXBhaWducz1cIiArXHJcbiAgICBzdG9yZUlkICtcclxuICAgIFwiJnJlZ2lvbj0wMCZjb2RlPWV5cTQ4dzYyYmomdXNlcj12aXNod2FqaXQ4MiZmb3JtYXQ9Y3N2JnY9NFwiO1xyXG4gIGNvbnN0IHJlcyA9IGF3YWl0IGF4aW9zLmdldChkYXRhVXJsKTtcclxuICBjb25zdCBkYXRhID0gUGFwYS5wYXJzZShyZXMuZGF0YSk7XHJcblxyXG5cclxuICAvLyBsZXQgY2xpbmtzUmVzID0gYXdhaXQgZmV0Y2goXHJcbiAgLy8gICBgaHR0cHM6Ly9vZmNjb2RlLWFwaS1naXQtbWFpbi1zcG9ydHlicnVoMTk5MC52ZXJjZWwuYXBwL2FwaS9mcm9udC9jdWVscy9vZmZlcnNgXHJcbiAgLy8gKTtcclxuICAvLyBsZXQgY3VlbGlua3NPZmZlcnMgPSBhd2FpdCBjbGlua3NSZXMuanNvbigpOyAgXHJcblxyXG4gIGxldCBjbGlua3NSZXMgPSBhd2FpdCBmZXRjaChcclxuICAgIGBodHRwOi8vbG9jYWxob3N0OjMwMDIvYXBpL2Zyb250L3NlYXJjaC9vZmZlcnNfX2J5X19xdWVyeT9xPSR7c3RvcmVTbHVnfWBcclxuICApO1xyXG4gIGxldCBjdWVsaW5rc09mZmVycyA9IGF3YWl0IGNsaW5rc1Jlcy5qc29uKCk7ICBcclxuICAgIFxyXG5cclxuICByZXR1cm4ge1xyXG4gICAgcHJvcHM6IHtcclxuICAgICAgc3RvcmVJbmZvOiBnZXRTdG9yZUlkUmVzLFxyXG4gICAgICBjb3Vwb25zRGF0YTE6IGRhdGEsXHJcbiAgICAgIGN1ZWxpbmtzT2ZmZXJzOiBjdWVsaW5rc09mZmVycy5yZXN1bHRzLFxyXG4gICAgfSxcclxuICB9O1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBTdG9yZVBhZ2U7XHJcbiJdLCJzb3VyY2VSb290IjoiIn0=