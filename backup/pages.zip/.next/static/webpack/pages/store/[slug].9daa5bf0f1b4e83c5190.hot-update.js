webpackHotUpdate_N_E("pages/store/[slug]",{

/***/ "./pages/components/Cards/Card.js":
/*!****************************************!*\
  !*** ./pages/components/Cards/Card.js ***!
  \****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/head */ "./node_modules/next/head.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/router */ "./node_modules/next/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! lodash */ "./node_modules/lodash/lodash.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_6__);


var _jsxFileName = "C:\\xampp\\htdocs\\ReactTuts\\NextJS\\ofccode\\pages\\components\\Cards\\Card.js",
    _this = undefined,
    _s = $RefreshSig$();








var getParsedDate = function getParsedDate(date) {
  return moment__WEBPACK_IMPORTED_MODULE_5___default()(date).startOf("hour").fromNow();
};

var Card = function Card(props) {
  _s();

  var router = Object(next_router__WEBPACK_IMPORTED_MODULE_3__["useRouter"])();
  var slug = router.query.slug; // Similar to componentDidMount and componentDidUpdate:

  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(function () {
    // <!-- other head elements from your page -->
    (function (g, o) {
      g[o] = g[o] || function () {
        (g[o]["q"] = g[o]["q"] || []).push(arguments);
      }, g[o]["t"] = 1 * new Date();
    })(window, "_googCsa");

    var pageOptions = {
      pubId: "pub-9616389000213823",
      // Make sure this the correct client ID!
      query: slug,
      adPage: 10,
      channel: "searchchnm"
    };
    var adblock1 = {
      container: "afscontainer1",
      linkTarget: "_blank",
      type: "ads",
      columns: 1,
      horizontalAlignment: "left",
      resultsPageQueryParam: "query",
      styleId: "6940738649",
      adLoadedCallback: null
    };
    var adblock2 = {
      container: "afscontainer2",
      linkTarget: "_blank",
      type: "ads",
      columns: 1,
      horizontalAlignment: "left",
      resultsPageQueryParam: "query",
      styleId: "6940738649",
      adLoadedCallback: null
    };

    _googCsa("ads", pageOptions, adblock1, adblock2);
  });
  var couponsData = props.couponsData1 ? props.couponsData1.data : {};
  var store__logo = props.storeInfo ? props.storeInfo.slug : {};
  var store__name = props.storeInfo ? props.storeInfo.formatted_name : {};

  if (couponsData.length > 2) {
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("section", {
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_head__WEBPACK_IMPORTED_MODULE_2___default.a, {
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("script", {
          async: "async",
          src: "https://www.google.com/adsense/search/ads.js"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 68,
          columnNumber: 11
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("script", {
          async: true,
          src: "https://cse.google.com/cse.js?cx=39bed8f3de88a4885"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 72,
          columnNumber: 11
        }, _this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 67,
        columnNumber: 9
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "clearfix",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            id: "afscontainer1"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 79,
            columnNumber: 13
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 80,
            columnNumber: 13
          }, _this), lodash__WEBPACK_IMPORTED_MODULE_4___default.a.map(couponsData, function (value, key) {
            // console.log(value);
            var discount = value[18];
            var promocodeCard = false;

            if (key > 0 && value[0] !== "") {
              if (value[8] == "promocode") {
                promocodeCard = true;
              }

              return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: key,
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                    className: "deal__card",
                    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                      className: "deal__discount",
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                        className: "deal__info",
                        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
                            src: "stores__logo/{value[1]}-logo-small.jpg",
                            onError: function onError(e) {
                              e.target.onerror = null;
                              e.target.src = "/img-notfound.jpg";
                            },
                            alt: value[1]
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 97,
                            columnNumber: 31
                          }, _this), " "]
                        }, void 0, true, {
                          fileName: _jsxFileName,
                          lineNumber: 96,
                          columnNumber: 29
                        }, _this)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 95,
                        columnNumber: 27
                      }, _this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 94,
                      columnNumber: 25
                    }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                      className: "deal__desc",
                      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                        className: "deal__desc-type"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 109,
                        columnNumber: 27
                      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                        className: "deal__desc-title",
                        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                          href: value[11],
                          "data-url": value[10],
                          "data-promocode": value[9],
                          "data-species": value[8],
                          "data-promolink": value[10],
                          "data-func": "getPromoCode",
                          "data-website": value[2],
                          target: "_blank",
                          title: "OffersCode.in - Promo code for " + store__name + " deal " + value[1],
                          rel: "nofollow",
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h3", {
                            children: value[1]
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 128,
                            columnNumber: 31
                          }, _this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 111,
                          columnNumber: 29
                        }, _this)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 110,
                        columnNumber: 27
                      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                        className: "deal__desc-meta",
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                          className: "deal__desc-meta-lastused",
                          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
                            className: "fa fa-users"
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 133,
                            columnNumber: 31
                          }, _this), "\xA0", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("b", {
                            children: Math.floor(Math.random() * 200) + 11
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 134,
                            columnNumber: 31
                          }, _this), " ", "People Used Today"]
                        }, void 0, true, {
                          fileName: _jsxFileName,
                          lineNumber: 132,
                          columnNumber: 29
                        }, _this), "\xA0|\xA0", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                          children: value[15]
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 138,
                          columnNumber: 29
                        }, _this)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 131,
                        columnNumber: 27
                      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                        className: "deal__cta",
                        children: [promocodeCard ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                          href: value[11],
                          "data-url": value[10],
                          "data-promocode": value[9],
                          "data-species": value[8],
                          "data-promolink": value[10],
                          "data-func": "getPromoCode",
                          className: "getPromoCode",
                          "data-website": value[2],
                          target: "_blank",
                          title: "OffersCode.in - Promo code for " + store__name + " deal " + value[1],
                          rel: "nofollow",
                          children: value[9]
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 143,
                          columnNumber: 31
                        }, _this) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_6___default.a, {
                            href: value[11],
                            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                              // href={`/goto`}
                              "data-url": value[10],
                              "data-promocode": value[9],
                              "data-species": value[8],
                              "data-promolink": value[10],
                              "data-func": "getDeal",
                              className: "getDeal",
                              "data-website": value[2],
                              target: "_blank" // gotoLink = {value[11]}
                              ,
                              rel: "nofollow",
                              children: "Get Deal"
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 166,
                              columnNumber: 35
                            }, _this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 165,
                            columnNumber: 33
                          }, _this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 164,
                          columnNumber: 31
                        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                          className: "deal__cta-meta",
                          children: value[13] !== "None" ? "Expiring In " + getParsedDate(value[13]) : ""
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 184,
                          columnNumber: 29
                        }, _this)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 141,
                        columnNumber: 27
                      }, _this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 108,
                      columnNumber: 25
                    }, _this)]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 93,
                    columnNumber: 23
                  }, _this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 92,
                  columnNumber: 21
                }, _this)
              }, key, false, {
                fileName: _jsxFileName,
                lineNumber: 91,
                columnNumber: 19
              }, _this);
            }
          }), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            id: "afscontainer2"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 211,
            columnNumber: 13
          }, _this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 78,
          columnNumber: 11
        }, _this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 77,
        columnNumber: 9
      }, _this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 66,
      columnNumber: 7
    }, _this);
  } else {
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 220,
        columnNumber: 9
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 221,
        columnNumber: 9
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 222,
        columnNumber: 9
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h3", {
        children: "No New Deals Or Coupons Found"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 223,
        columnNumber: 9
      }, _this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 219,
      columnNumber: 7
    }, _this);
  }
};

_s(Card, "vQduR7x+OPXj6PSmJyFnf+hU7bg=", false, function () {
  return [next_router__WEBPACK_IMPORTED_MODULE_3__["useRouter"]];
});

_c = Card;
/* harmony default export */ __webpack_exports__["default"] = (Card);

var _c;

$RefreshReg$(_c, "Card");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvY29tcG9uZW50cy9DYXJkcy9DYXJkLmpzIl0sIm5hbWVzIjpbImdldFBhcnNlZERhdGUiLCJkYXRlIiwiTW9tZW50Iiwic3RhcnRPZiIsImZyb21Ob3ciLCJDYXJkIiwicHJvcHMiLCJyb3V0ZXIiLCJ1c2VSb3V0ZXIiLCJzbHVnIiwicXVlcnkiLCJ1c2VFZmZlY3QiLCJnIiwibyIsInB1c2giLCJhcmd1bWVudHMiLCJEYXRlIiwid2luZG93IiwicGFnZU9wdGlvbnMiLCJwdWJJZCIsImFkUGFnZSIsImNoYW5uZWwiLCJhZGJsb2NrMSIsImNvbnRhaW5lciIsImxpbmtUYXJnZXQiLCJ0eXBlIiwiY29sdW1ucyIsImhvcml6b250YWxBbGlnbm1lbnQiLCJyZXN1bHRzUGFnZVF1ZXJ5UGFyYW0iLCJzdHlsZUlkIiwiYWRMb2FkZWRDYWxsYmFjayIsImFkYmxvY2syIiwiX2dvb2dDc2EiLCJjb3Vwb25zRGF0YSIsImNvdXBvbnNEYXRhMSIsImRhdGEiLCJzdG9yZV9fbG9nbyIsInN0b3JlSW5mbyIsInN0b3JlX19uYW1lIiwiZm9ybWF0dGVkX25hbWUiLCJsZW5ndGgiLCJfIiwibWFwIiwidmFsdWUiLCJrZXkiLCJkaXNjb3VudCIsInByb21vY29kZUNhcmQiLCJlIiwidGFyZ2V0Iiwib25lcnJvciIsInNyYyIsIk1hdGgiLCJmbG9vciIsInJhbmRvbSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxJQUFNQSxhQUFhLEdBQUcsU0FBaEJBLGFBQWdCLENBQUNDLElBQUQsRUFBVTtBQUM5QixTQUFPQyw2Q0FBTSxDQUFDRCxJQUFELENBQU4sQ0FBYUUsT0FBYixDQUFxQixNQUFyQixFQUE2QkMsT0FBN0IsRUFBUDtBQUNELENBRkQ7O0FBSUEsSUFBTUMsSUFBSSxHQUFHLFNBQVBBLElBQU8sQ0FBQ0MsS0FBRCxFQUFXO0FBQUE7O0FBQ3RCLE1BQU1DLE1BQU0sR0FBR0MsNkRBQVMsRUFBeEI7QUFEc0IsTUFFZEMsSUFGYyxHQUVMRixNQUFNLENBQUNHLEtBRkYsQ0FFZEQsSUFGYyxFQUd0Qjs7QUFDQUUseURBQVMsQ0FBQyxZQUFNO0FBQ2Q7QUFFQSxLQUFDLFVBQVVDLENBQVYsRUFBYUMsQ0FBYixFQUFnQjtBQUNkRCxPQUFDLENBQUNDLENBQUQsQ0FBRCxHQUNDRCxDQUFDLENBQUNDLENBQUQsQ0FBRCxJQUNBLFlBQVk7QUFDVixTQUFDRCxDQUFDLENBQUNDLENBQUQsQ0FBRCxDQUFLLEdBQUwsSUFBWUQsQ0FBQyxDQUFDQyxDQUFELENBQUQsQ0FBSyxHQUFMLEtBQWEsRUFBMUIsRUFBOEJDLElBQTlCLENBQW1DQyxTQUFuQztBQUNELE9BSkgsRUFLR0gsQ0FBQyxDQUFDQyxDQUFELENBQUQsQ0FBSyxHQUFMLElBQVksSUFBSSxJQUFJRyxJQUFKLEVBTG5CO0FBTUQsS0FQRCxFQU9HQyxNQVBILEVBT1csVUFQWDs7QUFTQSxRQUFJQyxXQUFXLEdBQUc7QUFDaEJDLFdBQUssRUFBRSxzQkFEUztBQUNlO0FBQy9CVCxXQUFLLEVBQUVELElBRlM7QUFHaEJXLFlBQU0sRUFBRSxFQUhRO0FBSWhCQyxhQUFPLEVBQUU7QUFKTyxLQUFsQjtBQU9BLFFBQUlDLFFBQVEsR0FBRztBQUNiQyxlQUFTLEVBQUMsZUFERztBQUViQyxnQkFBVSxFQUFDLFFBRkU7QUFHYkMsVUFBSSxFQUFDLEtBSFE7QUFJYkMsYUFBTyxFQUFDLENBSks7QUFLYkMseUJBQW1CLEVBQUMsTUFMUDtBQU1iQywyQkFBcUIsRUFBQyxPQU5UO0FBT2JDLGFBQU8sRUFBQyxZQVBLO0FBUWJDLHNCQUFnQixFQUFDO0FBUkosS0FBZjtBQVdBLFFBQUlDLFFBQVEsR0FBRztBQUNiUixlQUFTLEVBQUMsZUFERztBQUViQyxnQkFBVSxFQUFDLFFBRkU7QUFHYkMsVUFBSSxFQUFDLEtBSFE7QUFJYkMsYUFBTyxFQUFDLENBSks7QUFLYkMseUJBQW1CLEVBQUMsTUFMUDtBQU1iQywyQkFBcUIsRUFBQyxPQU5UO0FBT2JDLGFBQU8sRUFBQyxZQVBLO0FBUWJDLHNCQUFnQixFQUFDO0FBUkosS0FBZjs7QUFXQUUsWUFBUSxDQUFDLEtBQUQsRUFBUWQsV0FBUixFQUFxQkksUUFBckIsRUFBK0JTLFFBQS9CLENBQVI7QUFDRCxHQTFDUSxDQUFUO0FBNENBLE1BQU1FLFdBQVcsR0FBRzNCLEtBQUssQ0FBQzRCLFlBQU4sR0FBcUI1QixLQUFLLENBQUM0QixZQUFOLENBQW1CQyxJQUF4QyxHQUErQyxFQUFuRTtBQUNBLE1BQU1DLFdBQVcsR0FBRzlCLEtBQUssQ0FBQytCLFNBQU4sR0FBa0IvQixLQUFLLENBQUMrQixTQUFOLENBQWdCNUIsSUFBbEMsR0FBeUMsRUFBN0Q7QUFDQSxNQUFNNkIsV0FBVyxHQUFHaEMsS0FBSyxDQUFDK0IsU0FBTixHQUFrQi9CLEtBQUssQ0FBQytCLFNBQU4sQ0FBZ0JFLGNBQWxDLEdBQW1ELEVBQXZFOztBQUVBLE1BQUlOLFdBQVcsQ0FBQ08sTUFBWixHQUFxQixDQUF6QixFQUE0QjtBQUMxQix3QkFDRTtBQUFBLDhCQUNFLHFFQUFDLGdEQUFEO0FBQUEsZ0NBQ0U7QUFDRSxlQUFLLEVBQUMsT0FEUjtBQUVFLGFBQUcsRUFBQztBQUZOO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREYsZUFLRTtBQUNFLGVBQUssTUFEUDtBQUVFLGFBQUcsRUFBQztBQUZOO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREYsZUFXRTtBQUFBLCtCQUNFO0FBQUssbUJBQVMsRUFBQyxVQUFmO0FBQUEsa0NBQ0U7QUFBSyxjQUFFLEVBQUM7QUFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURGLGVBRUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFGRixFQUdHQyw2Q0FBQyxDQUFDQyxHQUFGLENBQU1ULFdBQU4sRUFBbUIsVUFBQ1UsS0FBRCxFQUFRQyxHQUFSLEVBQWdCO0FBQ2xDO0FBQ0EsZ0JBQU1DLFFBQVEsR0FBR0YsS0FBSyxDQUFDLEVBQUQsQ0FBdEI7QUFDQSxnQkFBSUcsYUFBYSxHQUFHLEtBQXBCOztBQUVBLGdCQUFJRixHQUFHLEdBQUcsQ0FBTixJQUFXRCxLQUFLLENBQUMsQ0FBRCxDQUFMLEtBQWEsRUFBNUIsRUFBZ0M7QUFDOUIsa0JBQUlBLEtBQUssQ0FBQyxDQUFELENBQUwsSUFBWSxXQUFoQixFQUE2QjtBQUMzQkcsNkJBQWEsR0FBRyxJQUFoQjtBQUNEOztBQUNELGtDQUNFO0FBQWUseUJBQVMsRUFBRUYsR0FBMUI7QUFBQSx1Q0FDRTtBQUFLLDJCQUFTLEVBQUMsRUFBZjtBQUFBLHlDQUNFO0FBQUssNkJBQVMsRUFBQyxZQUFmO0FBQUEsNENBQ0U7QUFBSywrQkFBUyxFQUFDLGdCQUFmO0FBQUEsNkNBQ0U7QUFBSyxpQ0FBUyxFQUFDLFlBQWY7QUFBQSwrQ0FDRTtBQUFBLGtEQUNFO0FBQ0UsK0JBQUcsRUFBQyx3Q0FETjtBQUVFLG1DQUFPLEVBQUUsaUJBQUNHLENBQUQsRUFBTztBQUNkQSwrQkFBQyxDQUFDQyxNQUFGLENBQVNDLE9BQVQsR0FBbUIsSUFBbkI7QUFDQUYsK0JBQUMsQ0FBQ0MsTUFBRixDQUFTRSxHQUFULEdBQWUsbUJBQWY7QUFDRCw2QkFMSDtBQU1FLCtCQUFHLEVBQUVQLEtBQUssQ0FBQyxDQUFEO0FBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FERixFQVFLLEdBUkw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBREYsZUFlRTtBQUFLLCtCQUFTLEVBQUMsWUFBZjtBQUFBLDhDQUNFO0FBQUssaUNBQVMsRUFBQztBQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBREYsZUFFRTtBQUFLLGlDQUFTLEVBQUMsa0JBQWY7QUFBQSwrQ0FDRTtBQUNFLDhCQUFJLEVBQUVBLEtBQUssQ0FBQyxFQUFELENBRGI7QUFFRSxzQ0FBVUEsS0FBSyxDQUFDLEVBQUQsQ0FGakI7QUFHRSw0Q0FBZ0JBLEtBQUssQ0FBQyxDQUFELENBSHZCO0FBSUUsMENBQWNBLEtBQUssQ0FBQyxDQUFELENBSnJCO0FBS0UsNENBQWdCQSxLQUFLLENBQUMsRUFBRCxDQUx2QjtBQU1FLHVDQUFVLGNBTlo7QUFPRSwwQ0FBY0EsS0FBSyxDQUFDLENBQUQsQ0FQckI7QUFRRSxnQ0FBTSxFQUFDLFFBUlQ7QUFTRSwrQkFBSyxFQUNILG9DQUNBTCxXQURBLGNBR0FLLEtBQUssQ0FBQyxDQUFELENBYlQ7QUFlRSw2QkFBRyxFQUFDLFVBZk47QUFBQSxpREFpQkU7QUFBQSxzQ0FBS0EsS0FBSyxDQUFDLENBQUQ7QUFBVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUZGLGVBdUJFO0FBQUssaUNBQVMsRUFBQyxpQkFBZjtBQUFBLGdEQUNFO0FBQU0sbUNBQVMsRUFBQywwQkFBaEI7QUFBQSxrREFDRTtBQUFHLHFDQUFTLEVBQUM7QUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQURGLHVCQUVFO0FBQUEsc0NBQUlRLElBQUksQ0FBQ0MsS0FBTCxDQUFXRCxJQUFJLENBQUNFLE1BQUwsS0FBZ0IsR0FBM0IsSUFBa0M7QUFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FGRixFQUVnRCxHQUZoRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBREYsNEJBT0U7QUFBQSxvQ0FBT1YsS0FBSyxDQUFDLEVBQUQ7QUFBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkF2QkYsZUFpQ0U7QUFBSyxpQ0FBUyxFQUFDLFdBQWY7QUFBQSxtQ0FDR0csYUFBYSxnQkFDWjtBQUNFLDhCQUFJLEVBQUVILEtBQUssQ0FBQyxFQUFELENBRGI7QUFFRSxzQ0FBVUEsS0FBSyxDQUFDLEVBQUQsQ0FGakI7QUFHRSw0Q0FBZ0JBLEtBQUssQ0FBQyxDQUFELENBSHZCO0FBSUUsMENBQWNBLEtBQUssQ0FBQyxDQUFELENBSnJCO0FBS0UsNENBQWdCQSxLQUFLLENBQUMsRUFBRCxDQUx2QjtBQU1FLHVDQUFVLGNBTlo7QUFPRSxtQ0FBUyxFQUFDLGNBUFo7QUFRRSwwQ0FBY0EsS0FBSyxDQUFDLENBQUQsQ0FSckI7QUFTRSxnQ0FBTSxFQUFDLFFBVFQ7QUFVRSwrQkFBSyxFQUNILG9DQUNBTCxXQURBLGNBR0FLLEtBQUssQ0FBQyxDQUFELENBZFQ7QUFnQkUsNkJBQUcsRUFBQyxVQWhCTjtBQUFBLG9DQWtCR0EsS0FBSyxDQUFDLENBQUQ7QUFsQlI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FEWSxnQkFzQlo7QUFBQSxpREFDRSxxRUFBQyxnREFBRDtBQUFNLGdDQUFJLEVBQUVBLEtBQUssQ0FBQyxFQUFELENBQWpCO0FBQUEsbURBQ0U7QUFDRTtBQUNBLDBDQUFVQSxLQUFLLENBQUMsRUFBRCxDQUZqQjtBQUdFLGdEQUFnQkEsS0FBSyxDQUFDLENBQUQsQ0FIdkI7QUFJRSw4Q0FBY0EsS0FBSyxDQUFDLENBQUQsQ0FKckI7QUFLRSxnREFBZ0JBLEtBQUssQ0FBQyxFQUFELENBTHZCO0FBTUUsMkNBQVUsU0FOWjtBQU9FLHVDQUFTLEVBQUMsU0FQWjtBQVFFLDhDQUFjQSxLQUFLLENBQUMsQ0FBRCxDQVJyQjtBQVNFLG9DQUFNLEVBQUMsUUFUVCxDQVVFO0FBVkY7QUFXRSxpQ0FBRyxFQUFDLFVBWE47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0F2QkosZUEyQ0U7QUFBTSxtQ0FBUyxFQUFDLGdCQUFoQjtBQUFBLG9DQUNHQSxLQUFLLENBQUMsRUFBRCxDQUFMLEtBQWMsTUFBZCxHQUNHLGlCQUFpQjNDLGFBQWEsQ0FBQzJDLEtBQUssQ0FBQyxFQUFELENBQU4sQ0FEakMsR0FFRztBQUhOO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBM0NGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFqQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERixpQkFBVUMsR0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQURGO0FBdUhEO0FBQ0YsV0FqSUEsQ0FISCxlQXFJRTtBQUFLLGNBQUUsRUFBQztBQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBcklGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFYRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFERjtBQXdKRCxHQXpKRCxNQXlKTztBQUNMLHdCQUNFO0FBQUEsOEJBQ0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGLGVBRUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUZGLGVBR0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUhGLGVBSUU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFERjtBQVFEO0FBQ0YsQ0F2TkQ7O0dBQU12QyxJO1VBQ1dHLHFEOzs7S0FEWEgsSTtBQXlOU0EsbUVBQWYiLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvc3RvcmUvW3NsdWddLjlkYWE1YmYwZjFiNGU4M2M1MTkwLmhvdC11cGRhdGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgQ29tcG9uZW50LCB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBIZWFkIGZyb20gXCJuZXh0L2hlYWRcIjtcclxuaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSBcIm5leHQvcm91dGVyXCI7XHJcbmltcG9ydCBfIGZyb20gXCJsb2Rhc2hcIjtcclxuaW1wb3J0IE1vbWVudCBmcm9tIFwibW9tZW50XCI7XHJcbmltcG9ydCBMaW5rIGZyb20gXCJuZXh0L2xpbmtcIjtcclxuXHJcbmNvbnN0IGdldFBhcnNlZERhdGUgPSAoZGF0ZSkgPT4ge1xyXG4gIHJldHVybiBNb21lbnQoZGF0ZSkuc3RhcnRPZihcImhvdXJcIikuZnJvbU5vdygpO1xyXG59O1xyXG5cclxuY29uc3QgQ2FyZCA9IChwcm9wcykgPT4ge1xyXG4gIGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpO1xyXG4gIGNvbnN0IHsgc2x1ZyB9ID0gcm91dGVyLnF1ZXJ5O1xyXG4gIC8vIFNpbWlsYXIgdG8gY29tcG9uZW50RGlkTW91bnQgYW5kIGNvbXBvbmVudERpZFVwZGF0ZTpcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgLy8gPCEtLSBvdGhlciBoZWFkIGVsZW1lbnRzIGZyb20geW91ciBwYWdlIC0tPlxyXG5cclxuICAgIChmdW5jdGlvbiAoZywgbykge1xyXG4gICAgICAoZ1tvXSA9XHJcbiAgICAgICAgZ1tvXSB8fFxyXG4gICAgICAgIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgIChnW29dW1wicVwiXSA9IGdbb11bXCJxXCJdIHx8IFtdKS5wdXNoKGFyZ3VtZW50cyk7XHJcbiAgICAgICAgfSksXHJcbiAgICAgICAgKGdbb11bXCJ0XCJdID0gMSAqIG5ldyBEYXRlKCkpO1xyXG4gICAgfSkod2luZG93LCBcIl9nb29nQ3NhXCIpO1xyXG5cclxuICAgIHZhciBwYWdlT3B0aW9ucyA9IHtcclxuICAgICAgcHViSWQ6IFwicHViLTk2MTYzODkwMDAyMTM4MjNcIiwgLy8gTWFrZSBzdXJlIHRoaXMgdGhlIGNvcnJlY3QgY2xpZW50IElEIVxyXG4gICAgICBxdWVyeTogc2x1ZyxcclxuICAgICAgYWRQYWdlOiAxMCxcclxuICAgICAgY2hhbm5lbDogXCJzZWFyY2hjaG5tXCIsXHJcbiAgICB9O1xyXG5cclxuICAgIHZhciBhZGJsb2NrMSA9IHtcclxuICAgICAgY29udGFpbmVyOlwiYWZzY29udGFpbmVyMVwiLFxyXG4gICAgICBsaW5rVGFyZ2V0OlwiX2JsYW5rXCIsXHJcbiAgICAgIHR5cGU6XCJhZHNcIixcclxuICAgICAgY29sdW1uczoxLFxyXG4gICAgICBob3Jpem9udGFsQWxpZ25tZW50OlwibGVmdFwiLFxyXG4gICAgICByZXN1bHRzUGFnZVF1ZXJ5UGFyYW06XCJxdWVyeVwiLFxyXG4gICAgICBzdHlsZUlkOlwiNjk0MDczODY0OVwiLFxyXG4gICAgICBhZExvYWRlZENhbGxiYWNrOm51bGxcclxuICAgIH07XHJcblxyXG4gICAgdmFyIGFkYmxvY2syID0ge1xyXG4gICAgICBjb250YWluZXI6XCJhZnNjb250YWluZXIyXCIsXHJcbiAgICAgIGxpbmtUYXJnZXQ6XCJfYmxhbmtcIixcclxuICAgICAgdHlwZTpcImFkc1wiLFxyXG4gICAgICBjb2x1bW5zOjEsXHJcbiAgICAgIGhvcml6b250YWxBbGlnbm1lbnQ6XCJsZWZ0XCIsXHJcbiAgICAgIHJlc3VsdHNQYWdlUXVlcnlQYXJhbTpcInF1ZXJ5XCIsXHJcbiAgICAgIHN0eWxlSWQ6XCI2OTQwNzM4NjQ5XCIsXHJcbiAgICAgIGFkTG9hZGVkQ2FsbGJhY2s6bnVsbFxyXG4gICAgfTtcclxuXHJcbiAgICBfZ29vZ0NzYShcImFkc1wiLCBwYWdlT3B0aW9ucywgYWRibG9jazEsIGFkYmxvY2syKTtcclxuICB9KTtcclxuXHJcbiAgY29uc3QgY291cG9uc0RhdGEgPSBwcm9wcy5jb3Vwb25zRGF0YTEgPyBwcm9wcy5jb3Vwb25zRGF0YTEuZGF0YSA6IHt9O1xyXG4gIGNvbnN0IHN0b3JlX19sb2dvID0gcHJvcHMuc3RvcmVJbmZvID8gcHJvcHMuc3RvcmVJbmZvLnNsdWcgOiB7fTtcclxuICBjb25zdCBzdG9yZV9fbmFtZSA9IHByb3BzLnN0b3JlSW5mbyA/IHByb3BzLnN0b3JlSW5mby5mb3JtYXR0ZWRfbmFtZSA6IHt9O1xyXG5cclxuICBpZiAoY291cG9uc0RhdGEubGVuZ3RoID4gMikge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPHNlY3Rpb24+XHJcbiAgICAgICAgPEhlYWQ+XHJcbiAgICAgICAgICA8c2NyaXB0XHJcbiAgICAgICAgICAgIGFzeW5jPVwiYXN5bmNcIlxyXG4gICAgICAgICAgICBzcmM9XCJodHRwczovL3d3dy5nb29nbGUuY29tL2Fkc2Vuc2Uvc2VhcmNoL2Fkcy5qc1wiXHJcbiAgICAgICAgICA+PC9zY3JpcHQ+XHJcbiAgICAgICAgICA8c2NyaXB0XHJcbiAgICAgICAgICAgIGFzeW5jXHJcbiAgICAgICAgICAgIHNyYz1cImh0dHBzOi8vY3NlLmdvb2dsZS5jb20vY3NlLmpzP2N4PTM5YmVkOGYzZGU4OGE0ODg1XCJcclxuICAgICAgICAgID48L3NjcmlwdD5cclxuICAgICAgICA8L0hlYWQ+XHJcbiAgICAgICAgPGRpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2xlYXJmaXhcIj5cclxuICAgICAgICAgICAgPGRpdiBpZD1cImFmc2NvbnRhaW5lcjFcIj48L2Rpdj5cclxuICAgICAgICAgICAgPGJyLz5cclxuICAgICAgICAgICAge18ubWFwKGNvdXBvbnNEYXRhLCAodmFsdWUsIGtleSkgPT4ge1xyXG4gICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKHZhbHVlKTtcclxuICAgICAgICAgICAgICBjb25zdCBkaXNjb3VudCA9IHZhbHVlWzE4XTtcclxuICAgICAgICAgICAgICBsZXQgcHJvbW9jb2RlQ2FyZCA9IGZhbHNlO1xyXG5cclxuICAgICAgICAgICAgICBpZiAoa2V5ID4gMCAmJiB2YWx1ZVswXSAhPT0gXCJcIikge1xyXG4gICAgICAgICAgICAgICAgaWYgKHZhbHVlWzhdID09IFwicHJvbW9jb2RlXCIpIHtcclxuICAgICAgICAgICAgICAgICAgcHJvbW9jb2RlQ2FyZCA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGtleT17a2V5fSBjbGFzc05hbWU9e2tleX0+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZGVhbF9fY2FyZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRlYWxfX2Rpc2NvdW50XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkZWFsX19pbmZvXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW1nXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3JjPVwic3RvcmVzX19sb2dvL3t2YWx1ZVsxXX0tbG9nby1zbWFsbC5qcGdcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uRXJyb3I9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlLnRhcmdldC5vbmVycm9yID0gbnVsbDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGUudGFyZ2V0LnNyYyA9IFwiL2ltZy1ub3Rmb3VuZC5qcGdcIjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFsdD17dmFsdWVbMV19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRlYWxfX2Rlc2NcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRlYWxfX2Rlc2MtdHlwZVwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZGVhbF9fZGVzYy10aXRsZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGFcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaHJlZj17dmFsdWVbMTFdfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhLXVybD17dmFsdWVbMTBdfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhLXByb21vY29kZT17dmFsdWVbOV19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGEtc3BlY2llcz17dmFsdWVbOF19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGEtcHJvbW9saW5rPXt2YWx1ZVsxMF19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGEtZnVuYz1cImdldFByb21vQ29kZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGEtd2Vic2l0ZT17dmFsdWVbMl19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRhcmdldD1cIl9ibGFua1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBgT2ZmZXJzQ29kZS5pbiAtIFByb21vIGNvZGUgZm9yIGAgK1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0b3JlX19uYW1lICtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBgIGRlYWwgYCArXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWVbMV1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWw9XCJub2ZvbGxvd1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMz57dmFsdWVbMV19PC9oMz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRlYWxfX2Rlc2MtbWV0YVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZGVhbF9fZGVzYy1tZXRhLWxhc3R1c2VkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpIGNsYXNzTmFtZT1cImZhIGZhLXVzZXJzXCI+PC9pPiZuYnNwO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Yj57TWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogMjAwKSArIDExfTwvYj57XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFBlb3BsZSBVc2VkIFRvZGF5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAmbmJzcDt8Jm5ic3A7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57dmFsdWVbMTVdfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkZWFsX19jdGFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtwcm9tb2NvZGVDYXJkID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhyZWY9e3ZhbHVlWzExXX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhLXVybD17dmFsdWVbMTBdfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGEtcHJvbW9jb2RlPXt2YWx1ZVs5XX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhLXNwZWNpZXM9e3ZhbHVlWzhdfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGEtcHJvbW9saW5rPXt2YWx1ZVsxMF19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YS1mdW5jPVwiZ2V0UHJvbW9Db2RlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJnZXRQcm9tb0NvZGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGEtd2Vic2l0ZT17dmFsdWVbMl19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGFyZ2V0PVwiX2JsYW5rXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBgT2ZmZXJzQ29kZS5pbiAtIFByb21vIGNvZGUgZm9yIGAgK1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RvcmVfX25hbWUgK1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYCBkZWFsIGAgK1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWVbMV1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVsPVwibm9mb2xsb3dcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3ZhbHVlWzldfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rIGhyZWY9e3ZhbHVlWzExXX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBocmVmPXtgL2dvdG9gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhLXVybD17dmFsdWVbMTBdfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhLXByb21vY29kZT17dmFsdWVbOV19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGEtc3BlY2llcz17dmFsdWVbOF19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGEtcHJvbW9saW5rPXt2YWx1ZVsxMF19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGEtZnVuYz1cImdldERlYWxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJnZXREZWFsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YS13ZWJzaXRlPXt2YWx1ZVsyXX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGFyZ2V0PVwiX2JsYW5rXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gZ290b0xpbmsgPSB7dmFsdWVbMTFdfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWw9XCJub2ZvbGxvd1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEdldCBEZWFsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJkZWFsX19jdGEtbWV0YVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dmFsdWVbMTNdICE9PSBcIk5vbmVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJFeHBpcmluZyBJbiBcIiArIGdldFBhcnNlZERhdGUodmFsdWVbMTNdKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogPGFcclxuICAgICAgICAgICAgICAgICAgICAgICAgIGhyZWY9e3ZhbHVlWzExXX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhLXVybD17dmFsdWVbMTBdfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGEtcHJvbW9jb2RlPXt2YWx1ZVs5XX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhLXNwZWNpZXM9e3ZhbHVlWzhdfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGEtcHJvbW9saW5rPXt2YWx1ZVsxMF19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YS1mdW5jPVwic2hvd0RlYWxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGEtd2Vic2l0ZT17dmFsdWVbMl19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdGFyZ2V0PVwiX2JsYW5rXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIEdldCBEZWFsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYT4gKi99XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiA8ZGl2Pnt2YWx1ZVs0XX08L2Rpdj4gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICA8ZGl2IGlkPVwiYWZzY29udGFpbmVyMlwiPjwvZGl2PlxyXG4gICAgICAgICAgIFxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvc2VjdGlvbj5cclxuICAgICk7XHJcbiAgfSBlbHNlIHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxkaXY+XHJcbiAgICAgICAgPGJyIC8+XHJcbiAgICAgICAgPGJyIC8+XHJcbiAgICAgICAgPGJyIC8+XHJcbiAgICAgICAgPGgzPk5vIE5ldyBEZWFscyBPciBDb3Vwb25zIEZvdW5kPC9oMz5cclxuICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG4gIH1cclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IENhcmQ7XHJcbiJdLCJzb3VyY2VSb290IjoiIn0=