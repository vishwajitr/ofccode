webpackHotUpdate_N_E("pages/offers",{

/***/ "./pages/components/Offer/offerCards.js":
/*!**********************************************!*\
  !*** ./pages/components/Offer/offerCards.js ***!
  \**********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! lodash */ "./node_modules/lodash/lodash.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_4__);


var _jsxFileName = "C:\\xampp\\htdocs\\ReactTuts\\NextJS\\ofccode\\pages\\components\\Offer\\offerCards.js",
    _this = undefined,
    _s = $RefreshSig$();






var slug = __webpack_require__(/*! slug */ "./node_modules/slug/slug.js");

var getParsedDate = function getParsedDate(date) {
  return moment__WEBPACK_IMPORTED_MODULE_3___default()(date).startOf("hour").fromNow();
};

var Card = function Card(props) {
  _s();

  var cuelinksOffers = props.cuelinksOffers ? props.cuelinksOffers : {};
  var store__logo = props.storeInfo ? props.storeInfo.slug : {};
  var store__name = props.storeInfo ? props.storeInfo.name : {};
  var limit = props.limit ? props.limit : {};
  react__WEBPACK_IMPORTED_MODULE_1___default.a.useEffect(function () {
    var clickUrl = function clickUrl(target) {
      if (window !== undefined) {
        window.location.href = target;
      }
    };
  });

  if (cuelinksOffers) {
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("section", {
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "clearfix",
        children: lodash__WEBPACK_IMPORTED_MODULE_2___default.a.map(cuelinksOffers, function (value, key) {
          var promocodeCard = false;
          var cuelOffers = {};
          cuelOffers['title'] = value['title'];
          cuelOffers['merchant'] = value['merchant'];
          cuelOffers['id'] = value['id'];
          cuelOffers['categories'] = value['categories'];
          cuelOffers['description'] = value['description'];
          cuelOffers['coupon_code'] = value['coupon_code'];
          cuelOffers['url'] = value['url'];
          cuelOffers['start_date'] = value['start_date'];
          cuelOffers['end_date'] = value['end_date'];
          cuelOffers['offer_added_at'] = value['offer_added_at'];
          cuelOffers['image_url'] = value['image_url'];
          cuelOffers['campaign_name'] = value['campaign_name'];

          if (value['title'] !== "") {
            if (cuelOffers['coupon_code'] != "") {
              promocodeCard = true;
            }

            return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: key,
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "row",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "deal__card",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                    className: "deal__discount",
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                      className: "deal__info",
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
                          src: cuelOffers['image_url'],
                          onError: function onError(e) {
                            e.target.onerror = null;
                            e.target.src = "/img-notfound.jpg";
                          },
                          alt: cuelOffers['title']
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 62,
                          columnNumber: 29
                        }, _this), " "]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 61,
                        columnNumber: 27
                      }, _this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 60,
                      columnNumber: 25
                    }, _this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 59,
                    columnNumber: 23
                  }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                    className: "deal__desc",
                    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                      className: "deal__desc-type"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 74,
                      columnNumber: 25
                    }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                      className: "deal__desc-title",
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h3", {
                        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_4___default.a, {
                          href: '/product/' + slug(cuelOffers['title']),
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                            "data-url": '/product/' + slug(cuelOffers['title']),
                            "data-promolink": '/product/' + slug(cuelOffers['title']),
                            "data-func": "getPromoCode",
                            className: "getPromoCode",
                            target: "_blank",
                            title: "OffersCode.in - Promo code for " + cuelOffers['campaign_name'] + " deal " + cuelOffers['title'],
                            rel: "nofollow",
                            children: [cuelOffers['merchant'], " : ", cuelOffers['title']]
                          }, void 0, true, {
                            fileName: _jsxFileName,
                            lineNumber: 78,
                            columnNumber: 31
                          }, _this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 77,
                          columnNumber: 29
                        }, _this)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 76,
                        columnNumber: 27
                      }, _this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 75,
                      columnNumber: 25
                    }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                      className: "deal__desc-meta",
                      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                        className: "deal__desc-meta-lastused",
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
                          className: "fa fa-users"
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 99,
                          columnNumber: 29
                        }, _this), "\xA0", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("b", {
                          children: Math.floor(Math.random() * 200) + 11
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 100,
                          columnNumber: 29
                        }, _this), " People Used Today"]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 98,
                        columnNumber: 27
                      }, _this), "\xA0|\xA0", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                        className: "deal__desc-meta-lastused",
                        children: cuelOffers['categories']
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 104,
                        columnNumber: 27
                      }, _this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 97,
                      columnNumber: 25
                    }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                      className: "deal__cta",
                      children: promocodeCard ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_4___default.a, {
                          onClick: _this.clickUrl(cuelOffers['url']),
                          href: '/product/' + slug(cuelOffers['title']),
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                            "data-url": '/product/' + slug(cuelOffers['title']) // data-promocode={''}
                            // data-species={''}
                            ,
                            "data-promolink": '/product/' + slug(cuelOffers['title']),
                            "data-func": "getPromoCode",
                            className: "getPromoCode" // data-website={''}
                            ,
                            target: "_blank",
                            title: "OffersCode.in - Promo code for " + cuelOffers['campaign_name'] + " deal " + cuelOffers['title'],
                            rel: "nofollow",
                            children: cuelOffers['coupon_code']
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 113,
                            columnNumber: 33
                          }, _this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 112,
                          columnNumber: 31
                        }, _this)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 111,
                        columnNumber: 29
                      }, _this) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_4___default.a, {
                          href: '/product/' + slug(cuelOffers['title']),
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                            // href={`/goto`}
                            "data-url": '/product/' + slug(cuelOffers['title']) // data-promocode={}
                            // data-species={}
                            // data-promolink={}
                            ,
                            "data-func": "getDeal",
                            className: "getDeal" // data-website={}
                            ,
                            target: "_blank" // gotoLink = {value[11]}
                            ,
                            rel: "nofollow",
                            children: "Get Deal"
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 137,
                            columnNumber: 33
                          }, _this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 136,
                          columnNumber: 31
                        }, _this)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 135,
                        columnNumber: 29
                      }, _this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 109,
                      columnNumber: 25
                    }, _this)]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 73,
                    columnNumber: 23
                  }, _this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 58,
                  columnNumber: 21
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 57,
                columnNumber: 19
              }, _this)
            }, key, false, {
              fileName: _jsxFileName,
              lineNumber: 56,
              columnNumber: 17
            }, _this);
          }
        })
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 34,
        columnNumber: 9
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 33,
      columnNumber: 7
    }, _this);
  } else {
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 169,
        columnNumber: 9
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 170,
        columnNumber: 9
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 171,
        columnNumber: 9
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h3", {
        children: "No New Deals Or Coupons Found"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 172,
        columnNumber: 9
      }, _this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 168,
      columnNumber: 7
    }, _this);
  }
};

_s(Card, "OD7bBpZva5O2jO+Puf00hKivP7c=");

_c = Card;
/* harmony default export */ __webpack_exports__["default"] = (Card);

var _c;

$RefreshReg$(_c, "Card");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvY29tcG9uZW50cy9PZmZlci9vZmZlckNhcmRzLmpzIl0sIm5hbWVzIjpbInNsdWciLCJyZXF1aXJlIiwiZ2V0UGFyc2VkRGF0ZSIsImRhdGUiLCJNb21lbnQiLCJzdGFydE9mIiwiZnJvbU5vdyIsIkNhcmQiLCJwcm9wcyIsImN1ZWxpbmtzT2ZmZXJzIiwic3RvcmVfX2xvZ28iLCJzdG9yZUluZm8iLCJzdG9yZV9fbmFtZSIsIm5hbWUiLCJsaW1pdCIsIlJlYWN0IiwidXNlRWZmZWN0IiwiY2xpY2tVcmwiLCJ0YXJnZXQiLCJ3aW5kb3ciLCJ1bmRlZmluZWQiLCJsb2NhdGlvbiIsImhyZWYiLCJfIiwibWFwIiwidmFsdWUiLCJrZXkiLCJwcm9tb2NvZGVDYXJkIiwiY3VlbE9mZmVycyIsImUiLCJvbmVycm9yIiwic3JjIiwiTWF0aCIsImZsb29yIiwicmFuZG9tIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQSxJQUFJQSxJQUFJLEdBQUdDLG1CQUFPLENBQUMseUNBQUQsQ0FBbEI7O0FBRUEsSUFBTUMsYUFBYSxHQUFHLFNBQWhCQSxhQUFnQixDQUFDQyxJQUFELEVBQVU7QUFDOUIsU0FBT0MsNkNBQU0sQ0FBQ0QsSUFBRCxDQUFOLENBQWFFLE9BQWIsQ0FBcUIsTUFBckIsRUFBNkJDLE9BQTdCLEVBQVA7QUFDRCxDQUZEOztBQU9BLElBQU1DLElBQUksR0FBRyxTQUFQQSxJQUFPLENBQUNDLEtBQUQsRUFBVztBQUFBOztBQUN0QixNQUFNQyxjQUFjLEdBQUdELEtBQUssQ0FBQ0MsY0FBTixHQUF1QkQsS0FBSyxDQUFDQyxjQUE3QixHQUE4QyxFQUFyRTtBQUNBLE1BQU1DLFdBQVcsR0FBR0YsS0FBSyxDQUFDRyxTQUFOLEdBQWtCSCxLQUFLLENBQUNHLFNBQU4sQ0FBZ0JYLElBQWxDLEdBQXlDLEVBQTdEO0FBQ0EsTUFBTVksV0FBVyxHQUFHSixLQUFLLENBQUNHLFNBQU4sR0FBa0JILEtBQUssQ0FBQ0csU0FBTixDQUFnQkUsSUFBbEMsR0FBeUMsRUFBN0Q7QUFDQSxNQUFNQyxLQUFLLEdBQUdOLEtBQUssQ0FBQ00sS0FBTixHQUFjTixLQUFLLENBQUNNLEtBQXBCLEdBQTRCLEVBQTFDO0FBR0FDLDhDQUFLLENBQUNDLFNBQU4sQ0FBZ0IsWUFBTTtBQUNwQixRQUFNQyxRQUFRLEdBQUcsU0FBWEEsUUFBVyxDQUFDQyxNQUFELEVBQVk7QUFDM0IsVUFBSUMsTUFBTSxLQUFLQyxTQUFmLEVBQTBCO0FBQzFCRCxjQUFNLENBQUNFLFFBQVAsQ0FBZ0JDLElBQWhCLEdBQXVCSixNQUF2QjtBQUNDO0FBQ0YsS0FKRDtBQUtELEdBTkQ7O0FBU0EsTUFBSVQsY0FBSixFQUFvQjtBQUNsQix3QkFDRTtBQUFBLDZCQUNFO0FBQUssaUJBQVMsRUFBQyxVQUFmO0FBQUEsa0JBQ0djLDZDQUFDLENBQUNDLEdBQUYsQ0FBTWYsY0FBTixFQUFzQixVQUFDZ0IsS0FBRCxFQUFRQyxHQUFSLEVBQWdCO0FBQ3JDLGNBQUlDLGFBQWEsR0FBRyxLQUFwQjtBQUNBLGNBQUlDLFVBQVUsR0FBRyxFQUFqQjtBQUNBQSxvQkFBVSxDQUFDLE9BQUQsQ0FBVixHQUFzQkgsS0FBSyxDQUFDLE9BQUQsQ0FBM0I7QUFDQUcsb0JBQVUsQ0FBQyxVQUFELENBQVYsR0FBeUJILEtBQUssQ0FBQyxVQUFELENBQTlCO0FBQ0FHLG9CQUFVLENBQUMsSUFBRCxDQUFWLEdBQW1CSCxLQUFLLENBQUMsSUFBRCxDQUF4QjtBQUNBRyxvQkFBVSxDQUFDLFlBQUQsQ0FBVixHQUEyQkgsS0FBSyxDQUFDLFlBQUQsQ0FBaEM7QUFDQUcsb0JBQVUsQ0FBQyxhQUFELENBQVYsR0FBNEJILEtBQUssQ0FBQyxhQUFELENBQWpDO0FBQ0FHLG9CQUFVLENBQUMsYUFBRCxDQUFWLEdBQTRCSCxLQUFLLENBQUMsYUFBRCxDQUFqQztBQUNBRyxvQkFBVSxDQUFDLEtBQUQsQ0FBVixHQUFvQkgsS0FBSyxDQUFDLEtBQUQsQ0FBekI7QUFDQUcsb0JBQVUsQ0FBQyxZQUFELENBQVYsR0FBMkJILEtBQUssQ0FBQyxZQUFELENBQWhDO0FBQ0FHLG9CQUFVLENBQUMsVUFBRCxDQUFWLEdBQXlCSCxLQUFLLENBQUMsVUFBRCxDQUE5QjtBQUNBRyxvQkFBVSxDQUFDLGdCQUFELENBQVYsR0FBK0JILEtBQUssQ0FBQyxnQkFBRCxDQUFwQztBQUNBRyxvQkFBVSxDQUFDLFdBQUQsQ0FBVixHQUEwQkgsS0FBSyxDQUFDLFdBQUQsQ0FBL0I7QUFDQUcsb0JBQVUsQ0FBQyxlQUFELENBQVYsR0FBOEJILEtBQUssQ0FBQyxlQUFELENBQW5DOztBQUVBLGNBQUlBLEtBQUssQ0FBQyxPQUFELENBQUwsS0FBbUIsRUFBdkIsRUFBMkI7QUFDekIsZ0JBQUlHLFVBQVUsQ0FBQyxhQUFELENBQVYsSUFBNkIsRUFBakMsRUFBcUM7QUFDbkNELDJCQUFhLEdBQUcsSUFBaEI7QUFDRDs7QUFDRCxnQ0FDRTtBQUFlLHVCQUFTLEVBQUVELEdBQTFCO0FBQUEscUNBQ0U7QUFBSyx5QkFBUyxFQUFDLEtBQWY7QUFBQSx1Q0FDRTtBQUFLLDJCQUFTLEVBQUMsWUFBZjtBQUFBLDBDQUNFO0FBQUssNkJBQVMsRUFBQyxnQkFBZjtBQUFBLDJDQUNFO0FBQUssK0JBQVMsRUFBQyxZQUFmO0FBQUEsNkNBQ0U7QUFBQSxnREFDRTtBQUNFLDZCQUFHLEVBQUVFLFVBQVUsQ0FBQyxXQUFELENBRGpCO0FBRUUsaUNBQU8sRUFBRSxpQkFBQ0MsQ0FBRCxFQUFPO0FBQ2RBLDZCQUFDLENBQUNYLE1BQUYsQ0FBU1ksT0FBVCxHQUFtQixJQUFuQjtBQUNBRCw2QkFBQyxDQUFDWCxNQUFGLENBQVNhLEdBQVQsR0FBZSxtQkFBZjtBQUNELDJCQUxIO0FBTUUsNkJBQUcsRUFBRUgsVUFBVSxDQUFDLE9BQUQ7QUFOakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FERixFQVFLLEdBUkw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBREYsZUFlRTtBQUFLLDZCQUFTLEVBQUMsWUFBZjtBQUFBLDRDQUNFO0FBQUssK0JBQVMsRUFBQztBQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBREYsZUFFRTtBQUFLLCtCQUFTLEVBQUMsa0JBQWY7QUFBQSw2Q0FDRTtBQUFBLCtDQUNFLHFFQUFDLGdEQUFEO0FBQU0sOEJBQUksRUFBRSxjQUFZNUIsSUFBSSxDQUFDNEIsVUFBVSxDQUFDLE9BQUQsQ0FBWCxDQUE1QjtBQUFBLGlEQUNFO0FBQ0Usd0NBQVUsY0FBWTVCLElBQUksQ0FBQzRCLFVBQVUsQ0FBQyxPQUFELENBQVgsQ0FENUI7QUFFRSw4Q0FBZ0IsY0FBWTVCLElBQUksQ0FBQzRCLFVBQVUsQ0FBQyxPQUFELENBQVgsQ0FGbEM7QUFHRSx5Q0FBVSxjQUhaO0FBSUUscUNBQVMsRUFBQyxjQUpaO0FBS0Usa0NBQU0sRUFBQyxRQUxUO0FBTUUsaUNBQUssRUFDSCxvQ0FDQUEsVUFBVSxDQUFDLGVBQUQsQ0FEVixjQUdBQSxVQUFVLENBQUMsT0FBRCxDQVZkO0FBWUUsK0JBQUcsRUFBQyxVQVpOO0FBQUEsdUNBY0dBLFVBQVUsQ0FBQyxVQUFELENBZGIsU0FjOEJBLFVBQVUsQ0FBQyxPQUFELENBZHhDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFGRixlQXdCRTtBQUFLLCtCQUFTLEVBQUMsaUJBQWY7QUFBQSw4Q0FDRTtBQUFNLGlDQUFTLEVBQUMsMEJBQWhCO0FBQUEsZ0RBQ0U7QUFBRyxtQ0FBUyxFQUFDO0FBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FERix1QkFFRTtBQUFBLG9DQUFJSSxJQUFJLENBQUNDLEtBQUwsQ0FBV0QsSUFBSSxDQUFDRSxNQUFMLEtBQWdCLEdBQTNCLElBQWtDO0FBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQURGLDRCQU9FO0FBQU0saUNBQVMsRUFBQywwQkFBaEI7QUFBQSxrQ0FDR04sVUFBVSxDQUFDLFlBQUQ7QUFEYjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkF4QkYsZUFvQ0U7QUFBSywrQkFBUyxFQUFDLFdBQWY7QUFBQSxnQ0FDR0QsYUFBYSxnQkFDWjtBQUFBLCtDQUNFLHFFQUFDLGdEQUFEO0FBQU0saUNBQU8sRUFBRSxLQUFJLENBQUNWLFFBQUwsQ0FBY1csVUFBVSxDQUFDLEtBQUQsQ0FBeEIsQ0FBZjtBQUFpRCw4QkFBSSxFQUFFLGNBQVk1QixJQUFJLENBQUM0QixVQUFVLENBQUMsT0FBRCxDQUFYLENBQXZFO0FBQUEsaURBQ0U7QUFDRSx3Q0FBVSxjQUFZNUIsSUFBSSxDQUFDNEIsVUFBVSxDQUFDLE9BQUQsQ0FBWCxDQUQ1QixDQUVFO0FBQ0E7QUFIRjtBQUlFLDhDQUFnQixjQUFZNUIsSUFBSSxDQUFDNEIsVUFBVSxDQUFDLE9BQUQsQ0FBWCxDQUpsQztBQUtFLHlDQUFVLGNBTFo7QUFNRSxxQ0FBUyxFQUFDLGNBTlosQ0FPRTtBQVBGO0FBUUUsa0NBQU0sRUFBQyxRQVJUO0FBU0UsaUNBQUssRUFDSCxvQ0FDQUEsVUFBVSxDQUFDLGVBQUQsQ0FEVixjQUdBQSxVQUFVLENBQUMsT0FBRCxDQWJkO0FBZUUsK0JBQUcsRUFBQyxVQWZOO0FBQUEsc0NBaUJHQSxVQUFVLENBQUMsYUFBRDtBQWpCYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBRFksZ0JBeUJaO0FBQUEsK0NBQ0UscUVBQUMsZ0RBQUQ7QUFBTSw4QkFBSSxFQUFFLGNBQVk1QixJQUFJLENBQUM0QixVQUFVLENBQUMsT0FBRCxDQUFYLENBQTVCO0FBQUEsaURBQ0U7QUFDRTtBQUNBLHdDQUFVLGNBQVk1QixJQUFJLENBQUM0QixVQUFVLENBQUMsT0FBRCxDQUFYLENBRjVCLENBR0U7QUFDQTtBQUNBO0FBTEY7QUFNRSx5Q0FBVSxTQU5aO0FBT0UscUNBQVMsRUFBQyxTQVBaLENBUUU7QUFSRjtBQVNFLGtDQUFNLEVBQUMsUUFUVCxDQVVFO0FBVkY7QUFXRSwrQkFBRyxFQUFDLFVBWE47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQTFCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQXBDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGLGVBQVVGLEdBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFERjtBQTBHRDtBQUNGLFNBL0hBO0FBREg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFERjtBQXNJRCxHQXZJRCxNQXVJTztBQUNMLHdCQUNFO0FBQUEsOEJBQ0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGLGVBRUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUZGLGVBR0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUhGLGVBSUU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFERjtBQVFEO0FBQ0YsQ0FqS0Q7O0dBQU1uQixJOztLQUFBQSxJO0FBbUtTQSxtRUFBZiIsImZpbGUiOiJzdGF0aWMvd2VicGFjay9wYWdlcy9vZmZlcnMuNDdmMGE4Y2QxNTg3ZWViYTZlYjMuaG90LXVwZGF0ZS5qcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG5pbXBvcnQgUmVhY3QsIHsgQ29tcG9uZW50LCB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBfIGZyb20gXCJsb2Rhc2hcIjtcclxuaW1wb3J0IE1vbWVudCBmcm9tIFwibW9tZW50XCI7XHJcbmltcG9ydCBMaW5rIGZyb20gXCJuZXh0L2xpbmtcIjtcclxudmFyIHNsdWcgPSByZXF1aXJlKCdzbHVnJylcclxuXHJcbmNvbnN0IGdldFBhcnNlZERhdGUgPSAoZGF0ZSkgPT4ge1xyXG4gIHJldHVybiBNb21lbnQoZGF0ZSkuc3RhcnRPZihcImhvdXJcIikuZnJvbU5vdygpO1xyXG59O1xyXG5cclxuXHJcblxyXG5cclxuY29uc3QgQ2FyZCA9IChwcm9wcykgPT4ge1xyXG4gIGNvbnN0IGN1ZWxpbmtzT2ZmZXJzID0gcHJvcHMuY3VlbGlua3NPZmZlcnMgPyBwcm9wcy5jdWVsaW5rc09mZmVycyA6IHt9O1xyXG4gIGNvbnN0IHN0b3JlX19sb2dvID0gcHJvcHMuc3RvcmVJbmZvID8gcHJvcHMuc3RvcmVJbmZvLnNsdWcgOiB7fTtcclxuICBjb25zdCBzdG9yZV9fbmFtZSA9IHByb3BzLnN0b3JlSW5mbyA/IHByb3BzLnN0b3JlSW5mby5uYW1lIDoge307XHJcbiAgY29uc3QgbGltaXQgPSBwcm9wcy5saW1pdCA/IHByb3BzLmxpbWl0IDoge307XHJcblxyXG5cclxuICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgY2xpY2tVcmwgPSAodGFyZ2V0KSA9PiB7XHJcbiAgICAgIGlmICh3aW5kb3cgIT09IHVuZGVmaW5lZCkge1xyXG4gICAgICB3aW5kb3cubG9jYXRpb24uaHJlZiA9IHRhcmdldDtcclxuICAgICAgfVxyXG4gICAgfTtcclxuICB9KTtcclxuXHJcblxyXG4gIGlmIChjdWVsaW5rc09mZmVycykge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPHNlY3Rpb24+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjbGVhcmZpeFwiPlxyXG4gICAgICAgICAge18ubWFwKGN1ZWxpbmtzT2ZmZXJzLCAodmFsdWUsIGtleSkgPT4ge1xyXG4gICAgICAgICAgICBsZXQgcHJvbW9jb2RlQ2FyZCA9IGZhbHNlO1xyXG4gICAgICAgICAgICBsZXQgY3VlbE9mZmVycyA9IHt9XHJcbiAgICAgICAgICAgIGN1ZWxPZmZlcnNbJ3RpdGxlJ10gPSB2YWx1ZVsndGl0bGUnXTtcclxuICAgICAgICAgICAgY3VlbE9mZmVyc1snbWVyY2hhbnQnXSA9IHZhbHVlWydtZXJjaGFudCddO1xyXG4gICAgICAgICAgICBjdWVsT2ZmZXJzWydpZCddID0gdmFsdWVbJ2lkJ107XHJcbiAgICAgICAgICAgIGN1ZWxPZmZlcnNbJ2NhdGVnb3JpZXMnXSA9IHZhbHVlWydjYXRlZ29yaWVzJ107XHJcbiAgICAgICAgICAgIGN1ZWxPZmZlcnNbJ2Rlc2NyaXB0aW9uJ10gPSB2YWx1ZVsnZGVzY3JpcHRpb24nXTtcclxuICAgICAgICAgICAgY3VlbE9mZmVyc1snY291cG9uX2NvZGUnXSA9IHZhbHVlWydjb3Vwb25fY29kZSddO1xyXG4gICAgICAgICAgICBjdWVsT2ZmZXJzWyd1cmwnXSA9IHZhbHVlWyd1cmwnXTtcclxuICAgICAgICAgICAgY3VlbE9mZmVyc1snc3RhcnRfZGF0ZSddID0gdmFsdWVbJ3N0YXJ0X2RhdGUnXTtcclxuICAgICAgICAgICAgY3VlbE9mZmVyc1snZW5kX2RhdGUnXSA9IHZhbHVlWydlbmRfZGF0ZSddO1xyXG4gICAgICAgICAgICBjdWVsT2ZmZXJzWydvZmZlcl9hZGRlZF9hdCddID0gdmFsdWVbJ29mZmVyX2FkZGVkX2F0J107XHJcbiAgICAgICAgICAgIGN1ZWxPZmZlcnNbJ2ltYWdlX3VybCddID0gdmFsdWVbJ2ltYWdlX3VybCddO1xyXG4gICAgICAgICAgICBjdWVsT2ZmZXJzWydjYW1wYWlnbl9uYW1lJ10gPSB2YWx1ZVsnY2FtcGFpZ25fbmFtZSddO1xyXG5cclxuICAgICAgICAgICAgaWYgKHZhbHVlWyd0aXRsZSddICE9PSBcIlwiKSB7XHJcbiAgICAgICAgICAgICAgaWYgKGN1ZWxPZmZlcnNbJ2NvdXBvbl9jb2RlJ10gIT0gXCJcIikge1xyXG4gICAgICAgICAgICAgICAgcHJvbW9jb2RlQ2FyZCA9IHRydWU7XHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGtleT17a2V5fSBjbGFzc05hbWU9e2tleX0+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkZWFsX19jYXJkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRlYWxfX2Rpc2NvdW50XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZGVhbF9faW5mb1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW1nXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNyYz17Y3VlbE9mZmVyc1snaW1hZ2VfdXJsJ119XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uRXJyb3I9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZS50YXJnZXQub25lcnJvciA9IG51bGw7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZS50YXJnZXQuc3JjID0gXCIvaW1nLW5vdGZvdW5kLmpwZ1wiO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbHQ9e2N1ZWxPZmZlcnNbJ3RpdGxlJ119XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZGVhbF9fZGVzY1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRlYWxfX2Rlc2MtdHlwZVwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRlYWxfX2Rlc2MtdGl0bGVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8aDM+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TGluayBocmVmPXsnL3Byb2R1Y3QvJytzbHVnKGN1ZWxPZmZlcnNbJ3RpdGxlJ10pfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGFcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhLXVybD17Jy9wcm9kdWN0Lycrc2x1ZyhjdWVsT2ZmZXJzWyd0aXRsZSddKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhLXByb21vbGluaz17Jy9wcm9kdWN0Lycrc2x1ZyhjdWVsT2ZmZXJzWyd0aXRsZSddKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhLWZ1bmM9XCJnZXRQcm9tb0NvZGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImdldFByb21vQ29kZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGFyZ2V0PVwiX2JsYW5rXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBgT2ZmZXJzQ29kZS5pbiAtIFByb21vIGNvZGUgZm9yIGAgK1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY3VlbE9mZmVyc1snY2FtcGFpZ25fbmFtZSddICtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGAgZGVhbCBgICtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGN1ZWxPZmZlcnNbJ3RpdGxlJ11cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVsPVwibm9mb2xsb3dcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2N1ZWxPZmZlcnNbJ21lcmNoYW50J119IDoge2N1ZWxPZmZlcnNbJ3RpdGxlJ119XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkZWFsX19kZXNjLW1ldGFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJkZWFsX19kZXNjLW1ldGEtbGFzdHVzZWRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpIGNsYXNzTmFtZT1cImZhIGZhLXVzZXJzXCI+PC9pPiZuYnNwO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGI+e01hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIDIwMCkgKyAxMX08L2I+IFBlb3BsZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgVXNlZCBUb2RheVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAmbmJzcDt8Jm5ic3A7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZGVhbF9fZGVzYy1tZXRhLWxhc3R1c2VkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y3VlbE9mZmVyc1snY2F0ZWdvcmllcyddfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRlYWxfX2N0YVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtwcm9tb2NvZGVDYXJkID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPExpbmsgb25DbGljaz17dGhpcy5jbGlja1VybChjdWVsT2ZmZXJzWyd1cmwnXSl9IGhyZWY9eycvcHJvZHVjdC8nK3NsdWcoY3VlbE9mZmVyc1sndGl0bGUnXSl9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxhXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhLXVybD17Jy9wcm9kdWN0Lycrc2x1ZyhjdWVsT2ZmZXJzWyd0aXRsZSddKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGRhdGEtcHJvbW9jb2RlPXsnJ31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGRhdGEtc3BlY2llcz17Jyd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhLXByb21vbGluaz17Jy9wcm9kdWN0Lycrc2x1ZyhjdWVsT2ZmZXJzWyd0aXRsZSddKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGEtZnVuYz1cImdldFByb21vQ29kZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJnZXRQcm9tb0NvZGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gZGF0YS13ZWJzaXRlPXsnJ31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRhcmdldD1cIl9ibGFua1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGBPZmZlcnNDb2RlLmluIC0gUHJvbW8gY29kZSBmb3IgYCArXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGN1ZWxPZmZlcnNbJ2NhbXBhaWduX25hbWUnXSArXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGAgZGVhbCBgICtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY3VlbE9mZmVyc1sndGl0bGUnXVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVsPVwibm9mb2xsb3dcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjdWVsT2ZmZXJzWydjb3Vwb25fY29kZSddfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rIGhyZWY9eycvcHJvZHVjdC8nK3NsdWcoY3VlbE9mZmVyc1sndGl0bGUnXSl9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxhXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBocmVmPXtgL2dvdG9gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YS11cmw9eycvcHJvZHVjdC8nK3NsdWcoY3VlbE9mZmVyc1sndGl0bGUnXSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBkYXRhLXByb21vY29kZT17fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gZGF0YS1zcGVjaWVzPXt9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBkYXRhLXByb21vbGluaz17fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YS1mdW5jPVwiZ2V0RGVhbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJnZXREZWFsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGRhdGEtd2Vic2l0ZT17fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGFyZ2V0PVwiX2JsYW5rXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGdvdG9MaW5rID0ge3ZhbHVlWzExXX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlbD1cIm5vZm9sbG93XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBHZXQgRGVhbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9KX1cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9zZWN0aW9uPlxyXG4gICAgKTtcclxuICB9IGVsc2Uge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPGRpdj5cclxuICAgICAgICA8YnIgLz5cclxuICAgICAgICA8YnIgLz5cclxuICAgICAgICA8YnIgLz5cclxuICAgICAgICA8aDM+Tm8gTmV3IERlYWxzIE9yIENvdXBvbnMgRm91bmQ8L2gzPlxyXG4gICAgICA8L2Rpdj5cclxuICAgICk7XHJcbiAgfVxyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgQ2FyZDtcclxuIl0sInNvdXJjZVJvb3QiOiIifQ==