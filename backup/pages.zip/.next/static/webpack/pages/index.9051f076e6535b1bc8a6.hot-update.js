webpackHotUpdate_N_E("pages/index",{

/***/ "./pages/components/Offer/offerCards.js":
/*!**********************************************!*\
  !*** ./pages/components/Offer/offerCards.js ***!
  \**********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! lodash */ "./node_modules/lodash/lodash.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_4__);


var _jsxFileName = "C:\\xampp\\htdocs\\ReactTuts\\NextJS\\ofccode\\pages\\components\\Offer\\offerCards.js",
    _this = undefined;






var slug = __webpack_require__(/*! slug */ "./node_modules/slug/slug.js");

var getParsedDate = function getParsedDate(date) {
  return moment__WEBPACK_IMPORTED_MODULE_3___default()(date).startOf("hour").fromNow();
};

var clickUrl = function clickUrl(target) {
  window.location.href = target;
};

var Card = function Card(props) {
  var cuelinksOffers = props.cuelinksOffers ? props.cuelinksOffers : {};
  var store__logo = props.storeInfo ? props.storeInfo.slug : {};
  var store__name = props.storeInfo ? props.storeInfo.name : {};
  var limit = props.limit ? props.limit : {};

  if (cuelinksOffers) {
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("section", {
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "clearfix",
        children: lodash__WEBPACK_IMPORTED_MODULE_2___default.a.map(cuelinksOffers, function (value, key) {
          var promocodeCard = false;
          var cuelOffers = {};
          cuelOffers['title'] = value['title'];
          cuelOffers['merchant'] = value['merchant'];
          cuelOffers['id'] = value['id'];
          cuelOffers['categories'] = value['categories'];
          cuelOffers['description'] = value['description'];
          cuelOffers['coupon_code'] = value['coupon_code'];
          cuelOffers['url'] = value['url'];
          cuelOffers['start_date'] = value['start_date'];
          cuelOffers['end_date'] = value['end_date'];
          cuelOffers['offer_added_at'] = value['offer_added_at'];
          cuelOffers['image_url'] = value['image_url'];
          cuelOffers['campaign_name'] = value['campaign_name'];

          if (value['title'] !== "") {
            if (cuelOffers['coupon_code'] != "") {
              promocodeCard = true;
            }

            return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: key,
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "row",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "deal__card",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                    className: "deal__discount",
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                      className: "deal__info",
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
                          src: cuelOffers['image_url'],
                          onError: function onError(e) {
                            e.target.onerror = null;
                            e.target.src = "/img-notfound.jpg";
                          },
                          alt: cuelOffers['title']
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 53,
                          columnNumber: 29
                        }, _this), " "]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 52,
                        columnNumber: 27
                      }, _this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 51,
                      columnNumber: 25
                    }, _this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 50,
                    columnNumber: 23
                  }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                    className: "deal__desc",
                    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                      className: "deal__desc-type"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 65,
                      columnNumber: 25
                    }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                      className: "deal__desc-title",
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h3", {
                        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_4___default.a, {
                          href: '/product/' + slug(cuelOffers['title']),
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                            "data-url": '/product/' + slug(cuelOffers['title']),
                            "data-promolink": '/product/' + slug(cuelOffers['title']),
                            "data-func": "getPromoCode",
                            className: "getPromoCode",
                            target: "_blank",
                            title: "OffersCode.in - Promo code for " + cuelOffers['campaign_name'] + " deal " + cuelOffers['title'],
                            rel: "nofollow",
                            children: [cuelOffers['merchant'], " : ", cuelOffers['title']]
                          }, void 0, true, {
                            fileName: _jsxFileName,
                            lineNumber: 69,
                            columnNumber: 31
                          }, _this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 68,
                          columnNumber: 29
                        }, _this)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 67,
                        columnNumber: 27
                      }, _this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 66,
                      columnNumber: 25
                    }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                      className: "deal__desc-meta",
                      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                        className: "deal__desc-meta-lastused",
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
                          className: "fa fa-users"
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 90,
                          columnNumber: 29
                        }, _this), "\xA0", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("b", {
                          children: Math.floor(Math.random() * 200) + 11
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 91,
                          columnNumber: 29
                        }, _this), " People Used Today"]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 89,
                        columnNumber: 27
                      }, _this), "\xA0|\xA0", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                        className: "deal__desc-meta-lastused",
                        children: cuelOffers['categories']
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 95,
                        columnNumber: 27
                      }, _this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 88,
                      columnNumber: 25
                    }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                      className: "deal__cta",
                      children: promocodeCard ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_4___default.a, {
                          onClick: clickUrl(cuelOffers['url']),
                          href: '/product/' + slug(cuelOffers['title']),
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                            "data-url": '/product/' + slug(cuelOffers['title']) // data-promocode={''}
                            // data-species={''}
                            ,
                            "data-promolink": '/product/' + slug(cuelOffers['title']),
                            "data-func": "getPromoCode",
                            className: "getPromoCode" // data-website={''}
                            ,
                            target: "_blank",
                            title: "OffersCode.in - Promo code for " + cuelOffers['campaign_name'] + " deal " + cuelOffers['title'],
                            rel: "nofollow",
                            children: cuelOffers['coupon_code']
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 104,
                            columnNumber: 33
                          }, _this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 103,
                          columnNumber: 31
                        }, _this)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 102,
                        columnNumber: 29
                      }, _this) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_4___default.a, {
                          href: '/product/' + slug(cuelOffers['title']),
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                            // href={`/goto`}
                            "data-url": '/product/' + slug(cuelOffers['title']) // data-promocode={}
                            // data-species={}
                            // data-promolink={}
                            ,
                            "data-func": "getDeal",
                            className: "getDeal" // data-website={}
                            ,
                            target: "_blank" // gotoLink = {value[11]}
                            ,
                            rel: "nofollow",
                            children: "Get Deal"
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 128,
                            columnNumber: 33
                          }, _this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 127,
                          columnNumber: 31
                        }, _this)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 126,
                        columnNumber: 29
                      }, _this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 100,
                      columnNumber: 25
                    }, _this)]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 64,
                    columnNumber: 23
                  }, _this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 49,
                  columnNumber: 21
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 48,
                columnNumber: 19
              }, _this)
            }, key, false, {
              fileName: _jsxFileName,
              lineNumber: 47,
              columnNumber: 17
            }, _this);
          }
        })
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 25,
        columnNumber: 9
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 24,
      columnNumber: 7
    }, _this);
  } else {
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 160,
        columnNumber: 9
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 161,
        columnNumber: 9
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 162,
        columnNumber: 9
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h3", {
        children: "No New Deals Or Coupons Found"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 163,
        columnNumber: 9
      }, _this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 159,
      columnNumber: 7
    }, _this);
  }
};

_c = Card;
/* harmony default export */ __webpack_exports__["default"] = (Card);

var _c;

$RefreshReg$(_c, "Card");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvY29tcG9uZW50cy9PZmZlci9vZmZlckNhcmRzLmpzIl0sIm5hbWVzIjpbInNsdWciLCJyZXF1aXJlIiwiZ2V0UGFyc2VkRGF0ZSIsImRhdGUiLCJNb21lbnQiLCJzdGFydE9mIiwiZnJvbU5vdyIsImNsaWNrVXJsIiwidGFyZ2V0Iiwid2luZG93IiwibG9jYXRpb24iLCJocmVmIiwiQ2FyZCIsInByb3BzIiwiY3VlbGlua3NPZmZlcnMiLCJzdG9yZV9fbG9nbyIsInN0b3JlSW5mbyIsInN0b3JlX19uYW1lIiwibmFtZSIsImxpbWl0IiwiXyIsIm1hcCIsInZhbHVlIiwia2V5IiwicHJvbW9jb2RlQ2FyZCIsImN1ZWxPZmZlcnMiLCJlIiwib25lcnJvciIsInNyYyIsIk1hdGgiLCJmbG9vciIsInJhbmRvbSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQSxJQUFJQSxJQUFJLEdBQUdDLG1CQUFPLENBQUMseUNBQUQsQ0FBbEI7O0FBRUEsSUFBTUMsYUFBYSxHQUFHLFNBQWhCQSxhQUFnQixDQUFDQyxJQUFELEVBQVU7QUFDOUIsU0FBT0MsNkNBQU0sQ0FBQ0QsSUFBRCxDQUFOLENBQWFFLE9BQWIsQ0FBcUIsTUFBckIsRUFBNkJDLE9BQTdCLEVBQVA7QUFDRCxDQUZEOztBQUtBLElBQU1DLFFBQVEsR0FBRyxTQUFYQSxRQUFXLENBQUNDLE1BQUQsRUFBWTtBQUMzQkMsUUFBTSxDQUFDQyxRQUFQLENBQWdCQyxJQUFoQixHQUF1QkgsTUFBdkI7QUFDRCxDQUZEOztBQUlBLElBQU1JLElBQUksR0FBRyxTQUFQQSxJQUFPLENBQUNDLEtBQUQsRUFBVztBQUN0QixNQUFNQyxjQUFjLEdBQUdELEtBQUssQ0FBQ0MsY0FBTixHQUF1QkQsS0FBSyxDQUFDQyxjQUE3QixHQUE4QyxFQUFyRTtBQUNBLE1BQU1DLFdBQVcsR0FBR0YsS0FBSyxDQUFDRyxTQUFOLEdBQWtCSCxLQUFLLENBQUNHLFNBQU4sQ0FBZ0JoQixJQUFsQyxHQUF5QyxFQUE3RDtBQUNBLE1BQU1pQixXQUFXLEdBQUdKLEtBQUssQ0FBQ0csU0FBTixHQUFrQkgsS0FBSyxDQUFDRyxTQUFOLENBQWdCRSxJQUFsQyxHQUF5QyxFQUE3RDtBQUNBLE1BQU1DLEtBQUssR0FBR04sS0FBSyxDQUFDTSxLQUFOLEdBQWNOLEtBQUssQ0FBQ00sS0FBcEIsR0FBNEIsRUFBMUM7O0FBRUEsTUFBSUwsY0FBSixFQUFvQjtBQUNsQix3QkFDRTtBQUFBLDZCQUNFO0FBQUssaUJBQVMsRUFBQyxVQUFmO0FBQUEsa0JBQ0dNLDZDQUFDLENBQUNDLEdBQUYsQ0FBTVAsY0FBTixFQUFzQixVQUFDUSxLQUFELEVBQVFDLEdBQVIsRUFBZ0I7QUFDckMsY0FBSUMsYUFBYSxHQUFHLEtBQXBCO0FBQ0EsY0FBSUMsVUFBVSxHQUFHLEVBQWpCO0FBQ0FBLG9CQUFVLENBQUMsT0FBRCxDQUFWLEdBQXNCSCxLQUFLLENBQUMsT0FBRCxDQUEzQjtBQUNBRyxvQkFBVSxDQUFDLFVBQUQsQ0FBVixHQUF5QkgsS0FBSyxDQUFDLFVBQUQsQ0FBOUI7QUFDQUcsb0JBQVUsQ0FBQyxJQUFELENBQVYsR0FBbUJILEtBQUssQ0FBQyxJQUFELENBQXhCO0FBQ0FHLG9CQUFVLENBQUMsWUFBRCxDQUFWLEdBQTJCSCxLQUFLLENBQUMsWUFBRCxDQUFoQztBQUNBRyxvQkFBVSxDQUFDLGFBQUQsQ0FBVixHQUE0QkgsS0FBSyxDQUFDLGFBQUQsQ0FBakM7QUFDQUcsb0JBQVUsQ0FBQyxhQUFELENBQVYsR0FBNEJILEtBQUssQ0FBQyxhQUFELENBQWpDO0FBQ0FHLG9CQUFVLENBQUMsS0FBRCxDQUFWLEdBQW9CSCxLQUFLLENBQUMsS0FBRCxDQUF6QjtBQUNBRyxvQkFBVSxDQUFDLFlBQUQsQ0FBVixHQUEyQkgsS0FBSyxDQUFDLFlBQUQsQ0FBaEM7QUFDQUcsb0JBQVUsQ0FBQyxVQUFELENBQVYsR0FBeUJILEtBQUssQ0FBQyxVQUFELENBQTlCO0FBQ0FHLG9CQUFVLENBQUMsZ0JBQUQsQ0FBVixHQUErQkgsS0FBSyxDQUFDLGdCQUFELENBQXBDO0FBQ0FHLG9CQUFVLENBQUMsV0FBRCxDQUFWLEdBQTBCSCxLQUFLLENBQUMsV0FBRCxDQUEvQjtBQUNBRyxvQkFBVSxDQUFDLGVBQUQsQ0FBVixHQUE4QkgsS0FBSyxDQUFDLGVBQUQsQ0FBbkM7O0FBRUEsY0FBSUEsS0FBSyxDQUFDLE9BQUQsQ0FBTCxLQUFtQixFQUF2QixFQUEyQjtBQUN6QixnQkFBSUcsVUFBVSxDQUFDLGFBQUQsQ0FBVixJQUE2QixFQUFqQyxFQUFxQztBQUNuQ0QsMkJBQWEsR0FBRyxJQUFoQjtBQUNEOztBQUNELGdDQUNFO0FBQWUsdUJBQVMsRUFBRUQsR0FBMUI7QUFBQSxxQ0FDRTtBQUFLLHlCQUFTLEVBQUMsS0FBZjtBQUFBLHVDQUNFO0FBQUssMkJBQVMsRUFBQyxZQUFmO0FBQUEsMENBQ0U7QUFBSyw2QkFBUyxFQUFDLGdCQUFmO0FBQUEsMkNBQ0U7QUFBSywrQkFBUyxFQUFDLFlBQWY7QUFBQSw2Q0FDRTtBQUFBLGdEQUNFO0FBQ0UsNkJBQUcsRUFBRUUsVUFBVSxDQUFDLFdBQUQsQ0FEakI7QUFFRSxpQ0FBTyxFQUFFLGlCQUFDQyxDQUFELEVBQU87QUFDZEEsNkJBQUMsQ0FBQ2xCLE1BQUYsQ0FBU21CLE9BQVQsR0FBbUIsSUFBbkI7QUFDQUQsNkJBQUMsQ0FBQ2xCLE1BQUYsQ0FBU29CLEdBQVQsR0FBZSxtQkFBZjtBQUNELDJCQUxIO0FBTUUsNkJBQUcsRUFBRUgsVUFBVSxDQUFDLE9BQUQ7QUFOakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FERixFQVFLLEdBUkw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBREYsZUFlRTtBQUFLLDZCQUFTLEVBQUMsWUFBZjtBQUFBLDRDQUNFO0FBQUssK0JBQVMsRUFBQztBQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBREYsZUFFRTtBQUFLLCtCQUFTLEVBQUMsa0JBQWY7QUFBQSw2Q0FDRTtBQUFBLCtDQUNFLHFFQUFDLGdEQUFEO0FBQU0sOEJBQUksRUFBRSxjQUFZekIsSUFBSSxDQUFDeUIsVUFBVSxDQUFDLE9BQUQsQ0FBWCxDQUE1QjtBQUFBLGlEQUNFO0FBQ0Usd0NBQVUsY0FBWXpCLElBQUksQ0FBQ3lCLFVBQVUsQ0FBQyxPQUFELENBQVgsQ0FENUI7QUFFRSw4Q0FBZ0IsY0FBWXpCLElBQUksQ0FBQ3lCLFVBQVUsQ0FBQyxPQUFELENBQVgsQ0FGbEM7QUFHRSx5Q0FBVSxjQUhaO0FBSUUscUNBQVMsRUFBQyxjQUpaO0FBS0Usa0NBQU0sRUFBQyxRQUxUO0FBTUUsaUNBQUssRUFDSCxvQ0FDQUEsVUFBVSxDQUFDLGVBQUQsQ0FEVixjQUdBQSxVQUFVLENBQUMsT0FBRCxDQVZkO0FBWUUsK0JBQUcsRUFBQyxVQVpOO0FBQUEsdUNBY0dBLFVBQVUsQ0FBQyxVQUFELENBZGIsU0FjOEJBLFVBQVUsQ0FBQyxPQUFELENBZHhDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFGRixlQXdCRTtBQUFLLCtCQUFTLEVBQUMsaUJBQWY7QUFBQSw4Q0FDRTtBQUFNLGlDQUFTLEVBQUMsMEJBQWhCO0FBQUEsZ0RBQ0U7QUFBRyxtQ0FBUyxFQUFDO0FBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FERix1QkFFRTtBQUFBLG9DQUFJSSxJQUFJLENBQUNDLEtBQUwsQ0FBV0QsSUFBSSxDQUFDRSxNQUFMLEtBQWdCLEdBQTNCLElBQWtDO0FBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQURGLDRCQU9FO0FBQU0saUNBQVMsRUFBQywwQkFBaEI7QUFBQSxrQ0FDR04sVUFBVSxDQUFDLFlBQUQ7QUFEYjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkF4QkYsZUFvQ0U7QUFBSywrQkFBUyxFQUFDLFdBQWY7QUFBQSxnQ0FDR0QsYUFBYSxnQkFDWjtBQUFBLCtDQUNFLHFFQUFDLGdEQUFEO0FBQU0saUNBQU8sRUFBRWpCLFFBQVEsQ0FBQ2tCLFVBQVUsQ0FBQyxLQUFELENBQVgsQ0FBdkI7QUFBNEMsOEJBQUksRUFBRSxjQUFZekIsSUFBSSxDQUFDeUIsVUFBVSxDQUFDLE9BQUQsQ0FBWCxDQUFsRTtBQUFBLGlEQUNFO0FBQ0Usd0NBQVUsY0FBWXpCLElBQUksQ0FBQ3lCLFVBQVUsQ0FBQyxPQUFELENBQVgsQ0FENUIsQ0FFRTtBQUNBO0FBSEY7QUFJRSw4Q0FBZ0IsY0FBWXpCLElBQUksQ0FBQ3lCLFVBQVUsQ0FBQyxPQUFELENBQVgsQ0FKbEM7QUFLRSx5Q0FBVSxjQUxaO0FBTUUscUNBQVMsRUFBQyxjQU5aLENBT0U7QUFQRjtBQVFFLGtDQUFNLEVBQUMsUUFSVDtBQVNFLGlDQUFLLEVBQ0gsb0NBQ0FBLFVBQVUsQ0FBQyxlQUFELENBRFYsY0FHQUEsVUFBVSxDQUFDLE9BQUQsQ0FiZDtBQWVFLCtCQUFHLEVBQUMsVUFmTjtBQUFBLHNDQWlCR0EsVUFBVSxDQUFDLGFBQUQ7QUFqQmI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQURZLGdCQXlCWjtBQUFBLCtDQUNFLHFFQUFDLGdEQUFEO0FBQU0sOEJBQUksRUFBRSxjQUFZekIsSUFBSSxDQUFDeUIsVUFBVSxDQUFDLE9BQUQsQ0FBWCxDQUE1QjtBQUFBLGlEQUNFO0FBQ0U7QUFDQSx3Q0FBVSxjQUFZekIsSUFBSSxDQUFDeUIsVUFBVSxDQUFDLE9BQUQsQ0FBWCxDQUY1QixDQUdFO0FBQ0E7QUFDQTtBQUxGO0FBTUUseUNBQVUsU0FOWjtBQU9FLHFDQUFTLEVBQUMsU0FQWixDQVFFO0FBUkY7QUFTRSxrQ0FBTSxFQUFDLFFBVFQsQ0FVRTtBQVZGO0FBV0UsK0JBQUcsRUFBQyxVQVhOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUExQko7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFwQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERixlQUFVRixHQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREY7QUEwR0Q7QUFDRixTQS9IQTtBQURIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBREY7QUFzSUQsR0F2SUQsTUF1SU87QUFDTCx3QkFDRTtBQUFBLDhCQUNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERixlQUVFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFGRixlQUdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFIRixlQUlFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBREY7QUFRRDtBQUNGLENBdkpEOztLQUFNWCxJO0FBeUpTQSxtRUFBZiIsImZpbGUiOiJzdGF0aWMvd2VicGFjay9wYWdlcy9pbmRleC45MDUxZjA3NmU2NTM1YjFiYzhhNi5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IENvbXBvbmVudCwgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgXyBmcm9tIFwibG9kYXNoXCI7XHJcbmltcG9ydCBNb21lbnQgZnJvbSBcIm1vbWVudFwiO1xyXG5pbXBvcnQgTGluayBmcm9tIFwibmV4dC9saW5rXCI7XHJcbnZhciBzbHVnID0gcmVxdWlyZSgnc2x1ZycpXHJcblxyXG5jb25zdCBnZXRQYXJzZWREYXRlID0gKGRhdGUpID0+IHtcclxuICByZXR1cm4gTW9tZW50KGRhdGUpLnN0YXJ0T2YoXCJob3VyXCIpLmZyb21Ob3coKTtcclxufTtcclxuXHJcblxyXG5jb25zdCBjbGlja1VybCA9ICh0YXJnZXQpID0+IHtcclxuICB3aW5kb3cubG9jYXRpb24uaHJlZiA9IHRhcmdldDtcclxufTtcclxuXHJcbmNvbnN0IENhcmQgPSAocHJvcHMpID0+IHtcclxuICBjb25zdCBjdWVsaW5rc09mZmVycyA9IHByb3BzLmN1ZWxpbmtzT2ZmZXJzID8gcHJvcHMuY3VlbGlua3NPZmZlcnMgOiB7fTtcclxuICBjb25zdCBzdG9yZV9fbG9nbyA9IHByb3BzLnN0b3JlSW5mbyA/IHByb3BzLnN0b3JlSW5mby5zbHVnIDoge307XHJcbiAgY29uc3Qgc3RvcmVfX25hbWUgPSBwcm9wcy5zdG9yZUluZm8gPyBwcm9wcy5zdG9yZUluZm8ubmFtZSA6IHt9O1xyXG4gIGNvbnN0IGxpbWl0ID0gcHJvcHMubGltaXQgPyBwcm9wcy5saW1pdCA6IHt9O1xyXG5cclxuICBpZiAoY3VlbGlua3NPZmZlcnMpIHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxzZWN0aW9uPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2xlYXJmaXhcIj5cclxuICAgICAgICAgIHtfLm1hcChjdWVsaW5rc09mZmVycywgKHZhbHVlLCBrZXkpID0+IHtcclxuICAgICAgICAgICAgbGV0IHByb21vY29kZUNhcmQgPSBmYWxzZTtcclxuICAgICAgICAgICAgbGV0IGN1ZWxPZmZlcnMgPSB7fVxyXG4gICAgICAgICAgICBjdWVsT2ZmZXJzWyd0aXRsZSddID0gdmFsdWVbJ3RpdGxlJ107XHJcbiAgICAgICAgICAgIGN1ZWxPZmZlcnNbJ21lcmNoYW50J10gPSB2YWx1ZVsnbWVyY2hhbnQnXTtcclxuICAgICAgICAgICAgY3VlbE9mZmVyc1snaWQnXSA9IHZhbHVlWydpZCddO1xyXG4gICAgICAgICAgICBjdWVsT2ZmZXJzWydjYXRlZ29yaWVzJ10gPSB2YWx1ZVsnY2F0ZWdvcmllcyddO1xyXG4gICAgICAgICAgICBjdWVsT2ZmZXJzWydkZXNjcmlwdGlvbiddID0gdmFsdWVbJ2Rlc2NyaXB0aW9uJ107XHJcbiAgICAgICAgICAgIGN1ZWxPZmZlcnNbJ2NvdXBvbl9jb2RlJ10gPSB2YWx1ZVsnY291cG9uX2NvZGUnXTtcclxuICAgICAgICAgICAgY3VlbE9mZmVyc1sndXJsJ10gPSB2YWx1ZVsndXJsJ107XHJcbiAgICAgICAgICAgIGN1ZWxPZmZlcnNbJ3N0YXJ0X2RhdGUnXSA9IHZhbHVlWydzdGFydF9kYXRlJ107XHJcbiAgICAgICAgICAgIGN1ZWxPZmZlcnNbJ2VuZF9kYXRlJ10gPSB2YWx1ZVsnZW5kX2RhdGUnXTtcclxuICAgICAgICAgICAgY3VlbE9mZmVyc1snb2ZmZXJfYWRkZWRfYXQnXSA9IHZhbHVlWydvZmZlcl9hZGRlZF9hdCddO1xyXG4gICAgICAgICAgICBjdWVsT2ZmZXJzWydpbWFnZV91cmwnXSA9IHZhbHVlWydpbWFnZV91cmwnXTtcclxuICAgICAgICAgICAgY3VlbE9mZmVyc1snY2FtcGFpZ25fbmFtZSddID0gdmFsdWVbJ2NhbXBhaWduX25hbWUnXTtcclxuXHJcbiAgICAgICAgICAgIGlmICh2YWx1ZVsndGl0bGUnXSAhPT0gXCJcIikge1xyXG4gICAgICAgICAgICAgIGlmIChjdWVsT2ZmZXJzWydjb3Vwb25fY29kZSddICE9IFwiXCIpIHtcclxuICAgICAgICAgICAgICAgIHByb21vY29kZUNhcmQgPSB0cnVlO1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBrZXk9e2tleX0gY2xhc3NOYW1lPXtrZXl9PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvd1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZGVhbF9fY2FyZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkZWFsX19kaXNjb3VudFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRlYWxfX2luZm9cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGltZ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzcmM9e2N1ZWxPZmZlcnNbJ2ltYWdlX3VybCddfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkVycm9yPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGUudGFyZ2V0Lm9uZXJyb3IgPSBudWxsO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGUudGFyZ2V0LnNyYyA9IFwiL2ltZy1ub3Rmb3VuZC5qcGdcIjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWx0PXtjdWVsT2ZmZXJzWyd0aXRsZSddfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz57XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRlYWxfX2Rlc2NcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkZWFsX19kZXNjLXR5cGVcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkZWFsX19kZXNjLXRpdGxlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGgzPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPExpbmsgaHJlZj17Jy9wcm9kdWN0Lycrc2x1ZyhjdWVsT2ZmZXJzWyd0aXRsZSddKX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxhXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YS11cmw9eycvcHJvZHVjdC8nK3NsdWcoY3VlbE9mZmVyc1sndGl0bGUnXSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YS1wcm9tb2xpbms9eycvcHJvZHVjdC8nK3NsdWcoY3VlbE9mZmVyc1sndGl0bGUnXSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YS1mdW5jPVwiZ2V0UHJvbW9Db2RlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJnZXRQcm9tb0NvZGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRhcmdldD1cIl9ibGFua1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYE9mZmVyc0NvZGUuaW4gLSBQcm9tbyBjb2RlIGZvciBgICtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGN1ZWxPZmZlcnNbJ2NhbXBhaWduX25hbWUnXSArXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBgIGRlYWwgYCArXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjdWVsT2ZmZXJzWyd0aXRsZSddXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlbD1cIm5vZm9sbG93XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjdWVsT2ZmZXJzWydtZXJjaGFudCddfSA6IHtjdWVsT2ZmZXJzWyd0aXRsZSddfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZGVhbF9fZGVzYy1tZXRhXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZGVhbF9fZGVzYy1tZXRhLWxhc3R1c2VkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aSBjbGFzc05hbWU9XCJmYSBmYS11c2Vyc1wiPjwvaT4mbmJzcDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxiPntNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiAyMDApICsgMTF9PC9iPiBQZW9wbGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFVzZWQgVG9kYXlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgJm5ic3A7fCZuYnNwO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImRlYWxfX2Rlc2MtbWV0YS1sYXN0dXNlZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2N1ZWxPZmZlcnNbJ2NhdGVnb3JpZXMnXX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkZWFsX19jdGFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7cHJvbW9jb2RlQ2FyZCA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rIG9uQ2xpY2s9e2NsaWNrVXJsKGN1ZWxPZmZlcnNbJ3VybCddKX0gaHJlZj17Jy9wcm9kdWN0Lycrc2x1ZyhjdWVsT2ZmZXJzWyd0aXRsZSddKX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGFcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGEtdXJsPXsnL3Byb2R1Y3QvJytzbHVnKGN1ZWxPZmZlcnNbJ3RpdGxlJ10pfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gZGF0YS1wcm9tb2NvZGU9eycnfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gZGF0YS1zcGVjaWVzPXsnJ31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGEtcHJvbW9saW5rPXsnL3Byb2R1Y3QvJytzbHVnKGN1ZWxPZmZlcnNbJ3RpdGxlJ10pfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YS1mdW5jPVwiZ2V0UHJvbW9Db2RlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImdldFByb21vQ29kZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBkYXRhLXdlYnNpdGU9eycnfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGFyZ2V0PVwiX2JsYW5rXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYE9mZmVyc0NvZGUuaW4gLSBQcm9tbyBjb2RlIGZvciBgICtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY3VlbE9mZmVyc1snY2FtcGFpZ25fbmFtZSddICtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYCBkZWFsIGAgK1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjdWVsT2ZmZXJzWyd0aXRsZSddXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWw9XCJub2ZvbGxvd1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2N1ZWxPZmZlcnNbJ2NvdXBvbl9jb2RlJ119XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9hPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPExpbmsgaHJlZj17Jy9wcm9kdWN0Lycrc2x1ZyhjdWVsT2ZmZXJzWyd0aXRsZSddKX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGFcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGhyZWY9e2AvZ290b2B9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhLXVybD17Jy9wcm9kdWN0Lycrc2x1ZyhjdWVsT2ZmZXJzWyd0aXRsZSddKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGRhdGEtcHJvbW9jb2RlPXt9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBkYXRhLXNwZWNpZXM9e31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGRhdGEtcHJvbW9saW5rPXt9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhLWZ1bmM9XCJnZXREZWFsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImdldERlYWxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gZGF0YS13ZWJzaXRlPXt9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0YXJnZXQ9XCJfYmxhbmtcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gZ290b0xpbmsgPSB7dmFsdWVbMTFdfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVsPVwibm9mb2xsb3dcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEdldCBEZWFsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9hPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH0pfVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L3NlY3Rpb24+XHJcbiAgICApO1xyXG4gIH0gZWxzZSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8ZGl2PlxyXG4gICAgICAgIDxiciAvPlxyXG4gICAgICAgIDxiciAvPlxyXG4gICAgICAgIDxiciAvPlxyXG4gICAgICAgIDxoMz5ObyBOZXcgRGVhbHMgT3IgQ291cG9ucyBGb3VuZDwvaDM+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgKTtcclxuICB9XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBDYXJkO1xyXG4iXSwic291cmNlUm9vdCI6IiJ9