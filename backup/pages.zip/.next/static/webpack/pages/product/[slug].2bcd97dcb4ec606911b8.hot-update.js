webpackHotUpdate_N_E("pages/product/[slug]",{

/***/ "./pages/product/[slug]/index.js":
/*!***************************************!*\
  !*** ./pages/product/[slug]/index.js ***!
  \***************************************/
/*! exports provided: __N_SSP, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__N_SSP", function() { return __N_SSP; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/router */ "./node_modules/next/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/head */ "./node_modules/next/head.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! next */ "next");
/* harmony import */ var next__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! lodash */ "./node_modules/lodash/lodash.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_7__);


var _jsxFileName = "C:\\xampp\\htdocs\\ReactTuts\\NextJS\\ofccode\\pages\\product\\[slug]\\index.js",
    _this = undefined;








 // import OffersPageContent from "../components/OffersPageContent";

var Papa = __webpack_require__(/*! papaparse */ "./node_modules/papaparse/papaparse.min.js");

var getParsedDate = function getParsedDate() {
  var d = new Date();
  var month = new Array();
  month[0] = "January";
  month[1] = "February";
  month[2] = "March";
  month[3] = "April";
  month[4] = "May";
  month[5] = "June";
  month[6] = "July";
  month[7] = "August";
  month[8] = "September";
  month[9] = "October";
  month[10] = "November";
  month[11] = "December";
  return month[d.getMonth()];
};

var ProductPage = function ProductPage(props) {
  var current__url = props.prod__url;
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: "ProdPage",
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_head__WEBPACK_IMPORTED_MODULE_3___default.a, {
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("link", {
        rel: "canonical",
        href: current__url
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 34,
        columnNumber: 1
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
        property: "og:site_name",
        content: "offerscode.in"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 35,
        columnNumber: 1
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
        property: "og:type",
        content: "website"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 36,
        columnNumber: 1
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
        property: "og:title",
        content: "Offerscode.in"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 37,
        columnNumber: 1
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
        property: "og:url",
        content: current__url
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 38,
        columnNumber: 1
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
        property: "og:description",
        content: props.results.title
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 39,
        columnNumber: 1
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
        property: "og:locale",
        content: "en_US"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 43,
        columnNumber: 1
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
        property: "og:image",
        content: props.results.image_url
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 44,
        columnNumber: 1
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
        property: "og:article:published_time",
        content: ""
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 45,
        columnNumber: 1
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
        name: "twitter:card",
        content: "summary_large_image"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 48,
        columnNumber: 1
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
        name: "twitter:description",
        content: props.results.title
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 49,
        columnNumber: 1
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
        name: "twitter:title",
        content: "offerscode.in"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 53,
        columnNumber: 1
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
        name: "twitter:site",
        content: "@offerscodein"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 54,
        columnNumber: 1
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
        name: "twitter:creator",
        content: "@offerscodein"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 55,
        columnNumber: 1
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
        itemProp: "name",
        content: "offerscode.in"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 58,
        columnNumber: 1
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
        itemProp: "description",
        content: props.results.title
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 59,
        columnNumber: 1
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
        itemProp: "image",
        content: props.results.image_url
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 63,
        columnNumber: 1
      }, _this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 33,
      columnNumber: 1
    }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "prodCard",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "prodCard__image",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
          src: props.results.image_url
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 69,
          columnNumber: 5
        }, _this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 68,
        columnNumber: 3
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "prodCard__field prodCard__name",
        children: props.results.title
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 71,
        columnNumber: 3
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "prodCard__field prodCard__cat",
        children: ["Categories: ", props.results.categories]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 72,
        columnNumber: 3
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "prodCard__field prodCard__brand",
        children: ["Brand: ", props.results.merchant]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 73,
        columnNumber: 3
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "prodCard__field prodCard__desc",
        children: ["Description: ", props.results.description]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 74,
        columnNumber: 3
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "prodCard__field prodCard__couponcode",
        children: ["Coupon_Code: ", props.results.coupon_code]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 75,
        columnNumber: 3
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "prodCard__field prodCard__buybtn",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
          href: props.results.url,
          target: "_blank",
          children: "Buy Now"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 76,
          columnNumber: 53
        }, _this), " "]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 76,
        columnNumber: 3
      }, _this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 67,
      columnNumber: 3
    }, _this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 32,
    columnNumber: 8
  }, _this);
};

_c = ProductPage;
var __N_SSP = true;
/* harmony default export */ __webpack_exports__["default"] = (ProductPage);

var _c;

$RefreshReg$(_c, "ProductPage");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvcHJvZHVjdC9bc2x1Z10vaW5kZXguanMiXSwibmFtZXMiOlsiUGFwYSIsInJlcXVpcmUiLCJnZXRQYXJzZWREYXRlIiwiZCIsIkRhdGUiLCJtb250aCIsIkFycmF5IiwiZ2V0TW9udGgiLCJQcm9kdWN0UGFnZSIsInByb3BzIiwiY3VycmVudF9fdXJsIiwicHJvZF9fdXJsIiwicmVzdWx0cyIsInRpdGxlIiwiaW1hZ2VfdXJsIiwiY2F0ZWdvcmllcyIsIm1lcmNoYW50IiwiZGVzY3JpcHRpb24iLCJjb3Vwb25fY29kZSIsInVybCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Q0FFQTs7QUFDQSxJQUFJQSxJQUFJLEdBQUdDLG1CQUFPLENBQUMsNERBQUQsQ0FBbEI7O0FBRUEsSUFBTUMsYUFBYSxHQUFHLFNBQWhCQSxhQUFnQixHQUFNO0FBQzFCLE1BQUlDLENBQUMsR0FBRyxJQUFJQyxJQUFKLEVBQVI7QUFDQSxNQUFJQyxLQUFLLEdBQUcsSUFBSUMsS0FBSixFQUFaO0FBQ0FELE9BQUssQ0FBQyxDQUFELENBQUwsR0FBVyxTQUFYO0FBQ0FBLE9BQUssQ0FBQyxDQUFELENBQUwsR0FBVyxVQUFYO0FBQ0FBLE9BQUssQ0FBQyxDQUFELENBQUwsR0FBVyxPQUFYO0FBQ0FBLE9BQUssQ0FBQyxDQUFELENBQUwsR0FBVyxPQUFYO0FBQ0FBLE9BQUssQ0FBQyxDQUFELENBQUwsR0FBVyxLQUFYO0FBQ0FBLE9BQUssQ0FBQyxDQUFELENBQUwsR0FBVyxNQUFYO0FBQ0FBLE9BQUssQ0FBQyxDQUFELENBQUwsR0FBVyxNQUFYO0FBQ0FBLE9BQUssQ0FBQyxDQUFELENBQUwsR0FBVyxRQUFYO0FBQ0FBLE9BQUssQ0FBQyxDQUFELENBQUwsR0FBVyxXQUFYO0FBQ0FBLE9BQUssQ0FBQyxDQUFELENBQUwsR0FBVyxTQUFYO0FBQ0FBLE9BQUssQ0FBQyxFQUFELENBQUwsR0FBWSxVQUFaO0FBQ0FBLE9BQUssQ0FBQyxFQUFELENBQUwsR0FBWSxVQUFaO0FBQ0EsU0FBT0EsS0FBSyxDQUFDRixDQUFDLENBQUNJLFFBQUYsRUFBRCxDQUFaO0FBQ0QsQ0FoQkQ7O0FBa0JBLElBQU1DLFdBQVcsR0FBRyxTQUFkQSxXQUFjLENBQUNDLEtBQUQsRUFBVztBQUMvQixNQUFJQyxZQUFZLEdBQUdELEtBQUssQ0FBQ0UsU0FBekI7QUFDQSxzQkFBTztBQUFLLGFBQVMsRUFBQyxVQUFmO0FBQUEsNEJBQ1AscUVBQUMsZ0RBQUQ7QUFBQSw4QkFDQTtBQUFNLFdBQUcsRUFBQyxXQUFWO0FBQXNCLFlBQUksRUFBRUQ7QUFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURBLGVBRUE7QUFBTSxnQkFBUSxFQUFDLGNBQWY7QUFBOEIsZUFBTyxFQUFDO0FBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFGQSxlQUdBO0FBQU0sZ0JBQVEsRUFBQyxTQUFmO0FBQXlCLGVBQU8sRUFBQztBQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBSEEsZUFJQTtBQUFNLGdCQUFRLEVBQUMsVUFBZjtBQUEwQixlQUFPLEVBQUM7QUFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUpBLGVBS0E7QUFBTSxnQkFBUSxFQUFDLFFBQWY7QUFBd0IsZUFBTyxFQUFFQTtBQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBTEEsZUFNQTtBQUNFLGdCQUFRLEVBQUMsZ0JBRFg7QUFFRSxlQUFPLEVBQUVELEtBQUssQ0FBQ0csT0FBTixDQUFjQztBQUZ6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBTkEsZUFVQTtBQUFNLGdCQUFRLEVBQUMsV0FBZjtBQUEyQixlQUFPLEVBQUM7QUFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVZBLGVBV0E7QUFBTSxnQkFBUSxFQUFDLFVBQWY7QUFBMEIsZUFBTyxFQUFFSixLQUFLLENBQUNHLE9BQU4sQ0FBY0U7QUFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVhBLGVBWUE7QUFBTSxnQkFBUSxFQUFDLDJCQUFmO0FBQTJDLGVBQU8sRUFBQztBQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBWkEsZUFlQTtBQUFNLFlBQUksRUFBQyxjQUFYO0FBQTBCLGVBQU8sRUFBQztBQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZkEsZUFnQkE7QUFDRSxZQUFJLEVBQUMscUJBRFA7QUFFRSxlQUFPLEVBQUVMLEtBQUssQ0FBQ0csT0FBTixDQUFjQztBQUZ6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBaEJBLGVBb0JBO0FBQU0sWUFBSSxFQUFDLGVBQVg7QUFBMkIsZUFBTyxFQUFDO0FBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFwQkEsZUFxQkE7QUFBTSxZQUFJLEVBQUMsY0FBWDtBQUEwQixlQUFPLEVBQUM7QUFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXJCQSxlQXNCQTtBQUFNLFlBQUksRUFBQyxpQkFBWDtBQUE2QixlQUFPLEVBQUM7QUFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXRCQSxlQXlCQTtBQUFNLGdCQUFRLEVBQUMsTUFBZjtBQUFzQixlQUFPLEVBQUM7QUFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXpCQSxlQTBCQTtBQUNFLGdCQUFRLEVBQUMsYUFEWDtBQUVFLGVBQU8sRUFBRUosS0FBSyxDQUFDRyxPQUFOLENBQWNDO0FBRnpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUExQkEsZUE4QkE7QUFBTSxnQkFBUSxFQUFDLE9BQWY7QUFBdUIsZUFBTyxFQUFFSixLQUFLLENBQUNHLE9BQU4sQ0FBY0U7QUFBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTlCQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFETyxlQW1DTDtBQUFLLGVBQVMsRUFBQyxVQUFmO0FBQUEsOEJBQ0E7QUFBSyxpQkFBUyxFQUFDLGlCQUFmO0FBQUEsK0JBQ0U7QUFBSyxhQUFHLEVBQUVMLEtBQUssQ0FBQ0csT0FBTixDQUFjRTtBQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURBLGVBSUE7QUFBSyxpQkFBUyxFQUFDLGdDQUFmO0FBQUEsa0JBQWlETCxLQUFLLENBQUNHLE9BQU4sQ0FBY0M7QUFBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUpBLGVBS0E7QUFBSyxpQkFBUyxFQUFDLCtCQUFmO0FBQUEsbUNBQTRESixLQUFLLENBQUNHLE9BQU4sQ0FBY0csVUFBMUU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBTEEsZUFNQTtBQUFLLGlCQUFTLEVBQUMsaUNBQWY7QUFBQSw4QkFBeUROLEtBQUssQ0FBQ0csT0FBTixDQUFjSSxRQUF2RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFOQSxlQU9BO0FBQUssaUJBQVMsRUFBQyxnQ0FBZjtBQUFBLG9DQUE4RFAsS0FBSyxDQUFDRyxPQUFOLENBQWNLLFdBQTVFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVBBLGVBUUE7QUFBSyxpQkFBUyxFQUFDLHNDQUFmO0FBQUEsb0NBQW9FUixLQUFLLENBQUNHLE9BQU4sQ0FBY00sV0FBbEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUkEsZUFTQTtBQUFLLGlCQUFTLEVBQUMsa0NBQWY7QUFBQSxnQ0FBa0Q7QUFBRyxjQUFJLEVBQUVULEtBQUssQ0FBQ0csT0FBTixDQUFjTyxHQUF2QjtBQUE0QixnQkFBTSxFQUFDLFFBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFUQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFuQ0s7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVA7QUErQ0MsQ0FqREQ7O0tBQU1YLFc7O0FBbUVTQSwwRUFBZiIsImZpbGUiOiJzdGF0aWMvd2VicGFjay9wYWdlcy9wcm9kdWN0L1tzbHVnXS4yYmNkOTdkY2I0ZWM2MDY5MTFiOC5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IENvbXBvbmVudCB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tIFwibmV4dC9yb3V0ZXJcIjtcclxuaW1wb3J0IEhlYWQgZnJvbSBcIm5leHQvaGVhZFwiO1xyXG5pbXBvcnQgR2V0U2VydmVyU2lkZVByb3BzIGZyb20gXCJuZXh0XCI7XHJcbmltcG9ydCBOZXh0UGFnZSBmcm9tIFwibmV4dFwiO1xyXG5pbXBvcnQgTGluayBmcm9tIFwibmV4dC9saW5rXCI7XHJcbmltcG9ydCBheGlvcyBmcm9tIFwiYXhpb3NcIjtcclxuaW1wb3J0IF8gZnJvbSBcImxvZGFzaFwiO1xyXG4vLyBpbXBvcnQgT2ZmZXJzUGFnZUNvbnRlbnQgZnJvbSBcIi4uL2NvbXBvbmVudHMvT2ZmZXJzUGFnZUNvbnRlbnRcIjtcclxudmFyIFBhcGEgPSByZXF1aXJlKFwicGFwYXBhcnNlXCIpO1xyXG5cclxuY29uc3QgZ2V0UGFyc2VkRGF0ZSA9ICgpID0+IHtcclxuICB2YXIgZCA9IG5ldyBEYXRlKCk7XHJcbiAgdmFyIG1vbnRoID0gbmV3IEFycmF5KCk7XHJcbiAgbW9udGhbMF0gPSBcIkphbnVhcnlcIjtcclxuICBtb250aFsxXSA9IFwiRmVicnVhcnlcIjtcclxuICBtb250aFsyXSA9IFwiTWFyY2hcIjtcclxuICBtb250aFszXSA9IFwiQXByaWxcIjtcclxuICBtb250aFs0XSA9IFwiTWF5XCI7XHJcbiAgbW9udGhbNV0gPSBcIkp1bmVcIjtcclxuICBtb250aFs2XSA9IFwiSnVseVwiO1xyXG4gIG1vbnRoWzddID0gXCJBdWd1c3RcIjtcclxuICBtb250aFs4XSA9IFwiU2VwdGVtYmVyXCI7XHJcbiAgbW9udGhbOV0gPSBcIk9jdG9iZXJcIjtcclxuICBtb250aFsxMF0gPSBcIk5vdmVtYmVyXCI7XHJcbiAgbW9udGhbMTFdID0gXCJEZWNlbWJlclwiO1xyXG4gIHJldHVybiBtb250aFtkLmdldE1vbnRoKCldO1xyXG59O1xyXG5cclxuY29uc3QgUHJvZHVjdFBhZ2UgPSAocHJvcHMpID0+IHtcclxubGV0IGN1cnJlbnRfX3VybCA9IHByb3BzLnByb2RfX3VybDtcclxucmV0dXJuIDxkaXYgY2xhc3NOYW1lPVwiUHJvZFBhZ2VcIj5cclxuPEhlYWQ+XHJcbjxsaW5rIHJlbD1cImNhbm9uaWNhbFwiIGhyZWY9e2N1cnJlbnRfX3VybH0gLz5cclxuPG1ldGEgcHJvcGVydHk9XCJvZzpzaXRlX25hbWVcIiBjb250ZW50PVwib2ZmZXJzY29kZS5pblwiIC8+XHJcbjxtZXRhIHByb3BlcnR5PVwib2c6dHlwZVwiIGNvbnRlbnQ9XCJ3ZWJzaXRlXCIgLz5cclxuPG1ldGEgcHJvcGVydHk9XCJvZzp0aXRsZVwiIGNvbnRlbnQ9XCJPZmZlcnNjb2RlLmluXCIgLz5cclxuPG1ldGEgcHJvcGVydHk9XCJvZzp1cmxcIiBjb250ZW50PXtjdXJyZW50X191cmx9IC8+XHJcbjxtZXRhXHJcbiAgcHJvcGVydHk9XCJvZzpkZXNjcmlwdGlvblwiXHJcbiAgY29udGVudD17cHJvcHMucmVzdWx0cy50aXRsZX1cclxuLz5cclxuPG1ldGEgcHJvcGVydHk9XCJvZzpsb2NhbGVcIiBjb250ZW50PVwiZW5fVVNcIiAvPlxyXG48bWV0YSBwcm9wZXJ0eT1cIm9nOmltYWdlXCIgY29udGVudD17cHJvcHMucmVzdWx0cy5pbWFnZV91cmx9IC8+XHJcbjxtZXRhIHByb3BlcnR5PVwib2c6YXJ0aWNsZTpwdWJsaXNoZWRfdGltZVwiIGNvbnRlbnQ9XCJcIiAvPlxyXG5cclxuey8qIDwhLS0gdHdpdHRlciBNZXRhIHRhZ3MgLS0+ICovfVxyXG48bWV0YSBuYW1lPVwidHdpdHRlcjpjYXJkXCIgY29udGVudD1cInN1bW1hcnlfbGFyZ2VfaW1hZ2VcIiAvPlxyXG48bWV0YVxyXG4gIG5hbWU9XCJ0d2l0dGVyOmRlc2NyaXB0aW9uXCJcclxuICBjb250ZW50PXtwcm9wcy5yZXN1bHRzLnRpdGxlfVxyXG4vPlxyXG48bWV0YSBuYW1lPVwidHdpdHRlcjp0aXRsZVwiIGNvbnRlbnQ9XCJvZmZlcnNjb2RlLmluXCIgLz5cclxuPG1ldGEgbmFtZT1cInR3aXR0ZXI6c2l0ZVwiIGNvbnRlbnQ9XCJAb2ZmZXJzY29kZWluXCIgLz5cclxuPG1ldGEgbmFtZT1cInR3aXR0ZXI6Y3JlYXRvclwiIGNvbnRlbnQ9XCJAb2ZmZXJzY29kZWluXCIgLz5cclxuXHJcbnsvKiA8IS0tIFN0YW5kYXJkIE1ldGEgdGFncyAtLT4gKi99XHJcbjxtZXRhIGl0ZW1Qcm9wPVwibmFtZVwiIGNvbnRlbnQ9XCJvZmZlcnNjb2RlLmluXCIgLz5cclxuPG1ldGFcclxuICBpdGVtUHJvcD1cImRlc2NyaXB0aW9uXCJcclxuICBjb250ZW50PXtwcm9wcy5yZXN1bHRzLnRpdGxlfVxyXG4vPlxyXG48bWV0YSBpdGVtUHJvcD1cImltYWdlXCIgY29udGVudD17cHJvcHMucmVzdWx0cy5pbWFnZV91cmx9IC8+XHJcblxyXG5cclxuPC9IZWFkPiAgIFxyXG4gIDxkaXYgY2xhc3NOYW1lPVwicHJvZENhcmRcIj5cclxuICA8ZGl2IGNsYXNzTmFtZT1cInByb2RDYXJkX19pbWFnZVwiPlxyXG4gICAgPGltZyBzcmM9e3Byb3BzLnJlc3VsdHMuaW1hZ2VfdXJsfS8+XHJcbiAgPC9kaXY+XHJcbiAgPGRpdiBjbGFzc05hbWU9XCJwcm9kQ2FyZF9fZmllbGQgcHJvZENhcmRfX25hbWVcIj57cHJvcHMucmVzdWx0cy50aXRsZX08L2Rpdj5cclxuICA8ZGl2IGNsYXNzTmFtZT1cInByb2RDYXJkX19maWVsZCBwcm9kQ2FyZF9fY2F0XCI+Q2F0ZWdvcmllczoge3Byb3BzLnJlc3VsdHMuY2F0ZWdvcmllc308L2Rpdj5cclxuICA8ZGl2IGNsYXNzTmFtZT1cInByb2RDYXJkX19maWVsZCBwcm9kQ2FyZF9fYnJhbmRcIj5CcmFuZDoge3Byb3BzLnJlc3VsdHMubWVyY2hhbnR9PC9kaXY+XHJcbiAgPGRpdiBjbGFzc05hbWU9XCJwcm9kQ2FyZF9fZmllbGQgcHJvZENhcmRfX2Rlc2NcIj5EZXNjcmlwdGlvbjoge3Byb3BzLnJlc3VsdHMuZGVzY3JpcHRpb259PC9kaXY+XHJcbiAgPGRpdiBjbGFzc05hbWU9XCJwcm9kQ2FyZF9fZmllbGQgcHJvZENhcmRfX2NvdXBvbmNvZGVcIj5Db3Vwb25fQ29kZToge3Byb3BzLnJlc3VsdHMuY291cG9uX2NvZGV9PC9kaXY+XHJcbiAgPGRpdiBjbGFzc05hbWU9XCJwcm9kQ2FyZF9fZmllbGQgcHJvZENhcmRfX2J1eWJ0blwiPjxhIGhyZWY9e3Byb3BzLnJlc3VsdHMudXJsfSB0YXJnZXQ9XCJfYmxhbmtcIj5CdXkgTm93PC9hPiA8L2Rpdj5cclxuICA8L2Rpdj5cclxuICA8L2Rpdj47XHJcbn07XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0U2VydmVyU2lkZVByb3BzKHsgcGFyYW1zIH0pIHtcclxuICBjb25zdCBTbHVnID0gcGFyYW1zLnNsdWc7XHJcbiAgY29uc29sZS5sb2cocGFyYW1zKVxyXG4gICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2goYGh0dHBzOi8vb2ZjY29kZS1hcGktZ2l0LW1haW4tc3BvcnR5YnJ1aDE5OTAudmVyY2VsLmFwcC9hcGkvZnJvbnQvb2ZmZXJzL3Byb2RfX2J5X19zbHVnP3E9JHtTbHVnfWApXHJcbiAgICBjb25zdCBqc29uID0gYXdhaXQgcmVzLmpzb24oKVxyXG4gICAgLy8gY29uc29sZS5sb2coanNvbilcclxuICAgIFxyXG4gICAgcmV0dXJuIHsgXHJcbiAgICAgIHByb3BzOiB7XHJcbiAgICAgICAgcmVzdWx0czoganNvbi5yZXN1bHRzWzBdLFxyXG4gICAgICAgIHByb2RfX3VybCA6ICcvL29mZmVyc2NvZGUuaW4vcHJvZHVjdC8nICtwYXJhbXMuc2x1Z1xyXG4gICAgICB9LFxyXG4gICAgfTtcclxuICB9XHJcbiAgXHJcblxyXG5leHBvcnQgZGVmYXVsdCBQcm9kdWN0UGFnZTtcclxuIl0sInNvdXJjZVJvb3QiOiIifQ==