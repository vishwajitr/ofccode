webpackHotUpdate_N_E("pages/product/[slug]",{

/***/ "./pages/product/[slug]/index.js":
/*!***************************************!*\
  !*** ./pages/product/[slug]/index.js ***!
  \***************************************/
/*! exports provided: __N_SSP, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__N_SSP", function() { return __N_SSP; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/router */ "./node_modules/next/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/head */ "./node_modules/next/head.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! next */ "next");
/* harmony import */ var next__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! lodash */ "./node_modules/lodash/lodash.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_7__);


var _jsxFileName = "C:\\xampp\\htdocs\\ReactTuts\\NextJS\\ofccode\\pages\\product\\[slug]\\index.js",
    _this = undefined;








 // import OffersPageContent from "../components/OffersPageContent";

var Papa = __webpack_require__(/*! papaparse */ "./node_modules/papaparse/papaparse.min.js");

var getParsedDate = function getParsedDate() {
  var d = new Date();
  var month = new Array();
  month[0] = "January";
  month[1] = "February";
  month[2] = "March";
  month[3] = "April";
  month[4] = "May";
  month[5] = "June";
  month[6] = "July";
  month[7] = "August";
  month[8] = "September";
  month[9] = "October";
  month[10] = "November";
  month[11] = "December";
  return month[d.getMonth()];
};

var ProductPage = function ProductPage(props) {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: "ProdPage",
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_head__WEBPACK_IMPORTED_MODULE_3___default.a, {
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("link", {
        rel: "canonical",
        href: props.prod__url
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 34,
        columnNumber: 1
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
        property: "og:site_name",
        content: "offerscode.in"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 35,
        columnNumber: 1
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
        property: "og:type",
        content: "website"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 36,
        columnNumber: 1
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
        property: "og:title",
        content: "Offerscode.in"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 37,
        columnNumber: 1
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
        property: "og:url",
        content: props.prod__url
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 38,
        columnNumber: 1
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
        property: "og:description",
        content: props.results.title
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 39,
        columnNumber: 1
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
        property: "og:locale",
        content: "en_US"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 43,
        columnNumber: 1
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
        property: "og:image",
        content: props.results.image_url
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 44,
        columnNumber: 1
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
        property: "og:article:published_time",
        content: ""
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 45,
        columnNumber: 1
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
        name: "twitter:card",
        content: "summary_large_image"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 48,
        columnNumber: 1
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
        name: "twitter:description",
        content: props.results.title
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 49,
        columnNumber: 1
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
        name: "twitter:title",
        content: "offerscode.in"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 53,
        columnNumber: 1
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
        name: "twitter:site",
        content: "@offerscodein"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 54,
        columnNumber: 1
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
        name: "twitter:creator",
        content: "@offerscodein"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 55,
        columnNumber: 1
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
        itemProp: "name",
        content: "offerscode.in"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 58,
        columnNumber: 1
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
        itemProp: "description",
        content: props.results.title
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 59,
        columnNumber: 1
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
        itemProp: "image",
        content: props.results.image_url
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 63,
        columnNumber: 1
      }, _this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 33,
      columnNumber: 1
    }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "prodCard",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "prodCard__image",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
          src: props.results.image_url
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 69,
          columnNumber: 5
        }, _this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 68,
        columnNumber: 3
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "prodCard__field prodCard__name",
        children: props.results.title
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 71,
        columnNumber: 3
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "prodCard__field prodCard__cat",
        children: ["Categories: ", props.results.categories]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 72,
        columnNumber: 3
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "prodCard__field prodCard__brand",
        children: ["Brand: ", props.results.merchant]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 73,
        columnNumber: 3
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "prodCard__field prodCard__desc",
        children: ["Description: ", props.results.description]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 74,
        columnNumber: 3
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "prodCard__field prodCard__buybtn",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
          href: props.results.link,
          target: "_blank",
          children: "Buy Now"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 76,
          columnNumber: 53
        }, _this), " "]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 76,
        columnNumber: 3
      }, _this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 67,
      columnNumber: 3
    }, _this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 32,
    columnNumber: 8
  }, _this);
};

_c = ProductPage;
var __N_SSP = true;
/* harmony default export */ __webpack_exports__["default"] = (ProductPage);

var _c;

$RefreshReg$(_c, "ProductPage");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvcHJvZHVjdC9bc2x1Z10vaW5kZXguanMiXSwibmFtZXMiOlsiUGFwYSIsInJlcXVpcmUiLCJnZXRQYXJzZWREYXRlIiwiZCIsIkRhdGUiLCJtb250aCIsIkFycmF5IiwiZ2V0TW9udGgiLCJQcm9kdWN0UGFnZSIsInByb3BzIiwicHJvZF9fdXJsIiwicmVzdWx0cyIsInRpdGxlIiwiaW1hZ2VfdXJsIiwiY2F0ZWdvcmllcyIsIm1lcmNoYW50IiwiZGVzY3JpcHRpb24iLCJsaW5rIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtDQUVBOztBQUNBLElBQUlBLElBQUksR0FBR0MsbUJBQU8sQ0FBQyw0REFBRCxDQUFsQjs7QUFFQSxJQUFNQyxhQUFhLEdBQUcsU0FBaEJBLGFBQWdCLEdBQU07QUFDMUIsTUFBSUMsQ0FBQyxHQUFHLElBQUlDLElBQUosRUFBUjtBQUNBLE1BQUlDLEtBQUssR0FBRyxJQUFJQyxLQUFKLEVBQVo7QUFDQUQsT0FBSyxDQUFDLENBQUQsQ0FBTCxHQUFXLFNBQVg7QUFDQUEsT0FBSyxDQUFDLENBQUQsQ0FBTCxHQUFXLFVBQVg7QUFDQUEsT0FBSyxDQUFDLENBQUQsQ0FBTCxHQUFXLE9BQVg7QUFDQUEsT0FBSyxDQUFDLENBQUQsQ0FBTCxHQUFXLE9BQVg7QUFDQUEsT0FBSyxDQUFDLENBQUQsQ0FBTCxHQUFXLEtBQVg7QUFDQUEsT0FBSyxDQUFDLENBQUQsQ0FBTCxHQUFXLE1BQVg7QUFDQUEsT0FBSyxDQUFDLENBQUQsQ0FBTCxHQUFXLE1BQVg7QUFDQUEsT0FBSyxDQUFDLENBQUQsQ0FBTCxHQUFXLFFBQVg7QUFDQUEsT0FBSyxDQUFDLENBQUQsQ0FBTCxHQUFXLFdBQVg7QUFDQUEsT0FBSyxDQUFDLENBQUQsQ0FBTCxHQUFXLFNBQVg7QUFDQUEsT0FBSyxDQUFDLEVBQUQsQ0FBTCxHQUFZLFVBQVo7QUFDQUEsT0FBSyxDQUFDLEVBQUQsQ0FBTCxHQUFZLFVBQVo7QUFDQSxTQUFPQSxLQUFLLENBQUNGLENBQUMsQ0FBQ0ksUUFBRixFQUFELENBQVo7QUFDRCxDQWhCRDs7QUFrQkEsSUFBTUMsV0FBVyxHQUFHLFNBQWRBLFdBQWMsQ0FBQ0MsS0FBRCxFQUFXO0FBRS9CLHNCQUFPO0FBQUssYUFBUyxFQUFDLFVBQWY7QUFBQSw0QkFDUCxxRUFBQyxnREFBRDtBQUFBLDhCQUNBO0FBQU0sV0FBRyxFQUFDLFdBQVY7QUFBc0IsWUFBSSxFQUFFQSxLQUFLLENBQUNDO0FBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFEQSxlQUVBO0FBQU0sZ0JBQVEsRUFBQyxjQUFmO0FBQThCLGVBQU8sRUFBQztBQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRkEsZUFHQTtBQUFNLGdCQUFRLEVBQUMsU0FBZjtBQUF5QixlQUFPLEVBQUM7QUFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUhBLGVBSUE7QUFBTSxnQkFBUSxFQUFDLFVBQWY7QUFBMEIsZUFBTyxFQUFDO0FBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFKQSxlQUtBO0FBQU0sZ0JBQVEsRUFBQyxRQUFmO0FBQXdCLGVBQU8sRUFBRUQsS0FBSyxDQUFDQztBQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBTEEsZUFNQTtBQUNFLGdCQUFRLEVBQUMsZ0JBRFg7QUFFRSxlQUFPLEVBQUVELEtBQUssQ0FBQ0UsT0FBTixDQUFjQztBQUZ6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBTkEsZUFVQTtBQUFNLGdCQUFRLEVBQUMsV0FBZjtBQUEyQixlQUFPLEVBQUM7QUFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVZBLGVBV0E7QUFBTSxnQkFBUSxFQUFDLFVBQWY7QUFBMEIsZUFBTyxFQUFFSCxLQUFLLENBQUNFLE9BQU4sQ0FBY0U7QUFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVhBLGVBWUE7QUFBTSxnQkFBUSxFQUFDLDJCQUFmO0FBQTJDLGVBQU8sRUFBQztBQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBWkEsZUFlQTtBQUFNLFlBQUksRUFBQyxjQUFYO0FBQTBCLGVBQU8sRUFBQztBQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZkEsZUFnQkE7QUFDRSxZQUFJLEVBQUMscUJBRFA7QUFFRSxlQUFPLEVBQUVKLEtBQUssQ0FBQ0UsT0FBTixDQUFjQztBQUZ6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBaEJBLGVBb0JBO0FBQU0sWUFBSSxFQUFDLGVBQVg7QUFBMkIsZUFBTyxFQUFDO0FBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFwQkEsZUFxQkE7QUFBTSxZQUFJLEVBQUMsY0FBWDtBQUEwQixlQUFPLEVBQUM7QUFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXJCQSxlQXNCQTtBQUFNLFlBQUksRUFBQyxpQkFBWDtBQUE2QixlQUFPLEVBQUM7QUFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXRCQSxlQXlCQTtBQUFNLGdCQUFRLEVBQUMsTUFBZjtBQUFzQixlQUFPLEVBQUM7QUFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXpCQSxlQTBCQTtBQUNFLGdCQUFRLEVBQUMsYUFEWDtBQUVFLGVBQU8sRUFBRUgsS0FBSyxDQUFDRSxPQUFOLENBQWNDO0FBRnpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUExQkEsZUE4QkE7QUFBTSxnQkFBUSxFQUFDLE9BQWY7QUFBdUIsZUFBTyxFQUFFSCxLQUFLLENBQUNFLE9BQU4sQ0FBY0U7QUFBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTlCQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFETyxlQW1DTDtBQUFLLGVBQVMsRUFBQyxVQUFmO0FBQUEsOEJBQ0E7QUFBSyxpQkFBUyxFQUFDLGlCQUFmO0FBQUEsK0JBQ0U7QUFBSyxhQUFHLEVBQUVKLEtBQUssQ0FBQ0UsT0FBTixDQUFjRTtBQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURBLGVBSUE7QUFBSyxpQkFBUyxFQUFDLGdDQUFmO0FBQUEsa0JBQWlESixLQUFLLENBQUNFLE9BQU4sQ0FBY0M7QUFBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUpBLGVBS0E7QUFBSyxpQkFBUyxFQUFDLCtCQUFmO0FBQUEsbUNBQTRESCxLQUFLLENBQUNFLE9BQU4sQ0FBY0csVUFBMUU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBTEEsZUFNQTtBQUFLLGlCQUFTLEVBQUMsaUNBQWY7QUFBQSw4QkFBeURMLEtBQUssQ0FBQ0UsT0FBTixDQUFjSSxRQUF2RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFOQSxlQU9BO0FBQUssaUJBQVMsRUFBQyxnQ0FBZjtBQUFBLG9DQUE4RE4sS0FBSyxDQUFDRSxPQUFOLENBQWNLLFdBQTVFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVBBLGVBU0E7QUFBSyxpQkFBUyxFQUFDLGtDQUFmO0FBQUEsZ0NBQWtEO0FBQUcsY0FBSSxFQUFFUCxLQUFLLENBQUNFLE9BQU4sQ0FBY00sSUFBdkI7QUFBNkIsZ0JBQU0sRUFBQyxRQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVEE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBbkNLO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFQO0FBK0NDLENBakREOztLQUFNVCxXOztBQW1FU0EsMEVBQWYiLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvcHJvZHVjdC9bc2x1Z10uNmFmYThjZTNlODljOGQzNGYxZDkuaG90LXVwZGF0ZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyBDb21wb25lbnQgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSBcIm5leHQvcm91dGVyXCI7XHJcbmltcG9ydCBIZWFkIGZyb20gXCJuZXh0L2hlYWRcIjtcclxuaW1wb3J0IEdldFNlcnZlclNpZGVQcm9wcyBmcm9tIFwibmV4dFwiO1xyXG5pbXBvcnQgTmV4dFBhZ2UgZnJvbSBcIm5leHRcIjtcclxuaW1wb3J0IExpbmsgZnJvbSBcIm5leHQvbGlua1wiO1xyXG5pbXBvcnQgYXhpb3MgZnJvbSBcImF4aW9zXCI7XHJcbmltcG9ydCBfIGZyb20gXCJsb2Rhc2hcIjtcclxuLy8gaW1wb3J0IE9mZmVyc1BhZ2VDb250ZW50IGZyb20gXCIuLi9jb21wb25lbnRzL09mZmVyc1BhZ2VDb250ZW50XCI7XHJcbnZhciBQYXBhID0gcmVxdWlyZShcInBhcGFwYXJzZVwiKTtcclxuXHJcbmNvbnN0IGdldFBhcnNlZERhdGUgPSAoKSA9PiB7XHJcbiAgdmFyIGQgPSBuZXcgRGF0ZSgpO1xyXG4gIHZhciBtb250aCA9IG5ldyBBcnJheSgpO1xyXG4gIG1vbnRoWzBdID0gXCJKYW51YXJ5XCI7XHJcbiAgbW9udGhbMV0gPSBcIkZlYnJ1YXJ5XCI7XHJcbiAgbW9udGhbMl0gPSBcIk1hcmNoXCI7XHJcbiAgbW9udGhbM10gPSBcIkFwcmlsXCI7XHJcbiAgbW9udGhbNF0gPSBcIk1heVwiO1xyXG4gIG1vbnRoWzVdID0gXCJKdW5lXCI7XHJcbiAgbW9udGhbNl0gPSBcIkp1bHlcIjtcclxuICBtb250aFs3XSA9IFwiQXVndXN0XCI7XHJcbiAgbW9udGhbOF0gPSBcIlNlcHRlbWJlclwiO1xyXG4gIG1vbnRoWzldID0gXCJPY3RvYmVyXCI7XHJcbiAgbW9udGhbMTBdID0gXCJOb3ZlbWJlclwiO1xyXG4gIG1vbnRoWzExXSA9IFwiRGVjZW1iZXJcIjtcclxuICByZXR1cm4gbW9udGhbZC5nZXRNb250aCgpXTtcclxufTtcclxuXHJcbmNvbnN0IFByb2R1Y3RQYWdlID0gKHByb3BzKSA9PiB7XHJcblxyXG5yZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJQcm9kUGFnZVwiPlxyXG48SGVhZD5cclxuPGxpbmsgcmVsPVwiY2Fub25pY2FsXCIgaHJlZj17cHJvcHMucHJvZF9fdXJsfSAvPlxyXG48bWV0YSBwcm9wZXJ0eT1cIm9nOnNpdGVfbmFtZVwiIGNvbnRlbnQ9XCJvZmZlcnNjb2RlLmluXCIgLz5cclxuPG1ldGEgcHJvcGVydHk9XCJvZzp0eXBlXCIgY29udGVudD1cIndlYnNpdGVcIiAvPlxyXG48bWV0YSBwcm9wZXJ0eT1cIm9nOnRpdGxlXCIgY29udGVudD1cIk9mZmVyc2NvZGUuaW5cIiAvPlxyXG48bWV0YSBwcm9wZXJ0eT1cIm9nOnVybFwiIGNvbnRlbnQ9e3Byb3BzLnByb2RfX3VybH0gLz5cclxuPG1ldGFcclxuICBwcm9wZXJ0eT1cIm9nOmRlc2NyaXB0aW9uXCJcclxuICBjb250ZW50PXtwcm9wcy5yZXN1bHRzLnRpdGxlfVxyXG4vPlxyXG48bWV0YSBwcm9wZXJ0eT1cIm9nOmxvY2FsZVwiIGNvbnRlbnQ9XCJlbl9VU1wiIC8+XHJcbjxtZXRhIHByb3BlcnR5PVwib2c6aW1hZ2VcIiBjb250ZW50PXtwcm9wcy5yZXN1bHRzLmltYWdlX3VybH0gLz5cclxuPG1ldGEgcHJvcGVydHk9XCJvZzphcnRpY2xlOnB1Ymxpc2hlZF90aW1lXCIgY29udGVudD1cIlwiIC8+XHJcblxyXG57LyogPCEtLSB0d2l0dGVyIE1ldGEgdGFncyAtLT4gKi99XHJcbjxtZXRhIG5hbWU9XCJ0d2l0dGVyOmNhcmRcIiBjb250ZW50PVwic3VtbWFyeV9sYXJnZV9pbWFnZVwiIC8+XHJcbjxtZXRhXHJcbiAgbmFtZT1cInR3aXR0ZXI6ZGVzY3JpcHRpb25cIlxyXG4gIGNvbnRlbnQ9e3Byb3BzLnJlc3VsdHMudGl0bGV9XHJcbi8+XHJcbjxtZXRhIG5hbWU9XCJ0d2l0dGVyOnRpdGxlXCIgY29udGVudD1cIm9mZmVyc2NvZGUuaW5cIiAvPlxyXG48bWV0YSBuYW1lPVwidHdpdHRlcjpzaXRlXCIgY29udGVudD1cIkBvZmZlcnNjb2RlaW5cIiAvPlxyXG48bWV0YSBuYW1lPVwidHdpdHRlcjpjcmVhdG9yXCIgY29udGVudD1cIkBvZmZlcnNjb2RlaW5cIiAvPlxyXG5cclxuey8qIDwhLS0gU3RhbmRhcmQgTWV0YSB0YWdzIC0tPiAqL31cclxuPG1ldGEgaXRlbVByb3A9XCJuYW1lXCIgY29udGVudD1cIm9mZmVyc2NvZGUuaW5cIiAvPlxyXG48bWV0YVxyXG4gIGl0ZW1Qcm9wPVwiZGVzY3JpcHRpb25cIlxyXG4gIGNvbnRlbnQ9e3Byb3BzLnJlc3VsdHMudGl0bGV9XHJcbi8+XHJcbjxtZXRhIGl0ZW1Qcm9wPVwiaW1hZ2VcIiBjb250ZW50PXtwcm9wcy5yZXN1bHRzLmltYWdlX3VybH0gLz5cclxuXHJcblxyXG48L0hlYWQ+ICAgXHJcbiAgPGRpdiBjbGFzc05hbWU9XCJwcm9kQ2FyZFwiPlxyXG4gIDxkaXYgY2xhc3NOYW1lPVwicHJvZENhcmRfX2ltYWdlXCI+XHJcbiAgICA8aW1nIHNyYz17cHJvcHMucmVzdWx0cy5pbWFnZV91cmx9Lz5cclxuICA8L2Rpdj5cclxuICA8ZGl2IGNsYXNzTmFtZT1cInByb2RDYXJkX19maWVsZCBwcm9kQ2FyZF9fbmFtZVwiPntwcm9wcy5yZXN1bHRzLnRpdGxlfTwvZGl2PlxyXG4gIDxkaXYgY2xhc3NOYW1lPVwicHJvZENhcmRfX2ZpZWxkIHByb2RDYXJkX19jYXRcIj5DYXRlZ29yaWVzOiB7cHJvcHMucmVzdWx0cy5jYXRlZ29yaWVzfTwvZGl2PlxyXG4gIDxkaXYgY2xhc3NOYW1lPVwicHJvZENhcmRfX2ZpZWxkIHByb2RDYXJkX19icmFuZFwiPkJyYW5kOiB7cHJvcHMucmVzdWx0cy5tZXJjaGFudH08L2Rpdj5cclxuICA8ZGl2IGNsYXNzTmFtZT1cInByb2RDYXJkX19maWVsZCBwcm9kQ2FyZF9fZGVzY1wiPkRlc2NyaXB0aW9uOiB7cHJvcHMucmVzdWx0cy5kZXNjcmlwdGlvbn08L2Rpdj5cclxuICB7LyogPGRpdiBjbGFzc05hbWU9XCJwcm9kQ2FyZF9fZmllbGQgcHJvZENhcmRfX2NvdXBvbmNvZGVcIj5Db3Vwb25fQ29kZToge3Byb3BzLnJlc3VsdHMuY291cG9uX2NvZGV9PC9kaXY+ICovfVxyXG4gIDxkaXYgY2xhc3NOYW1lPVwicHJvZENhcmRfX2ZpZWxkIHByb2RDYXJkX19idXlidG5cIj48YSBocmVmPXtwcm9wcy5yZXN1bHRzLmxpbmt9IHRhcmdldD1cIl9ibGFua1wiPkJ1eSBOb3c8L2E+IDwvZGl2PlxyXG4gIDwvZGl2PlxyXG4gIDwvZGl2PjtcclxufTtcclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRTZXJ2ZXJTaWRlUHJvcHMoeyBwYXJhbXMgfSkge1xyXG4gIGNvbnN0IFNsdWcgPSBwYXJhbXMuc2x1ZztcclxuICBjb25zb2xlLmxvZyhwYXJhbXMpXHJcbiAgICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaChgaHR0cDovL2xvY2FsaG9zdDozMDAyL2FwaS9mcm9udC9vZmZlcnMvcHJvZF9fYnlfX3NsdWc/cT0ke1NsdWd9YClcclxuICAgIGNvbnN0IGpzb24gPSBhd2FpdCByZXMuanNvbigpXHJcbiAgICAvLyBjb25zb2xlLmxvZyhqc29uKVxyXG4gICAgXHJcbiAgICByZXR1cm4geyBcclxuICAgICAgcHJvcHM6IHtcclxuICAgICAgICByZXN1bHRzOiBqc29uLnJlc3VsdHNbMF0sXHJcbiAgICAgICAgcHJvZF9fdXJsIDogJy8vb2ZmZXJzY29kZS5pbi9wcm9kdWN0LycgK3BhcmFtcy5zbHVnXHJcbiAgICAgIH0sXHJcbiAgICB9O1xyXG4gIH1cclxuICBcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFByb2R1Y3RQYWdlO1xyXG4iXSwic291cmNlUm9vdCI6IiJ9