webpackHotUpdate_N_E("pages/product/[slug]",{

/***/ "./pages/product/[slug]/index.js":
/*!***************************************!*\
  !*** ./pages/product/[slug]/index.js ***!
  \***************************************/
/*! exports provided: __N_SSP, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__N_SSP", function() { return __N_SSP; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/router */ "./node_modules/next/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/head */ "./node_modules/next/head.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! next */ "next");
/* harmony import */ var next__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! lodash */ "./node_modules/lodash/lodash.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_7__);


var _jsxFileName = "C:\\xampp\\htdocs\\ReactTuts\\NextJS\\ofccode\\pages\\product\\[slug]\\index.js",
    _this = undefined;








 // import OffersPageContent from "../components/OffersPageContent";

var Papa = __webpack_require__(/*! papaparse */ "./node_modules/papaparse/papaparse.min.js");

var getParsedDate = function getParsedDate() {
  var d = new Date();
  var month = new Array();
  month[0] = "January";
  month[1] = "February";
  month[2] = "March";
  month[3] = "April";
  month[4] = "May";
  month[5] = "June";
  month[6] = "July";
  month[7] = "August";
  month[8] = "September";
  month[9] = "October";
  month[10] = "November";
  month[11] = "December";
  return month[d.getMonth()];
};

var ProductPage = function ProductPage(props) {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: "ProdPage",
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_head__WEBPACK_IMPORTED_MODULE_3___default.a, {
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("link", {
        rel: "canonical",
        href: props.prod__url
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 34,
        columnNumber: 1
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
        property: "og:site_name",
        content: "offerscode.in"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 35,
        columnNumber: 1
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
        property: "og:type",
        content: "website"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 36,
        columnNumber: 1
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
        property: "og:title",
        content: "Offerscode.in"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 37,
        columnNumber: 1
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
        property: "og:url",
        content: props.prod__url
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 38,
        columnNumber: 1
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
        property: "og:description",
        content: props.results.title
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 39,
        columnNumber: 1
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
        property: "og:locale",
        content: "en_US"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 43,
        columnNumber: 1
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
        property: "og:image",
        content: props.results.image_url
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 44,
        columnNumber: 1
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
        property: "og:article:published_time",
        content: ""
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 45,
        columnNumber: 1
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
        name: "twitter:card",
        content: "summary_large_image"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 48,
        columnNumber: 1
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
        name: "twitter:description",
        content: props.results.title
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 49,
        columnNumber: 1
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
        name: "twitter:title",
        content: "offerscode.in"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 53,
        columnNumber: 1
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
        name: "twitter:site",
        content: "@offerscodein"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 54,
        columnNumber: 1
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
        name: "twitter:creator",
        content: "@offerscodein"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 55,
        columnNumber: 1
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
        itemProp: "name",
        content: "offerscode.in"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 58,
        columnNumber: 1
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
        itemProp: "description",
        content: props.results.title
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 59,
        columnNumber: 1
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
        itemProp: "image",
        content: props.results.image_url
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 63,
        columnNumber: 1
      }, _this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 33,
      columnNumber: 1
    }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "prodCard",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "prodCard__image",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
          src: "/stores__logo/" + props.results.merchant + "-logo-large.jpg"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 69,
          columnNumber: 5
        }, _this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 68,
        columnNumber: 3
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "prodCard__field prodCard__name",
        children: props.results.title
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 75,
        columnNumber: 3
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "prodCard__field prodCard__brand",
        children: ["Brand: ", props.results.merchant]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 77,
        columnNumber: 3
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "prodCard__field prodCard__desc",
        children: ["Description: ", props.results.description]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 78,
        columnNumber: 3
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "prodCard__field prodCard__buybtn",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
          href: props.results.link,
          target: "_blank",
          children: "Buy Now"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 80,
          columnNumber: 53
        }, _this), " "]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 80,
        columnNumber: 3
      }, _this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 67,
      columnNumber: 3
    }, _this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 32,
    columnNumber: 8
  }, _this);
};

_c = ProductPage;
var __N_SSP = true;
/* harmony default export */ __webpack_exports__["default"] = (ProductPage);

var _c;

$RefreshReg$(_c, "ProductPage");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvcHJvZHVjdC9bc2x1Z10vaW5kZXguanMiXSwibmFtZXMiOlsiUGFwYSIsInJlcXVpcmUiLCJnZXRQYXJzZWREYXRlIiwiZCIsIkRhdGUiLCJtb250aCIsIkFycmF5IiwiZ2V0TW9udGgiLCJQcm9kdWN0UGFnZSIsInByb3BzIiwicHJvZF9fdXJsIiwicmVzdWx0cyIsInRpdGxlIiwiaW1hZ2VfdXJsIiwibWVyY2hhbnQiLCJkZXNjcmlwdGlvbiIsImxpbmsiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0NBRUE7O0FBQ0EsSUFBSUEsSUFBSSxHQUFHQyxtQkFBTyxDQUFDLDREQUFELENBQWxCOztBQUVBLElBQU1DLGFBQWEsR0FBRyxTQUFoQkEsYUFBZ0IsR0FBTTtBQUMxQixNQUFJQyxDQUFDLEdBQUcsSUFBSUMsSUFBSixFQUFSO0FBQ0EsTUFBSUMsS0FBSyxHQUFHLElBQUlDLEtBQUosRUFBWjtBQUNBRCxPQUFLLENBQUMsQ0FBRCxDQUFMLEdBQVcsU0FBWDtBQUNBQSxPQUFLLENBQUMsQ0FBRCxDQUFMLEdBQVcsVUFBWDtBQUNBQSxPQUFLLENBQUMsQ0FBRCxDQUFMLEdBQVcsT0FBWDtBQUNBQSxPQUFLLENBQUMsQ0FBRCxDQUFMLEdBQVcsT0FBWDtBQUNBQSxPQUFLLENBQUMsQ0FBRCxDQUFMLEdBQVcsS0FBWDtBQUNBQSxPQUFLLENBQUMsQ0FBRCxDQUFMLEdBQVcsTUFBWDtBQUNBQSxPQUFLLENBQUMsQ0FBRCxDQUFMLEdBQVcsTUFBWDtBQUNBQSxPQUFLLENBQUMsQ0FBRCxDQUFMLEdBQVcsUUFBWDtBQUNBQSxPQUFLLENBQUMsQ0FBRCxDQUFMLEdBQVcsV0FBWDtBQUNBQSxPQUFLLENBQUMsQ0FBRCxDQUFMLEdBQVcsU0FBWDtBQUNBQSxPQUFLLENBQUMsRUFBRCxDQUFMLEdBQVksVUFBWjtBQUNBQSxPQUFLLENBQUMsRUFBRCxDQUFMLEdBQVksVUFBWjtBQUNBLFNBQU9BLEtBQUssQ0FBQ0YsQ0FBQyxDQUFDSSxRQUFGLEVBQUQsQ0FBWjtBQUNELENBaEJEOztBQWtCQSxJQUFNQyxXQUFXLEdBQUcsU0FBZEEsV0FBYyxDQUFDQyxLQUFELEVBQVc7QUFFL0Isc0JBQU87QUFBSyxhQUFTLEVBQUMsVUFBZjtBQUFBLDRCQUNQLHFFQUFDLGdEQUFEO0FBQUEsOEJBQ0E7QUFBTSxXQUFHLEVBQUMsV0FBVjtBQUFzQixZQUFJLEVBQUVBLEtBQUssQ0FBQ0M7QUFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURBLGVBRUE7QUFBTSxnQkFBUSxFQUFDLGNBQWY7QUFBOEIsZUFBTyxFQUFDO0FBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFGQSxlQUdBO0FBQU0sZ0JBQVEsRUFBQyxTQUFmO0FBQXlCLGVBQU8sRUFBQztBQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBSEEsZUFJQTtBQUFNLGdCQUFRLEVBQUMsVUFBZjtBQUEwQixlQUFPLEVBQUM7QUFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUpBLGVBS0E7QUFBTSxnQkFBUSxFQUFDLFFBQWY7QUFBd0IsZUFBTyxFQUFFRCxLQUFLLENBQUNDO0FBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFMQSxlQU1BO0FBQ0UsZ0JBQVEsRUFBQyxnQkFEWDtBQUVFLGVBQU8sRUFBRUQsS0FBSyxDQUFDRSxPQUFOLENBQWNDO0FBRnpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFOQSxlQVVBO0FBQU0sZ0JBQVEsRUFBQyxXQUFmO0FBQTJCLGVBQU8sRUFBQztBQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVkEsZUFXQTtBQUFNLGdCQUFRLEVBQUMsVUFBZjtBQUEwQixlQUFPLEVBQUVILEtBQUssQ0FBQ0UsT0FBTixDQUFjRTtBQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBWEEsZUFZQTtBQUFNLGdCQUFRLEVBQUMsMkJBQWY7QUFBMkMsZUFBTyxFQUFDO0FBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFaQSxlQWVBO0FBQU0sWUFBSSxFQUFDLGNBQVg7QUFBMEIsZUFBTyxFQUFDO0FBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFmQSxlQWdCQTtBQUNFLFlBQUksRUFBQyxxQkFEUDtBQUVFLGVBQU8sRUFBRUosS0FBSyxDQUFDRSxPQUFOLENBQWNDO0FBRnpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFoQkEsZUFvQkE7QUFBTSxZQUFJLEVBQUMsZUFBWDtBQUEyQixlQUFPLEVBQUM7QUFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXBCQSxlQXFCQTtBQUFNLFlBQUksRUFBQyxjQUFYO0FBQTBCLGVBQU8sRUFBQztBQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBckJBLGVBc0JBO0FBQU0sWUFBSSxFQUFDLGlCQUFYO0FBQTZCLGVBQU8sRUFBQztBQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBdEJBLGVBeUJBO0FBQU0sZ0JBQVEsRUFBQyxNQUFmO0FBQXNCLGVBQU8sRUFBQztBQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBekJBLGVBMEJBO0FBQ0UsZ0JBQVEsRUFBQyxhQURYO0FBRUUsZUFBTyxFQUFFSCxLQUFLLENBQUNFLE9BQU4sQ0FBY0M7QUFGekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTFCQSxlQThCQTtBQUFNLGdCQUFRLEVBQUMsT0FBZjtBQUF1QixlQUFPLEVBQUVILEtBQUssQ0FBQ0UsT0FBTixDQUFjRTtBQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBOUJBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQURPLGVBbUNMO0FBQUssZUFBUyxFQUFDLFVBQWY7QUFBQSw4QkFDQTtBQUFLLGlCQUFTLEVBQUMsaUJBQWY7QUFBQSwrQkFDRTtBQUFLLGFBQUcsRUFDc0IsbUJBQ0FKLEtBQUssQ0FBQ0UsT0FBTixDQUFjRyxRQURkO0FBRDlCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREEsZUFRQTtBQUFLLGlCQUFTLEVBQUMsZ0NBQWY7QUFBQSxrQkFBaURMLEtBQUssQ0FBQ0UsT0FBTixDQUFjQztBQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUkEsZUFVQTtBQUFLLGlCQUFTLEVBQUMsaUNBQWY7QUFBQSw4QkFBeURILEtBQUssQ0FBQ0UsT0FBTixDQUFjRyxRQUF2RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFWQSxlQVdBO0FBQUssaUJBQVMsRUFBQyxnQ0FBZjtBQUFBLG9DQUE4REwsS0FBSyxDQUFDRSxPQUFOLENBQWNJLFdBQTVFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVhBLGVBYUE7QUFBSyxpQkFBUyxFQUFDLGtDQUFmO0FBQUEsZ0NBQWtEO0FBQUcsY0FBSSxFQUFFTixLQUFLLENBQUNFLE9BQU4sQ0FBY0ssSUFBdkI7QUFBNkIsZ0JBQU0sRUFBQyxRQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBYkE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBbkNLO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFQO0FBbURDLENBckREOztLQUFNUixXOztBQXVFU0EsMEVBQWYiLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvcHJvZHVjdC9bc2x1Z10uZWYzNWFkOTQ0YWM5OTRjMzc1ZTQuaG90LXVwZGF0ZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyBDb21wb25lbnQgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSBcIm5leHQvcm91dGVyXCI7XHJcbmltcG9ydCBIZWFkIGZyb20gXCJuZXh0L2hlYWRcIjtcclxuaW1wb3J0IEdldFNlcnZlclNpZGVQcm9wcyBmcm9tIFwibmV4dFwiO1xyXG5pbXBvcnQgTmV4dFBhZ2UgZnJvbSBcIm5leHRcIjtcclxuaW1wb3J0IExpbmsgZnJvbSBcIm5leHQvbGlua1wiO1xyXG5pbXBvcnQgYXhpb3MgZnJvbSBcImF4aW9zXCI7XHJcbmltcG9ydCBfIGZyb20gXCJsb2Rhc2hcIjtcclxuLy8gaW1wb3J0IE9mZmVyc1BhZ2VDb250ZW50IGZyb20gXCIuLi9jb21wb25lbnRzL09mZmVyc1BhZ2VDb250ZW50XCI7XHJcbnZhciBQYXBhID0gcmVxdWlyZShcInBhcGFwYXJzZVwiKTtcclxuXHJcbmNvbnN0IGdldFBhcnNlZERhdGUgPSAoKSA9PiB7XHJcbiAgdmFyIGQgPSBuZXcgRGF0ZSgpO1xyXG4gIHZhciBtb250aCA9IG5ldyBBcnJheSgpO1xyXG4gIG1vbnRoWzBdID0gXCJKYW51YXJ5XCI7XHJcbiAgbW9udGhbMV0gPSBcIkZlYnJ1YXJ5XCI7XHJcbiAgbW9udGhbMl0gPSBcIk1hcmNoXCI7XHJcbiAgbW9udGhbM10gPSBcIkFwcmlsXCI7XHJcbiAgbW9udGhbNF0gPSBcIk1heVwiO1xyXG4gIG1vbnRoWzVdID0gXCJKdW5lXCI7XHJcbiAgbW9udGhbNl0gPSBcIkp1bHlcIjtcclxuICBtb250aFs3XSA9IFwiQXVndXN0XCI7XHJcbiAgbW9udGhbOF0gPSBcIlNlcHRlbWJlclwiO1xyXG4gIG1vbnRoWzldID0gXCJPY3RvYmVyXCI7XHJcbiAgbW9udGhbMTBdID0gXCJOb3ZlbWJlclwiO1xyXG4gIG1vbnRoWzExXSA9IFwiRGVjZW1iZXJcIjtcclxuICByZXR1cm4gbW9udGhbZC5nZXRNb250aCgpXTtcclxufTtcclxuXHJcbmNvbnN0IFByb2R1Y3RQYWdlID0gKHByb3BzKSA9PiB7XHJcblxyXG5yZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJQcm9kUGFnZVwiPlxyXG48SGVhZD5cclxuPGxpbmsgcmVsPVwiY2Fub25pY2FsXCIgaHJlZj17cHJvcHMucHJvZF9fdXJsfSAvPlxyXG48bWV0YSBwcm9wZXJ0eT1cIm9nOnNpdGVfbmFtZVwiIGNvbnRlbnQ9XCJvZmZlcnNjb2RlLmluXCIgLz5cclxuPG1ldGEgcHJvcGVydHk9XCJvZzp0eXBlXCIgY29udGVudD1cIndlYnNpdGVcIiAvPlxyXG48bWV0YSBwcm9wZXJ0eT1cIm9nOnRpdGxlXCIgY29udGVudD1cIk9mZmVyc2NvZGUuaW5cIiAvPlxyXG48bWV0YSBwcm9wZXJ0eT1cIm9nOnVybFwiIGNvbnRlbnQ9e3Byb3BzLnByb2RfX3VybH0gLz5cclxuPG1ldGFcclxuICBwcm9wZXJ0eT1cIm9nOmRlc2NyaXB0aW9uXCJcclxuICBjb250ZW50PXtwcm9wcy5yZXN1bHRzLnRpdGxlfVxyXG4vPlxyXG48bWV0YSBwcm9wZXJ0eT1cIm9nOmxvY2FsZVwiIGNvbnRlbnQ9XCJlbl9VU1wiIC8+XHJcbjxtZXRhIHByb3BlcnR5PVwib2c6aW1hZ2VcIiBjb250ZW50PXtwcm9wcy5yZXN1bHRzLmltYWdlX3VybH0gLz5cclxuPG1ldGEgcHJvcGVydHk9XCJvZzphcnRpY2xlOnB1Ymxpc2hlZF90aW1lXCIgY29udGVudD1cIlwiIC8+XHJcblxyXG57LyogPCEtLSB0d2l0dGVyIE1ldGEgdGFncyAtLT4gKi99XHJcbjxtZXRhIG5hbWU9XCJ0d2l0dGVyOmNhcmRcIiBjb250ZW50PVwic3VtbWFyeV9sYXJnZV9pbWFnZVwiIC8+XHJcbjxtZXRhXHJcbiAgbmFtZT1cInR3aXR0ZXI6ZGVzY3JpcHRpb25cIlxyXG4gIGNvbnRlbnQ9e3Byb3BzLnJlc3VsdHMudGl0bGV9XHJcbi8+XHJcbjxtZXRhIG5hbWU9XCJ0d2l0dGVyOnRpdGxlXCIgY29udGVudD1cIm9mZmVyc2NvZGUuaW5cIiAvPlxyXG48bWV0YSBuYW1lPVwidHdpdHRlcjpzaXRlXCIgY29udGVudD1cIkBvZmZlcnNjb2RlaW5cIiAvPlxyXG48bWV0YSBuYW1lPVwidHdpdHRlcjpjcmVhdG9yXCIgY29udGVudD1cIkBvZmZlcnNjb2RlaW5cIiAvPlxyXG5cclxuey8qIDwhLS0gU3RhbmRhcmQgTWV0YSB0YWdzIC0tPiAqL31cclxuPG1ldGEgaXRlbVByb3A9XCJuYW1lXCIgY29udGVudD1cIm9mZmVyc2NvZGUuaW5cIiAvPlxyXG48bWV0YVxyXG4gIGl0ZW1Qcm9wPVwiZGVzY3JpcHRpb25cIlxyXG4gIGNvbnRlbnQ9e3Byb3BzLnJlc3VsdHMudGl0bGV9XHJcbi8+XHJcbjxtZXRhIGl0ZW1Qcm9wPVwiaW1hZ2VcIiBjb250ZW50PXtwcm9wcy5yZXN1bHRzLmltYWdlX3VybH0gLz5cclxuXHJcblxyXG48L0hlYWQ+ICAgXHJcbiAgPGRpdiBjbGFzc05hbWU9XCJwcm9kQ2FyZFwiPlxyXG4gIDxkaXYgY2xhc3NOYW1lPVwicHJvZENhcmRfX2ltYWdlXCI+XHJcbiAgICA8aW1nIHNyYz17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBgL3N0b3Jlc19fbG9nby9gICtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHByb3BzLnJlc3VsdHMubWVyY2hhbnQgK1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYC1sb2dvLWxhcmdlLmpwZ2BcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9Lz5cclxuICA8L2Rpdj5cclxuICA8ZGl2IGNsYXNzTmFtZT1cInByb2RDYXJkX19maWVsZCBwcm9kQ2FyZF9fbmFtZVwiPntwcm9wcy5yZXN1bHRzLnRpdGxlfTwvZGl2PlxyXG4gIHsvKiA8ZGl2IGNsYXNzTmFtZT1cInByb2RDYXJkX19maWVsZCBwcm9kQ2FyZF9fY2F0XCI+Q2F0ZWdvcmllczoge3Byb3BzLnJlc3VsdHMuY2F0ZWdvcmllc308L2Rpdj4gKi99XHJcbiAgPGRpdiBjbGFzc05hbWU9XCJwcm9kQ2FyZF9fZmllbGQgcHJvZENhcmRfX2JyYW5kXCI+QnJhbmQ6IHtwcm9wcy5yZXN1bHRzLm1lcmNoYW50fTwvZGl2PlxyXG4gIDxkaXYgY2xhc3NOYW1lPVwicHJvZENhcmRfX2ZpZWxkIHByb2RDYXJkX19kZXNjXCI+RGVzY3JpcHRpb246IHtwcm9wcy5yZXN1bHRzLmRlc2NyaXB0aW9ufTwvZGl2PlxyXG4gIHsvKiA8ZGl2IGNsYXNzTmFtZT1cInByb2RDYXJkX19maWVsZCBwcm9kQ2FyZF9fY291cG9uY29kZVwiPkNvdXBvbl9Db2RlOiB7cHJvcHMucmVzdWx0cy5jb3Vwb25fY29kZX08L2Rpdj4gKi99XHJcbiAgPGRpdiBjbGFzc05hbWU9XCJwcm9kQ2FyZF9fZmllbGQgcHJvZENhcmRfX2J1eWJ0blwiPjxhIGhyZWY9e3Byb3BzLnJlc3VsdHMubGlua30gdGFyZ2V0PVwiX2JsYW5rXCI+QnV5IE5vdzwvYT4gPC9kaXY+XHJcbiAgPC9kaXY+XHJcbiAgPC9kaXY+O1xyXG59O1xyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFNlcnZlclNpZGVQcm9wcyh7IHBhcmFtcyB9KSB7XHJcbiAgY29uc3QgU2x1ZyA9IHBhcmFtcy5zbHVnO1xyXG4gIGNvbnNvbGUubG9nKHBhcmFtcylcclxuICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKGBodHRwOi8vbG9jYWxob3N0OjMwMDIvYXBpL2Zyb250L29mZmVycy9wcm9kX19ieV9fc2x1Zz9xPSR7U2x1Z31gKVxyXG4gICAgY29uc3QganNvbiA9IGF3YWl0IHJlcy5qc29uKClcclxuICAgIC8vIGNvbnNvbGUubG9nKGpzb24pXHJcbiAgICBcclxuICAgIHJldHVybiB7IFxyXG4gICAgICBwcm9wczoge1xyXG4gICAgICAgIHJlc3VsdHM6IGpzb24ucmVzdWx0c1swXSxcclxuICAgICAgICBwcm9kX191cmwgOiAnLy9vZmZlcnNjb2RlLmluL3Byb2R1Y3QvJyArcGFyYW1zLnNsdWdcclxuICAgICAgfSxcclxuICAgIH07XHJcbiAgfVxyXG4gIFxyXG5cclxuZXhwb3J0IGRlZmF1bHQgUHJvZHVjdFBhZ2U7XHJcbiJdLCJzb3VyY2VSb290IjoiIn0=