webpackHotUpdate_N_E("pages/product/[slug]",{

/***/ "./pages/product/[slug]/index.js":
/*!***************************************!*\
  !*** ./pages/product/[slug]/index.js ***!
  \***************************************/
/*! exports provided: __N_SSP, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__N_SSP", function() { return __N_SSP; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/router */ "./node_modules/next/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/head */ "./node_modules/next/head.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! next */ "next");
/* harmony import */ var next__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! lodash */ "./node_modules/lodash/lodash.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_7__);


var _jsxFileName = "C:\\xampp\\htdocs\\ReactTuts\\NextJS\\ofccode\\pages\\product\\[slug]\\index.js",
    _this = undefined;








 // import OffersPageContent from "../components/OffersPageContent";

var Papa = __webpack_require__(/*! papaparse */ "./node_modules/papaparse/papaparse.min.js");

var getParsedDate = function getParsedDate() {
  var d = new Date();
  var month = new Array();
  month[0] = "January";
  month[1] = "February";
  month[2] = "March";
  month[3] = "April";
  month[4] = "May";
  month[5] = "June";
  month[6] = "July";
  month[7] = "August";
  month[8] = "September";
  month[9] = "October";
  month[10] = "November";
  month[11] = "December";
  return month[d.getMonth()];
};

var ProductPage = function ProductPage(props) {
  if (window !== undefined) {
    var _current__url = window.location.href;
  }

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: "ProdPage",
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_head__WEBPACK_IMPORTED_MODULE_3___default.a, {
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("link", {
        rel: "canonical",
        href: current__url
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 37,
        columnNumber: 1
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
        property: "og:site_name",
        content: "offerscode.in"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 38,
        columnNumber: 1
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
        property: "og:type",
        content: "website"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 39,
        columnNumber: 1
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
        property: "og:title",
        content: "Offerscode.in"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 40,
        columnNumber: 1
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
        property: "og:url",
        content: current__url
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 41,
        columnNumber: 1
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
        property: "og:description",
        content: props.results.title
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 42,
        columnNumber: 1
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
        property: "og:locale",
        content: "en_US"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 46,
        columnNumber: 1
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
        property: "og:image",
        content: props.results.image_url
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 47,
        columnNumber: 1
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
        property: "og:article:published_time",
        content: ""
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 48,
        columnNumber: 1
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
        name: "twitter:card",
        content: "summary_large_image"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 51,
        columnNumber: 1
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
        name: "twitter:description",
        content: props.results.title
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 52,
        columnNumber: 1
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
        name: "twitter:title",
        content: "offerscode.in"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 56,
        columnNumber: 1
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
        name: "twitter:site",
        content: "@offerscodein"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 57,
        columnNumber: 1
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
        name: "twitter:creator",
        content: "@offerscodein"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 58,
        columnNumber: 1
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
        itemProp: "name",
        content: "offerscode.in"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 61,
        columnNumber: 1
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
        itemProp: "description",
        content: props.results.title
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 62,
        columnNumber: 1
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
        itemProp: "image",
        content: props.results.image_url
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 66,
        columnNumber: 1
      }, _this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 36,
      columnNumber: 1
    }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "prodCard",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "prodCard__image",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
          src: props.results.image_url
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 72,
          columnNumber: 5
        }, _this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 71,
        columnNumber: 3
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "prodCard__field prodCard__name",
        children: props.results.title
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 74,
        columnNumber: 3
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "prodCard__field prodCard__cat",
        children: ["Categories: ", props.results.categories]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 75,
        columnNumber: 3
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "prodCard__field prodCard__brand",
        children: ["Brand: ", props.results.merchant]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 76,
        columnNumber: 3
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "prodCard__field prodCard__desc",
        children: ["Description: ", props.results.description]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 77,
        columnNumber: 3
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "prodCard__field prodCard__couponcode",
        children: ["Coupon_Code: ", props.results.coupon_code]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 78,
        columnNumber: 3
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "prodCard__field prodCard__buybtn",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
          href: props.results.url,
          target: "_blank",
          children: "Buy Now"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 79,
          columnNumber: 53
        }, _this), " "]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 79,
        columnNumber: 3
      }, _this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 70,
      columnNumber: 3
    }, _this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 35,
    columnNumber: 8
  }, _this);
};

_c = ProductPage;
var __N_SSP = true;
/* harmony default export */ __webpack_exports__["default"] = (ProductPage);

var _c;

$RefreshReg$(_c, "ProductPage");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvcHJvZHVjdC9bc2x1Z10vaW5kZXguanMiXSwibmFtZXMiOlsiUGFwYSIsInJlcXVpcmUiLCJnZXRQYXJzZWREYXRlIiwiZCIsIkRhdGUiLCJtb250aCIsIkFycmF5IiwiZ2V0TW9udGgiLCJQcm9kdWN0UGFnZSIsInByb3BzIiwid2luZG93IiwidW5kZWZpbmVkIiwiY3VycmVudF9fdXJsIiwibG9jYXRpb24iLCJocmVmIiwicmVzdWx0cyIsInRpdGxlIiwiaW1hZ2VfdXJsIiwiY2F0ZWdvcmllcyIsIm1lcmNoYW50IiwiZGVzY3JpcHRpb24iLCJjb3Vwb25fY29kZSIsInVybCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Q0FFQTs7QUFDQSxJQUFJQSxJQUFJLEdBQUdDLG1CQUFPLENBQUMsNERBQUQsQ0FBbEI7O0FBRUEsSUFBTUMsYUFBYSxHQUFHLFNBQWhCQSxhQUFnQixHQUFNO0FBQzFCLE1BQUlDLENBQUMsR0FBRyxJQUFJQyxJQUFKLEVBQVI7QUFDQSxNQUFJQyxLQUFLLEdBQUcsSUFBSUMsS0FBSixFQUFaO0FBQ0FELE9BQUssQ0FBQyxDQUFELENBQUwsR0FBVyxTQUFYO0FBQ0FBLE9BQUssQ0FBQyxDQUFELENBQUwsR0FBVyxVQUFYO0FBQ0FBLE9BQUssQ0FBQyxDQUFELENBQUwsR0FBVyxPQUFYO0FBQ0FBLE9BQUssQ0FBQyxDQUFELENBQUwsR0FBVyxPQUFYO0FBQ0FBLE9BQUssQ0FBQyxDQUFELENBQUwsR0FBVyxLQUFYO0FBQ0FBLE9BQUssQ0FBQyxDQUFELENBQUwsR0FBVyxNQUFYO0FBQ0FBLE9BQUssQ0FBQyxDQUFELENBQUwsR0FBVyxNQUFYO0FBQ0FBLE9BQUssQ0FBQyxDQUFELENBQUwsR0FBVyxRQUFYO0FBQ0FBLE9BQUssQ0FBQyxDQUFELENBQUwsR0FBVyxXQUFYO0FBQ0FBLE9BQUssQ0FBQyxDQUFELENBQUwsR0FBVyxTQUFYO0FBQ0FBLE9BQUssQ0FBQyxFQUFELENBQUwsR0FBWSxVQUFaO0FBQ0FBLE9BQUssQ0FBQyxFQUFELENBQUwsR0FBWSxVQUFaO0FBQ0EsU0FBT0EsS0FBSyxDQUFDRixDQUFDLENBQUNJLFFBQUYsRUFBRCxDQUFaO0FBQ0QsQ0FoQkQ7O0FBa0JBLElBQU1DLFdBQVcsR0FBRyxTQUFkQSxXQUFjLENBQUNDLEtBQUQsRUFBVztBQUUvQixNQUFJQyxNQUFNLEtBQUtDLFNBQWYsRUFBMEI7QUFDMUIsUUFBSUMsYUFBWSxHQUFHRixNQUFNLENBQUNHLFFBQVAsQ0FBZ0JDLElBQW5DO0FBQ0M7O0FBQ0Qsc0JBQU87QUFBSyxhQUFTLEVBQUMsVUFBZjtBQUFBLDRCQUNQLHFFQUFDLGdEQUFEO0FBQUEsOEJBQ0E7QUFBTSxXQUFHLEVBQUMsV0FBVjtBQUFzQixZQUFJLEVBQUVGO0FBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFEQSxlQUVBO0FBQU0sZ0JBQVEsRUFBQyxjQUFmO0FBQThCLGVBQU8sRUFBQztBQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRkEsZUFHQTtBQUFNLGdCQUFRLEVBQUMsU0FBZjtBQUF5QixlQUFPLEVBQUM7QUFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUhBLGVBSUE7QUFBTSxnQkFBUSxFQUFDLFVBQWY7QUFBMEIsZUFBTyxFQUFDO0FBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFKQSxlQUtBO0FBQU0sZ0JBQVEsRUFBQyxRQUFmO0FBQXdCLGVBQU8sRUFBRUE7QUFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUxBLGVBTUE7QUFDRSxnQkFBUSxFQUFDLGdCQURYO0FBRUUsZUFBTyxFQUFFSCxLQUFLLENBQUNNLE9BQU4sQ0FBY0M7QUFGekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU5BLGVBVUE7QUFBTSxnQkFBUSxFQUFDLFdBQWY7QUFBMkIsZUFBTyxFQUFDO0FBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFWQSxlQVdBO0FBQU0sZ0JBQVEsRUFBQyxVQUFmO0FBQTBCLGVBQU8sRUFBRVAsS0FBSyxDQUFDTSxPQUFOLENBQWNFO0FBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFYQSxlQVlBO0FBQU0sZ0JBQVEsRUFBQywyQkFBZjtBQUEyQyxlQUFPLEVBQUM7QUFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVpBLGVBZUE7QUFBTSxZQUFJLEVBQUMsY0FBWDtBQUEwQixlQUFPLEVBQUM7QUFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWZBLGVBZ0JBO0FBQ0UsWUFBSSxFQUFDLHFCQURQO0FBRUUsZUFBTyxFQUFFUixLQUFLLENBQUNNLE9BQU4sQ0FBY0M7QUFGekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWhCQSxlQW9CQTtBQUFNLFlBQUksRUFBQyxlQUFYO0FBQTJCLGVBQU8sRUFBQztBQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBcEJBLGVBcUJBO0FBQU0sWUFBSSxFQUFDLGNBQVg7QUFBMEIsZUFBTyxFQUFDO0FBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFyQkEsZUFzQkE7QUFBTSxZQUFJLEVBQUMsaUJBQVg7QUFBNkIsZUFBTyxFQUFDO0FBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF0QkEsZUF5QkE7QUFBTSxnQkFBUSxFQUFDLE1BQWY7QUFBc0IsZUFBTyxFQUFDO0FBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF6QkEsZUEwQkE7QUFDRSxnQkFBUSxFQUFDLGFBRFg7QUFFRSxlQUFPLEVBQUVQLEtBQUssQ0FBQ00sT0FBTixDQUFjQztBQUZ6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBMUJBLGVBOEJBO0FBQU0sZ0JBQVEsRUFBQyxPQUFmO0FBQXVCLGVBQU8sRUFBRVAsS0FBSyxDQUFDTSxPQUFOLENBQWNFO0FBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE5QkE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRE8sZUFtQ0w7QUFBSyxlQUFTLEVBQUMsVUFBZjtBQUFBLDhCQUNBO0FBQUssaUJBQVMsRUFBQyxpQkFBZjtBQUFBLCtCQUNFO0FBQUssYUFBRyxFQUFFUixLQUFLLENBQUNNLE9BQU4sQ0FBY0U7QUFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFEQSxlQUlBO0FBQUssaUJBQVMsRUFBQyxnQ0FBZjtBQUFBLGtCQUFpRFIsS0FBSyxDQUFDTSxPQUFOLENBQWNDO0FBQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFKQSxlQUtBO0FBQUssaUJBQVMsRUFBQywrQkFBZjtBQUFBLG1DQUE0RFAsS0FBSyxDQUFDTSxPQUFOLENBQWNHLFVBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUxBLGVBTUE7QUFBSyxpQkFBUyxFQUFDLGlDQUFmO0FBQUEsOEJBQXlEVCxLQUFLLENBQUNNLE9BQU4sQ0FBY0ksUUFBdkU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBTkEsZUFPQTtBQUFLLGlCQUFTLEVBQUMsZ0NBQWY7QUFBQSxvQ0FBOERWLEtBQUssQ0FBQ00sT0FBTixDQUFjSyxXQUE1RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFQQSxlQVFBO0FBQUssaUJBQVMsRUFBQyxzQ0FBZjtBQUFBLG9DQUFvRVgsS0FBSyxDQUFDTSxPQUFOLENBQWNNLFdBQWxGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVJBLGVBU0E7QUFBSyxpQkFBUyxFQUFDLGtDQUFmO0FBQUEsZ0NBQWtEO0FBQUcsY0FBSSxFQUFFWixLQUFLLENBQUNNLE9BQU4sQ0FBY08sR0FBdkI7QUFBNEIsZ0JBQU0sRUFBQyxRQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVEE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBbkNLO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFQO0FBK0NDLENBcEREOztLQUFNZCxXOztBQXFFU0EsMEVBQWYiLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvcHJvZHVjdC9bc2x1Z10uNTg5Zjg4YTAxOWQ5YWZhYzE3ZWYuaG90LXVwZGF0ZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyBDb21wb25lbnQgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSBcIm5leHQvcm91dGVyXCI7XHJcbmltcG9ydCBIZWFkIGZyb20gXCJuZXh0L2hlYWRcIjtcclxuaW1wb3J0IEdldFNlcnZlclNpZGVQcm9wcyBmcm9tIFwibmV4dFwiO1xyXG5pbXBvcnQgTmV4dFBhZ2UgZnJvbSBcIm5leHRcIjtcclxuaW1wb3J0IExpbmsgZnJvbSBcIm5leHQvbGlua1wiO1xyXG5pbXBvcnQgYXhpb3MgZnJvbSBcImF4aW9zXCI7XHJcbmltcG9ydCBfIGZyb20gXCJsb2Rhc2hcIjtcclxuLy8gaW1wb3J0IE9mZmVyc1BhZ2VDb250ZW50IGZyb20gXCIuLi9jb21wb25lbnRzL09mZmVyc1BhZ2VDb250ZW50XCI7XHJcbnZhciBQYXBhID0gcmVxdWlyZShcInBhcGFwYXJzZVwiKTtcclxuXHJcbmNvbnN0IGdldFBhcnNlZERhdGUgPSAoKSA9PiB7XHJcbiAgdmFyIGQgPSBuZXcgRGF0ZSgpO1xyXG4gIHZhciBtb250aCA9IG5ldyBBcnJheSgpO1xyXG4gIG1vbnRoWzBdID0gXCJKYW51YXJ5XCI7XHJcbiAgbW9udGhbMV0gPSBcIkZlYnJ1YXJ5XCI7XHJcbiAgbW9udGhbMl0gPSBcIk1hcmNoXCI7XHJcbiAgbW9udGhbM10gPSBcIkFwcmlsXCI7XHJcbiAgbW9udGhbNF0gPSBcIk1heVwiO1xyXG4gIG1vbnRoWzVdID0gXCJKdW5lXCI7XHJcbiAgbW9udGhbNl0gPSBcIkp1bHlcIjtcclxuICBtb250aFs3XSA9IFwiQXVndXN0XCI7XHJcbiAgbW9udGhbOF0gPSBcIlNlcHRlbWJlclwiO1xyXG4gIG1vbnRoWzldID0gXCJPY3RvYmVyXCI7XHJcbiAgbW9udGhbMTBdID0gXCJOb3ZlbWJlclwiO1xyXG4gIG1vbnRoWzExXSA9IFwiRGVjZW1iZXJcIjtcclxuICByZXR1cm4gbW9udGhbZC5nZXRNb250aCgpXTtcclxufTtcclxuXHJcbmNvbnN0IFByb2R1Y3RQYWdlID0gKHByb3BzKSA9PiB7XHJcblxyXG5pZiAod2luZG93ICE9PSB1bmRlZmluZWQpIHtcclxubGV0IGN1cnJlbnRfX3VybCA9IHdpbmRvdy5sb2NhdGlvbi5ocmVmO1xyXG59XHJcbnJldHVybiA8ZGl2IGNsYXNzTmFtZT1cIlByb2RQYWdlXCI+XHJcbjxIZWFkPlxyXG48bGluayByZWw9XCJjYW5vbmljYWxcIiBocmVmPXtjdXJyZW50X191cmx9IC8+XHJcbjxtZXRhIHByb3BlcnR5PVwib2c6c2l0ZV9uYW1lXCIgY29udGVudD1cIm9mZmVyc2NvZGUuaW5cIiAvPlxyXG48bWV0YSBwcm9wZXJ0eT1cIm9nOnR5cGVcIiBjb250ZW50PVwid2Vic2l0ZVwiIC8+XHJcbjxtZXRhIHByb3BlcnR5PVwib2c6dGl0bGVcIiBjb250ZW50PVwiT2ZmZXJzY29kZS5pblwiIC8+XHJcbjxtZXRhIHByb3BlcnR5PVwib2c6dXJsXCIgY29udGVudD17Y3VycmVudF9fdXJsfSAvPlxyXG48bWV0YVxyXG4gIHByb3BlcnR5PVwib2c6ZGVzY3JpcHRpb25cIlxyXG4gIGNvbnRlbnQ9e3Byb3BzLnJlc3VsdHMudGl0bGV9XHJcbi8+XHJcbjxtZXRhIHByb3BlcnR5PVwib2c6bG9jYWxlXCIgY29udGVudD1cImVuX1VTXCIgLz5cclxuPG1ldGEgcHJvcGVydHk9XCJvZzppbWFnZVwiIGNvbnRlbnQ9e3Byb3BzLnJlc3VsdHMuaW1hZ2VfdXJsfSAvPlxyXG48bWV0YSBwcm9wZXJ0eT1cIm9nOmFydGljbGU6cHVibGlzaGVkX3RpbWVcIiBjb250ZW50PVwiXCIgLz5cclxuXHJcbnsvKiA8IS0tIHR3aXR0ZXIgTWV0YSB0YWdzIC0tPiAqL31cclxuPG1ldGEgbmFtZT1cInR3aXR0ZXI6Y2FyZFwiIGNvbnRlbnQ9XCJzdW1tYXJ5X2xhcmdlX2ltYWdlXCIgLz5cclxuPG1ldGFcclxuICBuYW1lPVwidHdpdHRlcjpkZXNjcmlwdGlvblwiXHJcbiAgY29udGVudD17cHJvcHMucmVzdWx0cy50aXRsZX1cclxuLz5cclxuPG1ldGEgbmFtZT1cInR3aXR0ZXI6dGl0bGVcIiBjb250ZW50PVwib2ZmZXJzY29kZS5pblwiIC8+XHJcbjxtZXRhIG5hbWU9XCJ0d2l0dGVyOnNpdGVcIiBjb250ZW50PVwiQG9mZmVyc2NvZGVpblwiIC8+XHJcbjxtZXRhIG5hbWU9XCJ0d2l0dGVyOmNyZWF0b3JcIiBjb250ZW50PVwiQG9mZmVyc2NvZGVpblwiIC8+XHJcblxyXG57LyogPCEtLSBTdGFuZGFyZCBNZXRhIHRhZ3MgLS0+ICovfVxyXG48bWV0YSBpdGVtUHJvcD1cIm5hbWVcIiBjb250ZW50PVwib2ZmZXJzY29kZS5pblwiIC8+XHJcbjxtZXRhXHJcbiAgaXRlbVByb3A9XCJkZXNjcmlwdGlvblwiXHJcbiAgY29udGVudD17cHJvcHMucmVzdWx0cy50aXRsZX1cclxuLz5cclxuPG1ldGEgaXRlbVByb3A9XCJpbWFnZVwiIGNvbnRlbnQ9e3Byb3BzLnJlc3VsdHMuaW1hZ2VfdXJsfSAvPlxyXG5cclxuXHJcbjwvSGVhZD4gICBcclxuICA8ZGl2IGNsYXNzTmFtZT1cInByb2RDYXJkXCI+XHJcbiAgPGRpdiBjbGFzc05hbWU9XCJwcm9kQ2FyZF9faW1hZ2VcIj5cclxuICAgIDxpbWcgc3JjPXtwcm9wcy5yZXN1bHRzLmltYWdlX3VybH0vPlxyXG4gIDwvZGl2PlxyXG4gIDxkaXYgY2xhc3NOYW1lPVwicHJvZENhcmRfX2ZpZWxkIHByb2RDYXJkX19uYW1lXCI+e3Byb3BzLnJlc3VsdHMudGl0bGV9PC9kaXY+XHJcbiAgPGRpdiBjbGFzc05hbWU9XCJwcm9kQ2FyZF9fZmllbGQgcHJvZENhcmRfX2NhdFwiPkNhdGVnb3JpZXM6IHtwcm9wcy5yZXN1bHRzLmNhdGVnb3JpZXN9PC9kaXY+XHJcbiAgPGRpdiBjbGFzc05hbWU9XCJwcm9kQ2FyZF9fZmllbGQgcHJvZENhcmRfX2JyYW5kXCI+QnJhbmQ6IHtwcm9wcy5yZXN1bHRzLm1lcmNoYW50fTwvZGl2PlxyXG4gIDxkaXYgY2xhc3NOYW1lPVwicHJvZENhcmRfX2ZpZWxkIHByb2RDYXJkX19kZXNjXCI+RGVzY3JpcHRpb246IHtwcm9wcy5yZXN1bHRzLmRlc2NyaXB0aW9ufTwvZGl2PlxyXG4gIDxkaXYgY2xhc3NOYW1lPVwicHJvZENhcmRfX2ZpZWxkIHByb2RDYXJkX19jb3Vwb25jb2RlXCI+Q291cG9uX0NvZGU6IHtwcm9wcy5yZXN1bHRzLmNvdXBvbl9jb2RlfTwvZGl2PlxyXG4gIDxkaXYgY2xhc3NOYW1lPVwicHJvZENhcmRfX2ZpZWxkIHByb2RDYXJkX19idXlidG5cIj48YSBocmVmPXtwcm9wcy5yZXN1bHRzLnVybH0gdGFyZ2V0PVwiX2JsYW5rXCI+QnV5IE5vdzwvYT4gPC9kaXY+XHJcbiAgPC9kaXY+XHJcbiAgPC9kaXY+O1xyXG59O1xyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFNlcnZlclNpZGVQcm9wcyh7IHBhcmFtcyB9KSB7XHJcbiAgY29uc3QgU2x1ZyA9IHBhcmFtcy5zbHVnO1xyXG4gIGNvbnNvbGUubG9nKHBhcmFtcylcclxuICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKGBodHRwczovL29mY2NvZGUtYXBpLWdpdC1tYWluLXNwb3J0eWJydWgxOTkwLnZlcmNlbC5hcHAvYXBpL2Zyb250L29mZmVycy9wcm9kX19ieV9fc2x1Zz9xPSR7U2x1Z31gKVxyXG4gICAgY29uc3QganNvbiA9IGF3YWl0IHJlcy5qc29uKClcclxuICAgIC8vIGNvbnNvbGUubG9nKGpzb24pXHJcbiAgICBcclxuICAgIHJldHVybiB7IFxyXG4gICAgICBwcm9wczoge1xyXG4gICAgICAgIHJlc3VsdHM6IGpzb24ucmVzdWx0c1swXSxcclxuICAgICAgfSxcclxuICAgIH07XHJcbiAgfVxyXG4gIFxyXG5cclxuZXhwb3J0IGRlZmF1bHQgUHJvZHVjdFBhZ2U7XHJcbiJdLCJzb3VyY2VSb290IjoiIn0=