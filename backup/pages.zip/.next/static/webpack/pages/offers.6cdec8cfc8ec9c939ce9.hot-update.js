webpackHotUpdate_N_E("pages/offers",{

/***/ "./node_modules/next/dist/next-server/lib/dynamic.js":
/*!***********************************************************!*\
  !*** ./node_modules/next/dist/next-server/lib/dynamic.js ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(module) {

var _defineProperty = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/defineProperty */ "./node_modules/@babel/runtime/helpers/defineProperty.js");

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

exports.__esModule = true;
exports.noSSR = noSSR;
exports["default"] = dynamic;

var _react = _interopRequireDefault(__webpack_require__(/*! react */ "./node_modules/react/index.js"));

var _loadable = _interopRequireDefault(__webpack_require__(/*! ./loadable */ "./node_modules/next/dist/next-server/lib/loadable.js"));

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    "default": obj
  };
}

var isServerSide = false;

function noSSR(LoadableInitializer, loadableOptions) {
  // Removing webpack and modules means react-loadable won't try preloading
  delete loadableOptions.webpack;
  delete loadableOptions.modules; // This check is necessary to prevent react-loadable from initializing on the server

  if (!isServerSide) {
    return LoadableInitializer(loadableOptions);
  }

  var Loading = loadableOptions.loading; // This will only be rendered on the server side

  return function () {
    return /*#__PURE__*/_react["default"].createElement(Loading, {
      error: null,
      isLoading: true,
      pastDelay: false,
      timedOut: false
    });
  };
} // function dynamic<P = {}, O extends DynamicOptions>(options: O):


function dynamic(dynamicOptions, options) {
  var loadableFn = _loadable["default"];
  var loadableOptions = {
    // A loading component is not required, so we default it
    loading: function loading(_ref) {
      var error = _ref.error,
          isLoading = _ref.isLoading,
          pastDelay = _ref.pastDelay;
      if (!pastDelay) return null;

      if (true) {
        if (isLoading) {
          return null;
        }

        if (error) {
          return /*#__PURE__*/_react["default"].createElement("p", null, error.message, /*#__PURE__*/_react["default"].createElement("br", null), error.stack);
        }
      }

      return null;
    }
  }; // Support for direct import(), eg: dynamic(import('../hello-world'))
  // Note that this is only kept for the edge case where someone is passing in a promise as first argument
  // The react-loadable babel plugin will turn dynamic(import('../hello-world')) into dynamic(() => import('../hello-world'))
  // To make sure we don't execute the import without rendering first

  if (dynamicOptions instanceof Promise) {
    loadableOptions.loader = function () {
      return dynamicOptions;
    }; // Support for having import as a function, eg: dynamic(() => import('../hello-world'))

  } else if (typeof dynamicOptions === 'function') {
    loadableOptions.loader = dynamicOptions; // Support for having first argument being options, eg: dynamic({loader: import('../hello-world')})
  } else if (typeof dynamicOptions === 'object') {
    loadableOptions = _objectSpread(_objectSpread({}, loadableOptions), dynamicOptions);
  } // Support for passing options, eg: dynamic(import('../hello-world'), {loading: () => <p>Loading something</p>})


  loadableOptions = _objectSpread(_objectSpread({}, loadableOptions), options);

  if (typeof dynamicOptions === 'object' && !(dynamicOptions instanceof Promise)) {
    // show deprecation warning for `modules` key in development
    if (true) {
      if (dynamicOptions.modules) {
        console.warn('The modules option for next/dynamic has been deprecated. See here for more info https://err.sh/vercel/next.js/next-dynamic-modules');
      }
    } // Support for `render` when using a mapping, eg: `dynamic({ modules: () => {return {HelloWorld: import('../hello-world')}, render(props, loaded) {} } })


    if (dynamicOptions.render) {
      loadableOptions.render = function (loaded, props) {
        return dynamicOptions.render(props, loaded);
      };
    } // Support for `modules` when using a mapping, eg: `dynamic({ modules: () => {return {HelloWorld: import('../hello-world')}, render(props, loaded) {} } })


    if (dynamicOptions.modules) {
      loadableFn = _loadable["default"].Map;
      var loadModules = {};
      var modules = dynamicOptions.modules();
      Object.keys(modules).forEach(function (key) {
        var value = modules[key];

        if (typeof value.then === 'function') {
          loadModules[key] = function () {
            return value.then(function (mod) {
              return mod["default"] || mod;
            });
          };

          return;
        }

        loadModules[key] = value;
      });
      loadableOptions.loader = loadModules;
    }
  } // coming from build/babel/plugins/react-loadable-plugin.js


  if (loadableOptions.loadableGenerated) {
    loadableOptions = _objectSpread(_objectSpread({}, loadableOptions), loadableOptions.loadableGenerated);
    delete loadableOptions.loadableGenerated;
  } // support for disabling server side rendering, eg: dynamic(import('../hello-world'), {ssr: false})


  if (typeof loadableOptions.ssr === 'boolean') {
    if (!loadableOptions.ssr) {
      delete loadableOptions.ssr;
      return noSSR(loadableFn, loadableOptions);
    }

    delete loadableOptions.ssr;
  }

  return loadableFn(loadableOptions);
}

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../compiled/webpack/module.js */ "./node_modules/next/dist/compiled/webpack/module.js")(module)))

/***/ }),

/***/ "./node_modules/next/dist/next-server/lib/loadable-context.js":
/*!********************************************************************!*\
  !*** ./node_modules/next/dist/next-server/lib/loadable-context.js ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(module) {

exports.__esModule = true;
exports.LoadableContext = void 0;

var _react = _interopRequireDefault(__webpack_require__(/*! react */ "./node_modules/react/index.js"));

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    "default": obj
  };
}

var LoadableContext = /*#__PURE__*/_react["default"].createContext(null);

exports.LoadableContext = LoadableContext;

if (true) {
  LoadableContext.displayName = 'LoadableContext';
}

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../compiled/webpack/module.js */ "./node_modules/next/dist/compiled/webpack/module.js")(module)))

/***/ }),

/***/ "./node_modules/next/dist/next-server/lib/loadable.js":
/*!************************************************************!*\
  !*** ./node_modules/next/dist/next-server/lib/loadable.js ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(module) {

var _defineProperty = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/defineProperty */ "./node_modules/@babel/runtime/helpers/defineProperty.js");

var _classCallCheck = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/classCallCheck */ "./node_modules/@babel/runtime/helpers/classCallCheck.js");

var _createClass = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/createClass */ "./node_modules/@babel/runtime/helpers/createClass.js");

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _createForOfIteratorHelper(o, allowArrayLike) { var it; if (typeof Symbol === "undefined" || o[Symbol.iterator] == null) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = o[Symbol.iterator](); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

exports.__esModule = true;
exports["default"] = void 0;

var _react = _interopRequireDefault(__webpack_require__(/*! react */ "./node_modules/react/index.js"));

var _useSubscription = __webpack_require__(/*! use-subscription */ "./node_modules/use-subscription/index.js");

var _loadableContext = __webpack_require__(/*! ./loadable-context */ "./node_modules/next/dist/next-server/lib/loadable-context.js");

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    "default": obj
  };
}
/**
@copyright (c) 2017-present James Kyle <me@thejameskyle.com>
MIT License
Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:
The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE
*/
// https://github.com/jamiebuilds/react-loadable/blob/v5.5.0/src/index.js
// Modified to be compatible with webpack 4 / Next.js


var ALL_INITIALIZERS = [];
var READY_INITIALIZERS = [];
var initialized = false;

function load(loader) {
  var promise = loader();
  var state = {
    loading: true,
    loaded: null,
    error: null
  };
  state.promise = promise.then(function (loaded) {
    state.loading = false;
    state.loaded = loaded;
    return loaded;
  })["catch"](function (err) {
    state.loading = false;
    state.error = err;
    throw err;
  });
  return state;
}

function loadMap(obj) {
  var state = {
    loading: false,
    loaded: {},
    error: null
  };
  var promises = [];

  try {
    Object.keys(obj).forEach(function (key) {
      var result = load(obj[key]);

      if (!result.loading) {
        state.loaded[key] = result.loaded;
        state.error = result.error;
      } else {
        state.loading = true;
      }

      promises.push(result.promise);
      result.promise.then(function (res) {
        state.loaded[key] = res;
      })["catch"](function (err) {
        state.error = err;
      });
    });
  } catch (err) {
    state.error = err;
  }

  state.promise = Promise.all(promises).then(function (res) {
    state.loading = false;
    return res;
  })["catch"](function (err) {
    state.loading = false;
    throw err;
  });
  return state;
}

function resolve(obj) {
  return obj && obj.__esModule ? obj["default"] : obj;
}

function render(loaded, props) {
  return /*#__PURE__*/_react["default"].createElement(resolve(loaded), props);
}

function createLoadableComponent(loadFn, options) {
  var _s = $RefreshSig$();

  var opts = Object.assign({
    loader: null,
    loading: null,
    delay: 200,
    timeout: null,
    render: render,
    webpack: null,
    modules: null
  }, options);
  var subscription = null;

  function init() {
    if (!subscription) {
      var sub = new LoadableSubscription(loadFn, opts);
      subscription = {
        getCurrentValue: sub.getCurrentValue.bind(sub),
        subscribe: sub.subscribe.bind(sub),
        retry: sub.retry.bind(sub),
        promise: sub.promise.bind(sub)
      };
    }

    return subscription.promise();
  } // Server only


  if (false) {} // Client only


  if (!initialized && true && typeof opts.webpack === 'function') {
    var moduleIds = opts.webpack();
    READY_INITIALIZERS.push(function (ids) {
      var _iterator = _createForOfIteratorHelper(moduleIds),
          _step;

      try {
        for (_iterator.s(); !(_step = _iterator.n()).done;) {
          var moduleId = _step.value;

          if (ids.indexOf(moduleId) !== -1) {
            return init();
          }
        }
      } catch (err) {
        _iterator.e(err);
      } finally {
        _iterator.f();
      }
    });
  }

  var LoadableComponent = function LoadableComponent(props, ref) {
    _s();

    init();

    var context = _react["default"].useContext(_loadableContext.LoadableContext);

    var state = (0, _useSubscription.useSubscription)(subscription);

    _react["default"].useImperativeHandle(ref, function () {
      return {
        retry: subscription.retry
      };
    }, []);

    if (context && Array.isArray(opts.modules)) {
      opts.modules.forEach(function (moduleName) {
        context(moduleName);
      });
    }

    return _react["default"].useMemo(function () {
      if (state.loading || state.error) {
        return /*#__PURE__*/_react["default"].createElement(opts.loading, {
          isLoading: state.loading,
          pastDelay: state.pastDelay,
          timedOut: state.timedOut,
          error: state.error,
          retry: subscription.retry
        });
      } else if (state.loaded) {
        return opts.render(state.loaded, props);
      } else {
        return null;
      }
    }, [props, state]);
  };

  _s(LoadableComponent, "Bp87+qHhaUk8bOFGKxqLWPW1xR0=", true);

  LoadableComponent.preload = function () {
    return init();
  };

  LoadableComponent.displayName = 'LoadableComponent';
  return /*#__PURE__*/_react["default"].forwardRef(LoadableComponent);
}

var LoadableSubscription = /*#__PURE__*/function () {
  function LoadableSubscription(loadFn, opts) {
    _classCallCheck(this, LoadableSubscription);

    this._loadFn = loadFn;
    this._opts = opts;
    this._callbacks = new Set();
    this._delay = null;
    this._timeout = null;
    this.retry();
  }

  _createClass(LoadableSubscription, [{
    key: "promise",
    value: function promise() {
      return this._res.promise;
    }
  }, {
    key: "retry",
    value: function retry() {
      var _this = this;

      this._clearTimeouts();

      this._res = this._loadFn(this._opts.loader);
      this._state = {
        pastDelay: false,
        timedOut: false
      };
      var res = this._res,
          opts = this._opts;

      if (res.loading) {
        if (typeof opts.delay === 'number') {
          if (opts.delay === 0) {
            this._state.pastDelay = true;
          } else {
            this._delay = setTimeout(function () {
              _this._update({
                pastDelay: true
              });
            }, opts.delay);
          }
        }

        if (typeof opts.timeout === 'number') {
          this._timeout = setTimeout(function () {
            _this._update({
              timedOut: true
            });
          }, opts.timeout);
        }
      }

      this._res.promise.then(function () {
        _this._update({});

        _this._clearTimeouts();
      })["catch"](function (_err) {
        _this._update({});

        _this._clearTimeouts();
      });

      this._update({});
    }
  }, {
    key: "_update",
    value: function _update(partial) {
      this._state = _objectSpread(_objectSpread({}, this._state), {}, {
        error: this._res.error,
        loaded: this._res.loaded,
        loading: this._res.loading
      }, partial);

      this._callbacks.forEach(function (callback) {
        return callback();
      });
    }
  }, {
    key: "_clearTimeouts",
    value: function _clearTimeouts() {
      clearTimeout(this._delay);
      clearTimeout(this._timeout);
    }
  }, {
    key: "getCurrentValue",
    value: function getCurrentValue() {
      return this._state;
    }
  }, {
    key: "subscribe",
    value: function subscribe(callback) {
      var _this2 = this;

      this._callbacks.add(callback);

      return function () {
        _this2._callbacks["delete"](callback);
      };
    }
  }]);

  return LoadableSubscription;
}();

function Loadable(opts) {
  return createLoadableComponent(load, opts);
}

_c = Loadable;

function LoadableMap(opts) {
  if (typeof opts.render !== 'function') {
    throw new Error('LoadableMap requires a `render(loaded, props)` function');
  }

  return createLoadableComponent(loadMap, opts);
}

_c2 = LoadableMap;
Loadable.Map = LoadableMap;

function flushInitializers(initializers, ids) {
  var promises = [];

  while (initializers.length) {
    var init = initializers.pop();
    promises.push(init(ids));
  }

  return Promise.all(promises).then(function () {
    if (initializers.length) {
      return flushInitializers(initializers, ids);
    }
  });
}

Loadable.preloadAll = function () {
  return new Promise(function (resolveInitializers, reject) {
    flushInitializers(ALL_INITIALIZERS).then(resolveInitializers, reject);
  });
};

Loadable.preloadReady = function () {
  var ids = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : [];
  return new Promise(function (resolvePreload) {
    var res = function res() {
      initialized = true;
      return resolvePreload();
    }; // We always will resolve, errors should be handled within loading UIs.


    flushInitializers(READY_INITIALIZERS, ids).then(res, res);
  });
};

if (true) {
  window.__NEXT_PRELOADREADY = Loadable.preloadReady;
}

var _default = Loadable;
exports["default"] = _default;

var _c, _c2;

$RefreshReg$(_c, "Loadable");
$RefreshReg$(_c2, "LoadableMap");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../compiled/webpack/module.js */ "./node_modules/next/dist/compiled/webpack/module.js")(module)))

/***/ }),

/***/ "./node_modules/next/dynamic.js":
/*!**************************************!*\
  !*** ./node_modules/next/dynamic.js ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! ./dist/next-server/lib/dynamic */ "./node_modules/next/dist/next-server/lib/dynamic.js")


/***/ }),

/***/ "./node_modules/use-subscription/cjs/use-subscription.development.js":
/*!***************************************************************************!*\
  !*** ./node_modules/use-subscription/cjs/use-subscription.development.js ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/** @license React vundefined
 * use-subscription.development.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */



if (true) {
  (function() {
'use strict';

var _assign = __webpack_require__(/*! object-assign */ "./node_modules/next/dist/build/polyfills/object-assign.js");
var react = __webpack_require__(/*! react */ "./node_modules/react/index.js");

//
// In order to avoid removing and re-adding subscriptions each time this hook is called,
// the parameters passed to this hook should be memoized in some way–
// either by wrapping the entire params object with useMemo()
// or by wrapping the individual callbacks with useCallback().

function useSubscription(_ref) {
  var getCurrentValue = _ref.getCurrentValue,
      subscribe = _ref.subscribe;

  // Read the current value from our subscription.
  // When this value changes, we'll schedule an update with React.
  // It's important to also store the hook params so that we can check for staleness.
  // (See the comment in checkForUpdates() below for more info.)
  var _useState = react.useState(function () {
    return {
      getCurrentValue: getCurrentValue,
      subscribe: subscribe,
      value: getCurrentValue()
    };
  }),
      state = _useState[0],
      setState = _useState[1];

  var valueToReturn = state.value; // If parameters have changed since our last render, schedule an update with its current value.

  if (state.getCurrentValue !== getCurrentValue || state.subscribe !== subscribe) {
    // If the subscription has been updated, we'll schedule another update with React.
    // React will process this update immediately, so the old subscription value won't be committed.
    // It is still nice to avoid returning a mismatched value though, so let's override the return value.
    valueToReturn = getCurrentValue();
    setState({
      getCurrentValue: getCurrentValue,
      subscribe: subscribe,
      value: valueToReturn
    });
  } // Display the current value for this hook in React DevTools.


  react.useDebugValue(valueToReturn); // It is important not to subscribe while rendering because this can lead to memory leaks.
  // (Learn more at reactjs.org/docs/strict-mode.html#detecting-unexpected-side-effects)
  // Instead, we wait until the commit phase to attach our handler.
  //
  // We intentionally use a passive effect (useEffect) rather than a synchronous one (useLayoutEffect)
  // so that we don't stretch the commit phase.
  // This also has an added benefit when multiple components are subscribed to the same source:
  // It allows each of the event handlers to safely schedule work without potentially removing an another handler.
  // (Learn more at https://codesandbox.io/s/k0yvr5970o)

  react.useEffect(function () {
    var didUnsubscribe = false;

    var checkForUpdates = function () {
      // It's possible that this callback will be invoked even after being unsubscribed,
      // if it's removed as a result of a subscription event/update.
      // In this case, React will log a DEV warning about an update from an unmounted component.
      // We can avoid triggering that warning with this check.
      if (didUnsubscribe) {
        return;
      } // We use a state updater function to avoid scheduling work for a stale source.
      // However it's important to eagerly read the currently value,
      // so that all scheduled work shares the same value (in the event of multiple subscriptions).
      // This avoids visual "tearing" when a mutation happens during a (concurrent) render.


      var value = getCurrentValue();
      setState(function (prevState) {
        // Ignore values from stale sources!
        // Since we subscribe an unsubscribe in a passive effect,
        // it's possible that this callback will be invoked for a stale (previous) subscription.
        // This check avoids scheduling an update for that stale subscription.
        if (prevState.getCurrentValue !== getCurrentValue || prevState.subscribe !== subscribe) {
          return prevState;
        } // Some subscriptions will auto-invoke the handler, even if the value hasn't changed.
        // If the value hasn't changed, no update is needed.
        // Return state as-is so React can bail out and avoid an unnecessary render.


        if (prevState.value === value) {
          return prevState;
        }

        return _assign({}, prevState, {
          value: value
        });
      });
    };

    var unsubscribe = subscribe(checkForUpdates); // Because we're subscribing in a passive effect,
    // it's possible that an update has occurred between render and our effect handler.
    // Check for this and schedule an update if work has occurred.

    checkForUpdates();
    return function () {
      didUnsubscribe = true;
      unsubscribe();
    };
  }, [getCurrentValue, subscribe]); // Return the current value for our caller to use while rendering.

  return valueToReturn;
}

exports.useSubscription = useSubscription;
  })();
}


/***/ }),

/***/ "./node_modules/use-subscription/index.js":
/*!************************************************!*\
  !*** ./node_modules/use-subscription/index.js ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


if (false) {} else {
  module.exports = __webpack_require__(/*! ./cjs/use-subscription.development.js */ "./node_modules/use-subscription/cjs/use-subscription.development.js");
}


/***/ }),

/***/ "./pages/components/Offer/offerCards.js":
/*!**********************************************!*\
  !*** ./pages/components/Offer/offerCards.js ***!
  \**********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/dynamic */ "./node_modules/next/dynamic.js");
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! lodash */ "./node_modules/lodash/lodash.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_5__);


var _jsxFileName = "C:\\xampp\\htdocs\\ReactTuts\\NextJS\\ofccode\\pages\\components\\Offer\\offerCards.js",
    _this = undefined;







var slug = __webpack_require__(/*! slug */ "./node_modules/slug/slug.js");

var getParsedDate = function getParsedDate(date) {
  return moment__WEBPACK_IMPORTED_MODULE_4___default()(date).startOf("hour").fromNow();
};

var Card = function Card(props) {
  var cuelinksOffers = props.cuelinksOffers ? props.cuelinksOffers : {};
  var store__logo = props.storeInfo ? props.storeInfo.slug : {};
  var store__name = props.storeInfo ? props.storeInfo.name : {};
  var limit = props.limit ? props.limit : {};

  if (cuelinksOffers) {
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("section", {
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "clearfix",
        children: lodash__WEBPACK_IMPORTED_MODULE_3___default.a.map(cuelinksOffers, function (value, key) {
          var promocodeCard = false;
          var cuelOffers = {};
          cuelOffers['title'] = value['title'];
          cuelOffers['merchant'] = value['merchant'];
          cuelOffers['id'] = value['id'];
          cuelOffers['categories'] = value['categories'];
          cuelOffers['description'] = value['description'];
          cuelOffers['coupon_code'] = value['coupon_code'];
          cuelOffers['url'] = value['url'];
          cuelOffers['start_date'] = value['start_date'];
          cuelOffers['end_date'] = value['end_date'];
          cuelOffers['offer_added_at'] = value['offer_added_at'];
          cuelOffers['image_url'] = value['image_url'];
          cuelOffers['campaign_name'] = value['campaign_name'];

          if (value['title'] !== "") {
            if (cuelOffers['coupon_code'] != "") {
              promocodeCard = true;
            }

            return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: key,
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "row",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "deal__card",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                    className: "deal__discount",
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                      className: "deal__info",
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
                          src: cuelOffers['image_url'],
                          onError: function onError(e) {
                            e.target.onerror = null;
                            e.target.src = "/img-notfound.jpg";
                          },
                          alt: cuelOffers['title']
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 53,
                          columnNumber: 29
                        }, _this), " "]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 52,
                        columnNumber: 27
                      }, _this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 51,
                      columnNumber: 25
                    }, _this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 50,
                    columnNumber: 23
                  }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                    className: "deal__desc",
                    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                      className: "deal__desc-type"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 65,
                      columnNumber: 25
                    }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                      className: "deal__desc-title",
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h3", {
                        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_5___default.a, {
                          href: '/product/' + slug(cuelOffers['title']),
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                            "data-url": '/product/' + slug(cuelOffers['title']),
                            "data-promolink": '/product/' + slug(cuelOffers['title']),
                            "data-func": "getPromoCode",
                            className: "getPromoCode",
                            target: "_blank",
                            title: "OffersCode.in - Promo code for " + cuelOffers['campaign_name'] + " deal " + cuelOffers['title'],
                            rel: "nofollow",
                            children: [cuelOffers['merchant'], " : ", cuelOffers['title']]
                          }, void 0, true, {
                            fileName: _jsxFileName,
                            lineNumber: 69,
                            columnNumber: 31
                          }, _this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 68,
                          columnNumber: 29
                        }, _this)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 67,
                        columnNumber: 27
                      }, _this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 66,
                      columnNumber: 25
                    }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                      className: "deal__desc-meta",
                      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                        className: "deal__desc-meta-lastused",
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
                          className: "fa fa-users"
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 90,
                          columnNumber: 29
                        }, _this), "\xA0", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("b", {
                          children: Math.floor(Math.random() * 200) + 11
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 91,
                          columnNumber: 29
                        }, _this), " People Used Today"]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 89,
                        columnNumber: 27
                      }, _this), "\xA0|\xA0", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                        className: "deal__desc-meta-lastused",
                        children: cuelOffers['categories']
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 95,
                        columnNumber: 27
                      }, _this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 88,
                      columnNumber: 25
                    }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                      className: "deal__cta",
                      children: promocodeCard ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_5___default.a, {
                          href: '/product/' + slug(cuelOffers['title']),
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                            "data-url": '/product/' + slug(cuelOffers['title']) // data-promocode={''}
                            // data-species={''}
                            ,
                            "data-promolink": '/product/' + slug(cuelOffers['title']),
                            "data-func": "getPromoCode",
                            className: "getPromoCode" // data-website={''}
                            ,
                            target: "_blank",
                            title: "OffersCode.in - Promo code for " + cuelOffers['campaign_name'] + " deal " + cuelOffers['title'],
                            rel: "nofollow",
                            onClick: clickUrl(cuelOffers['url']),
                            children: cuelOffers['coupon_code']
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 104,
                            columnNumber: 33
                          }, _this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 103,
                          columnNumber: 31
                        }, _this)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 102,
                        columnNumber: 29
                      }, _this) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_5___default.a, {
                          href: '/product/' + slug(cuelOffers['title']),
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                            // href={`/goto`}
                            "data-url": '/product/' + slug(cuelOffers['title']) // data-promocode={}
                            // data-species={}
                            // data-promolink={}
                            ,
                            "data-func": "getDeal",
                            className: "getDeal" // data-website={}
                            ,
                            target: "_blank" // gotoLink = {value[11]}
                            ,
                            rel: "nofollow",
                            children: "Get Deal"
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 129,
                            columnNumber: 33
                          }, _this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 128,
                          columnNumber: 31
                        }, _this)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 127,
                        columnNumber: 29
                      }, _this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 100,
                      columnNumber: 25
                    }, _this)]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 64,
                    columnNumber: 23
                  }, _this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 49,
                  columnNumber: 21
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 48,
                columnNumber: 19
              }, _this)
            }, key, false, {
              fileName: _jsxFileName,
              lineNumber: 47,
              columnNumber: 17
            }, _this);
          }
        })
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 25,
        columnNumber: 9
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 24,
      columnNumber: 7
    }, _this);
  } else {
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 161,
        columnNumber: 9
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 162,
        columnNumber: 9
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 163,
        columnNumber: 9
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h3", {
        children: "No New Deals Or Coupons Found"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 164,
        columnNumber: 9
      }, _this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 160,
      columnNumber: 7
    }, _this);
  }
};

_c = Card;
/* harmony default export */ __webpack_exports__["default"] = (Card);

var _c;

$RefreshReg$(_c, "Card");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4uLy4uLy4uL25leHQtc2VydmVyL2xpYi9keW5hbWljLnRzeCIsIndlYnBhY2s6Ly9fTl9FLy4uLy4uLy4uL25leHQtc2VydmVyL2xpYi9sb2FkYWJsZS1jb250ZXh0LnRzIiwid2VicGFjazovL19OX0UvLi4vLi4vLi4vbmV4dC1zZXJ2ZXIvbGliL2xvYWRhYmxlLmpzIiwid2VicGFjazovL19OX0UvLi9ub2RlX21vZHVsZXMvbmV4dC9keW5hbWljLmpzIiwid2VicGFjazovL19OX0UvLi9ub2RlX21vZHVsZXMvdXNlLXN1YnNjcmlwdGlvbi9janMvdXNlLXN1YnNjcmlwdGlvbi5kZXZlbG9wbWVudC5qcyIsIndlYnBhY2s6Ly9fTl9FLy4vbm9kZV9tb2R1bGVzL3VzZS1zdWJzY3JpcHRpb24vaW5kZXguanMiLCJ3ZWJwYWNrOi8vX05fRS8uL3BhZ2VzL2NvbXBvbmVudHMvT2ZmZXIvb2ZmZXJDYXJkcy5qcyJdLCJuYW1lcyI6WyJpc1NlcnZlclNpZGUiLCJsb2FkYWJsZU9wdGlvbnMiLCJMb2FkYWJsZUluaXRpYWxpemVyIiwiTG9hZGluZyIsImxvYWRhYmxlRm4iLCJMb2FkYWJsZSIsImxvYWRpbmciLCJlcnJvciIsImR5bmFtaWNPcHRpb25zIiwiY29uc29sZSIsImxvYWRNb2R1bGVzIiwibW9kdWxlcyIsIk9iamVjdCIsImtleSIsInZhbHVlIiwibW9kIiwibm9TU1IiLCJMb2FkYWJsZUNvbnRleHQiLCJSZWFjdCIsIkFMTF9JTklUSUFMSVpFUlMiLCJSRUFEWV9JTklUSUFMSVpFUlMiLCJpbml0aWFsaXplZCIsInByb21pc2UiLCJsb2FkZXIiLCJzdGF0ZSIsImxvYWRlZCIsImVyciIsInByb21pc2VzIiwicmVzdWx0IiwibG9hZCIsIm9iaiIsInJlcyIsIlByb21pc2UiLCJyZXNvbHZlIiwib3B0cyIsImRlbGF5IiwidGltZW91dCIsInJlbmRlciIsIndlYnBhY2siLCJzdWJzY3JpcHRpb24iLCJzdWIiLCJnZXRDdXJyZW50VmFsdWUiLCJzdWJzY3JpYmUiLCJyZXRyeSIsIm1vZHVsZUlkcyIsImlkcyIsImluaXQiLCJMb2FkYWJsZUNvbXBvbmVudCIsImNvbnRleHQiLCJBcnJheSIsIm1vZHVsZU5hbWUiLCJpc0xvYWRpbmciLCJwYXN0RGVsYXkiLCJ0aW1lZE91dCIsIkxvYWRhYmxlU3Vic2NyaXB0aW9uIiwiY29uc3RydWN0b3IiLCJfcmVzIiwiX29wdHMiLCJzZXRUaW1lb3V0IiwiX2VyciIsIl91cGRhdGUiLCJjYWxsYmFjayIsIl9jbGVhclRpbWVvdXRzIiwiY2xlYXJUaW1lb3V0IiwiY3JlYXRlTG9hZGFibGVDb21wb25lbnQiLCJpbml0aWFsaXplcnMiLCJmbHVzaEluaXRpYWxpemVycyIsInJlc29sdmVQcmVsb2FkIiwid2luZG93Iiwic2x1ZyIsInJlcXVpcmUiLCJnZXRQYXJzZWREYXRlIiwiZGF0ZSIsIk1vbWVudCIsInN0YXJ0T2YiLCJmcm9tTm93IiwiQ2FyZCIsInByb3BzIiwiY3VlbGlua3NPZmZlcnMiLCJzdG9yZV9fbG9nbyIsInN0b3JlSW5mbyIsInN0b3JlX19uYW1lIiwibmFtZSIsImxpbWl0IiwiXyIsIm1hcCIsInByb21vY29kZUNhcmQiLCJjdWVsT2ZmZXJzIiwiZSIsInRhcmdldCIsIm9uZXJyb3IiLCJzcmMiLCJNYXRoIiwiZmxvb3IiLCJyYW5kb20iLCJjbGlja1VybCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBOztBQUNBOzs7Ozs7QUFFQTs7QUFBQSxJQUFNQSxZQUFOOztBQWlETyxxREFHbUI7QUFDeEI7QUFDQSxTQUFPQyxlQUFlLENBQXRCO0FBQ0EsU0FBT0EsZUFBZSxDQUF0QixRQUh3QixDQUt4Qjs7QUFDQSxNQUFJLENBQUosY0FBbUI7QUFDakIsV0FBT0MsbUJBQW1CLENBQTFCLGVBQTBCLENBQTFCO0FBR0Y7O0FBQUEsTUFBTUMsT0FBTyxHQUFHRixlQUFlLENBQS9CLFFBVndCLENBV3hCOztBQUNBLFNBQU87QUFBQSx3QkFDTDtBQUFTLFdBQUssRUFBZDtBQUFzQixlQUFTLEVBQS9CO0FBQWdDLGVBQVMsRUFBekM7QUFBa0QsY0FBUSxFQUQ1RDtBQUNFLE1BREs7QUFBQSxHQUFQO0FBS0YsQyxDQUFBOzs7QUFFZSwwQ0FHVztBQUN4QixNQUFJRyxVQUF5QixHQUFHQyxTQUFoQztBQUNBLE1BQUlKLGVBQW1DLEdBQUc7QUFDeEM7QUFDQUssV0FBTyxFQUFFLHVCQUFxQztBQUFBLFVBQXBDLEtBQW9DLFFBQXBDLEtBQW9DO0FBQUEsVUFBcEMsU0FBb0MsUUFBcEMsU0FBb0M7QUFBQSxVQUFyQyxTQUFxQyxRQUFyQyxTQUFxQztBQUM1QyxVQUFJLENBQUosV0FBZ0I7O0FBQ2hCLGdCQUE0QztBQUMxQyx1QkFBZTtBQUNiO0FBRUY7O0FBQUEsbUJBQVc7QUFDVCw4QkFDRSwyQ0FDR0MsS0FBSyxDQURSLHNCQUVFLHNDQUZGLElBRUUsQ0FGRixFQUdHQSxLQUFLLENBSlYsS0FDRSxDQURGO0FBUUg7QUFFRDs7QUFBQTtBQW5CSjtBQUEwQyxHQUExQyxDQUZ3QixDQXlCeEI7QUFDQTtBQUNBO0FBQ0E7O0FBQ0EsTUFBSUMsY0FBYyxZQUFsQixTQUF1QztBQUNyQ1AsbUJBQWUsQ0FBZkEsU0FBeUI7QUFBQSxhQUF6QkEsY0FBeUI7QUFBQSxLQUF6QkEsQ0FEcUMsQ0FFckM7O0FBRkYsU0FHTyxJQUFJLDBCQUFKLFlBQTBDO0FBQy9DQSxtQkFBZSxDQUFmQSx3QkFEK0MsQ0FFL0M7QUFGSyxTQUdBLElBQUksMEJBQUosVUFBd0M7QUFDN0NBLG1CQUFlLG1DQUFHLGVBQUgsR0FBZkEsY0FBZSxDQUFmQTtBQUdGLEdBdkN3QixDQXVDeEI7OztBQUNBQSxpQkFBZSxtQ0FBRyxlQUFILEdBQWZBLE9BQWUsQ0FBZkE7O0FBRUEsTUFDRSxzQ0FDQSxFQUFFTyxjQUFjLFlBRmxCLE9BRUUsQ0FGRixFQUdFO0FBQ0E7QUFDQSxjQUEyQztBQUN6QyxVQUFJQSxjQUFjLENBQWxCLFNBQTRCO0FBQzFCQyxlQUFPLENBQVBBO0FBSUg7QUFDRCxLQVRBLENBU0E7OztBQUNBLFFBQUlELGNBQWMsQ0FBbEIsUUFBMkI7QUFDekJQLHFCQUFlLENBQWZBLFNBQXlCO0FBQUEsZUFDdkJPLGNBQWMsQ0FBZEEsY0FERlAsTUFDRU8sQ0FEdUI7QUFBQSxPQUF6QlA7QUFHRixLQWRBLENBY0E7OztBQUNBLFFBQUlPLGNBQWMsQ0FBbEIsU0FBNEI7QUFDMUJKLGdCQUFVLEdBQUdDLHFCQUFiRDtBQUNBLFVBQU1NLFdBQXNCLEdBQTVCO0FBQ0EsVUFBTUMsT0FBTyxHQUFHSCxjQUFjLENBQTlCLE9BQWdCQSxFQUFoQjtBQUNBSSxZQUFNLENBQU5BLHNCQUE4QkMsYUFBRCxFQUFTO0FBQ3BDLFlBQU1DLEtBQVUsR0FBR0gsT0FBTyxDQUExQixHQUEwQixDQUExQjs7QUFDQSxZQUFJLE9BQU9HLEtBQUssQ0FBWixTQUFKLFlBQXNDO0FBQ3BDSixxQkFBVyxDQUFYQSxHQUFXLENBQVhBLEdBQW1CO0FBQUEsbUJBQU1JLEtBQUssQ0FBTEEsS0FBWUMsYUFBRDtBQUFBLHFCQUFjQSxrQkFBbERMLEdBQW9DO0FBQUEsYUFBWEksQ0FBTjtBQUFBLFdBQW5CSjs7QUFDQTtBQUVGQTs7QUFBQUEsbUJBQVcsQ0FBWEEsR0FBVyxDQUFYQTtBQU5GRTtBQVFBWCxxQkFBZSxDQUFmQTtBQUVIO0FBRUQsR0E1RXdCLENBNEV4Qjs7O0FBQ0EsTUFBSUEsZUFBZSxDQUFuQixtQkFBdUM7QUFDckNBLG1CQUFlLG1DQUFHLGVBQUgsR0FFVkEsZUFBZSxDQUZwQkEsaUJBQWUsQ0FBZkE7QUFJQSxXQUFPQSxlQUFlLENBQXRCO0FBR0YsR0FyRndCLENBcUZ4Qjs7O0FBQ0EsTUFBSSxPQUFPQSxlQUFlLENBQXRCLFFBQUosV0FBOEM7QUFDNUMsUUFBSSxDQUFDQSxlQUFlLENBQXBCLEtBQTBCO0FBQ3hCLGFBQU9BLGVBQWUsQ0FBdEI7QUFDQSxhQUFPZSxLQUFLLGFBQVosZUFBWSxDQUFaO0FBRUY7O0FBQUEsV0FBT2YsZUFBZSxDQUF0QjtBQUdGOztBQUFBLFNBQU9HLFVBQVUsQ0FBakIsZUFBaUIsQ0FBakI7QUFDRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUM1S0Q7Ozs7OztBQUlPOztBQUFBLElBQU1hLGVBQWUsZ0JBQUdDLGdDQUF4QixJQUF3QkEsQ0FBeEI7Ozs7QUFFUCxVQUEyQztBQUN6Q0QsaUJBQWUsQ0FBZkE7QUFDRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDZUQ7O0FBQ0E7O0FBQ0E7Ozs7OztBQXpCQTtBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFNQSxJQUFNRSxnQkFBZ0IsR0FBdEI7QUFDQSxJQUFNQyxrQkFBa0IsR0FBeEI7QUFDQSxJQUFJQyxXQUFXLEdBQWY7O0FBRUEsc0JBQXNCO0FBQ3BCLE1BQUlDLE9BQU8sR0FBR0MsTUFBZDtBQUVBLE1BQUlDLEtBQUssR0FBRztBQUNWbEIsV0FBTyxFQURHO0FBRVZtQixVQUFNLEVBRkk7QUFHVmxCLFNBQUssRUFIUDtBQUFZLEdBQVo7QUFNQWlCLE9BQUssQ0FBTEEsVUFBZ0JGLE9BQU8sQ0FBUEEsS0FDUEcsZ0JBQUQsRUFBWTtBQUNoQkQsU0FBSyxDQUFMQTtBQUNBQSxTQUFLLENBQUxBO0FBQ0E7QUFKWUYsY0FNTkksYUFBRCxFQUFTO0FBQ2RGLFNBQUssQ0FBTEE7QUFDQUEsU0FBSyxDQUFMQTtBQUNBO0FBVEpBLEdBQWdCRixDQUFoQkU7QUFZQTtBQUdGOztBQUFBLHNCQUFzQjtBQUNwQixNQUFJQSxLQUFLLEdBQUc7QUFDVmxCLFdBQU8sRUFERztBQUVWbUIsVUFBTSxFQUZJO0FBR1ZsQixTQUFLLEVBSFA7QUFBWSxHQUFaO0FBTUEsTUFBSW9CLFFBQVEsR0FBWjs7QUFFQSxNQUFJO0FBQ0ZmLFVBQU0sQ0FBTkEsa0JBQTBCQyxhQUFELEVBQVM7QUFDaEMsVUFBSWUsTUFBTSxHQUFHQyxJQUFJLENBQUNDLEdBQUcsQ0FBckIsR0FBcUIsQ0FBSixDQUFqQjs7QUFFQSxVQUFJLENBQUNGLE1BQU0sQ0FBWCxTQUFxQjtBQUNuQkosYUFBSyxDQUFMQSxjQUFvQkksTUFBTSxDQUExQko7QUFDQUEsYUFBSyxDQUFMQSxRQUFjSSxNQUFNLENBQXBCSjtBQUZGLGFBR087QUFDTEEsYUFBSyxDQUFMQTtBQUdGRzs7QUFBQUEsY0FBUSxDQUFSQSxLQUFjQyxNQUFNLENBQXBCRDtBQUVBQyxZQUFNLENBQU5BLGFBQ1NHLGFBQUQsRUFBUztBQUNiUCxhQUFLLENBQUxBO0FBRkpJLGtCQUlVRixhQUFELEVBQVM7QUFDZEYsYUFBSyxDQUFMQTtBQUxKSTtBQVpGaEI7QUFvQkEsR0FyQkYsQ0FxQkUsWUFBWTtBQUNaWSxTQUFLLENBQUxBO0FBR0ZBOztBQUFBQSxPQUFLLENBQUxBLFVBQWdCUSxPQUFPLENBQVBBLG1CQUNQRCxhQUFELEVBQVM7QUFDYlAsU0FBSyxDQUFMQTtBQUNBO0FBSFlRLGNBS05OLGFBQUQsRUFBUztBQUNkRixTQUFLLENBQUxBO0FBQ0E7QUFQSkEsR0FBZ0JRLENBQWhCUjtBQVVBO0FBR0Y7O0FBQUEsc0JBQXNCO0FBQ3BCLFNBQU9NLEdBQUcsSUFBSUEsR0FBRyxDQUFWQSxhQUF3QkEsR0FBeEJBLGNBQVA7QUFHRjs7QUFBQSwrQkFBK0I7QUFDN0Isc0JBQU9aLGdDQUFvQmUsT0FBTyxDQUEzQmYsTUFBMkIsQ0FBM0JBLEVBQVAsS0FBT0EsQ0FBUDtBQUdGOztBQUFBLGtEQUFrRDtBQUFBOztBQUNoRCxNQUFJZ0IsSUFBSSxHQUFHdEIsTUFBTSxDQUFOQSxPQUNUO0FBQ0VXLFVBQU0sRUFEUjtBQUVFakIsV0FBTyxFQUZUO0FBR0U2QixTQUFLLEVBSFA7QUFJRUMsV0FBTyxFQUpUO0FBS0VDLFVBQU0sRUFMUjtBQU1FQyxXQUFPLEVBTlQ7QUFPRTNCLFdBQU8sRUFSQUM7QUFDVCxHQURTQSxFQUFYLE9BQVdBLENBQVg7QUFhQSxNQUFJMkIsWUFBWSxHQUFoQjs7QUFFQSxrQkFBZ0I7QUFDZCxRQUFJLENBQUosY0FBbUI7QUFDakIsVUFBTUMsR0FBRyxHQUFHLGlDQUFaLElBQVksQ0FBWjtBQUNBRCxrQkFBWSxHQUFHO0FBQ2JFLHVCQUFlLEVBQUVELEdBQUcsQ0FBSEEscUJBREosR0FDSUEsQ0FESjtBQUViRSxpQkFBUyxFQUFFRixHQUFHLENBQUhBLGVBRkUsR0FFRkEsQ0FGRTtBQUdiRyxhQUFLLEVBQUVILEdBQUcsQ0FBSEEsV0FITSxHQUdOQSxDQUhNO0FBSWJsQixlQUFPLEVBQUVrQixHQUFHLENBQUhBLGFBSlhELEdBSVdDO0FBSkksT0FBZkQ7QUFPRjs7QUFBQSxXQUFPQSxZQUFZLENBQW5CLE9BQU9BLEVBQVA7QUFHRixHQTdCZ0QsQ0E2QmhEOzs7QUFDQSxhQUFtQyxFQTlCYSxDQWtDaEQ7OztBQUNBLE1BQ0Usd0JBRUEsT0FBT0wsSUFBSSxDQUFYLFlBSEYsWUFJRTtBQUNBLFFBQU1VLFNBQVMsR0FBR1YsSUFBSSxDQUF0QixPQUFrQkEsRUFBbEI7QUFDQWQsc0JBQWtCLENBQWxCQSxLQUF5QnlCLGFBQUQsRUFBUztBQUFBLGlEQUMvQixTQUQrQjtBQUFBOztBQUFBO0FBQy9CLDREQUFrQztBQUFBLGNBQWxDLFFBQWtDOztBQUNoQyxjQUFJQSxHQUFHLENBQUhBLHNCQUEwQixDQUE5QixHQUFrQztBQUNoQyxtQkFBT0MsSUFBUDtBQUVIO0FBQ0Y7QUFOZ0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFqQzFCO0FBU0Y7O0FBQUEsTUFBTTJCLGlCQUFpQixHQUFHLFNBQXBCQSxpQkFBb0IsYUFBZ0I7QUFBQTs7QUFDeENELFFBQUk7O0FBRUosUUFBTUUsT0FBTyxHQUFHOUIsNkJBQWlCRCxpQkFBakMsZUFBZ0JDLENBQWhCOztBQUNBLFFBQU1NLEtBQUssR0FBRyxzQ0FBZCxZQUFjLENBQWQ7O0FBRUFOLCtDQUVFO0FBQUEsYUFBTztBQUNMeUIsYUFBSyxFQUFFSixZQUFZLENBSHZCckI7QUFFUyxPQUFQO0FBQUEsS0FGRkE7O0FBUUEsUUFBSThCLE9BQU8sSUFBSUMsS0FBSyxDQUFMQSxRQUFjZixJQUFJLENBQWpDLE9BQWVlLENBQWYsRUFBNEM7QUFDMUNmLFVBQUksQ0FBSkEsZ0JBQXNCZ0Isb0JBQUQsRUFBZ0I7QUFDbkNGLGVBQU8sQ0FBUEEsVUFBTyxDQUFQQTtBQURGZDtBQUtGOztBQUFBLFdBQU9oQiwwQkFBYyxZQUFNO0FBQ3pCLFVBQUlNLEtBQUssQ0FBTEEsV0FBaUJBLEtBQUssQ0FBMUIsT0FBa0M7QUFDaEMsNEJBQU9OLGdDQUFvQmdCLElBQUksQ0FBeEJoQixTQUFrQztBQUN2Q2lDLG1CQUFTLEVBQUUzQixLQUFLLENBRHVCO0FBRXZDNEIsbUJBQVMsRUFBRTVCLEtBQUssQ0FGdUI7QUFHdkM2QixrQkFBUSxFQUFFN0IsS0FBSyxDQUh3QjtBQUl2Q2pCLGVBQUssRUFBRWlCLEtBQUssQ0FKMkI7QUFLdkNtQixlQUFLLEVBQUVKLFlBQVksQ0FMckI7QUFBeUMsU0FBbENyQixDQUFQO0FBREYsYUFRTyxJQUFJTSxLQUFLLENBQVQsUUFBa0I7QUFDdkIsZUFBT1UsSUFBSSxDQUFKQSxPQUFZVixLQUFLLENBQWpCVSxRQUFQLEtBQU9BLENBQVA7QUFESyxhQUVBO0FBQ0w7QUFFSDtBQWRNaEIsT0FjSixRQWRILEtBY0csQ0FkSUEsQ0FBUDtBQXBCRjs7QUFsRGdELEtBa0QxQzZCLGlCQWxEMEM7O0FBdUZoREEsbUJBQWlCLENBQWpCQSxVQUE0QjtBQUFBLFdBQU1ELElBQWxDQyxFQUE0QjtBQUFBLEdBQTVCQTs7QUFDQUEsbUJBQWlCLENBQWpCQTtBQUVBLHNCQUFPN0IsNkJBQVAsaUJBQU9BLENBQVA7QUFHRjs7SUFBTW9DLG9CO0FBQ0pDLGdDQUFXLE1BQVhBLEVBQVcsSUFBWEEsRUFBMEI7QUFBQTs7QUFDeEI7QUFDQTtBQUNBLHNCQUFrQixJQUFsQixHQUFrQixFQUFsQjtBQUNBO0FBQ0E7QUFFQTtBQUdGakM7Ozs7OEJBQVU7QUFDUixhQUFPLFVBQVA7QUFHRnFCOzs7NEJBQVE7QUFBQTs7QUFDTjs7QUFDQSxrQkFBWSxhQUFhLFdBQXpCLE1BQVksQ0FBWjtBQUVBLG9CQUFjO0FBQ1pTLGlCQUFTLEVBREc7QUFFWkMsZ0JBQVEsRUFGVjtBQUFjLE9BQWQ7QUFKTSxVQVNBLEdBVEEsR0FTTixJQVRNLENBU0VHLElBVEY7QUFBQSxVQVNBLElBVEEsR0FTTixJQVRNLENBU2FDLEtBVGI7O0FBV04sVUFBSTFCLEdBQUcsQ0FBUCxTQUFpQjtBQUNmLFlBQUksT0FBT0csSUFBSSxDQUFYLFVBQUosVUFBb0M7QUFDbEMsY0FBSUEsSUFBSSxDQUFKQSxVQUFKLEdBQXNCO0FBQ3BCO0FBREYsaUJBRU87QUFDTCwwQkFBY3dCLFVBQVUsQ0FBQyxZQUFNO0FBQzdCLDRCQUFhO0FBQ1hOLHlCQUFTLEVBRFg7QUFBYSxlQUFiO0FBRHNCLGVBSXJCbEIsSUFBSSxDQUpQLEtBQXdCLENBQXhCO0FBTUg7QUFFRDs7QUFBQSxZQUFJLE9BQU9BLElBQUksQ0FBWCxZQUFKLFVBQXNDO0FBQ3BDLDBCQUFnQndCLFVBQVUsQ0FBQyxZQUFNO0FBQy9CLDBCQUFhO0FBQUVMLHNCQUFRLEVBQXZCO0FBQWEsYUFBYjtBQUR3QixhQUV2Qm5CLElBQUksQ0FGUCxPQUEwQixDQUExQjtBQUlIO0FBRUQ7O0FBQUEsNkJBQ1EsWUFBTTtBQUNWOztBQUNBO0FBSEosa0JBS1V5QixjQUFELEVBQVU7QUFDZjs7QUFDQTtBQVBKOztBQVNBO0FBR0ZDOzs7NEJBQU8sTyxFQUFVO0FBQ2Ysb0RBQ0ssS0FEUyxNQUFkO0FBRUVyRCxhQUFLLEVBQUUsVUFGSyxLQUFkO0FBR0VrQixjQUFNLEVBQUUsVUFISSxNQUFkO0FBSUVuQixlQUFPLEVBQUUsVUFKRztBQUFkOztBQU9BLDhCQUF5QnVELGtCQUFEO0FBQUEsZUFBY0EsUUFBdEMsRUFBd0I7QUFBQSxPQUF4QjtBQUdGQzs7O3FDQUFpQjtBQUNmQyxrQkFBWSxDQUFDLEtBQWJBLE1BQVksQ0FBWkE7QUFDQUEsa0JBQVksQ0FBQyxLQUFiQSxRQUFZLENBQVpBO0FBR0Z0Qjs7O3NDQUFrQjtBQUNoQixhQUFPLEtBQVA7QUFHRkM7Ozs4QkFBUyxRLEVBQVc7QUFBQTs7QUFDbEI7O0FBQ0EsYUFBTyxZQUFNO0FBQ1g7QUFERjtBQWhGdUI7Ozs7OztBQXNGM0Isd0JBQXdCO0FBQ3RCLFNBQU9zQix1QkFBdUIsT0FBOUIsSUFBOEIsQ0FBOUI7QUFHRjs7S0FKQSxROztBQUlBLDJCQUEyQjtBQUN6QixNQUFJLE9BQU85QixJQUFJLENBQVgsV0FBSixZQUF1QztBQUNyQyxVQUFNLFVBQU4seURBQU0sQ0FBTjtBQUdGOztBQUFBLFNBQU84Qix1QkFBdUIsVUFBOUIsSUFBOEIsQ0FBOUI7QUFHRjNEOztNQVJBLFc7QUFRQUEsUUFBUSxDQUFSQTs7QUFFQSw4Q0FBOEM7QUFDNUMsTUFBSXNCLFFBQVEsR0FBWjs7QUFFQSxTQUFPc0MsWUFBWSxDQUFuQixRQUE0QjtBQUMxQixRQUFJbkIsSUFBSSxHQUFHbUIsWUFBWSxDQUF2QixHQUFXQSxFQUFYO0FBQ0F0QyxZQUFRLENBQVJBLEtBQWNtQixJQUFJLENBQWxCbkIsR0FBa0IsQ0FBbEJBO0FBR0Y7O0FBQUEsU0FBT0ssT0FBTyxDQUFQQSxtQkFBMkIsWUFBTTtBQUN0QyxRQUFJaUMsWUFBWSxDQUFoQixRQUF5QjtBQUN2QixhQUFPQyxpQkFBaUIsZUFBeEIsR0FBd0IsQ0FBeEI7QUFFSDtBQUpELEdBQU9sQyxDQUFQO0FBT0YzQjs7QUFBQUEsUUFBUSxDQUFSQSxhQUFzQixZQUFNO0FBQzFCLFNBQU8sWUFBWSx1Q0FBaUM7QUFDbEQ2RCxxQkFBaUIsQ0FBakJBLGdCQUFpQixDQUFqQkE7QUFERixHQUFPLENBQVA7QUFERjdEOztBQU1BLFFBQVEsQ0FBUixlQUF3QixZQUFjO0FBQUEsTUFBYndDLEdBQWEsdUVBQWQsRUFBYztBQUNwQyxTQUFPLFlBQWFzQix3QkFBRCxFQUFvQjtBQUNyQyxRQUFNcEMsR0FBRyxHQUFHLFNBQU5BLEdBQU0sR0FBTTtBQUNoQlYsaUJBQVcsR0FBWEE7QUFDQSxhQUFPOEMsY0FBUDtBQUZGLE1BRHFDLENBS3JDOzs7QUFDQUQscUJBQWlCLHFCQUFqQkEsR0FBaUIsQ0FBakJBO0FBTkYsR0FBTyxDQUFQO0FBREY7O0FBV0EsVUFBbUM7QUFDakNFLFFBQU0sQ0FBTkEsc0JBQTZCL0QsUUFBUSxDQUFyQytEOzs7ZUFHYS9ELFE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDblZmLGlCQUFpQixtQkFBTyxDQUFDLDJGQUFnQzs7Ozs7Ozs7Ozs7OztBQ0F6RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVhOztBQUViLElBQUksSUFBcUM7QUFDekM7QUFDQTs7QUFFQSxjQUFjLG1CQUFPLENBQUMsZ0ZBQWU7QUFDckMsWUFBWSxtQkFBTyxDQUFDLDRDQUFPOztBQUUzQjtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBOztBQUVBLGtDQUFrQzs7QUFFbEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMLEdBQUc7OztBQUdILHFDQUFxQztBQUNyQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBOzs7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7OztBQUdBO0FBQ0E7QUFDQTs7QUFFQSx5QkFBeUI7QUFDekI7QUFDQSxTQUFTO0FBQ1QsT0FBTztBQUNQOztBQUVBLGlEQUFpRDtBQUNqRDtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHLGdDQUFnQzs7QUFFbkM7QUFDQTs7QUFFQTtBQUNBLEdBQUc7QUFDSDs7Ozs7Ozs7Ozs7OztBQzFIYTs7QUFFYixJQUFJLEtBQXFDLEVBQUUsRUFFMUM7QUFDRCxtQkFBbUIsbUJBQU8sQ0FBQyxrSEFBdUM7QUFDbEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNMQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBLElBQUlnRSxJQUFJLEdBQUdDLG1CQUFPLENBQUMseUNBQUQsQ0FBbEI7O0FBRUEsSUFBTUMsYUFBYSxHQUFHLFNBQWhCQSxhQUFnQixDQUFDQyxJQUFELEVBQVU7QUFDOUIsU0FBT0MsNkNBQU0sQ0FBQ0QsSUFBRCxDQUFOLENBQWFFLE9BQWIsQ0FBcUIsTUFBckIsRUFBNkJDLE9BQTdCLEVBQVA7QUFDRCxDQUZEOztBQU9BLElBQU1DLElBQUksR0FBRyxTQUFQQSxJQUFPLENBQUNDLEtBQUQsRUFBVztBQUN0QixNQUFNQyxjQUFjLEdBQUdELEtBQUssQ0FBQ0MsY0FBTixHQUF1QkQsS0FBSyxDQUFDQyxjQUE3QixHQUE4QyxFQUFyRTtBQUNBLE1BQU1DLFdBQVcsR0FBR0YsS0FBSyxDQUFDRyxTQUFOLEdBQWtCSCxLQUFLLENBQUNHLFNBQU4sQ0FBZ0JYLElBQWxDLEdBQXlDLEVBQTdEO0FBQ0EsTUFBTVksV0FBVyxHQUFHSixLQUFLLENBQUNHLFNBQU4sR0FBa0JILEtBQUssQ0FBQ0csU0FBTixDQUFnQkUsSUFBbEMsR0FBeUMsRUFBN0Q7QUFDQSxNQUFNQyxLQUFLLEdBQUdOLEtBQUssQ0FBQ00sS0FBTixHQUFjTixLQUFLLENBQUNNLEtBQXBCLEdBQTRCLEVBQTFDOztBQUVBLE1BQUlMLGNBQUosRUFBb0I7QUFDbEIsd0JBQ0U7QUFBQSw2QkFDRTtBQUFLLGlCQUFTLEVBQUMsVUFBZjtBQUFBLGtCQUNHTSw2Q0FBQyxDQUFDQyxHQUFGLENBQU1QLGNBQU4sRUFBc0IsVUFBQ2hFLEtBQUQsRUFBUUQsR0FBUixFQUFnQjtBQUNyQyxjQUFJeUUsYUFBYSxHQUFHLEtBQXBCO0FBQ0EsY0FBSUMsVUFBVSxHQUFHLEVBQWpCO0FBQ0FBLG9CQUFVLENBQUMsT0FBRCxDQUFWLEdBQXNCekUsS0FBSyxDQUFDLE9BQUQsQ0FBM0I7QUFDQXlFLG9CQUFVLENBQUMsVUFBRCxDQUFWLEdBQXlCekUsS0FBSyxDQUFDLFVBQUQsQ0FBOUI7QUFDQXlFLG9CQUFVLENBQUMsSUFBRCxDQUFWLEdBQW1CekUsS0FBSyxDQUFDLElBQUQsQ0FBeEI7QUFDQXlFLG9CQUFVLENBQUMsWUFBRCxDQUFWLEdBQTJCekUsS0FBSyxDQUFDLFlBQUQsQ0FBaEM7QUFDQXlFLG9CQUFVLENBQUMsYUFBRCxDQUFWLEdBQTRCekUsS0FBSyxDQUFDLGFBQUQsQ0FBakM7QUFDQXlFLG9CQUFVLENBQUMsYUFBRCxDQUFWLEdBQTRCekUsS0FBSyxDQUFDLGFBQUQsQ0FBakM7QUFDQXlFLG9CQUFVLENBQUMsS0FBRCxDQUFWLEdBQW9CekUsS0FBSyxDQUFDLEtBQUQsQ0FBekI7QUFDQXlFLG9CQUFVLENBQUMsWUFBRCxDQUFWLEdBQTJCekUsS0FBSyxDQUFDLFlBQUQsQ0FBaEM7QUFDQXlFLG9CQUFVLENBQUMsVUFBRCxDQUFWLEdBQXlCekUsS0FBSyxDQUFDLFVBQUQsQ0FBOUI7QUFDQXlFLG9CQUFVLENBQUMsZ0JBQUQsQ0FBVixHQUErQnpFLEtBQUssQ0FBQyxnQkFBRCxDQUFwQztBQUNBeUUsb0JBQVUsQ0FBQyxXQUFELENBQVYsR0FBMEJ6RSxLQUFLLENBQUMsV0FBRCxDQUEvQjtBQUNBeUUsb0JBQVUsQ0FBQyxlQUFELENBQVYsR0FBOEJ6RSxLQUFLLENBQUMsZUFBRCxDQUFuQzs7QUFFQSxjQUFJQSxLQUFLLENBQUMsT0FBRCxDQUFMLEtBQW1CLEVBQXZCLEVBQTJCO0FBQ3pCLGdCQUFJeUUsVUFBVSxDQUFDLGFBQUQsQ0FBVixJQUE2QixFQUFqQyxFQUFxQztBQUNuQ0QsMkJBQWEsR0FBRyxJQUFoQjtBQUNEOztBQUNELGdDQUNFO0FBQWUsdUJBQVMsRUFBRXpFLEdBQTFCO0FBQUEscUNBQ0U7QUFBSyx5QkFBUyxFQUFDLEtBQWY7QUFBQSx1Q0FDRTtBQUFLLDJCQUFTLEVBQUMsWUFBZjtBQUFBLDBDQUNFO0FBQUssNkJBQVMsRUFBQyxnQkFBZjtBQUFBLDJDQUNFO0FBQUssK0JBQVMsRUFBQyxZQUFmO0FBQUEsNkNBQ0U7QUFBQSxnREFDRTtBQUNFLDZCQUFHLEVBQUUwRSxVQUFVLENBQUMsV0FBRCxDQURqQjtBQUVFLGlDQUFPLEVBQUUsaUJBQUNDLENBQUQsRUFBTztBQUNkQSw2QkFBQyxDQUFDQyxNQUFGLENBQVNDLE9BQVQsR0FBbUIsSUFBbkI7QUFDQUYsNkJBQUMsQ0FBQ0MsTUFBRixDQUFTRSxHQUFULEdBQWUsbUJBQWY7QUFDRCwyQkFMSDtBQU1FLDZCQUFHLEVBQUVKLFVBQVUsQ0FBQyxPQUFEO0FBTmpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBREYsRUFRSyxHQVJMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQURGLGVBZUU7QUFBSyw2QkFBUyxFQUFDLFlBQWY7QUFBQSw0Q0FDRTtBQUFLLCtCQUFTLEVBQUM7QUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQURGLGVBRUU7QUFBSywrQkFBUyxFQUFDLGtCQUFmO0FBQUEsNkNBQ0U7QUFBQSwrQ0FDRSxxRUFBQyxnREFBRDtBQUFNLDhCQUFJLEVBQUUsY0FBWWxCLElBQUksQ0FBQ2tCLFVBQVUsQ0FBQyxPQUFELENBQVgsQ0FBNUI7QUFBQSxpREFDRTtBQUNFLHdDQUFVLGNBQVlsQixJQUFJLENBQUNrQixVQUFVLENBQUMsT0FBRCxDQUFYLENBRDVCO0FBRUUsOENBQWdCLGNBQVlsQixJQUFJLENBQUNrQixVQUFVLENBQUMsT0FBRCxDQUFYLENBRmxDO0FBR0UseUNBQVUsY0FIWjtBQUlFLHFDQUFTLEVBQUMsY0FKWjtBQUtFLGtDQUFNLEVBQUMsUUFMVDtBQU1FLGlDQUFLLEVBQ0gsb0NBQ0FBLFVBQVUsQ0FBQyxlQUFELENBRFYsY0FHQUEsVUFBVSxDQUFDLE9BQUQsQ0FWZDtBQVlFLCtCQUFHLEVBQUMsVUFaTjtBQUFBLHVDQWNHQSxVQUFVLENBQUMsVUFBRCxDQWRiLFNBYzhCQSxVQUFVLENBQUMsT0FBRCxDQWR4QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRkYsZUF3QkU7QUFBSywrQkFBUyxFQUFDLGlCQUFmO0FBQUEsOENBQ0U7QUFBTSxpQ0FBUyxFQUFDLDBCQUFoQjtBQUFBLGdEQUNFO0FBQUcsbUNBQVMsRUFBQztBQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBREYsdUJBRUU7QUFBQSxvQ0FBSUssSUFBSSxDQUFDQyxLQUFMLENBQVdELElBQUksQ0FBQ0UsTUFBTCxLQUFnQixHQUEzQixJQUFrQztBQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFERiw0QkFPRTtBQUFNLGlDQUFTLEVBQUMsMEJBQWhCO0FBQUEsa0NBQ0dQLFVBQVUsQ0FBQyxZQUFEO0FBRGI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBeEJGLGVBb0NFO0FBQUssK0JBQVMsRUFBQyxXQUFmO0FBQUEsZ0NBQ0dELGFBQWEsZ0JBQ1o7QUFBQSwrQ0FDRSxxRUFBQyxnREFBRDtBQUFPLDhCQUFJLEVBQUUsY0FBWWpCLElBQUksQ0FBQ2tCLFVBQVUsQ0FBQyxPQUFELENBQVgsQ0FBN0I7QUFBQSxpREFDRTtBQUNFLHdDQUFVLGNBQVlsQixJQUFJLENBQUNrQixVQUFVLENBQUMsT0FBRCxDQUFYLENBRDVCLENBRUU7QUFDQTtBQUhGO0FBSUUsOENBQWdCLGNBQVlsQixJQUFJLENBQUNrQixVQUFVLENBQUMsT0FBRCxDQUFYLENBSmxDO0FBS0UseUNBQVUsY0FMWjtBQU1FLHFDQUFTLEVBQUMsY0FOWixDQU9FO0FBUEY7QUFRRSxrQ0FBTSxFQUFDLFFBUlQ7QUFTRSxpQ0FBSyxFQUNILG9DQUNBQSxVQUFVLENBQUMsZUFBRCxDQURWLGNBR0FBLFVBQVUsQ0FBQyxPQUFELENBYmQ7QUFlRSwrQkFBRyxFQUFDLFVBZk47QUFnQkUsbUNBQU8sRUFBRVEsUUFBUSxDQUFDUixVQUFVLENBQUMsS0FBRCxDQUFYLENBaEJuQjtBQUFBLHNDQWtCR0EsVUFBVSxDQUFDLGFBQUQ7QUFsQmI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQURZLGdCQTBCWjtBQUFBLCtDQUNFLHFFQUFDLGdEQUFEO0FBQU0sOEJBQUksRUFBRSxjQUFZbEIsSUFBSSxDQUFDa0IsVUFBVSxDQUFDLE9BQUQsQ0FBWCxDQUE1QjtBQUFBLGlEQUNFO0FBQ0U7QUFDQSx3Q0FBVSxjQUFZbEIsSUFBSSxDQUFDa0IsVUFBVSxDQUFDLE9BQUQsQ0FBWCxDQUY1QixDQUdFO0FBQ0E7QUFDQTtBQUxGO0FBTUUseUNBQVUsU0FOWjtBQU9FLHFDQUFTLEVBQUMsU0FQWixDQVFFO0FBUkY7QUFTRSxrQ0FBTSxFQUFDLFFBVFQsQ0FVRTtBQVZGO0FBV0UsK0JBQUcsRUFBQyxVQVhOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUEzQko7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFwQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERixlQUFVMUUsR0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURGO0FBMkdEO0FBQ0YsU0FoSUE7QUFESDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQURGO0FBdUlELEdBeElELE1Bd0lPO0FBQ0wsd0JBQ0U7QUFBQSw4QkFDRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREYsZUFFRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRkYsZUFHRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBSEYsZUFJRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQURGO0FBUUQ7QUFDRixDQXhKRDs7S0FBTStELEk7QUEwSlNBLG1FQUFmIiwiZmlsZSI6InN0YXRpYy93ZWJwYWNrL3BhZ2VzL29mZmVycy42Y2RlYzhjZmM4ZWM5YzkzOWNlOS5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0J1xuaW1wb3J0IExvYWRhYmxlIGZyb20gJy4vbG9hZGFibGUnXG5cbmNvbnN0IGlzU2VydmVyU2lkZSA9IHR5cGVvZiB3aW5kb3cgPT09ICd1bmRlZmluZWQnXG5cbmV4cG9ydCB0eXBlIExvYWRlckNvbXBvbmVudDxQID0ge30+ID0gUHJvbWlzZTxcbiAgUmVhY3QuQ29tcG9uZW50VHlwZTxQPiB8IHsgZGVmYXVsdDogUmVhY3QuQ29tcG9uZW50VHlwZTxQPiB9XG4+XG5cbmV4cG9ydCB0eXBlIExvYWRlcjxQID0ge30+ID0gKCgpID0+IExvYWRlckNvbXBvbmVudDxQPikgfCBMb2FkZXJDb21wb25lbnQ8UD5cblxuZXhwb3J0IHR5cGUgTG9hZGVyTWFwID0geyBbbWR1bGU6IHN0cmluZ106ICgpID0+IExvYWRlcjxhbnk+IH1cblxuZXhwb3J0IHR5cGUgTG9hZGFibGVHZW5lcmF0ZWRPcHRpb25zID0ge1xuICB3ZWJwYWNrPygpOiBhbnlcbiAgbW9kdWxlcz8oKTogTG9hZGVyTWFwXG59XG5cbmV4cG9ydCB0eXBlIExvYWRhYmxlQmFzZU9wdGlvbnM8UCA9IHt9PiA9IExvYWRhYmxlR2VuZXJhdGVkT3B0aW9ucyAmIHtcbiAgbG9hZGluZz86ICh7XG4gICAgZXJyb3IsXG4gICAgaXNMb2FkaW5nLFxuICAgIHBhc3REZWxheSxcbiAgfToge1xuICAgIGVycm9yPzogRXJyb3IgfCBudWxsXG4gICAgaXNMb2FkaW5nPzogYm9vbGVhblxuICAgIHBhc3REZWxheT86IGJvb2xlYW5cbiAgICByZXRyeT86ICgpID0+IHZvaWRcbiAgICB0aW1lZE91dD86IGJvb2xlYW5cbiAgfSkgPT4gSlNYLkVsZW1lbnQgfCBudWxsXG4gIGxvYWRlcj86IExvYWRlcjxQPiB8IExvYWRlck1hcFxuICBsb2FkYWJsZUdlbmVyYXRlZD86IExvYWRhYmxlR2VuZXJhdGVkT3B0aW9uc1xuICBzc3I/OiBib29sZWFuXG59XG5cbmV4cG9ydCB0eXBlIExvYWRhYmxlT3B0aW9uczxQID0ge30+ID0gTG9hZGFibGVCYXNlT3B0aW9uczxQPiAmIHtcbiAgcmVuZGVyPyhsb2FkZXI6IGFueSwgcHJvcHM6IGFueSk6IEpTWC5FbGVtZW50XG59XG5cbmV4cG9ydCB0eXBlIER5bmFtaWNPcHRpb25zPFAgPSB7fT4gPSBMb2FkYWJsZUJhc2VPcHRpb25zPFA+ICYge1xuICAvKipcbiAgICogQGRlcHJlY2F0ZWQgdGhlIG1vZHVsZXMgb3B0aW9uIGhhcyBiZWVuIHBsYW5uZWQgZm9yIHJlbW92YWxcbiAgICovXG4gIHJlbmRlcj8ocHJvcHM6IFAsIGxvYWRlZDogYW55KTogSlNYLkVsZW1lbnRcbn1cblxuZXhwb3J0IHR5cGUgTG9hZGFibGVGbjxQID0ge30+ID0gKFxuICBvcHRzOiBMb2FkYWJsZU9wdGlvbnM8UD5cbikgPT4gUmVhY3QuQ29tcG9uZW50VHlwZTxQPlxuXG5leHBvcnQgdHlwZSBMb2FkYWJsZUNvbXBvbmVudDxQID0ge30+ID0gUmVhY3QuQ29tcG9uZW50VHlwZTxQPlxuXG5leHBvcnQgZnVuY3Rpb24gbm9TU1I8UCA9IHt9PihcbiAgTG9hZGFibGVJbml0aWFsaXplcjogTG9hZGFibGVGbjxQPixcbiAgbG9hZGFibGVPcHRpb25zOiBMb2FkYWJsZU9wdGlvbnM8UD5cbik6IFJlYWN0LkNvbXBvbmVudFR5cGU8UD4ge1xuICAvLyBSZW1vdmluZyB3ZWJwYWNrIGFuZCBtb2R1bGVzIG1lYW5zIHJlYWN0LWxvYWRhYmxlIHdvbid0IHRyeSBwcmVsb2FkaW5nXG4gIGRlbGV0ZSBsb2FkYWJsZU9wdGlvbnMud2VicGFja1xuICBkZWxldGUgbG9hZGFibGVPcHRpb25zLm1vZHVsZXNcblxuICAvLyBUaGlzIGNoZWNrIGlzIG5lY2Vzc2FyeSB0byBwcmV2ZW50IHJlYWN0LWxvYWRhYmxlIGZyb20gaW5pdGlhbGl6aW5nIG9uIHRoZSBzZXJ2ZXJcbiAgaWYgKCFpc1NlcnZlclNpZGUpIHtcbiAgICByZXR1cm4gTG9hZGFibGVJbml0aWFsaXplcihsb2FkYWJsZU9wdGlvbnMpXG4gIH1cblxuICBjb25zdCBMb2FkaW5nID0gbG9hZGFibGVPcHRpb25zLmxvYWRpbmchXG4gIC8vIFRoaXMgd2lsbCBvbmx5IGJlIHJlbmRlcmVkIG9uIHRoZSBzZXJ2ZXIgc2lkZVxuICByZXR1cm4gKCkgPT4gKFxuICAgIDxMb2FkaW5nIGVycm9yPXtudWxsfSBpc0xvYWRpbmcgcGFzdERlbGF5PXtmYWxzZX0gdGltZWRPdXQ9e2ZhbHNlfSAvPlxuICApXG59XG5cbi8vIGZ1bmN0aW9uIGR5bmFtaWM8UCA9IHt9LCBPIGV4dGVuZHMgRHluYW1pY09wdGlvbnM+KG9wdGlvbnM6IE8pOlxuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBkeW5hbWljPFAgPSB7fT4oXG4gIGR5bmFtaWNPcHRpb25zOiBEeW5hbWljT3B0aW9uczxQPiB8IExvYWRlcjxQPixcbiAgb3B0aW9ucz86IER5bmFtaWNPcHRpb25zPFA+XG4pOiBSZWFjdC5Db21wb25lbnRUeXBlPFA+IHtcbiAgbGV0IGxvYWRhYmxlRm46IExvYWRhYmxlRm48UD4gPSBMb2FkYWJsZVxuICBsZXQgbG9hZGFibGVPcHRpb25zOiBMb2FkYWJsZU9wdGlvbnM8UD4gPSB7XG4gICAgLy8gQSBsb2FkaW5nIGNvbXBvbmVudCBpcyBub3QgcmVxdWlyZWQsIHNvIHdlIGRlZmF1bHQgaXRcbiAgICBsb2FkaW5nOiAoeyBlcnJvciwgaXNMb2FkaW5nLCBwYXN0RGVsYXkgfSkgPT4ge1xuICAgICAgaWYgKCFwYXN0RGVsYXkpIHJldHVybiBudWxsXG4gICAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09ICdkZXZlbG9wbWVudCcpIHtcbiAgICAgICAgaWYgKGlzTG9hZGluZykge1xuICAgICAgICAgIHJldHVybiBudWxsXG4gICAgICAgIH1cbiAgICAgICAgaWYgKGVycm9yKSB7XG4gICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgIDxwPlxuICAgICAgICAgICAgICB7ZXJyb3IubWVzc2FnZX1cbiAgICAgICAgICAgICAgPGJyIC8+XG4gICAgICAgICAgICAgIHtlcnJvci5zdGFja31cbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICApXG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgcmV0dXJuIG51bGxcbiAgICB9LFxuICB9XG5cbiAgLy8gU3VwcG9ydCBmb3IgZGlyZWN0IGltcG9ydCgpLCBlZzogZHluYW1pYyhpbXBvcnQoJy4uL2hlbGxvLXdvcmxkJykpXG4gIC8vIE5vdGUgdGhhdCB0aGlzIGlzIG9ubHkga2VwdCBmb3IgdGhlIGVkZ2UgY2FzZSB3aGVyZSBzb21lb25lIGlzIHBhc3NpbmcgaW4gYSBwcm9taXNlIGFzIGZpcnN0IGFyZ3VtZW50XG4gIC8vIFRoZSByZWFjdC1sb2FkYWJsZSBiYWJlbCBwbHVnaW4gd2lsbCB0dXJuIGR5bmFtaWMoaW1wb3J0KCcuLi9oZWxsby13b3JsZCcpKSBpbnRvIGR5bmFtaWMoKCkgPT4gaW1wb3J0KCcuLi9oZWxsby13b3JsZCcpKVxuICAvLyBUbyBtYWtlIHN1cmUgd2UgZG9uJ3QgZXhlY3V0ZSB0aGUgaW1wb3J0IHdpdGhvdXQgcmVuZGVyaW5nIGZpcnN0XG4gIGlmIChkeW5hbWljT3B0aW9ucyBpbnN0YW5jZW9mIFByb21pc2UpIHtcbiAgICBsb2FkYWJsZU9wdGlvbnMubG9hZGVyID0gKCkgPT4gZHluYW1pY09wdGlvbnNcbiAgICAvLyBTdXBwb3J0IGZvciBoYXZpbmcgaW1wb3J0IGFzIGEgZnVuY3Rpb24sIGVnOiBkeW5hbWljKCgpID0+IGltcG9ydCgnLi4vaGVsbG8td29ybGQnKSlcbiAgfSBlbHNlIGlmICh0eXBlb2YgZHluYW1pY09wdGlvbnMgPT09ICdmdW5jdGlvbicpIHtcbiAgICBsb2FkYWJsZU9wdGlvbnMubG9hZGVyID0gZHluYW1pY09wdGlvbnNcbiAgICAvLyBTdXBwb3J0IGZvciBoYXZpbmcgZmlyc3QgYXJndW1lbnQgYmVpbmcgb3B0aW9ucywgZWc6IGR5bmFtaWMoe2xvYWRlcjogaW1wb3J0KCcuLi9oZWxsby13b3JsZCcpfSlcbiAgfSBlbHNlIGlmICh0eXBlb2YgZHluYW1pY09wdGlvbnMgPT09ICdvYmplY3QnKSB7XG4gICAgbG9hZGFibGVPcHRpb25zID0geyAuLi5sb2FkYWJsZU9wdGlvbnMsIC4uLmR5bmFtaWNPcHRpb25zIH1cbiAgfVxuXG4gIC8vIFN1cHBvcnQgZm9yIHBhc3Npbmcgb3B0aW9ucywgZWc6IGR5bmFtaWMoaW1wb3J0KCcuLi9oZWxsby13b3JsZCcpLCB7bG9hZGluZzogKCkgPT4gPHA+TG9hZGluZyBzb21ldGhpbmc8L3A+fSlcbiAgbG9hZGFibGVPcHRpb25zID0geyAuLi5sb2FkYWJsZU9wdGlvbnMsIC4uLm9wdGlvbnMgfVxuXG4gIGlmIChcbiAgICB0eXBlb2YgZHluYW1pY09wdGlvbnMgPT09ICdvYmplY3QnICYmXG4gICAgIShkeW5hbWljT3B0aW9ucyBpbnN0YW5jZW9mIFByb21pc2UpXG4gICkge1xuICAgIC8vIHNob3cgZGVwcmVjYXRpb24gd2FybmluZyBmb3IgYG1vZHVsZXNgIGtleSBpbiBkZXZlbG9wbWVudFxuICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB7XG4gICAgICBpZiAoZHluYW1pY09wdGlvbnMubW9kdWxlcykge1xuICAgICAgICBjb25zb2xlLndhcm4oXG4gICAgICAgICAgJ1RoZSBtb2R1bGVzIG9wdGlvbiBmb3IgbmV4dC9keW5hbWljIGhhcyBiZWVuIGRlcHJlY2F0ZWQuIFNlZSBoZXJlIGZvciBtb3JlIGluZm8gaHR0cHM6Ly9lcnIuc2gvdmVyY2VsL25leHQuanMvbmV4dC1keW5hbWljLW1vZHVsZXMnXG4gICAgICAgIClcbiAgICAgIH1cbiAgICB9XG4gICAgLy8gU3VwcG9ydCBmb3IgYHJlbmRlcmAgd2hlbiB1c2luZyBhIG1hcHBpbmcsIGVnOiBgZHluYW1pYyh7IG1vZHVsZXM6ICgpID0+IHtyZXR1cm4ge0hlbGxvV29ybGQ6IGltcG9ydCgnLi4vaGVsbG8td29ybGQnKX0sIHJlbmRlcihwcm9wcywgbG9hZGVkKSB7fSB9IH0pXG4gICAgaWYgKGR5bmFtaWNPcHRpb25zLnJlbmRlcikge1xuICAgICAgbG9hZGFibGVPcHRpb25zLnJlbmRlciA9IChsb2FkZWQsIHByb3BzKSA9PlxuICAgICAgICBkeW5hbWljT3B0aW9ucy5yZW5kZXIhKHByb3BzLCBsb2FkZWQpXG4gICAgfVxuICAgIC8vIFN1cHBvcnQgZm9yIGBtb2R1bGVzYCB3aGVuIHVzaW5nIGEgbWFwcGluZywgZWc6IGBkeW5hbWljKHsgbW9kdWxlczogKCkgPT4ge3JldHVybiB7SGVsbG9Xb3JsZDogaW1wb3J0KCcuLi9oZWxsby13b3JsZCcpfSwgcmVuZGVyKHByb3BzLCBsb2FkZWQpIHt9IH0gfSlcbiAgICBpZiAoZHluYW1pY09wdGlvbnMubW9kdWxlcykge1xuICAgICAgbG9hZGFibGVGbiA9IExvYWRhYmxlLk1hcFxuICAgICAgY29uc3QgbG9hZE1vZHVsZXM6IExvYWRlck1hcCA9IHt9XG4gICAgICBjb25zdCBtb2R1bGVzID0gZHluYW1pY09wdGlvbnMubW9kdWxlcygpXG4gICAgICBPYmplY3Qua2V5cyhtb2R1bGVzKS5mb3JFYWNoKChrZXkpID0+IHtcbiAgICAgICAgY29uc3QgdmFsdWU6IGFueSA9IG1vZHVsZXNba2V5XVxuICAgICAgICBpZiAodHlwZW9mIHZhbHVlLnRoZW4gPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgICBsb2FkTW9kdWxlc1trZXldID0gKCkgPT4gdmFsdWUudGhlbigobW9kOiBhbnkpID0+IG1vZC5kZWZhdWx0IHx8IG1vZClcbiAgICAgICAgICByZXR1cm5cbiAgICAgICAgfVxuICAgICAgICBsb2FkTW9kdWxlc1trZXldID0gdmFsdWVcbiAgICAgIH0pXG4gICAgICBsb2FkYWJsZU9wdGlvbnMubG9hZGVyID0gbG9hZE1vZHVsZXNcbiAgICB9XG4gIH1cblxuICAvLyBjb21pbmcgZnJvbSBidWlsZC9iYWJlbC9wbHVnaW5zL3JlYWN0LWxvYWRhYmxlLXBsdWdpbi5qc1xuICBpZiAobG9hZGFibGVPcHRpb25zLmxvYWRhYmxlR2VuZXJhdGVkKSB7XG4gICAgbG9hZGFibGVPcHRpb25zID0ge1xuICAgICAgLi4ubG9hZGFibGVPcHRpb25zLFxuICAgICAgLi4ubG9hZGFibGVPcHRpb25zLmxvYWRhYmxlR2VuZXJhdGVkLFxuICAgIH1cbiAgICBkZWxldGUgbG9hZGFibGVPcHRpb25zLmxvYWRhYmxlR2VuZXJhdGVkXG4gIH1cblxuICAvLyBzdXBwb3J0IGZvciBkaXNhYmxpbmcgc2VydmVyIHNpZGUgcmVuZGVyaW5nLCBlZzogZHluYW1pYyhpbXBvcnQoJy4uL2hlbGxvLXdvcmxkJyksIHtzc3I6IGZhbHNlfSlcbiAgaWYgKHR5cGVvZiBsb2FkYWJsZU9wdGlvbnMuc3NyID09PSAnYm9vbGVhbicpIHtcbiAgICBpZiAoIWxvYWRhYmxlT3B0aW9ucy5zc3IpIHtcbiAgICAgIGRlbGV0ZSBsb2FkYWJsZU9wdGlvbnMuc3NyXG4gICAgICByZXR1cm4gbm9TU1IobG9hZGFibGVGbiwgbG9hZGFibGVPcHRpb25zKVxuICAgIH1cbiAgICBkZWxldGUgbG9hZGFibGVPcHRpb25zLnNzclxuICB9XG5cbiAgcmV0dXJuIGxvYWRhYmxlRm4obG9hZGFibGVPcHRpb25zKVxufVxuIiwiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0J1xuXG50eXBlIENhcHR1cmVGbiA9IChtb2R1bGVOYW1lOiBzdHJpbmcpID0+IHZvaWRcblxuZXhwb3J0IGNvbnN0IExvYWRhYmxlQ29udGV4dCA9IFJlYWN0LmNyZWF0ZUNvbnRleHQ8Q2FwdHVyZUZuIHwgbnVsbD4obnVsbClcblxuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHtcbiAgTG9hZGFibGVDb250ZXh0LmRpc3BsYXlOYW1lID0gJ0xvYWRhYmxlQ29udGV4dCdcbn1cbiIsIi8qKlxuQGNvcHlyaWdodCAoYykgMjAxNy1wcmVzZW50IEphbWVzIEt5bGUgPG1lQHRoZWphbWVza3lsZS5jb20+XG4gTUlUIExpY2Vuc2VcbiBQZXJtaXNzaW9uIGlzIGhlcmVieSBncmFudGVkLCBmcmVlIG9mIGNoYXJnZSwgdG8gYW55IHBlcnNvbiBvYnRhaW5pbmdcbmEgY29weSBvZiB0aGlzIHNvZnR3YXJlIGFuZCBhc3NvY2lhdGVkIGRvY3VtZW50YXRpb24gZmlsZXMgKHRoZVxuXCJTb2Z0d2FyZVwiKSwgdG8gZGVhbCBpbiB0aGUgU29mdHdhcmUgd2l0aG91dCByZXN0cmljdGlvbiwgaW5jbHVkaW5nXG53aXRob3V0IGxpbWl0YXRpb24gdGhlIHJpZ2h0cyB0byB1c2UsIGNvcHksIG1vZGlmeSwgbWVyZ2UsIHB1Ymxpc2gsXG5kaXN0cmlidXRlLCBzdWJsaWNlbnNlLCBhbmQvb3Igc2VsbCBjb3BpZXMgb2YgdGhlIFNvZnR3YXJlLCBhbmQgdG9cbnBlcm1pdCBwZXJzb25zIHRvIHdob20gdGhlIFNvZnR3YXJlIGlzIGZ1cm5pc2hlZCB0byBkbyBzbywgc3ViamVjdCB0b1xudGhlIGZvbGxvd2luZyBjb25kaXRpb25zOlxuIFRoZSBhYm92ZSBjb3B5cmlnaHQgbm90aWNlIGFuZCB0aGlzIHBlcm1pc3Npb24gbm90aWNlIHNoYWxsIGJlXG5pbmNsdWRlZCBpbiBhbGwgY29waWVzIG9yIHN1YnN0YW50aWFsIHBvcnRpb25zIG9mIHRoZSBTb2Z0d2FyZS5cbiBUSEUgU09GVFdBUkUgSVMgUFJPVklERUQgXCJBUyBJU1wiLCBXSVRIT1VUIFdBUlJBTlRZIE9GIEFOWSBLSU5ELFxuRVhQUkVTUyBPUiBJTVBMSUVELCBJTkNMVURJTkcgQlVUIE5PVCBMSU1JVEVEIFRPIFRIRSBXQVJSQU5USUVTIE9GXG5NRVJDSEFOVEFCSUxJVFksIEZJVE5FU1MgRk9SIEEgUEFSVElDVUxBUiBQVVJQT1NFIEFORFxuTk9OSU5GUklOR0VNRU5ULiBJTiBOTyBFVkVOVCBTSEFMTCBUSEUgQVVUSE9SUyBPUiBDT1BZUklHSFQgSE9MREVSUyBCRVxuTElBQkxFIEZPUiBBTlkgQ0xBSU0sIERBTUFHRVMgT1IgT1RIRVIgTElBQklMSVRZLCBXSEVUSEVSIElOIEFOIEFDVElPTlxuT0YgQ09OVFJBQ1QsIFRPUlQgT1IgT1RIRVJXSVNFLCBBUklTSU5HIEZST00sIE9VVCBPRiBPUiBJTiBDT05ORUNUSU9OXG5XSVRIIFRIRSBTT0ZUV0FSRSBPUiBUSEUgVVNFIE9SIE9USEVSIERFQUxJTkdTIElOIFRIRSBTT0ZUV0FSRVxuKi9cbi8vIGh0dHBzOi8vZ2l0aHViLmNvbS9qYW1pZWJ1aWxkcy9yZWFjdC1sb2FkYWJsZS9ibG9iL3Y1LjUuMC9zcmMvaW5kZXguanNcbi8vIE1vZGlmaWVkIHRvIGJlIGNvbXBhdGlibGUgd2l0aCB3ZWJwYWNrIDQgLyBOZXh0LmpzXG5cbmltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCdcbmltcG9ydCB7IHVzZVN1YnNjcmlwdGlvbiB9IGZyb20gJ3VzZS1zdWJzY3JpcHRpb24nXG5pbXBvcnQgeyBMb2FkYWJsZUNvbnRleHQgfSBmcm9tICcuL2xvYWRhYmxlLWNvbnRleHQnXG5cbmNvbnN0IEFMTF9JTklUSUFMSVpFUlMgPSBbXVxuY29uc3QgUkVBRFlfSU5JVElBTElaRVJTID0gW11cbmxldCBpbml0aWFsaXplZCA9IGZhbHNlXG5cbmZ1bmN0aW9uIGxvYWQobG9hZGVyKSB7XG4gIGxldCBwcm9taXNlID0gbG9hZGVyKClcblxuICBsZXQgc3RhdGUgPSB7XG4gICAgbG9hZGluZzogdHJ1ZSxcbiAgICBsb2FkZWQ6IG51bGwsXG4gICAgZXJyb3I6IG51bGwsXG4gIH1cblxuICBzdGF0ZS5wcm9taXNlID0gcHJvbWlzZVxuICAgIC50aGVuKChsb2FkZWQpID0+IHtcbiAgICAgIHN0YXRlLmxvYWRpbmcgPSBmYWxzZVxuICAgICAgc3RhdGUubG9hZGVkID0gbG9hZGVkXG4gICAgICByZXR1cm4gbG9hZGVkXG4gICAgfSlcbiAgICAuY2F0Y2goKGVycikgPT4ge1xuICAgICAgc3RhdGUubG9hZGluZyA9IGZhbHNlXG4gICAgICBzdGF0ZS5lcnJvciA9IGVyclxuICAgICAgdGhyb3cgZXJyXG4gICAgfSlcblxuICByZXR1cm4gc3RhdGVcbn1cblxuZnVuY3Rpb24gbG9hZE1hcChvYmopIHtcbiAgbGV0IHN0YXRlID0ge1xuICAgIGxvYWRpbmc6IGZhbHNlLFxuICAgIGxvYWRlZDoge30sXG4gICAgZXJyb3I6IG51bGwsXG4gIH1cblxuICBsZXQgcHJvbWlzZXMgPSBbXVxuXG4gIHRyeSB7XG4gICAgT2JqZWN0LmtleXMob2JqKS5mb3JFYWNoKChrZXkpID0+IHtcbiAgICAgIGxldCByZXN1bHQgPSBsb2FkKG9ialtrZXldKVxuXG4gICAgICBpZiAoIXJlc3VsdC5sb2FkaW5nKSB7XG4gICAgICAgIHN0YXRlLmxvYWRlZFtrZXldID0gcmVzdWx0LmxvYWRlZFxuICAgICAgICBzdGF0ZS5lcnJvciA9IHJlc3VsdC5lcnJvclxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgc3RhdGUubG9hZGluZyA9IHRydWVcbiAgICAgIH1cblxuICAgICAgcHJvbWlzZXMucHVzaChyZXN1bHQucHJvbWlzZSlcblxuICAgICAgcmVzdWx0LnByb21pc2VcbiAgICAgICAgLnRoZW4oKHJlcykgPT4ge1xuICAgICAgICAgIHN0YXRlLmxvYWRlZFtrZXldID0gcmVzXG4gICAgICAgIH0pXG4gICAgICAgIC5jYXRjaCgoZXJyKSA9PiB7XG4gICAgICAgICAgc3RhdGUuZXJyb3IgPSBlcnJcbiAgICAgICAgfSlcbiAgICB9KVxuICB9IGNhdGNoIChlcnIpIHtcbiAgICBzdGF0ZS5lcnJvciA9IGVyclxuICB9XG5cbiAgc3RhdGUucHJvbWlzZSA9IFByb21pc2UuYWxsKHByb21pc2VzKVxuICAgIC50aGVuKChyZXMpID0+IHtcbiAgICAgIHN0YXRlLmxvYWRpbmcgPSBmYWxzZVxuICAgICAgcmV0dXJuIHJlc1xuICAgIH0pXG4gICAgLmNhdGNoKChlcnIpID0+IHtcbiAgICAgIHN0YXRlLmxvYWRpbmcgPSBmYWxzZVxuICAgICAgdGhyb3cgZXJyXG4gICAgfSlcblxuICByZXR1cm4gc3RhdGVcbn1cblxuZnVuY3Rpb24gcmVzb2x2ZShvYmopIHtcbiAgcmV0dXJuIG9iaiAmJiBvYmouX19lc01vZHVsZSA/IG9iai5kZWZhdWx0IDogb2JqXG59XG5cbmZ1bmN0aW9uIHJlbmRlcihsb2FkZWQsIHByb3BzKSB7XG4gIHJldHVybiBSZWFjdC5jcmVhdGVFbGVtZW50KHJlc29sdmUobG9hZGVkKSwgcHJvcHMpXG59XG5cbmZ1bmN0aW9uIGNyZWF0ZUxvYWRhYmxlQ29tcG9uZW50KGxvYWRGbiwgb3B0aW9ucykge1xuICBsZXQgb3B0cyA9IE9iamVjdC5hc3NpZ24oXG4gICAge1xuICAgICAgbG9hZGVyOiBudWxsLFxuICAgICAgbG9hZGluZzogbnVsbCxcbiAgICAgIGRlbGF5OiAyMDAsXG4gICAgICB0aW1lb3V0OiBudWxsLFxuICAgICAgcmVuZGVyOiByZW5kZXIsXG4gICAgICB3ZWJwYWNrOiBudWxsLFxuICAgICAgbW9kdWxlczogbnVsbCxcbiAgICB9LFxuICAgIG9wdGlvbnNcbiAgKVxuXG4gIGxldCBzdWJzY3JpcHRpb24gPSBudWxsXG5cbiAgZnVuY3Rpb24gaW5pdCgpIHtcbiAgICBpZiAoIXN1YnNjcmlwdGlvbikge1xuICAgICAgY29uc3Qgc3ViID0gbmV3IExvYWRhYmxlU3Vic2NyaXB0aW9uKGxvYWRGbiwgb3B0cylcbiAgICAgIHN1YnNjcmlwdGlvbiA9IHtcbiAgICAgICAgZ2V0Q3VycmVudFZhbHVlOiBzdWIuZ2V0Q3VycmVudFZhbHVlLmJpbmQoc3ViKSxcbiAgICAgICAgc3Vic2NyaWJlOiBzdWIuc3Vic2NyaWJlLmJpbmQoc3ViKSxcbiAgICAgICAgcmV0cnk6IHN1Yi5yZXRyeS5iaW5kKHN1YiksXG4gICAgICAgIHByb21pc2U6IHN1Yi5wcm9taXNlLmJpbmQoc3ViKSxcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHN1YnNjcmlwdGlvbi5wcm9taXNlKClcbiAgfVxuXG4gIC8vIFNlcnZlciBvbmx5XG4gIGlmICh0eXBlb2Ygd2luZG93ID09PSAndW5kZWZpbmVkJykge1xuICAgIEFMTF9JTklUSUFMSVpFUlMucHVzaChpbml0KVxuICB9XG5cbiAgLy8gQ2xpZW50IG9ubHlcbiAgaWYgKFxuICAgICFpbml0aWFsaXplZCAmJlxuICAgIHR5cGVvZiB3aW5kb3cgIT09ICd1bmRlZmluZWQnICYmXG4gICAgdHlwZW9mIG9wdHMud2VicGFjayA9PT0gJ2Z1bmN0aW9uJ1xuICApIHtcbiAgICBjb25zdCBtb2R1bGVJZHMgPSBvcHRzLndlYnBhY2soKVxuICAgIFJFQURZX0lOSVRJQUxJWkVSUy5wdXNoKChpZHMpID0+IHtcbiAgICAgIGZvciAoY29uc3QgbW9kdWxlSWQgb2YgbW9kdWxlSWRzKSB7XG4gICAgICAgIGlmIChpZHMuaW5kZXhPZihtb2R1bGVJZCkgIT09IC0xKSB7XG4gICAgICAgICAgcmV0dXJuIGluaXQoKVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfSlcbiAgfVxuXG4gIGNvbnN0IExvYWRhYmxlQ29tcG9uZW50ID0gKHByb3BzLCByZWYpID0+IHtcbiAgICBpbml0KClcblxuICAgIGNvbnN0IGNvbnRleHQgPSBSZWFjdC51c2VDb250ZXh0KExvYWRhYmxlQ29udGV4dClcbiAgICBjb25zdCBzdGF0ZSA9IHVzZVN1YnNjcmlwdGlvbihzdWJzY3JpcHRpb24pXG5cbiAgICBSZWFjdC51c2VJbXBlcmF0aXZlSGFuZGxlKFxuICAgICAgcmVmLFxuICAgICAgKCkgPT4gKHtcbiAgICAgICAgcmV0cnk6IHN1YnNjcmlwdGlvbi5yZXRyeSxcbiAgICAgIH0pLFxuICAgICAgW11cbiAgICApXG5cbiAgICBpZiAoY29udGV4dCAmJiBBcnJheS5pc0FycmF5KG9wdHMubW9kdWxlcykpIHtcbiAgICAgIG9wdHMubW9kdWxlcy5mb3JFYWNoKChtb2R1bGVOYW1lKSA9PiB7XG4gICAgICAgIGNvbnRleHQobW9kdWxlTmFtZSlcbiAgICAgIH0pXG4gICAgfVxuXG4gICAgcmV0dXJuIFJlYWN0LnVzZU1lbW8oKCkgPT4ge1xuICAgICAgaWYgKHN0YXRlLmxvYWRpbmcgfHwgc3RhdGUuZXJyb3IpIHtcbiAgICAgICAgcmV0dXJuIFJlYWN0LmNyZWF0ZUVsZW1lbnQob3B0cy5sb2FkaW5nLCB7XG4gICAgICAgICAgaXNMb2FkaW5nOiBzdGF0ZS5sb2FkaW5nLFxuICAgICAgICAgIHBhc3REZWxheTogc3RhdGUucGFzdERlbGF5LFxuICAgICAgICAgIHRpbWVkT3V0OiBzdGF0ZS50aW1lZE91dCxcbiAgICAgICAgICBlcnJvcjogc3RhdGUuZXJyb3IsXG4gICAgICAgICAgcmV0cnk6IHN1YnNjcmlwdGlvbi5yZXRyeSxcbiAgICAgICAgfSlcbiAgICAgIH0gZWxzZSBpZiAoc3RhdGUubG9hZGVkKSB7XG4gICAgICAgIHJldHVybiBvcHRzLnJlbmRlcihzdGF0ZS5sb2FkZWQsIHByb3BzKVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmV0dXJuIG51bGxcbiAgICAgIH1cbiAgICB9LCBbcHJvcHMsIHN0YXRlXSlcbiAgfVxuXG4gIExvYWRhYmxlQ29tcG9uZW50LnByZWxvYWQgPSAoKSA9PiBpbml0KClcbiAgTG9hZGFibGVDb21wb25lbnQuZGlzcGxheU5hbWUgPSAnTG9hZGFibGVDb21wb25lbnQnXG5cbiAgcmV0dXJuIFJlYWN0LmZvcndhcmRSZWYoTG9hZGFibGVDb21wb25lbnQpXG59XG5cbmNsYXNzIExvYWRhYmxlU3Vic2NyaXB0aW9uIHtcbiAgY29uc3RydWN0b3IobG9hZEZuLCBvcHRzKSB7XG4gICAgdGhpcy5fbG9hZEZuID0gbG9hZEZuXG4gICAgdGhpcy5fb3B0cyA9IG9wdHNcbiAgICB0aGlzLl9jYWxsYmFja3MgPSBuZXcgU2V0KClcbiAgICB0aGlzLl9kZWxheSA9IG51bGxcbiAgICB0aGlzLl90aW1lb3V0ID0gbnVsbFxuXG4gICAgdGhpcy5yZXRyeSgpXG4gIH1cblxuICBwcm9taXNlKCkge1xuICAgIHJldHVybiB0aGlzLl9yZXMucHJvbWlzZVxuICB9XG5cbiAgcmV0cnkoKSB7XG4gICAgdGhpcy5fY2xlYXJUaW1lb3V0cygpXG4gICAgdGhpcy5fcmVzID0gdGhpcy5fbG9hZEZuKHRoaXMuX29wdHMubG9hZGVyKVxuXG4gICAgdGhpcy5fc3RhdGUgPSB7XG4gICAgICBwYXN0RGVsYXk6IGZhbHNlLFxuICAgICAgdGltZWRPdXQ6IGZhbHNlLFxuICAgIH1cblxuICAgIGNvbnN0IHsgX3JlczogcmVzLCBfb3B0czogb3B0cyB9ID0gdGhpc1xuXG4gICAgaWYgKHJlcy5sb2FkaW5nKSB7XG4gICAgICBpZiAodHlwZW9mIG9wdHMuZGVsYXkgPT09ICdudW1iZXInKSB7XG4gICAgICAgIGlmIChvcHRzLmRlbGF5ID09PSAwKSB7XG4gICAgICAgICAgdGhpcy5fc3RhdGUucGFzdERlbGF5ID0gdHJ1ZVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHRoaXMuX2RlbGF5ID0gc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgICB0aGlzLl91cGRhdGUoe1xuICAgICAgICAgICAgICBwYXN0RGVsYXk6IHRydWUsXG4gICAgICAgICAgICB9KVxuICAgICAgICAgIH0sIG9wdHMuZGVsYXkpXG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgaWYgKHR5cGVvZiBvcHRzLnRpbWVvdXQgPT09ICdudW1iZXInKSB7XG4gICAgICAgIHRoaXMuX3RpbWVvdXQgPSBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICB0aGlzLl91cGRhdGUoeyB0aW1lZE91dDogdHJ1ZSB9KVxuICAgICAgICB9LCBvcHRzLnRpbWVvdXQpXG4gICAgICB9XG4gICAgfVxuXG4gICAgdGhpcy5fcmVzLnByb21pc2VcbiAgICAgIC50aGVuKCgpID0+IHtcbiAgICAgICAgdGhpcy5fdXBkYXRlKHt9KVxuICAgICAgICB0aGlzLl9jbGVhclRpbWVvdXRzKClcbiAgICAgIH0pXG4gICAgICAuY2F0Y2goKF9lcnIpID0+IHtcbiAgICAgICAgdGhpcy5fdXBkYXRlKHt9KVxuICAgICAgICB0aGlzLl9jbGVhclRpbWVvdXRzKClcbiAgICAgIH0pXG4gICAgdGhpcy5fdXBkYXRlKHt9KVxuICB9XG5cbiAgX3VwZGF0ZShwYXJ0aWFsKSB7XG4gICAgdGhpcy5fc3RhdGUgPSB7XG4gICAgICAuLi50aGlzLl9zdGF0ZSxcbiAgICAgIGVycm9yOiB0aGlzLl9yZXMuZXJyb3IsXG4gICAgICBsb2FkZWQ6IHRoaXMuX3Jlcy5sb2FkZWQsXG4gICAgICBsb2FkaW5nOiB0aGlzLl9yZXMubG9hZGluZyxcbiAgICAgIC4uLnBhcnRpYWwsXG4gICAgfVxuICAgIHRoaXMuX2NhbGxiYWNrcy5mb3JFYWNoKChjYWxsYmFjaykgPT4gY2FsbGJhY2soKSlcbiAgfVxuXG4gIF9jbGVhclRpbWVvdXRzKCkge1xuICAgIGNsZWFyVGltZW91dCh0aGlzLl9kZWxheSlcbiAgICBjbGVhclRpbWVvdXQodGhpcy5fdGltZW91dClcbiAgfVxuXG4gIGdldEN1cnJlbnRWYWx1ZSgpIHtcbiAgICByZXR1cm4gdGhpcy5fc3RhdGVcbiAgfVxuXG4gIHN1YnNjcmliZShjYWxsYmFjaykge1xuICAgIHRoaXMuX2NhbGxiYWNrcy5hZGQoY2FsbGJhY2spXG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIHRoaXMuX2NhbGxiYWNrcy5kZWxldGUoY2FsbGJhY2spXG4gICAgfVxuICB9XG59XG5cbmZ1bmN0aW9uIExvYWRhYmxlKG9wdHMpIHtcbiAgcmV0dXJuIGNyZWF0ZUxvYWRhYmxlQ29tcG9uZW50KGxvYWQsIG9wdHMpXG59XG5cbmZ1bmN0aW9uIExvYWRhYmxlTWFwKG9wdHMpIHtcbiAgaWYgKHR5cGVvZiBvcHRzLnJlbmRlciAhPT0gJ2Z1bmN0aW9uJykge1xuICAgIHRocm93IG5ldyBFcnJvcignTG9hZGFibGVNYXAgcmVxdWlyZXMgYSBgcmVuZGVyKGxvYWRlZCwgcHJvcHMpYCBmdW5jdGlvbicpXG4gIH1cblxuICByZXR1cm4gY3JlYXRlTG9hZGFibGVDb21wb25lbnQobG9hZE1hcCwgb3B0cylcbn1cblxuTG9hZGFibGUuTWFwID0gTG9hZGFibGVNYXBcblxuZnVuY3Rpb24gZmx1c2hJbml0aWFsaXplcnMoaW5pdGlhbGl6ZXJzLCBpZHMpIHtcbiAgbGV0IHByb21pc2VzID0gW11cblxuICB3aGlsZSAoaW5pdGlhbGl6ZXJzLmxlbmd0aCkge1xuICAgIGxldCBpbml0ID0gaW5pdGlhbGl6ZXJzLnBvcCgpXG4gICAgcHJvbWlzZXMucHVzaChpbml0KGlkcykpXG4gIH1cblxuICByZXR1cm4gUHJvbWlzZS5hbGwocHJvbWlzZXMpLnRoZW4oKCkgPT4ge1xuICAgIGlmIChpbml0aWFsaXplcnMubGVuZ3RoKSB7XG4gICAgICByZXR1cm4gZmx1c2hJbml0aWFsaXplcnMoaW5pdGlhbGl6ZXJzLCBpZHMpXG4gICAgfVxuICB9KVxufVxuXG5Mb2FkYWJsZS5wcmVsb2FkQWxsID0gKCkgPT4ge1xuICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmVJbml0aWFsaXplcnMsIHJlamVjdCkgPT4ge1xuICAgIGZsdXNoSW5pdGlhbGl6ZXJzKEFMTF9JTklUSUFMSVpFUlMpLnRoZW4ocmVzb2x2ZUluaXRpYWxpemVycywgcmVqZWN0KVxuICB9KVxufVxuXG5Mb2FkYWJsZS5wcmVsb2FkUmVhZHkgPSAoaWRzID0gW10pID0+IHtcbiAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlUHJlbG9hZCkgPT4ge1xuICAgIGNvbnN0IHJlcyA9ICgpID0+IHtcbiAgICAgIGluaXRpYWxpemVkID0gdHJ1ZVxuICAgICAgcmV0dXJuIHJlc29sdmVQcmVsb2FkKClcbiAgICB9XG4gICAgLy8gV2UgYWx3YXlzIHdpbGwgcmVzb2x2ZSwgZXJyb3JzIHNob3VsZCBiZSBoYW5kbGVkIHdpdGhpbiBsb2FkaW5nIFVJcy5cbiAgICBmbHVzaEluaXRpYWxpemVycyhSRUFEWV9JTklUSUFMSVpFUlMsIGlkcykudGhlbihyZXMsIHJlcylcbiAgfSlcbn1cblxuaWYgKHR5cGVvZiB3aW5kb3cgIT09ICd1bmRlZmluZWQnKSB7XG4gIHdpbmRvdy5fX05FWFRfUFJFTE9BRFJFQURZID0gTG9hZGFibGUucHJlbG9hZFJlYWR5XG59XG5cbmV4cG9ydCBkZWZhdWx0IExvYWRhYmxlXG4iLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoJy4vZGlzdC9uZXh0LXNlcnZlci9saWIvZHluYW1pYycpXG4iLCIvKiogQGxpY2Vuc2UgUmVhY3QgdnVuZGVmaW5lZFxuICogdXNlLXN1YnNjcmlwdGlvbi5kZXZlbG9wbWVudC5qc1xuICpcbiAqIENvcHlyaWdodCAoYykgRmFjZWJvb2ssIEluYy4gYW5kIGl0cyBhZmZpbGlhdGVzLlxuICpcbiAqIFRoaXMgc291cmNlIGNvZGUgaXMgbGljZW5zZWQgdW5kZXIgdGhlIE1JVCBsaWNlbnNlIGZvdW5kIGluIHRoZVxuICogTElDRU5TRSBmaWxlIGluIHRoZSByb290IGRpcmVjdG9yeSBvZiB0aGlzIHNvdXJjZSB0cmVlLlxuICovXG5cbid1c2Ugc3RyaWN0JztcblxuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuICAoZnVuY3Rpb24oKSB7XG4ndXNlIHN0cmljdCc7XG5cbnZhciBfYXNzaWduID0gcmVxdWlyZSgnb2JqZWN0LWFzc2lnbicpO1xudmFyIHJlYWN0ID0gcmVxdWlyZSgncmVhY3QnKTtcblxuLy9cbi8vIEluIG9yZGVyIHRvIGF2b2lkIHJlbW92aW5nIGFuZCByZS1hZGRpbmcgc3Vic2NyaXB0aW9ucyBlYWNoIHRpbWUgdGhpcyBob29rIGlzIGNhbGxlZCxcbi8vIHRoZSBwYXJhbWV0ZXJzIHBhc3NlZCB0byB0aGlzIGhvb2sgc2hvdWxkIGJlIG1lbW9pemVkIGluIHNvbWUgd2F54oCTXG4vLyBlaXRoZXIgYnkgd3JhcHBpbmcgdGhlIGVudGlyZSBwYXJhbXMgb2JqZWN0IHdpdGggdXNlTWVtbygpXG4vLyBvciBieSB3cmFwcGluZyB0aGUgaW5kaXZpZHVhbCBjYWxsYmFja3Mgd2l0aCB1c2VDYWxsYmFjaygpLlxuXG5mdW5jdGlvbiB1c2VTdWJzY3JpcHRpb24oX3JlZikge1xuICB2YXIgZ2V0Q3VycmVudFZhbHVlID0gX3JlZi5nZXRDdXJyZW50VmFsdWUsXG4gICAgICBzdWJzY3JpYmUgPSBfcmVmLnN1YnNjcmliZTtcblxuICAvLyBSZWFkIHRoZSBjdXJyZW50IHZhbHVlIGZyb20gb3VyIHN1YnNjcmlwdGlvbi5cbiAgLy8gV2hlbiB0aGlzIHZhbHVlIGNoYW5nZXMsIHdlJ2xsIHNjaGVkdWxlIGFuIHVwZGF0ZSB3aXRoIFJlYWN0LlxuICAvLyBJdCdzIGltcG9ydGFudCB0byBhbHNvIHN0b3JlIHRoZSBob29rIHBhcmFtcyBzbyB0aGF0IHdlIGNhbiBjaGVjayBmb3Igc3RhbGVuZXNzLlxuICAvLyAoU2VlIHRoZSBjb21tZW50IGluIGNoZWNrRm9yVXBkYXRlcygpIGJlbG93IGZvciBtb3JlIGluZm8uKVxuICB2YXIgX3VzZVN0YXRlID0gcmVhY3QudXNlU3RhdGUoZnVuY3Rpb24gKCkge1xuICAgIHJldHVybiB7XG4gICAgICBnZXRDdXJyZW50VmFsdWU6IGdldEN1cnJlbnRWYWx1ZSxcbiAgICAgIHN1YnNjcmliZTogc3Vic2NyaWJlLFxuICAgICAgdmFsdWU6IGdldEN1cnJlbnRWYWx1ZSgpXG4gICAgfTtcbiAgfSksXG4gICAgICBzdGF0ZSA9IF91c2VTdGF0ZVswXSxcbiAgICAgIHNldFN0YXRlID0gX3VzZVN0YXRlWzFdO1xuXG4gIHZhciB2YWx1ZVRvUmV0dXJuID0gc3RhdGUudmFsdWU7IC8vIElmIHBhcmFtZXRlcnMgaGF2ZSBjaGFuZ2VkIHNpbmNlIG91ciBsYXN0IHJlbmRlciwgc2NoZWR1bGUgYW4gdXBkYXRlIHdpdGggaXRzIGN1cnJlbnQgdmFsdWUuXG5cbiAgaWYgKHN0YXRlLmdldEN1cnJlbnRWYWx1ZSAhPT0gZ2V0Q3VycmVudFZhbHVlIHx8IHN0YXRlLnN1YnNjcmliZSAhPT0gc3Vic2NyaWJlKSB7XG4gICAgLy8gSWYgdGhlIHN1YnNjcmlwdGlvbiBoYXMgYmVlbiB1cGRhdGVkLCB3ZSdsbCBzY2hlZHVsZSBhbm90aGVyIHVwZGF0ZSB3aXRoIFJlYWN0LlxuICAgIC8vIFJlYWN0IHdpbGwgcHJvY2VzcyB0aGlzIHVwZGF0ZSBpbW1lZGlhdGVseSwgc28gdGhlIG9sZCBzdWJzY3JpcHRpb24gdmFsdWUgd29uJ3QgYmUgY29tbWl0dGVkLlxuICAgIC8vIEl0IGlzIHN0aWxsIG5pY2UgdG8gYXZvaWQgcmV0dXJuaW5nIGEgbWlzbWF0Y2hlZCB2YWx1ZSB0aG91Z2gsIHNvIGxldCdzIG92ZXJyaWRlIHRoZSByZXR1cm4gdmFsdWUuXG4gICAgdmFsdWVUb1JldHVybiA9IGdldEN1cnJlbnRWYWx1ZSgpO1xuICAgIHNldFN0YXRlKHtcbiAgICAgIGdldEN1cnJlbnRWYWx1ZTogZ2V0Q3VycmVudFZhbHVlLFxuICAgICAgc3Vic2NyaWJlOiBzdWJzY3JpYmUsXG4gICAgICB2YWx1ZTogdmFsdWVUb1JldHVyblxuICAgIH0pO1xuICB9IC8vIERpc3BsYXkgdGhlIGN1cnJlbnQgdmFsdWUgZm9yIHRoaXMgaG9vayBpbiBSZWFjdCBEZXZUb29scy5cblxuXG4gIHJlYWN0LnVzZURlYnVnVmFsdWUodmFsdWVUb1JldHVybik7IC8vIEl0IGlzIGltcG9ydGFudCBub3QgdG8gc3Vic2NyaWJlIHdoaWxlIHJlbmRlcmluZyBiZWNhdXNlIHRoaXMgY2FuIGxlYWQgdG8gbWVtb3J5IGxlYWtzLlxuICAvLyAoTGVhcm4gbW9yZSBhdCByZWFjdGpzLm9yZy9kb2NzL3N0cmljdC1tb2RlLmh0bWwjZGV0ZWN0aW5nLXVuZXhwZWN0ZWQtc2lkZS1lZmZlY3RzKVxuICAvLyBJbnN0ZWFkLCB3ZSB3YWl0IHVudGlsIHRoZSBjb21taXQgcGhhc2UgdG8gYXR0YWNoIG91ciBoYW5kbGVyLlxuICAvL1xuICAvLyBXZSBpbnRlbnRpb25hbGx5IHVzZSBhIHBhc3NpdmUgZWZmZWN0ICh1c2VFZmZlY3QpIHJhdGhlciB0aGFuIGEgc3luY2hyb25vdXMgb25lICh1c2VMYXlvdXRFZmZlY3QpXG4gIC8vIHNvIHRoYXQgd2UgZG9uJ3Qgc3RyZXRjaCB0aGUgY29tbWl0IHBoYXNlLlxuICAvLyBUaGlzIGFsc28gaGFzIGFuIGFkZGVkIGJlbmVmaXQgd2hlbiBtdWx0aXBsZSBjb21wb25lbnRzIGFyZSBzdWJzY3JpYmVkIHRvIHRoZSBzYW1lIHNvdXJjZTpcbiAgLy8gSXQgYWxsb3dzIGVhY2ggb2YgdGhlIGV2ZW50IGhhbmRsZXJzIHRvIHNhZmVseSBzY2hlZHVsZSB3b3JrIHdpdGhvdXQgcG90ZW50aWFsbHkgcmVtb3ZpbmcgYW4gYW5vdGhlciBoYW5kbGVyLlxuICAvLyAoTGVhcm4gbW9yZSBhdCBodHRwczovL2NvZGVzYW5kYm94LmlvL3MvazB5dnI1OTcwbylcblxuICByZWFjdC51c2VFZmZlY3QoZnVuY3Rpb24gKCkge1xuICAgIHZhciBkaWRVbnN1YnNjcmliZSA9IGZhbHNlO1xuXG4gICAgdmFyIGNoZWNrRm9yVXBkYXRlcyA9IGZ1bmN0aW9uICgpIHtcbiAgICAgIC8vIEl0J3MgcG9zc2libGUgdGhhdCB0aGlzIGNhbGxiYWNrIHdpbGwgYmUgaW52b2tlZCBldmVuIGFmdGVyIGJlaW5nIHVuc3Vic2NyaWJlZCxcbiAgICAgIC8vIGlmIGl0J3MgcmVtb3ZlZCBhcyBhIHJlc3VsdCBvZiBhIHN1YnNjcmlwdGlvbiBldmVudC91cGRhdGUuXG4gICAgICAvLyBJbiB0aGlzIGNhc2UsIFJlYWN0IHdpbGwgbG9nIGEgREVWIHdhcm5pbmcgYWJvdXQgYW4gdXBkYXRlIGZyb20gYW4gdW5tb3VudGVkIGNvbXBvbmVudC5cbiAgICAgIC8vIFdlIGNhbiBhdm9pZCB0cmlnZ2VyaW5nIHRoYXQgd2FybmluZyB3aXRoIHRoaXMgY2hlY2suXG4gICAgICBpZiAoZGlkVW5zdWJzY3JpYmUpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfSAvLyBXZSB1c2UgYSBzdGF0ZSB1cGRhdGVyIGZ1bmN0aW9uIHRvIGF2b2lkIHNjaGVkdWxpbmcgd29yayBmb3IgYSBzdGFsZSBzb3VyY2UuXG4gICAgICAvLyBIb3dldmVyIGl0J3MgaW1wb3J0YW50IHRvIGVhZ2VybHkgcmVhZCB0aGUgY3VycmVudGx5IHZhbHVlLFxuICAgICAgLy8gc28gdGhhdCBhbGwgc2NoZWR1bGVkIHdvcmsgc2hhcmVzIHRoZSBzYW1lIHZhbHVlIChpbiB0aGUgZXZlbnQgb2YgbXVsdGlwbGUgc3Vic2NyaXB0aW9ucykuXG4gICAgICAvLyBUaGlzIGF2b2lkcyB2aXN1YWwgXCJ0ZWFyaW5nXCIgd2hlbiBhIG11dGF0aW9uIGhhcHBlbnMgZHVyaW5nIGEgKGNvbmN1cnJlbnQpIHJlbmRlci5cblxuXG4gICAgICB2YXIgdmFsdWUgPSBnZXRDdXJyZW50VmFsdWUoKTtcbiAgICAgIHNldFN0YXRlKGZ1bmN0aW9uIChwcmV2U3RhdGUpIHtcbiAgICAgICAgLy8gSWdub3JlIHZhbHVlcyBmcm9tIHN0YWxlIHNvdXJjZXMhXG4gICAgICAgIC8vIFNpbmNlIHdlIHN1YnNjcmliZSBhbiB1bnN1YnNjcmliZSBpbiBhIHBhc3NpdmUgZWZmZWN0LFxuICAgICAgICAvLyBpdCdzIHBvc3NpYmxlIHRoYXQgdGhpcyBjYWxsYmFjayB3aWxsIGJlIGludm9rZWQgZm9yIGEgc3RhbGUgKHByZXZpb3VzKSBzdWJzY3JpcHRpb24uXG4gICAgICAgIC8vIFRoaXMgY2hlY2sgYXZvaWRzIHNjaGVkdWxpbmcgYW4gdXBkYXRlIGZvciB0aGF0IHN0YWxlIHN1YnNjcmlwdGlvbi5cbiAgICAgICAgaWYgKHByZXZTdGF0ZS5nZXRDdXJyZW50VmFsdWUgIT09IGdldEN1cnJlbnRWYWx1ZSB8fCBwcmV2U3RhdGUuc3Vic2NyaWJlICE9PSBzdWJzY3JpYmUpIHtcbiAgICAgICAgICByZXR1cm4gcHJldlN0YXRlO1xuICAgICAgICB9IC8vIFNvbWUgc3Vic2NyaXB0aW9ucyB3aWxsIGF1dG8taW52b2tlIHRoZSBoYW5kbGVyLCBldmVuIGlmIHRoZSB2YWx1ZSBoYXNuJ3QgY2hhbmdlZC5cbiAgICAgICAgLy8gSWYgdGhlIHZhbHVlIGhhc24ndCBjaGFuZ2VkLCBubyB1cGRhdGUgaXMgbmVlZGVkLlxuICAgICAgICAvLyBSZXR1cm4gc3RhdGUgYXMtaXMgc28gUmVhY3QgY2FuIGJhaWwgb3V0IGFuZCBhdm9pZCBhbiB1bm5lY2Vzc2FyeSByZW5kZXIuXG5cblxuICAgICAgICBpZiAocHJldlN0YXRlLnZhbHVlID09PSB2YWx1ZSkge1xuICAgICAgICAgIHJldHVybiBwcmV2U3RhdGU7XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gX2Fzc2lnbih7fSwgcHJldlN0YXRlLCB7XG4gICAgICAgICAgdmFsdWU6IHZhbHVlXG4gICAgICAgIH0pO1xuICAgICAgfSk7XG4gICAgfTtcblxuICAgIHZhciB1bnN1YnNjcmliZSA9IHN1YnNjcmliZShjaGVja0ZvclVwZGF0ZXMpOyAvLyBCZWNhdXNlIHdlJ3JlIHN1YnNjcmliaW5nIGluIGEgcGFzc2l2ZSBlZmZlY3QsXG4gICAgLy8gaXQncyBwb3NzaWJsZSB0aGF0IGFuIHVwZGF0ZSBoYXMgb2NjdXJyZWQgYmV0d2VlbiByZW5kZXIgYW5kIG91ciBlZmZlY3QgaGFuZGxlci5cbiAgICAvLyBDaGVjayBmb3IgdGhpcyBhbmQgc2NoZWR1bGUgYW4gdXBkYXRlIGlmIHdvcmsgaGFzIG9jY3VycmVkLlxuXG4gICAgY2hlY2tGb3JVcGRhdGVzKCk7XG4gICAgcmV0dXJuIGZ1bmN0aW9uICgpIHtcbiAgICAgIGRpZFVuc3Vic2NyaWJlID0gdHJ1ZTtcbiAgICAgIHVuc3Vic2NyaWJlKCk7XG4gICAgfTtcbiAgfSwgW2dldEN1cnJlbnRWYWx1ZSwgc3Vic2NyaWJlXSk7IC8vIFJldHVybiB0aGUgY3VycmVudCB2YWx1ZSBmb3Igb3VyIGNhbGxlciB0byB1c2Ugd2hpbGUgcmVuZGVyaW5nLlxuXG4gIHJldHVybiB2YWx1ZVRvUmV0dXJuO1xufVxuXG5leHBvcnRzLnVzZVN1YnNjcmlwdGlvbiA9IHVzZVN1YnNjcmlwdGlvbjtcbiAgfSkoKTtcbn1cbiIsIid1c2Ugc3RyaWN0JztcblxuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WID09PSAncHJvZHVjdGlvbicpIHtcbiAgbW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKCcuL2Nqcy91c2Utc3Vic2NyaXB0aW9uLnByb2R1Y3Rpb24ubWluLmpzJyk7XG59IGVsc2Uge1xuICBtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoJy4vY2pzL3VzZS1zdWJzY3JpcHRpb24uZGV2ZWxvcG1lbnQuanMnKTtcbn1cbiIsIlxyXG5pbXBvcnQgUmVhY3QsIHsgQ29tcG9uZW50LCB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBkeW5hbWljIGZyb20gXCJuZXh0L2R5bmFtaWNcIjtcclxuaW1wb3J0IF8gZnJvbSBcImxvZGFzaFwiO1xyXG5pbXBvcnQgTW9tZW50IGZyb20gXCJtb21lbnRcIjtcclxuaW1wb3J0IExpbmsgZnJvbSBcIm5leHQvbGlua1wiO1xyXG52YXIgc2x1ZyA9IHJlcXVpcmUoJ3NsdWcnKVxyXG5cclxuY29uc3QgZ2V0UGFyc2VkRGF0ZSA9IChkYXRlKSA9PiB7XHJcbiAgcmV0dXJuIE1vbWVudChkYXRlKS5zdGFydE9mKFwiaG91clwiKS5mcm9tTm93KCk7XHJcbn07XHJcblxyXG5cclxuXHJcblxyXG5jb25zdCBDYXJkID0gKHByb3BzKSA9PiB7XHJcbiAgY29uc3QgY3VlbGlua3NPZmZlcnMgPSBwcm9wcy5jdWVsaW5rc09mZmVycyA/IHByb3BzLmN1ZWxpbmtzT2ZmZXJzIDoge307XHJcbiAgY29uc3Qgc3RvcmVfX2xvZ28gPSBwcm9wcy5zdG9yZUluZm8gPyBwcm9wcy5zdG9yZUluZm8uc2x1ZyA6IHt9O1xyXG4gIGNvbnN0IHN0b3JlX19uYW1lID0gcHJvcHMuc3RvcmVJbmZvID8gcHJvcHMuc3RvcmVJbmZvLm5hbWUgOiB7fTtcclxuICBjb25zdCBsaW1pdCA9IHByb3BzLmxpbWl0ID8gcHJvcHMubGltaXQgOiB7fTtcclxuICBcclxuICBpZiAoY3VlbGlua3NPZmZlcnMpIHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxzZWN0aW9uPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2xlYXJmaXhcIj5cclxuICAgICAgICAgIHtfLm1hcChjdWVsaW5rc09mZmVycywgKHZhbHVlLCBrZXkpID0+IHtcclxuICAgICAgICAgICAgbGV0IHByb21vY29kZUNhcmQgPSBmYWxzZTtcclxuICAgICAgICAgICAgbGV0IGN1ZWxPZmZlcnMgPSB7fVxyXG4gICAgICAgICAgICBjdWVsT2ZmZXJzWyd0aXRsZSddID0gdmFsdWVbJ3RpdGxlJ107XHJcbiAgICAgICAgICAgIGN1ZWxPZmZlcnNbJ21lcmNoYW50J10gPSB2YWx1ZVsnbWVyY2hhbnQnXTtcclxuICAgICAgICAgICAgY3VlbE9mZmVyc1snaWQnXSA9IHZhbHVlWydpZCddO1xyXG4gICAgICAgICAgICBjdWVsT2ZmZXJzWydjYXRlZ29yaWVzJ10gPSB2YWx1ZVsnY2F0ZWdvcmllcyddO1xyXG4gICAgICAgICAgICBjdWVsT2ZmZXJzWydkZXNjcmlwdGlvbiddID0gdmFsdWVbJ2Rlc2NyaXB0aW9uJ107XHJcbiAgICAgICAgICAgIGN1ZWxPZmZlcnNbJ2NvdXBvbl9jb2RlJ10gPSB2YWx1ZVsnY291cG9uX2NvZGUnXTtcclxuICAgICAgICAgICAgY3VlbE9mZmVyc1sndXJsJ10gPSB2YWx1ZVsndXJsJ107XHJcbiAgICAgICAgICAgIGN1ZWxPZmZlcnNbJ3N0YXJ0X2RhdGUnXSA9IHZhbHVlWydzdGFydF9kYXRlJ107XHJcbiAgICAgICAgICAgIGN1ZWxPZmZlcnNbJ2VuZF9kYXRlJ10gPSB2YWx1ZVsnZW5kX2RhdGUnXTtcclxuICAgICAgICAgICAgY3VlbE9mZmVyc1snb2ZmZXJfYWRkZWRfYXQnXSA9IHZhbHVlWydvZmZlcl9hZGRlZF9hdCddO1xyXG4gICAgICAgICAgICBjdWVsT2ZmZXJzWydpbWFnZV91cmwnXSA9IHZhbHVlWydpbWFnZV91cmwnXTtcclxuICAgICAgICAgICAgY3VlbE9mZmVyc1snY2FtcGFpZ25fbmFtZSddID0gdmFsdWVbJ2NhbXBhaWduX25hbWUnXTtcclxuXHJcbiAgICAgICAgICAgIGlmICh2YWx1ZVsndGl0bGUnXSAhPT0gXCJcIikge1xyXG4gICAgICAgICAgICAgIGlmIChjdWVsT2ZmZXJzWydjb3Vwb25fY29kZSddICE9IFwiXCIpIHtcclxuICAgICAgICAgICAgICAgIHByb21vY29kZUNhcmQgPSB0cnVlO1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBrZXk9e2tleX0gY2xhc3NOYW1lPXtrZXl9PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvd1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZGVhbF9fY2FyZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkZWFsX19kaXNjb3VudFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRlYWxfX2luZm9cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGltZ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzcmM9e2N1ZWxPZmZlcnNbJ2ltYWdlX3VybCddfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkVycm9yPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGUudGFyZ2V0Lm9uZXJyb3IgPSBudWxsO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGUudGFyZ2V0LnNyYyA9IFwiL2ltZy1ub3Rmb3VuZC5qcGdcIjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWx0PXtjdWVsT2ZmZXJzWyd0aXRsZSddfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz57XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRlYWxfX2Rlc2NcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkZWFsX19kZXNjLXR5cGVcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkZWFsX19kZXNjLXRpdGxlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGgzPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPExpbmsgaHJlZj17Jy9wcm9kdWN0Lycrc2x1ZyhjdWVsT2ZmZXJzWyd0aXRsZSddKX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxhXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YS11cmw9eycvcHJvZHVjdC8nK3NsdWcoY3VlbE9mZmVyc1sndGl0bGUnXSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YS1wcm9tb2xpbms9eycvcHJvZHVjdC8nK3NsdWcoY3VlbE9mZmVyc1sndGl0bGUnXSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YS1mdW5jPVwiZ2V0UHJvbW9Db2RlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJnZXRQcm9tb0NvZGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRhcmdldD1cIl9ibGFua1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYE9mZmVyc0NvZGUuaW4gLSBQcm9tbyBjb2RlIGZvciBgICtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGN1ZWxPZmZlcnNbJ2NhbXBhaWduX25hbWUnXSArXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBgIGRlYWwgYCArXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjdWVsT2ZmZXJzWyd0aXRsZSddXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlbD1cIm5vZm9sbG93XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjdWVsT2ZmZXJzWydtZXJjaGFudCddfSA6IHtjdWVsT2ZmZXJzWyd0aXRsZSddfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZGVhbF9fZGVzYy1tZXRhXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZGVhbF9fZGVzYy1tZXRhLWxhc3R1c2VkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aSBjbGFzc05hbWU9XCJmYSBmYS11c2Vyc1wiPjwvaT4mbmJzcDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxiPntNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiAyMDApICsgMTF9PC9iPiBQZW9wbGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFVzZWQgVG9kYXlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgJm5ic3A7fCZuYnNwO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImRlYWxfX2Rlc2MtbWV0YS1sYXN0dXNlZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2N1ZWxPZmZlcnNbJ2NhdGVnb3JpZXMnXX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkZWFsX19jdGFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7cHJvbW9jb2RlQ2FyZCA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rICBocmVmPXsnL3Byb2R1Y3QvJytzbHVnKGN1ZWxPZmZlcnNbJ3RpdGxlJ10pfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YS11cmw9eycvcHJvZHVjdC8nK3NsdWcoY3VlbE9mZmVyc1sndGl0bGUnXSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBkYXRhLXByb21vY29kZT17Jyd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBkYXRhLXNwZWNpZXM9eycnfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YS1wcm9tb2xpbms9eycvcHJvZHVjdC8nK3NsdWcoY3VlbE9mZmVyc1sndGl0bGUnXSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhLWZ1bmM9XCJnZXRQcm9tb0NvZGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZ2V0UHJvbW9Db2RlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGRhdGEtd2Vic2l0ZT17Jyd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0YXJnZXQ9XCJfYmxhbmtcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBgT2ZmZXJzQ29kZS5pbiAtIFByb21vIGNvZGUgZm9yIGAgK1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjdWVsT2ZmZXJzWydjYW1wYWlnbl9uYW1lJ10gK1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBgIGRlYWwgYCArXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGN1ZWxPZmZlcnNbJ3RpdGxlJ11cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlbD1cIm5vZm9sbG93XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2NsaWNrVXJsKGN1ZWxPZmZlcnNbJ3VybCddKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y3VlbE9mZmVyc1snY291cG9uX2NvZGUnXX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TGluayBocmVmPXsnL3Byb2R1Y3QvJytzbHVnKGN1ZWxPZmZlcnNbJ3RpdGxlJ10pfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gaHJlZj17YC9nb3RvYH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGEtdXJsPXsnL3Byb2R1Y3QvJytzbHVnKGN1ZWxPZmZlcnNbJ3RpdGxlJ10pfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gZGF0YS1wcm9tb2NvZGU9e31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGRhdGEtc3BlY2llcz17fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gZGF0YS1wcm9tb2xpbms9e31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGEtZnVuYz1cImdldERlYWxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZ2V0RGVhbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBkYXRhLXdlYnNpdGU9e31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRhcmdldD1cIl9ibGFua1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBnb3RvTGluayA9IHt2YWx1ZVsxMV19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWw9XCJub2ZvbGxvd1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgR2V0IERlYWxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfSl9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvc2VjdGlvbj5cclxuICAgICk7XHJcbiAgfSBlbHNlIHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxkaXY+XHJcbiAgICAgICAgPGJyIC8+XHJcbiAgICAgICAgPGJyIC8+XHJcbiAgICAgICAgPGJyIC8+XHJcbiAgICAgICAgPGgzPk5vIE5ldyBEZWFscyBPciBDb3Vwb25zIEZvdW5kPC9oMz5cclxuICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG4gIH1cclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IENhcmQ7XHJcbiJdLCJzb3VyY2VSb290IjoiIn0=