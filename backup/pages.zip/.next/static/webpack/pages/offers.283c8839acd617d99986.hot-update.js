webpackHotUpdate_N_E("pages/offers",{

/***/ "./pages/components/Offer/offerCards.js":
/*!**********************************************!*\
  !*** ./pages/components/Offer/offerCards.js ***!
  \**********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/dynamic */ "./node_modules/next/dynamic.js");
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! lodash */ "./node_modules/lodash/lodash.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_5__);


var _jsxFileName = "C:\\xampp\\htdocs\\ReactTuts\\NextJS\\ofccode\\pages\\components\\Offer\\offerCards.js",
    _this = undefined;







var slug = __webpack_require__(/*! slug */ "./node_modules/slug/slug.js");

var getParsedDate = function getParsedDate(date) {
  return moment__WEBPACK_IMPORTED_MODULE_4___default()(date).startOf("hour").fromNow();
}; // const clickUrl = (target) => {
//   // http://localhost:3000/offers
//     if (typeof window !== "undefined") {
//     window.location.href = target;
//     }
// };


var clickUrl = function clickUrl(target) {
  console.log("Great Shot!");
};

var Card = function Card(props) {
  var cuelinksOffers = props.cuelinksOffers ? props.cuelinksOffers : {};
  var store__logo = props.storeInfo ? props.storeInfo.slug : {};
  var store__name = props.storeInfo ? props.storeInfo.name : {};
  var limit = props.limit ? props.limit : {};

  if (cuelinksOffers) {
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("section", {
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "clearfix",
        children: lodash__WEBPACK_IMPORTED_MODULE_3___default.a.map(cuelinksOffers, function (value, key) {
          var promocodeCard = false;
          var cuelOffers = {};
          cuelOffers['title'] = value['title'];
          cuelOffers['merchant'] = value['merchant'];
          cuelOffers['id'] = value['id'];
          cuelOffers['categories'] = value['categories'];
          cuelOffers['description'] = value['description'];
          cuelOffers['coupon_code'] = value['coupon_code'];
          cuelOffers['url'] = value['url'];
          cuelOffers['start_date'] = value['start_date'];
          cuelOffers['end_date'] = value['end_date'];
          cuelOffers['offer_added_at'] = value['offer_added_at'];
          cuelOffers['image_url'] = value['image_url'];
          cuelOffers['campaign_name'] = value['campaign_name'];

          if (value['title'] !== "") {
            if (cuelOffers['coupon_code'] != "") {
              promocodeCard = true;
            }

            return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: key,
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "row",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "deal__card",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                    className: "deal__discount",
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                      className: "deal__info",
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
                          src: cuelOffers['image_url'],
                          onError: function onError(e) {
                            e.target.onerror = null;
                            e.target.src = "/img-notfound.jpg";
                          },
                          alt: cuelOffers['title']
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 62,
                          columnNumber: 29
                        }, _this), " "]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 61,
                        columnNumber: 27
                      }, _this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 60,
                      columnNumber: 25
                    }, _this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 59,
                    columnNumber: 23
                  }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                    className: "deal__desc",
                    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                      className: "deal__desc-type"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 74,
                      columnNumber: 25
                    }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                      className: "deal__desc-title",
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h3", {
                        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_5___default.a, {
                          href: '/product/' + slug(cuelOffers['title']),
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                            "data-url": '/product/' + slug(cuelOffers['title']),
                            "data-promolink": '/product/' + slug(cuelOffers['title']),
                            "data-func": "getPromoCode",
                            className: "getPromoCode",
                            target: "_blank",
                            title: "OffersCode.in - Promo code for " + cuelOffers['campaign_name'] + " deal " + cuelOffers['title'],
                            rel: "nofollow",
                            children: [cuelOffers['merchant'], " : ", cuelOffers['title']]
                          }, void 0, true, {
                            fileName: _jsxFileName,
                            lineNumber: 78,
                            columnNumber: 31
                          }, _this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 77,
                          columnNumber: 29
                        }, _this)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 76,
                        columnNumber: 27
                      }, _this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 75,
                      columnNumber: 25
                    }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                      className: "deal__desc-meta",
                      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                        className: "deal__desc-meta-lastused",
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
                          className: "fa fa-users"
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 99,
                          columnNumber: 29
                        }, _this), "\xA0", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("b", {
                          children: Math.floor(Math.random() * 200) + 11
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 100,
                          columnNumber: 29
                        }, _this), " People Used Today"]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 98,
                        columnNumber: 27
                      }, _this), "\xA0|\xA0", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                        className: "deal__desc-meta-lastused",
                        children: cuelOffers['categories']
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 104,
                        columnNumber: 27
                      }, _this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 97,
                      columnNumber: 25
                    }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                      className: "deal__cta",
                      children: promocodeCard ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                        onClick: clickUrl(cuelOffers['url']),
                        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_5___default.a, {
                          href: '/product/' + slug(cuelOffers['title']),
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                            "data-url": '/product/' + slug(cuelOffers['title']) // data-promocode={''}
                            // data-species={''}
                            ,
                            "data-promolink": '/product/' + slug(cuelOffers['title']),
                            "data-func": "getPromoCode",
                            className: "getPromoCode" // data-website={''}
                            ,
                            target: "_blank",
                            title: "OffersCode.in - Promo code for " + cuelOffers['campaign_name'] + " deal " + cuelOffers['title'],
                            rel: "nofollow",
                            children: cuelOffers['coupon_code']
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 115,
                            columnNumber: 33
                          }, _this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 113,
                          columnNumber: 31
                        }, _this)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 111,
                        columnNumber: 29
                      }, _this) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_5___default.a, {
                          href: '/product/' + slug(cuelOffers['title']),
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                            // href={`/goto`}
                            "data-url": '/product/' + slug(cuelOffers['title']) // data-promocode={}
                            // data-species={}
                            // data-promolink={}
                            ,
                            "data-func": "getDeal",
                            className: "getDeal" // data-website={}
                            ,
                            target: "_blank" // gotoLink = {value[11]}
                            ,
                            rel: "nofollow",
                            children: "Get Deal"
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 139,
                            columnNumber: 33
                          }, _this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 138,
                          columnNumber: 31
                        }, _this)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 137,
                        columnNumber: 29
                      }, _this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 109,
                      columnNumber: 25
                    }, _this)]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 73,
                    columnNumber: 23
                  }, _this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 58,
                  columnNumber: 21
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 57,
                columnNumber: 19
              }, _this)
            }, key, false, {
              fileName: _jsxFileName,
              lineNumber: 56,
              columnNumber: 17
            }, _this);
          }
        })
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 34,
        columnNumber: 9
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 33,
      columnNumber: 7
    }, _this);
  } else {
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 171,
        columnNumber: 9
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 172,
        columnNumber: 9
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 173,
        columnNumber: 9
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h3", {
        children: "No New Deals Or Coupons Found"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 174,
        columnNumber: 9
      }, _this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 170,
      columnNumber: 7
    }, _this);
  }
};

_c = Card;
/* harmony default export */ __webpack_exports__["default"] = (Card);

var _c;

$RefreshReg$(_c, "Card");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvY29tcG9uZW50cy9PZmZlci9vZmZlckNhcmRzLmpzIl0sIm5hbWVzIjpbInNsdWciLCJyZXF1aXJlIiwiZ2V0UGFyc2VkRGF0ZSIsImRhdGUiLCJNb21lbnQiLCJzdGFydE9mIiwiZnJvbU5vdyIsImNsaWNrVXJsIiwidGFyZ2V0IiwiY29uc29sZSIsImxvZyIsIkNhcmQiLCJwcm9wcyIsImN1ZWxpbmtzT2ZmZXJzIiwic3RvcmVfX2xvZ28iLCJzdG9yZUluZm8iLCJzdG9yZV9fbmFtZSIsIm5hbWUiLCJsaW1pdCIsIl8iLCJtYXAiLCJ2YWx1ZSIsImtleSIsInByb21vY29kZUNhcmQiLCJjdWVsT2ZmZXJzIiwiZSIsIm9uZXJyb3IiLCJzcmMiLCJNYXRoIiwiZmxvb3IiLCJyYW5kb20iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBLElBQUlBLElBQUksR0FBR0MsbUJBQU8sQ0FBQyx5Q0FBRCxDQUFsQjs7QUFFQSxJQUFNQyxhQUFhLEdBQUcsU0FBaEJBLGFBQWdCLENBQUNDLElBQUQsRUFBVTtBQUM5QixTQUFPQyw2Q0FBTSxDQUFDRCxJQUFELENBQU4sQ0FBYUUsT0FBYixDQUFxQixNQUFyQixFQUE2QkMsT0FBN0IsRUFBUDtBQUNELENBRkQsQyxDQUtBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBRUEsSUFBTUMsUUFBUSxHQUFHLFNBQVhBLFFBQVcsQ0FBQ0MsTUFBRCxFQUFZO0FBQzNCQyxTQUFPLENBQUNDLEdBQVIsQ0FBWSxhQUFaO0FBQ0QsQ0FGRDs7QUFJQSxJQUFNQyxJQUFJLEdBQUcsU0FBUEEsSUFBTyxDQUFDQyxLQUFELEVBQVc7QUFDdEIsTUFBTUMsY0FBYyxHQUFHRCxLQUFLLENBQUNDLGNBQU4sR0FBdUJELEtBQUssQ0FBQ0MsY0FBN0IsR0FBOEMsRUFBckU7QUFDQSxNQUFNQyxXQUFXLEdBQUdGLEtBQUssQ0FBQ0csU0FBTixHQUFrQkgsS0FBSyxDQUFDRyxTQUFOLENBQWdCZixJQUFsQyxHQUF5QyxFQUE3RDtBQUNBLE1BQU1nQixXQUFXLEdBQUdKLEtBQUssQ0FBQ0csU0FBTixHQUFrQkgsS0FBSyxDQUFDRyxTQUFOLENBQWdCRSxJQUFsQyxHQUF5QyxFQUE3RDtBQUNBLE1BQU1DLEtBQUssR0FBR04sS0FBSyxDQUFDTSxLQUFOLEdBQWNOLEtBQUssQ0FBQ00sS0FBcEIsR0FBNEIsRUFBMUM7O0FBRUEsTUFBSUwsY0FBSixFQUFvQjtBQUNsQix3QkFDRTtBQUFBLDZCQUNFO0FBQUssaUJBQVMsRUFBQyxVQUFmO0FBQUEsa0JBQ0dNLDZDQUFDLENBQUNDLEdBQUYsQ0FBTVAsY0FBTixFQUFzQixVQUFDUSxLQUFELEVBQVFDLEdBQVIsRUFBZ0I7QUFDckMsY0FBSUMsYUFBYSxHQUFHLEtBQXBCO0FBQ0EsY0FBSUMsVUFBVSxHQUFHLEVBQWpCO0FBQ0FBLG9CQUFVLENBQUMsT0FBRCxDQUFWLEdBQXNCSCxLQUFLLENBQUMsT0FBRCxDQUEzQjtBQUNBRyxvQkFBVSxDQUFDLFVBQUQsQ0FBVixHQUF5QkgsS0FBSyxDQUFDLFVBQUQsQ0FBOUI7QUFDQUcsb0JBQVUsQ0FBQyxJQUFELENBQVYsR0FBbUJILEtBQUssQ0FBQyxJQUFELENBQXhCO0FBQ0FHLG9CQUFVLENBQUMsWUFBRCxDQUFWLEdBQTJCSCxLQUFLLENBQUMsWUFBRCxDQUFoQztBQUNBRyxvQkFBVSxDQUFDLGFBQUQsQ0FBVixHQUE0QkgsS0FBSyxDQUFDLGFBQUQsQ0FBakM7QUFDQUcsb0JBQVUsQ0FBQyxhQUFELENBQVYsR0FBNEJILEtBQUssQ0FBQyxhQUFELENBQWpDO0FBQ0FHLG9CQUFVLENBQUMsS0FBRCxDQUFWLEdBQW9CSCxLQUFLLENBQUMsS0FBRCxDQUF6QjtBQUNBRyxvQkFBVSxDQUFDLFlBQUQsQ0FBVixHQUEyQkgsS0FBSyxDQUFDLFlBQUQsQ0FBaEM7QUFDQUcsb0JBQVUsQ0FBQyxVQUFELENBQVYsR0FBeUJILEtBQUssQ0FBQyxVQUFELENBQTlCO0FBQ0FHLG9CQUFVLENBQUMsZ0JBQUQsQ0FBVixHQUErQkgsS0FBSyxDQUFDLGdCQUFELENBQXBDO0FBQ0FHLG9CQUFVLENBQUMsV0FBRCxDQUFWLEdBQTBCSCxLQUFLLENBQUMsV0FBRCxDQUEvQjtBQUNBRyxvQkFBVSxDQUFDLGVBQUQsQ0FBVixHQUE4QkgsS0FBSyxDQUFDLGVBQUQsQ0FBbkM7O0FBRUEsY0FBSUEsS0FBSyxDQUFDLE9BQUQsQ0FBTCxLQUFtQixFQUF2QixFQUEyQjtBQUN6QixnQkFBSUcsVUFBVSxDQUFDLGFBQUQsQ0FBVixJQUE2QixFQUFqQyxFQUFxQztBQUNuQ0QsMkJBQWEsR0FBRyxJQUFoQjtBQUNEOztBQUNELGdDQUNFO0FBQWUsdUJBQVMsRUFBRUQsR0FBMUI7QUFBQSxxQ0FDRTtBQUFLLHlCQUFTLEVBQUMsS0FBZjtBQUFBLHVDQUNFO0FBQUssMkJBQVMsRUFBQyxZQUFmO0FBQUEsMENBQ0U7QUFBSyw2QkFBUyxFQUFDLGdCQUFmO0FBQUEsMkNBQ0U7QUFBSywrQkFBUyxFQUFDLFlBQWY7QUFBQSw2Q0FDRTtBQUFBLGdEQUNFO0FBQ0UsNkJBQUcsRUFBRUUsVUFBVSxDQUFDLFdBQUQsQ0FEakI7QUFFRSxpQ0FBTyxFQUFFLGlCQUFDQyxDQUFELEVBQU87QUFDZEEsNkJBQUMsQ0FBQ2pCLE1BQUYsQ0FBU2tCLE9BQVQsR0FBbUIsSUFBbkI7QUFDQUQsNkJBQUMsQ0FBQ2pCLE1BQUYsQ0FBU21CLEdBQVQsR0FBZSxtQkFBZjtBQUNELDJCQUxIO0FBTUUsNkJBQUcsRUFBRUgsVUFBVSxDQUFDLE9BQUQ7QUFOakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FERixFQVFLLEdBUkw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBREYsZUFlRTtBQUFLLDZCQUFTLEVBQUMsWUFBZjtBQUFBLDRDQUNFO0FBQUssK0JBQVMsRUFBQztBQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBREYsZUFFRTtBQUFLLCtCQUFTLEVBQUMsa0JBQWY7QUFBQSw2Q0FDRTtBQUFBLCtDQUNFLHFFQUFDLGdEQUFEO0FBQU0sOEJBQUksRUFBRSxjQUFZeEIsSUFBSSxDQUFDd0IsVUFBVSxDQUFDLE9BQUQsQ0FBWCxDQUE1QjtBQUFBLGlEQUNFO0FBQ0Usd0NBQVUsY0FBWXhCLElBQUksQ0FBQ3dCLFVBQVUsQ0FBQyxPQUFELENBQVgsQ0FENUI7QUFFRSw4Q0FBZ0IsY0FBWXhCLElBQUksQ0FBQ3dCLFVBQVUsQ0FBQyxPQUFELENBQVgsQ0FGbEM7QUFHRSx5Q0FBVSxjQUhaO0FBSUUscUNBQVMsRUFBQyxjQUpaO0FBS0Usa0NBQU0sRUFBQyxRQUxUO0FBTUUsaUNBQUssRUFDSCxvQ0FDQUEsVUFBVSxDQUFDLGVBQUQsQ0FEVixjQUdBQSxVQUFVLENBQUMsT0FBRCxDQVZkO0FBWUUsK0JBQUcsRUFBQyxVQVpOO0FBQUEsdUNBY0dBLFVBQVUsQ0FBQyxVQUFELENBZGIsU0FjOEJBLFVBQVUsQ0FBQyxPQUFELENBZHhDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFGRixlQXdCRTtBQUFLLCtCQUFTLEVBQUMsaUJBQWY7QUFBQSw4Q0FDRTtBQUFNLGlDQUFTLEVBQUMsMEJBQWhCO0FBQUEsZ0RBQ0U7QUFBRyxtQ0FBUyxFQUFDO0FBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FERix1QkFFRTtBQUFBLG9DQUFJSSxJQUFJLENBQUNDLEtBQUwsQ0FBV0QsSUFBSSxDQUFDRSxNQUFMLEtBQWdCLEdBQTNCLElBQWtDO0FBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQURGLDRCQU9FO0FBQU0saUNBQVMsRUFBQywwQkFBaEI7QUFBQSxrQ0FDR04sVUFBVSxDQUFDLFlBQUQ7QUFEYjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkF4QkYsZUFvQ0U7QUFBSywrQkFBUyxFQUFDLFdBQWY7QUFBQSxnQ0FDR0QsYUFBYSxnQkFDWjtBQUNBLCtCQUFPLEVBQUVoQixRQUFRLENBQUNpQixVQUFVLENBQUMsS0FBRCxDQUFYLENBRGpCO0FBQUEsK0NBRUUscUVBQUMsZ0RBQUQ7QUFDRyw4QkFBSSxFQUFFLGNBQVl4QixJQUFJLENBQUN3QixVQUFVLENBQUMsT0FBRCxDQUFYLENBRHpCO0FBQUEsaURBRUU7QUFDRSx3Q0FBVSxjQUFZeEIsSUFBSSxDQUFDd0IsVUFBVSxDQUFDLE9BQUQsQ0FBWCxDQUQ1QixDQUVFO0FBQ0E7QUFIRjtBQUlFLDhDQUFnQixjQUFZeEIsSUFBSSxDQUFDd0IsVUFBVSxDQUFDLE9BQUQsQ0FBWCxDQUpsQztBQUtFLHlDQUFVLGNBTFo7QUFNRSxxQ0FBUyxFQUFDLGNBTlosQ0FPRTtBQVBGO0FBUUUsa0NBQU0sRUFBQyxRQVJUO0FBU0UsaUNBQUssRUFDSCxvQ0FDQUEsVUFBVSxDQUFDLGVBQUQsQ0FEVixjQUdBQSxVQUFVLENBQUMsT0FBRCxDQWJkO0FBZUUsK0JBQUcsRUFBQyxVQWZOO0FBQUEsc0NBaUJHQSxVQUFVLENBQUMsYUFBRDtBQWpCYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBRFksZ0JBMkJaO0FBQUEsK0NBQ0UscUVBQUMsZ0RBQUQ7QUFBTSw4QkFBSSxFQUFFLGNBQVl4QixJQUFJLENBQUN3QixVQUFVLENBQUMsT0FBRCxDQUFYLENBQTVCO0FBQUEsaURBQ0U7QUFDRTtBQUNBLHdDQUFVLGNBQVl4QixJQUFJLENBQUN3QixVQUFVLENBQUMsT0FBRCxDQUFYLENBRjVCLENBR0U7QUFDQTtBQUNBO0FBTEY7QUFNRSx5Q0FBVSxTQU5aO0FBT0UscUNBQVMsRUFBQyxTQVBaLENBUUU7QUFSRjtBQVNFLGtDQUFNLEVBQUMsUUFUVCxDQVVFO0FBVkY7QUFXRSwrQkFBRyxFQUFDLFVBWE47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQTVCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQXBDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGLGVBQVVGLEdBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFERjtBQTRHRDtBQUNGLFNBaklBO0FBREg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFERjtBQXdJRCxHQXpJRCxNQXlJTztBQUNMLHdCQUNFO0FBQUEsOEJBQ0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGLGVBRUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUZGLGVBR0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUhGLGVBSUU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFERjtBQVFEO0FBQ0YsQ0F6SkQ7O0tBQU1YLEk7QUEySlNBLG1FQUFmIiwiZmlsZSI6InN0YXRpYy93ZWJwYWNrL3BhZ2VzL29mZmVycy4yODNjODgzOWFjZDYxN2Q5OTk4Ni5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbmltcG9ydCBSZWFjdCwgeyBDb21wb25lbnQsIHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IGR5bmFtaWMgZnJvbSBcIm5leHQvZHluYW1pY1wiO1xyXG5pbXBvcnQgXyBmcm9tIFwibG9kYXNoXCI7XHJcbmltcG9ydCBNb21lbnQgZnJvbSBcIm1vbWVudFwiO1xyXG5pbXBvcnQgTGluayBmcm9tIFwibmV4dC9saW5rXCI7XHJcbnZhciBzbHVnID0gcmVxdWlyZSgnc2x1ZycpXHJcblxyXG5jb25zdCBnZXRQYXJzZWREYXRlID0gKGRhdGUpID0+IHtcclxuICByZXR1cm4gTW9tZW50KGRhdGUpLnN0YXJ0T2YoXCJob3VyXCIpLmZyb21Ob3coKTtcclxufTtcclxuXHJcblxyXG4vLyBjb25zdCBjbGlja1VybCA9ICh0YXJnZXQpID0+IHtcclxuLy8gICAvLyBodHRwOi8vbG9jYWxob3N0OjMwMDAvb2ZmZXJzXHJcbi8vICAgICBpZiAodHlwZW9mIHdpbmRvdyAhPT0gXCJ1bmRlZmluZWRcIikge1xyXG4vLyAgICAgd2luZG93LmxvY2F0aW9uLmhyZWYgPSB0YXJnZXQ7XHJcbi8vICAgICB9XHJcbi8vIH07XHJcblxyXG5jb25zdCBjbGlja1VybCA9ICh0YXJnZXQpID0+IHtcclxuICBjb25zb2xlLmxvZyhcIkdyZWF0IFNob3QhXCIpO1xyXG59XHJcblxyXG5jb25zdCBDYXJkID0gKHByb3BzKSA9PiB7XHJcbiAgY29uc3QgY3VlbGlua3NPZmZlcnMgPSBwcm9wcy5jdWVsaW5rc09mZmVycyA/IHByb3BzLmN1ZWxpbmtzT2ZmZXJzIDoge307XHJcbiAgY29uc3Qgc3RvcmVfX2xvZ28gPSBwcm9wcy5zdG9yZUluZm8gPyBwcm9wcy5zdG9yZUluZm8uc2x1ZyA6IHt9O1xyXG4gIGNvbnN0IHN0b3JlX19uYW1lID0gcHJvcHMuc3RvcmVJbmZvID8gcHJvcHMuc3RvcmVJbmZvLm5hbWUgOiB7fTtcclxuICBjb25zdCBsaW1pdCA9IHByb3BzLmxpbWl0ID8gcHJvcHMubGltaXQgOiB7fTtcclxuICBcclxuICBpZiAoY3VlbGlua3NPZmZlcnMpIHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxzZWN0aW9uPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2xlYXJmaXhcIj5cclxuICAgICAgICAgIHtfLm1hcChjdWVsaW5rc09mZmVycywgKHZhbHVlLCBrZXkpID0+IHtcclxuICAgICAgICAgICAgbGV0IHByb21vY29kZUNhcmQgPSBmYWxzZTtcclxuICAgICAgICAgICAgbGV0IGN1ZWxPZmZlcnMgPSB7fVxyXG4gICAgICAgICAgICBjdWVsT2ZmZXJzWyd0aXRsZSddID0gdmFsdWVbJ3RpdGxlJ107XHJcbiAgICAgICAgICAgIGN1ZWxPZmZlcnNbJ21lcmNoYW50J10gPSB2YWx1ZVsnbWVyY2hhbnQnXTtcclxuICAgICAgICAgICAgY3VlbE9mZmVyc1snaWQnXSA9IHZhbHVlWydpZCddO1xyXG4gICAgICAgICAgICBjdWVsT2ZmZXJzWydjYXRlZ29yaWVzJ10gPSB2YWx1ZVsnY2F0ZWdvcmllcyddO1xyXG4gICAgICAgICAgICBjdWVsT2ZmZXJzWydkZXNjcmlwdGlvbiddID0gdmFsdWVbJ2Rlc2NyaXB0aW9uJ107XHJcbiAgICAgICAgICAgIGN1ZWxPZmZlcnNbJ2NvdXBvbl9jb2RlJ10gPSB2YWx1ZVsnY291cG9uX2NvZGUnXTtcclxuICAgICAgICAgICAgY3VlbE9mZmVyc1sndXJsJ10gPSB2YWx1ZVsndXJsJ107XHJcbiAgICAgICAgICAgIGN1ZWxPZmZlcnNbJ3N0YXJ0X2RhdGUnXSA9IHZhbHVlWydzdGFydF9kYXRlJ107XHJcbiAgICAgICAgICAgIGN1ZWxPZmZlcnNbJ2VuZF9kYXRlJ10gPSB2YWx1ZVsnZW5kX2RhdGUnXTtcclxuICAgICAgICAgICAgY3VlbE9mZmVyc1snb2ZmZXJfYWRkZWRfYXQnXSA9IHZhbHVlWydvZmZlcl9hZGRlZF9hdCddO1xyXG4gICAgICAgICAgICBjdWVsT2ZmZXJzWydpbWFnZV91cmwnXSA9IHZhbHVlWydpbWFnZV91cmwnXTtcclxuICAgICAgICAgICAgY3VlbE9mZmVyc1snY2FtcGFpZ25fbmFtZSddID0gdmFsdWVbJ2NhbXBhaWduX25hbWUnXTtcclxuXHJcbiAgICAgICAgICAgIGlmICh2YWx1ZVsndGl0bGUnXSAhPT0gXCJcIikge1xyXG4gICAgICAgICAgICAgIGlmIChjdWVsT2ZmZXJzWydjb3Vwb25fY29kZSddICE9IFwiXCIpIHtcclxuICAgICAgICAgICAgICAgIHByb21vY29kZUNhcmQgPSB0cnVlO1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBrZXk9e2tleX0gY2xhc3NOYW1lPXtrZXl9PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvd1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZGVhbF9fY2FyZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkZWFsX19kaXNjb3VudFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRlYWxfX2luZm9cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGltZ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzcmM9e2N1ZWxPZmZlcnNbJ2ltYWdlX3VybCddfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkVycm9yPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGUudGFyZ2V0Lm9uZXJyb3IgPSBudWxsO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGUudGFyZ2V0LnNyYyA9IFwiL2ltZy1ub3Rmb3VuZC5qcGdcIjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWx0PXtjdWVsT2ZmZXJzWyd0aXRsZSddfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz57XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRlYWxfX2Rlc2NcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkZWFsX19kZXNjLXR5cGVcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkZWFsX19kZXNjLXRpdGxlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGgzPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPExpbmsgaHJlZj17Jy9wcm9kdWN0Lycrc2x1ZyhjdWVsT2ZmZXJzWyd0aXRsZSddKX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxhXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YS11cmw9eycvcHJvZHVjdC8nK3NsdWcoY3VlbE9mZmVyc1sndGl0bGUnXSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YS1wcm9tb2xpbms9eycvcHJvZHVjdC8nK3NsdWcoY3VlbE9mZmVyc1sndGl0bGUnXSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YS1mdW5jPVwiZ2V0UHJvbW9Db2RlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJnZXRQcm9tb0NvZGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRhcmdldD1cIl9ibGFua1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYE9mZmVyc0NvZGUuaW4gLSBQcm9tbyBjb2RlIGZvciBgICtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGN1ZWxPZmZlcnNbJ2NhbXBhaWduX25hbWUnXSArXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBgIGRlYWwgYCArXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjdWVsT2ZmZXJzWyd0aXRsZSddXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlbD1cIm5vZm9sbG93XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjdWVsT2ZmZXJzWydtZXJjaGFudCddfSA6IHtjdWVsT2ZmZXJzWyd0aXRsZSddfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZGVhbF9fZGVzYy1tZXRhXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZGVhbF9fZGVzYy1tZXRhLWxhc3R1c2VkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aSBjbGFzc05hbWU9XCJmYSBmYS11c2Vyc1wiPjwvaT4mbmJzcDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxiPntNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiAyMDApICsgMTF9PC9iPiBQZW9wbGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFVzZWQgVG9kYXlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgJm5ic3A7fCZuYnNwO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImRlYWxfX2Rlc2MtbWV0YS1sYXN0dXNlZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2N1ZWxPZmZlcnNbJ2NhdGVnb3JpZXMnXX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkZWFsX19jdGFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7cHJvbW9jb2RlQ2FyZCA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtjbGlja1VybChjdWVsT2ZmZXJzWyd1cmwnXSl9ID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPExpbmsgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBocmVmPXsnL3Byb2R1Y3QvJytzbHVnKGN1ZWxPZmZlcnNbJ3RpdGxlJ10pfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YS11cmw9eycvcHJvZHVjdC8nK3NsdWcoY3VlbE9mZmVyc1sndGl0bGUnXSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBkYXRhLXByb21vY29kZT17Jyd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBkYXRhLXNwZWNpZXM9eycnfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YS1wcm9tb2xpbms9eycvcHJvZHVjdC8nK3NsdWcoY3VlbE9mZmVyc1sndGl0bGUnXSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhLWZ1bmM9XCJnZXRQcm9tb0NvZGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZ2V0UHJvbW9Db2RlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGRhdGEtd2Vic2l0ZT17Jyd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0YXJnZXQ9XCJfYmxhbmtcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBgT2ZmZXJzQ29kZS5pbiAtIFByb21vIGNvZGUgZm9yIGAgK1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjdWVsT2ZmZXJzWydjYW1wYWlnbl9uYW1lJ10gK1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBgIGRlYWwgYCArXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGN1ZWxPZmZlcnNbJ3RpdGxlJ11cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlbD1cIm5vZm9sbG93XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y3VlbE9mZmVyc1snY291cG9uX2NvZGUnXX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TGluayBocmVmPXsnL3Byb2R1Y3QvJytzbHVnKGN1ZWxPZmZlcnNbJ3RpdGxlJ10pfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gaHJlZj17YC9nb3RvYH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGEtdXJsPXsnL3Byb2R1Y3QvJytzbHVnKGN1ZWxPZmZlcnNbJ3RpdGxlJ10pfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gZGF0YS1wcm9tb2NvZGU9e31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGRhdGEtc3BlY2llcz17fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gZGF0YS1wcm9tb2xpbms9e31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGEtZnVuYz1cImdldERlYWxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZ2V0RGVhbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBkYXRhLXdlYnNpdGU9e31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRhcmdldD1cIl9ibGFua1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBnb3RvTGluayA9IHt2YWx1ZVsxMV19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWw9XCJub2ZvbGxvd1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgR2V0IERlYWxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfSl9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvc2VjdGlvbj5cclxuICAgICk7XHJcbiAgfSBlbHNlIHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxkaXY+XHJcbiAgICAgICAgPGJyIC8+XHJcbiAgICAgICAgPGJyIC8+XHJcbiAgICAgICAgPGJyIC8+XHJcbiAgICAgICAgPGgzPk5vIE5ldyBEZWFscyBPciBDb3Vwb25zIEZvdW5kPC9oMz5cclxuICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG4gIH1cclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IENhcmQ7XHJcbiJdLCJzb3VyY2VSb290IjoiIn0=