webpackHotUpdate_N_E("pages/offers",{

/***/ "./pages/components/Offer/offerCards.js":
/*!**********************************************!*\
  !*** ./pages/components/Offer/offerCards.js ***!
  \**********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! lodash */ "./node_modules/lodash/lodash.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_4__);


var _jsxFileName = "C:\\xampp\\htdocs\\ReactTuts\\NextJS\\ofccode\\pages\\components\\Offer\\offerCards.js",
    _this = undefined,
    _s = $RefreshSig$();






var slug = __webpack_require__(/*! slug */ "./node_modules/slug/slug.js");

var getParsedDate = function getParsedDate(date) {
  return moment__WEBPACK_IMPORTED_MODULE_3___default()(date).startOf("hour").fromNow();
};

var Card = function Card(props) {
  _s();

  var cuelinksOffers = props.cuelinksOffers ? props.cuelinksOffers : {};
  var store__logo = props.storeInfo ? props.storeInfo.slug : {};
  var store__name = props.storeInfo ? props.storeInfo.name : {};
  var limit = props.limit ? props.limit : {};
  react__WEBPACK_IMPORTED_MODULE_1___default.a.useEffect(function () {
    var clickUrl = function clickUrl(target) {
      if (window !== undefined) {
        window.location.href = target;
      }
    };
  });

  if (cuelinksOffers) {
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("section", {
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "clearfix",
        children: lodash__WEBPACK_IMPORTED_MODULE_2___default.a.map(cuelinksOffers, function (value, key) {
          var promocodeCard = false;
          var cuelOffers = {};
          cuelOffers['title'] = value['title'];
          cuelOffers['merchant'] = value['merchant'];
          cuelOffers['id'] = value['id'];
          cuelOffers['categories'] = value['categories'];
          cuelOffers['description'] = value['description'];
          cuelOffers['coupon_code'] = value['coupon_code'];
          cuelOffers['url'] = value['url'];
          cuelOffers['start_date'] = value['start_date'];
          cuelOffers['end_date'] = value['end_date'];
          cuelOffers['offer_added_at'] = value['offer_added_at'];
          cuelOffers['image_url'] = value['image_url'];
          cuelOffers['campaign_name'] = value['campaign_name'];

          if (value['title'] !== "") {
            if (cuelOffers['coupon_code'] != "") {
              promocodeCard = true;
            }

            return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: key,
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "row",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "deal__card",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                    className: "deal__discount",
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                      className: "deal__info",
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
                          src: cuelOffers['image_url'],
                          onError: function onError(e) {
                            e.target.onerror = null;
                            e.target.src = "/img-notfound.jpg";
                          },
                          alt: cuelOffers['title']
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 62,
                          columnNumber: 29
                        }, _this), " "]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 61,
                        columnNumber: 27
                      }, _this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 60,
                      columnNumber: 25
                    }, _this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 59,
                    columnNumber: 23
                  }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                    className: "deal__desc",
                    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                      className: "deal__desc-type"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 74,
                      columnNumber: 25
                    }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                      className: "deal__desc-title",
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h3", {
                        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_4___default.a, {
                          href: '/product/' + slug(cuelOffers['title']),
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                            "data-url": '/product/' + slug(cuelOffers['title']),
                            "data-promolink": '/product/' + slug(cuelOffers['title']),
                            "data-func": "getPromoCode",
                            className: "getPromoCode",
                            target: "_blank",
                            title: "OffersCode.in - Promo code for " + cuelOffers['campaign_name'] + " deal " + cuelOffers['title'],
                            rel: "nofollow",
                            children: [cuelOffers['merchant'], " : ", cuelOffers['title']]
                          }, void 0, true, {
                            fileName: _jsxFileName,
                            lineNumber: 78,
                            columnNumber: 31
                          }, _this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 77,
                          columnNumber: 29
                        }, _this)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 76,
                        columnNumber: 27
                      }, _this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 75,
                      columnNumber: 25
                    }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                      className: "deal__desc-meta",
                      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                        className: "deal__desc-meta-lastused",
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
                          className: "fa fa-users"
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 99,
                          columnNumber: 29
                        }, _this), "\xA0", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("b", {
                          children: Math.floor(Math.random() * 200) + 11
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 100,
                          columnNumber: 29
                        }, _this), " People Used Today"]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 98,
                        columnNumber: 27
                      }, _this), "\xA0|\xA0", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                        className: "deal__desc-meta-lastused",
                        children: cuelOffers['categories']
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 104,
                        columnNumber: 27
                      }, _this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 97,
                      columnNumber: 25
                    }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                      className: "deal__cta",
                      children: promocodeCard ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_4___default.a, {
                          onClick: clickUrl(cuelOffers['url']),
                          href: '/product/' + slug(cuelOffers['title']),
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                            "data-url": '/product/' + slug(cuelOffers['title']) // data-promocode={''}
                            // data-species={''}
                            ,
                            "data-promolink": '/product/' + slug(cuelOffers['title']),
                            "data-func": "getPromoCode",
                            className: "getPromoCode" // data-website={''}
                            ,
                            target: "_blank",
                            title: "OffersCode.in - Promo code for " + cuelOffers['campaign_name'] + " deal " + cuelOffers['title'],
                            rel: "nofollow",
                            children: cuelOffers['coupon_code']
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 113,
                            columnNumber: 33
                          }, _this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 112,
                          columnNumber: 31
                        }, _this)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 111,
                        columnNumber: 29
                      }, _this) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_4___default.a, {
                          href: '/product/' + slug(cuelOffers['title']),
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                            // href={`/goto`}
                            "data-url": '/product/' + slug(cuelOffers['title']) // data-promocode={}
                            // data-species={}
                            // data-promolink={}
                            ,
                            "data-func": "getDeal",
                            className: "getDeal" // data-website={}
                            ,
                            target: "_blank" // gotoLink = {value[11]}
                            ,
                            rel: "nofollow",
                            children: "Get Deal"
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 137,
                            columnNumber: 33
                          }, _this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 136,
                          columnNumber: 31
                        }, _this)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 135,
                        columnNumber: 29
                      }, _this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 109,
                      columnNumber: 25
                    }, _this)]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 73,
                    columnNumber: 23
                  }, _this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 58,
                  columnNumber: 21
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 57,
                columnNumber: 19
              }, _this)
            }, key, false, {
              fileName: _jsxFileName,
              lineNumber: 56,
              columnNumber: 17
            }, _this);
          }
        })
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 34,
        columnNumber: 9
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 33,
      columnNumber: 7
    }, _this);
  } else {
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 169,
        columnNumber: 9
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 170,
        columnNumber: 9
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 171,
        columnNumber: 9
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h3", {
        children: "No New Deals Or Coupons Found"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 172,
        columnNumber: 9
      }, _this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 168,
      columnNumber: 7
    }, _this);
  }
};

_s(Card, "OD7bBpZva5O2jO+Puf00hKivP7c=");

_c = Card;
/* harmony default export */ __webpack_exports__["default"] = (Card);

var _c;

$RefreshReg$(_c, "Card");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvY29tcG9uZW50cy9PZmZlci9vZmZlckNhcmRzLmpzIl0sIm5hbWVzIjpbInNsdWciLCJyZXF1aXJlIiwiZ2V0UGFyc2VkRGF0ZSIsImRhdGUiLCJNb21lbnQiLCJzdGFydE9mIiwiZnJvbU5vdyIsIkNhcmQiLCJwcm9wcyIsImN1ZWxpbmtzT2ZmZXJzIiwic3RvcmVfX2xvZ28iLCJzdG9yZUluZm8iLCJzdG9yZV9fbmFtZSIsIm5hbWUiLCJsaW1pdCIsIlJlYWN0IiwidXNlRWZmZWN0IiwiY2xpY2tVcmwiLCJ0YXJnZXQiLCJ3aW5kb3ciLCJ1bmRlZmluZWQiLCJsb2NhdGlvbiIsImhyZWYiLCJfIiwibWFwIiwidmFsdWUiLCJrZXkiLCJwcm9tb2NvZGVDYXJkIiwiY3VlbE9mZmVycyIsImUiLCJvbmVycm9yIiwic3JjIiwiTWF0aCIsImZsb29yIiwicmFuZG9tIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQSxJQUFJQSxJQUFJLEdBQUdDLG1CQUFPLENBQUMseUNBQUQsQ0FBbEI7O0FBRUEsSUFBTUMsYUFBYSxHQUFHLFNBQWhCQSxhQUFnQixDQUFDQyxJQUFELEVBQVU7QUFDOUIsU0FBT0MsNkNBQU0sQ0FBQ0QsSUFBRCxDQUFOLENBQWFFLE9BQWIsQ0FBcUIsTUFBckIsRUFBNkJDLE9BQTdCLEVBQVA7QUFDRCxDQUZEOztBQU9BLElBQU1DLElBQUksR0FBRyxTQUFQQSxJQUFPLENBQUNDLEtBQUQsRUFBVztBQUFBOztBQUN0QixNQUFNQyxjQUFjLEdBQUdELEtBQUssQ0FBQ0MsY0FBTixHQUF1QkQsS0FBSyxDQUFDQyxjQUE3QixHQUE4QyxFQUFyRTtBQUNBLE1BQU1DLFdBQVcsR0FBR0YsS0FBSyxDQUFDRyxTQUFOLEdBQWtCSCxLQUFLLENBQUNHLFNBQU4sQ0FBZ0JYLElBQWxDLEdBQXlDLEVBQTdEO0FBQ0EsTUFBTVksV0FBVyxHQUFHSixLQUFLLENBQUNHLFNBQU4sR0FBa0JILEtBQUssQ0FBQ0csU0FBTixDQUFnQkUsSUFBbEMsR0FBeUMsRUFBN0Q7QUFDQSxNQUFNQyxLQUFLLEdBQUdOLEtBQUssQ0FBQ00sS0FBTixHQUFjTixLQUFLLENBQUNNLEtBQXBCLEdBQTRCLEVBQTFDO0FBR0FDLDhDQUFLLENBQUNDLFNBQU4sQ0FBZ0IsWUFBTTtBQUNwQixRQUFNQyxRQUFRLEdBQUcsU0FBWEEsUUFBVyxDQUFDQyxNQUFELEVBQVk7QUFDM0IsVUFBSUMsTUFBTSxLQUFLQyxTQUFmLEVBQTBCO0FBQzFCRCxjQUFNLENBQUNFLFFBQVAsQ0FBZ0JDLElBQWhCLEdBQXVCSixNQUF2QjtBQUNDO0FBQ0YsS0FKRDtBQUtELEdBTkQ7O0FBU0EsTUFBSVQsY0FBSixFQUFvQjtBQUNsQix3QkFDRTtBQUFBLDZCQUNFO0FBQUssaUJBQVMsRUFBQyxVQUFmO0FBQUEsa0JBQ0djLDZDQUFDLENBQUNDLEdBQUYsQ0FBTWYsY0FBTixFQUFzQixVQUFDZ0IsS0FBRCxFQUFRQyxHQUFSLEVBQWdCO0FBQ3JDLGNBQUlDLGFBQWEsR0FBRyxLQUFwQjtBQUNBLGNBQUlDLFVBQVUsR0FBRyxFQUFqQjtBQUNBQSxvQkFBVSxDQUFDLE9BQUQsQ0FBVixHQUFzQkgsS0FBSyxDQUFDLE9BQUQsQ0FBM0I7QUFDQUcsb0JBQVUsQ0FBQyxVQUFELENBQVYsR0FBeUJILEtBQUssQ0FBQyxVQUFELENBQTlCO0FBQ0FHLG9CQUFVLENBQUMsSUFBRCxDQUFWLEdBQW1CSCxLQUFLLENBQUMsSUFBRCxDQUF4QjtBQUNBRyxvQkFBVSxDQUFDLFlBQUQsQ0FBVixHQUEyQkgsS0FBSyxDQUFDLFlBQUQsQ0FBaEM7QUFDQUcsb0JBQVUsQ0FBQyxhQUFELENBQVYsR0FBNEJILEtBQUssQ0FBQyxhQUFELENBQWpDO0FBQ0FHLG9CQUFVLENBQUMsYUFBRCxDQUFWLEdBQTRCSCxLQUFLLENBQUMsYUFBRCxDQUFqQztBQUNBRyxvQkFBVSxDQUFDLEtBQUQsQ0FBVixHQUFvQkgsS0FBSyxDQUFDLEtBQUQsQ0FBekI7QUFDQUcsb0JBQVUsQ0FBQyxZQUFELENBQVYsR0FBMkJILEtBQUssQ0FBQyxZQUFELENBQWhDO0FBQ0FHLG9CQUFVLENBQUMsVUFBRCxDQUFWLEdBQXlCSCxLQUFLLENBQUMsVUFBRCxDQUE5QjtBQUNBRyxvQkFBVSxDQUFDLGdCQUFELENBQVYsR0FBK0JILEtBQUssQ0FBQyxnQkFBRCxDQUFwQztBQUNBRyxvQkFBVSxDQUFDLFdBQUQsQ0FBVixHQUEwQkgsS0FBSyxDQUFDLFdBQUQsQ0FBL0I7QUFDQUcsb0JBQVUsQ0FBQyxlQUFELENBQVYsR0FBOEJILEtBQUssQ0FBQyxlQUFELENBQW5DOztBQUVBLGNBQUlBLEtBQUssQ0FBQyxPQUFELENBQUwsS0FBbUIsRUFBdkIsRUFBMkI7QUFDekIsZ0JBQUlHLFVBQVUsQ0FBQyxhQUFELENBQVYsSUFBNkIsRUFBakMsRUFBcUM7QUFDbkNELDJCQUFhLEdBQUcsSUFBaEI7QUFDRDs7QUFDRCxnQ0FDRTtBQUFlLHVCQUFTLEVBQUVELEdBQTFCO0FBQUEscUNBQ0U7QUFBSyx5QkFBUyxFQUFDLEtBQWY7QUFBQSx1Q0FDRTtBQUFLLDJCQUFTLEVBQUMsWUFBZjtBQUFBLDBDQUNFO0FBQUssNkJBQVMsRUFBQyxnQkFBZjtBQUFBLDJDQUNFO0FBQUssK0JBQVMsRUFBQyxZQUFmO0FBQUEsNkNBQ0U7QUFBQSxnREFDRTtBQUNFLDZCQUFHLEVBQUVFLFVBQVUsQ0FBQyxXQUFELENBRGpCO0FBRUUsaUNBQU8sRUFBRSxpQkFBQ0MsQ0FBRCxFQUFPO0FBQ2RBLDZCQUFDLENBQUNYLE1BQUYsQ0FBU1ksT0FBVCxHQUFtQixJQUFuQjtBQUNBRCw2QkFBQyxDQUFDWCxNQUFGLENBQVNhLEdBQVQsR0FBZSxtQkFBZjtBQUNELDJCQUxIO0FBTUUsNkJBQUcsRUFBRUgsVUFBVSxDQUFDLE9BQUQ7QUFOakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FERixFQVFLLEdBUkw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBREYsZUFlRTtBQUFLLDZCQUFTLEVBQUMsWUFBZjtBQUFBLDRDQUNFO0FBQUssK0JBQVMsRUFBQztBQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBREYsZUFFRTtBQUFLLCtCQUFTLEVBQUMsa0JBQWY7QUFBQSw2Q0FDRTtBQUFBLCtDQUNFLHFFQUFDLGdEQUFEO0FBQU0sOEJBQUksRUFBRSxjQUFZNUIsSUFBSSxDQUFDNEIsVUFBVSxDQUFDLE9BQUQsQ0FBWCxDQUE1QjtBQUFBLGlEQUNFO0FBQ0Usd0NBQVUsY0FBWTVCLElBQUksQ0FBQzRCLFVBQVUsQ0FBQyxPQUFELENBQVgsQ0FENUI7QUFFRSw4Q0FBZ0IsY0FBWTVCLElBQUksQ0FBQzRCLFVBQVUsQ0FBQyxPQUFELENBQVgsQ0FGbEM7QUFHRSx5Q0FBVSxjQUhaO0FBSUUscUNBQVMsRUFBQyxjQUpaO0FBS0Usa0NBQU0sRUFBQyxRQUxUO0FBTUUsaUNBQUssRUFDSCxvQ0FDQUEsVUFBVSxDQUFDLGVBQUQsQ0FEVixjQUdBQSxVQUFVLENBQUMsT0FBRCxDQVZkO0FBWUUsK0JBQUcsRUFBQyxVQVpOO0FBQUEsdUNBY0dBLFVBQVUsQ0FBQyxVQUFELENBZGIsU0FjOEJBLFVBQVUsQ0FBQyxPQUFELENBZHhDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFGRixlQXdCRTtBQUFLLCtCQUFTLEVBQUMsaUJBQWY7QUFBQSw4Q0FDRTtBQUFNLGlDQUFTLEVBQUMsMEJBQWhCO0FBQUEsZ0RBQ0U7QUFBRyxtQ0FBUyxFQUFDO0FBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FERix1QkFFRTtBQUFBLG9DQUFJSSxJQUFJLENBQUNDLEtBQUwsQ0FBV0QsSUFBSSxDQUFDRSxNQUFMLEtBQWdCLEdBQTNCLElBQWtDO0FBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQURGLDRCQU9FO0FBQU0saUNBQVMsRUFBQywwQkFBaEI7QUFBQSxrQ0FDR04sVUFBVSxDQUFDLFlBQUQ7QUFEYjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkF4QkYsZUFvQ0U7QUFBSywrQkFBUyxFQUFDLFdBQWY7QUFBQSxnQ0FDR0QsYUFBYSxnQkFDWjtBQUFBLCtDQUNFLHFFQUFDLGdEQUFEO0FBQU0saUNBQU8sRUFBRVYsUUFBUSxDQUFDVyxVQUFVLENBQUMsS0FBRCxDQUFYLENBQXZCO0FBQTRDLDhCQUFJLEVBQUUsY0FBWTVCLElBQUksQ0FBQzRCLFVBQVUsQ0FBQyxPQUFELENBQVgsQ0FBbEU7QUFBQSxpREFDRTtBQUNFLHdDQUFVLGNBQVk1QixJQUFJLENBQUM0QixVQUFVLENBQUMsT0FBRCxDQUFYLENBRDVCLENBRUU7QUFDQTtBQUhGO0FBSUUsOENBQWdCLGNBQVk1QixJQUFJLENBQUM0QixVQUFVLENBQUMsT0FBRCxDQUFYLENBSmxDO0FBS0UseUNBQVUsY0FMWjtBQU1FLHFDQUFTLEVBQUMsY0FOWixDQU9FO0FBUEY7QUFRRSxrQ0FBTSxFQUFDLFFBUlQ7QUFTRSxpQ0FBSyxFQUNILG9DQUNBQSxVQUFVLENBQUMsZUFBRCxDQURWLGNBR0FBLFVBQVUsQ0FBQyxPQUFELENBYmQ7QUFlRSwrQkFBRyxFQUFDLFVBZk47QUFBQSxzQ0FpQkdBLFVBQVUsQ0FBQyxhQUFEO0FBakJiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFEWSxnQkF5Qlo7QUFBQSwrQ0FDRSxxRUFBQyxnREFBRDtBQUFNLDhCQUFJLEVBQUUsY0FBWTVCLElBQUksQ0FBQzRCLFVBQVUsQ0FBQyxPQUFELENBQVgsQ0FBNUI7QUFBQSxpREFDRTtBQUNFO0FBQ0Esd0NBQVUsY0FBWTVCLElBQUksQ0FBQzRCLFVBQVUsQ0FBQyxPQUFELENBQVgsQ0FGNUIsQ0FHRTtBQUNBO0FBQ0E7QUFMRjtBQU1FLHlDQUFVLFNBTlo7QUFPRSxxQ0FBUyxFQUFDLFNBUFosQ0FRRTtBQVJGO0FBU0Usa0NBQU0sRUFBQyxRQVRULENBVUU7QUFWRjtBQVdFLCtCQUFHLEVBQUMsVUFYTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBMUJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBcENGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFmRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREYsZUFBVUYsR0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURGO0FBMEdEO0FBQ0YsU0EvSEE7QUFESDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQURGO0FBc0lELEdBdklELE1BdUlPO0FBQ0wsd0JBQ0U7QUFBQSw4QkFDRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREYsZUFFRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRkYsZUFHRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBSEYsZUFJRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQURGO0FBUUQ7QUFDRixDQWpLRDs7R0FBTW5CLEk7O0tBQUFBLEk7QUFtS1NBLG1FQUFmIiwiZmlsZSI6InN0YXRpYy93ZWJwYWNrL3BhZ2VzL29mZmVycy41NGIxNTNiOGU1OTIzOTIyMzgyMi5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbmltcG9ydCBSZWFjdCwgeyBDb21wb25lbnQsIHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IF8gZnJvbSBcImxvZGFzaFwiO1xyXG5pbXBvcnQgTW9tZW50IGZyb20gXCJtb21lbnRcIjtcclxuaW1wb3J0IExpbmsgZnJvbSBcIm5leHQvbGlua1wiO1xyXG52YXIgc2x1ZyA9IHJlcXVpcmUoJ3NsdWcnKVxyXG5cclxuY29uc3QgZ2V0UGFyc2VkRGF0ZSA9IChkYXRlKSA9PiB7XHJcbiAgcmV0dXJuIE1vbWVudChkYXRlKS5zdGFydE9mKFwiaG91clwiKS5mcm9tTm93KCk7XHJcbn07XHJcblxyXG5cclxuXHJcblxyXG5jb25zdCBDYXJkID0gKHByb3BzKSA9PiB7XHJcbiAgY29uc3QgY3VlbGlua3NPZmZlcnMgPSBwcm9wcy5jdWVsaW5rc09mZmVycyA/IHByb3BzLmN1ZWxpbmtzT2ZmZXJzIDoge307XHJcbiAgY29uc3Qgc3RvcmVfX2xvZ28gPSBwcm9wcy5zdG9yZUluZm8gPyBwcm9wcy5zdG9yZUluZm8uc2x1ZyA6IHt9O1xyXG4gIGNvbnN0IHN0b3JlX19uYW1lID0gcHJvcHMuc3RvcmVJbmZvID8gcHJvcHMuc3RvcmVJbmZvLm5hbWUgOiB7fTtcclxuICBjb25zdCBsaW1pdCA9IHByb3BzLmxpbWl0ID8gcHJvcHMubGltaXQgOiB7fTtcclxuXHJcblxyXG4gIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBjbGlja1VybCA9ICh0YXJnZXQpID0+IHtcclxuICAgICAgaWYgKHdpbmRvdyAhPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgIHdpbmRvdy5sb2NhdGlvbi5ocmVmID0gdGFyZ2V0O1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gIH0pO1xyXG5cclxuXHJcbiAgaWYgKGN1ZWxpbmtzT2ZmZXJzKSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8c2VjdGlvbj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNsZWFyZml4XCI+XHJcbiAgICAgICAgICB7Xy5tYXAoY3VlbGlua3NPZmZlcnMsICh2YWx1ZSwga2V5KSA9PiB7XHJcbiAgICAgICAgICAgIGxldCBwcm9tb2NvZGVDYXJkID0gZmFsc2U7XHJcbiAgICAgICAgICAgIGxldCBjdWVsT2ZmZXJzID0ge31cclxuICAgICAgICAgICAgY3VlbE9mZmVyc1sndGl0bGUnXSA9IHZhbHVlWyd0aXRsZSddO1xyXG4gICAgICAgICAgICBjdWVsT2ZmZXJzWydtZXJjaGFudCddID0gdmFsdWVbJ21lcmNoYW50J107XHJcbiAgICAgICAgICAgIGN1ZWxPZmZlcnNbJ2lkJ10gPSB2YWx1ZVsnaWQnXTtcclxuICAgICAgICAgICAgY3VlbE9mZmVyc1snY2F0ZWdvcmllcyddID0gdmFsdWVbJ2NhdGVnb3JpZXMnXTtcclxuICAgICAgICAgICAgY3VlbE9mZmVyc1snZGVzY3JpcHRpb24nXSA9IHZhbHVlWydkZXNjcmlwdGlvbiddO1xyXG4gICAgICAgICAgICBjdWVsT2ZmZXJzWydjb3Vwb25fY29kZSddID0gdmFsdWVbJ2NvdXBvbl9jb2RlJ107XHJcbiAgICAgICAgICAgIGN1ZWxPZmZlcnNbJ3VybCddID0gdmFsdWVbJ3VybCddO1xyXG4gICAgICAgICAgICBjdWVsT2ZmZXJzWydzdGFydF9kYXRlJ10gPSB2YWx1ZVsnc3RhcnRfZGF0ZSddO1xyXG4gICAgICAgICAgICBjdWVsT2ZmZXJzWydlbmRfZGF0ZSddID0gdmFsdWVbJ2VuZF9kYXRlJ107XHJcbiAgICAgICAgICAgIGN1ZWxPZmZlcnNbJ29mZmVyX2FkZGVkX2F0J10gPSB2YWx1ZVsnb2ZmZXJfYWRkZWRfYXQnXTtcclxuICAgICAgICAgICAgY3VlbE9mZmVyc1snaW1hZ2VfdXJsJ10gPSB2YWx1ZVsnaW1hZ2VfdXJsJ107XHJcbiAgICAgICAgICAgIGN1ZWxPZmZlcnNbJ2NhbXBhaWduX25hbWUnXSA9IHZhbHVlWydjYW1wYWlnbl9uYW1lJ107XHJcblxyXG4gICAgICAgICAgICBpZiAodmFsdWVbJ3RpdGxlJ10gIT09IFwiXCIpIHtcclxuICAgICAgICAgICAgICBpZiAoY3VlbE9mZmVyc1snY291cG9uX2NvZGUnXSAhPSBcIlwiKSB7XHJcbiAgICAgICAgICAgICAgICBwcm9tb2NvZGVDYXJkID0gdHJ1ZTtcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgIDxkaXYga2V5PXtrZXl9IGNsYXNzTmFtZT17a2V5fT5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3dcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRlYWxfX2NhcmRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZGVhbF9fZGlzY291bnRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkZWFsX19pbmZvXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbWdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3JjPXtjdWVsT2ZmZXJzWydpbWFnZV91cmwnXX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25FcnJvcj17KGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlLnRhcmdldC5vbmVycm9yID0gbnVsbDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlLnRhcmdldC5zcmMgPSBcIi9pbWctbm90Zm91bmQuanBnXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFsdD17Y3VlbE9mZmVyc1sndGl0bGUnXX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkZWFsX19kZXNjXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZGVhbF9fZGVzYy10eXBlXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZGVhbF9fZGVzYy10aXRsZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxoMz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rIGhyZWY9eycvcHJvZHVjdC8nK3NsdWcoY3VlbE9mZmVyc1sndGl0bGUnXSl9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGEtdXJsPXsnL3Byb2R1Y3QvJytzbHVnKGN1ZWxPZmZlcnNbJ3RpdGxlJ10pfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGEtcHJvbW9saW5rPXsnL3Byb2R1Y3QvJytzbHVnKGN1ZWxPZmZlcnNbJ3RpdGxlJ10pfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGEtZnVuYz1cImdldFByb21vQ29kZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZ2V0UHJvbW9Db2RlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0YXJnZXQ9XCJfYmxhbmtcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGBPZmZlcnNDb2RlLmluIC0gUHJvbW8gY29kZSBmb3IgYCArXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjdWVsT2ZmZXJzWydjYW1wYWlnbl9uYW1lJ10gK1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYCBkZWFsIGAgK1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY3VlbE9mZmVyc1sndGl0bGUnXVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWw9XCJub2ZvbGxvd1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y3VlbE9mZmVyc1snbWVyY2hhbnQnXX0gOiB7Y3VlbE9mZmVyc1sndGl0bGUnXX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9hPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRlYWxfX2Rlc2MtbWV0YVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImRlYWxfX2Rlc2MtbWV0YS1sYXN0dXNlZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGkgY2xhc3NOYW1lPVwiZmEgZmEtdXNlcnNcIj48L2k+Jm5ic3A7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Yj57TWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogMjAwKSArIDExfTwvYj4gUGVvcGxlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBVc2VkIFRvZGF5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICZuYnNwO3wmbmJzcDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJkZWFsX19kZXNjLW1ldGEtbGFzdHVzZWRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjdWVsT2ZmZXJzWydjYXRlZ29yaWVzJ119XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZGVhbF9fY3RhXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge3Byb21vY29kZUNhcmQgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TGluayBvbkNsaWNrPXtjbGlja1VybChjdWVsT2ZmZXJzWyd1cmwnXSl9IGhyZWY9eycvcHJvZHVjdC8nK3NsdWcoY3VlbE9mZmVyc1sndGl0bGUnXSl9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxhXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhLXVybD17Jy9wcm9kdWN0Lycrc2x1ZyhjdWVsT2ZmZXJzWyd0aXRsZSddKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGRhdGEtcHJvbW9jb2RlPXsnJ31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGRhdGEtc3BlY2llcz17Jyd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhLXByb21vbGluaz17Jy9wcm9kdWN0Lycrc2x1ZyhjdWVsT2ZmZXJzWyd0aXRsZSddKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGEtZnVuYz1cImdldFByb21vQ29kZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJnZXRQcm9tb0NvZGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gZGF0YS13ZWJzaXRlPXsnJ31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRhcmdldD1cIl9ibGFua1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGBPZmZlcnNDb2RlLmluIC0gUHJvbW8gY29kZSBmb3IgYCArXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGN1ZWxPZmZlcnNbJ2NhbXBhaWduX25hbWUnXSArXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGAgZGVhbCBgICtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY3VlbE9mZmVyc1sndGl0bGUnXVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVsPVwibm9mb2xsb3dcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjdWVsT2ZmZXJzWydjb3Vwb25fY29kZSddfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rIGhyZWY9eycvcHJvZHVjdC8nK3NsdWcoY3VlbE9mZmVyc1sndGl0bGUnXSl9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxhXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBocmVmPXtgL2dvdG9gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YS11cmw9eycvcHJvZHVjdC8nK3NsdWcoY3VlbE9mZmVyc1sndGl0bGUnXSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBkYXRhLXByb21vY29kZT17fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gZGF0YS1zcGVjaWVzPXt9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBkYXRhLXByb21vbGluaz17fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YS1mdW5jPVwiZ2V0RGVhbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJnZXREZWFsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGRhdGEtd2Vic2l0ZT17fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGFyZ2V0PVwiX2JsYW5rXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGdvdG9MaW5rID0ge3ZhbHVlWzExXX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlbD1cIm5vZm9sbG93XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBHZXQgRGVhbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9KX1cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9zZWN0aW9uPlxyXG4gICAgKTtcclxuICB9IGVsc2Uge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPGRpdj5cclxuICAgICAgICA8YnIgLz5cclxuICAgICAgICA8YnIgLz5cclxuICAgICAgICA8YnIgLz5cclxuICAgICAgICA8aDM+Tm8gTmV3IERlYWxzIE9yIENvdXBvbnMgRm91bmQ8L2gzPlxyXG4gICAgICA8L2Rpdj5cclxuICAgICk7XHJcbiAgfVxyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgQ2FyZDtcclxuIl0sInNvdXJjZVJvb3QiOiIifQ==