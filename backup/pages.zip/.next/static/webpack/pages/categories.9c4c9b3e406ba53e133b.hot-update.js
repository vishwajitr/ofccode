webpackHotUpdate_N_E("pages/categories",{

/***/ "./pages/categories/index.js":
/*!***********************************!*\
  !*** ./pages/categories/index.js ***!
  \***********************************/
/*! exports provided: __N_SSP, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__N_SSP", function() { return __N_SSP; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/router */ "./node_modules/next/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next */ "next");
/* harmony import */ var next__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! lodash */ "./node_modules/lodash/lodash.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _components_ProductsPageContent__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../components/ProductsPageContent */ "./pages/components/ProductsPageContent.js");


var _jsxFileName = "C:\\xampp\\htdocs\\ReactTuts\\NextJS\\ofccode\\pages\\categories\\index.js",
    _this = undefined;










var Papa = __webpack_require__(/*! papaparse */ "./node_modules/papaparse/papaparse.min.js");

var slug = __webpack_require__(/*! slug */ "./node_modules/slug/slug.js");

var FlipkartCategories = function FlipkartCategories(_ref) {
  var flipkartCategories = _ref.flipkartCategories;
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("ul", {
      children: Object.keys(flipkartCategories).map(function (value, index) {
        return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h6", {
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_4___default.a, {
              href: "categories/".concat(flipkartCategories[index]['cat__name'].replace(" ", "-")),
              as: "categories/".concat(flipkartCategories[index]['cat__name'].replace(" ", "-")),
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                target: "_blank",
                children: "".concat(flipkartCategories[index]['cat__name'])
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 23,
                columnNumber: 13
              }, _this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 22,
              columnNumber: 13
            }, _this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 21,
            columnNumber: 13
          }, _this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 20,
          columnNumber: 13
        }, _this);
      })
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 18,
      columnNumber: 7
    }, _this)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 17,
    columnNumber: 3
  }, _this);
};

_c = FlipkartCategories;

var CategoriesPage = function CategoriesPage(props) {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(FlipkartCategories, {
      flipkartCategories: props.getCategories
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 42,
      columnNumber: 7
    }, _this)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 41,
    columnNumber: 5
  }, _this);
};

_c2 = CategoriesPage;
var __N_SSP = true;
/* harmony default export */ __webpack_exports__["default"] = (CategoriesPage);

var _c, _c2;

$RefreshReg$(_c, "FlipkartCategories");
$RefreshReg$(_c2, "CategoriesPage");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvY2F0ZWdvcmllcy9pbmRleC5qcyJdLCJuYW1lcyI6WyJQYXBhIiwicmVxdWlyZSIsInNsdWciLCJGbGlwa2FydENhdGVnb3JpZXMiLCJmbGlwa2FydENhdGVnb3JpZXMiLCJPYmplY3QiLCJrZXlzIiwibWFwIiwidmFsdWUiLCJpbmRleCIsInJlcGxhY2UiLCJDYXRlZ29yaWVzUGFnZSIsInByb3BzIiwiZ2V0Q2F0ZWdvcmllcyJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBLElBQUlBLElBQUksR0FBR0MsbUJBQU8sQ0FBQyw0REFBRCxDQUFsQjs7QUFDQSxJQUFJQyxJQUFJLEdBQUdELG1CQUFPLENBQUMseUNBQUQsQ0FBbEI7O0FBR0EsSUFBTUUsa0JBQWtCLEdBQUcsU0FBckJBLGtCQUFxQixPQUE0QjtBQUFBLE1BQXpCQyxrQkFBeUIsUUFBekJBLGtCQUF5QjtBQUV2RCxzQkFFRTtBQUFBLDJCQUNJO0FBQUEsZ0JBQ0dDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZRixrQkFBWixFQUFnQ0csR0FBaEMsQ0FBb0MsVUFBQ0MsS0FBRCxFQUFRQyxLQUFSO0FBQUEsNEJBQ2pDO0FBQUEsaUNBQ0E7QUFBQSxtQ0FDQSxxRUFBQyxnREFBRDtBQUFNLGtCQUFJLHVCQUFnQkwsa0JBQWtCLENBQUNLLEtBQUQsQ0FBbEIsQ0FBMEIsV0FBMUIsRUFBdUNDLE9BQXZDLENBQStDLEdBQS9DLEVBQW9ELEdBQXBELENBQWhCLENBQVY7QUFBc0YsZ0JBQUUsdUJBQWdCTixrQkFBa0IsQ0FBQ0ssS0FBRCxDQUFsQixDQUEwQixXQUExQixFQUF1Q0MsT0FBdkMsQ0FBK0MsR0FBL0MsRUFBb0QsR0FBcEQsQ0FBaEIsQ0FBeEY7QUFBQSxxQ0FDQTtBQUFHLHNCQUFNLEVBQUMsUUFBVjtBQUFBLG9DQUNJTixrQkFBa0IsQ0FBQ0ssS0FBRCxDQUFsQixDQUEwQixXQUExQixDQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFEQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFEaUM7QUFBQSxPQUFwQztBQURIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRkY7QUFtQkMsQ0FyQkQ7O0tBQU1OLGtCOztBQTBCTixJQUFNUSxjQUFjLEdBQUcsU0FBakJBLGNBQWlCLENBQUNDLEtBQUQsRUFBVztBQUNoQyxzQkFDRTtBQUFBLDJCQUNFLHFFQUFDLGtCQUFEO0FBQW9CLHdCQUFrQixFQUFFQSxLQUFLLENBQUNDO0FBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBREY7QUFLRCxDQU5EOztNQUFNRixjOztBQW1CU0EsNkVBQWYiLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvY2F0ZWdvcmllcy45YzRjOWIzZTQwNmJhNTNlMTMzYi5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IENvbXBvbmVudCB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tIFwibmV4dC9yb3V0ZXJcIjtcclxuaW1wb3J0IEdldFNlcnZlclNpZGVQcm9wcyBmcm9tIFwibmV4dFwiO1xyXG5pbXBvcnQgTmV4dFBhZ2UgZnJvbSBcIm5leHRcIjtcclxuaW1wb3J0IExpbmsgZnJvbSBcIm5leHQvbGlua1wiO1xyXG5pbXBvcnQgYXhpb3MgZnJvbSBcImF4aW9zXCI7XHJcbmltcG9ydCBfIGZyb20gXCJsb2Rhc2hcIjtcclxuaW1wb3J0IFByb2R1Y3RzUGFnZUNvbnRlbnQgZnJvbSBcIi4uL2NvbXBvbmVudHMvUHJvZHVjdHNQYWdlQ29udGVudFwiO1xyXG52YXIgUGFwYSA9IHJlcXVpcmUoXCJwYXBhcGFyc2VcIik7XHJcbnZhciBzbHVnID0gcmVxdWlyZSgnc2x1ZycpXHJcblxyXG5cclxuY29uc3QgRmxpcGthcnRDYXRlZ29yaWVzID0gKHsgZmxpcGthcnRDYXRlZ29yaWVzIH0pID0+IHtcclxuIFxyXG5yZXR1cm4oXHJcblxyXG4gIDxkaXY+XHJcbiAgICAgIDx1bD5cclxuICAgICAgICB7T2JqZWN0LmtleXMoZmxpcGthcnRDYXRlZ29yaWVzKS5tYXAoKHZhbHVlLCBpbmRleCk9PihcclxuICAgICAgICAgICAgPGxpPiAgXHJcbiAgICAgICAgICAgIDxoNj4gIFxyXG4gICAgICAgICAgICA8TGluayBocmVmPXtgY2F0ZWdvcmllcy8ke2ZsaXBrYXJ0Q2F0ZWdvcmllc1tpbmRleF1bJ2NhdF9fbmFtZSddLnJlcGxhY2UoXCIgXCIsIFwiLVwiKX1gfSBhcz17YGNhdGVnb3JpZXMvJHtmbGlwa2FydENhdGVnb3JpZXNbaW5kZXhdWydjYXRfX25hbWUnXS5yZXBsYWNlKFwiIFwiLCBcIi1cIil9YH0+XHJcbiAgICAgICAgICAgIDxhIHRhcmdldD1cIl9ibGFua1wiPlxyXG4gICAgICAgICAgICB7YCR7ZmxpcGthcnRDYXRlZ29yaWVzW2luZGV4XVsnY2F0X19uYW1lJ119YH1cclxuICAgICAgICAgICAgPC9hPlxyXG4gICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgIDwvaDY+XHJcbiAgICAgICAgICAgIDwvbGk+XHJcbiAgICAgICkpfVxyXG4gICAgICA8L3VsPlxyXG5cclxuICA8L2Rpdj5cclxuKVxyXG59XHJcblxyXG5cclxuXHJcblxyXG5jb25zdCBDYXRlZ29yaWVzUGFnZSA9IChwcm9wcykgPT4geyAgXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXY+XHJcbiAgICAgIDxGbGlwa2FydENhdGVnb3JpZXMgZmxpcGthcnRDYXRlZ29yaWVzPXtwcm9wcy5nZXRDYXRlZ29yaWVzfSAvPlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRTZXJ2ZXJTaWRlUHJvcHMoeyBwYXJhbXMgfSkge1xyXG4gIGxldCByZXNwb25zZSA9IGF3YWl0IGZldGNoKGBodHRwczovL29mY2NvZGUtYXBpLWdpdC1tYWluLXNwb3J0eWJydWgxOTkwLnZlcmNlbC5hcHAvYXBpL2Zyb250L2RpcmVjdFBhcnRuZXJzL2ZsaXBrYXJ0X19vZmZlcnM/cT1nZXRDYXRlZ29yeUZlZWRgKTtcclxuICBsZXQgZ2V0Q2F0ZWdvcmllc0RhdGEgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XHJcblxyXG4gIHJldHVybiB7XHJcbiAgICBwcm9wczoge1xyXG4gICAgICBnZXRDYXRlZ29yaWVzOiBnZXRDYXRlZ29yaWVzRGF0YS5jYXREYXRhLFxyXG4gICAgfSxcclxuICB9O1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBDYXRlZ29yaWVzUGFnZTtcclxuIl0sInNvdXJjZVJvb3QiOiIifQ==