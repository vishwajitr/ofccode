webpackHotUpdate_N_E("pages/categories",{

/***/ "./pages/categories/index.js":
/*!***********************************!*\
  !*** ./pages/categories/index.js ***!
  \***********************************/
/*! exports provided: __N_SSP, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__N_SSP", function() { return __N_SSP; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/router */ "./node_modules/next/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next */ "next");
/* harmony import */ var next__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! lodash */ "./node_modules/lodash/lodash.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _components_ProductsPageContent__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../components/ProductsPageContent */ "./pages/components/ProductsPageContent.js");


var _jsxFileName = "C:\\xampp\\htdocs\\ReactTuts\\NextJS\\ofccode\\pages\\categories\\index.js",
    _this = undefined;










var Papa = __webpack_require__(/*! papaparse */ "./node_modules/papaparse/papaparse.min.js");

var slug = __webpack_require__(/*! slug */ "./node_modules/slug/slug.js");

var FlipkartCategories = function FlipkartCategories(_ref) {
  var flipkartCategories = _ref.flipkartCategories;
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("ul", {
      children: Object.keys(flipkartCategories).map(function (value, index) {
        return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h6", {
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_4___default.a, {
              href: "".concat(flipkartCategories[index]['cat__link']),
              as: "".concat(flipkartCategories[index]['cat__name']),
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                target: "_blank",
                children: "".concat(flipkartCategories[index]['cat__name'])
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 28,
                columnNumber: 13
              }, _this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 27,
              columnNumber: 13
            }, _this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 21,
            columnNumber: 13
          }, _this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 20,
          columnNumber: 13
        }, _this);
      })
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 18,
      columnNumber: 7
    }, _this)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 17,
    columnNumber: 3
  }, _this);
};

_c = FlipkartCategories;

var CategoriesPage = function CategoriesPage(props) {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(FlipkartCategories, {
      flipkartCategories: props.getCategories
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 47,
      columnNumber: 7
    }, _this)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 46,
    columnNumber: 5
  }, _this);
};

_c2 = CategoriesPage;
var __N_SSP = true;
/* harmony default export */ __webpack_exports__["default"] = (CategoriesPage);

var _c, _c2;

$RefreshReg$(_c, "FlipkartCategories");
$RefreshReg$(_c2, "CategoriesPage");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvY2F0ZWdvcmllcy9pbmRleC5qcyJdLCJuYW1lcyI6WyJQYXBhIiwicmVxdWlyZSIsInNsdWciLCJGbGlwa2FydENhdGVnb3JpZXMiLCJmbGlwa2FydENhdGVnb3JpZXMiLCJPYmplY3QiLCJrZXlzIiwibWFwIiwidmFsdWUiLCJpbmRleCIsIkNhdGVnb3JpZXNQYWdlIiwicHJvcHMiLCJnZXRDYXRlZ29yaWVzIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0EsSUFBSUEsSUFBSSxHQUFHQyxtQkFBTyxDQUFDLDREQUFELENBQWxCOztBQUNBLElBQUlDLElBQUksR0FBR0QsbUJBQU8sQ0FBQyx5Q0FBRCxDQUFsQjs7QUFHQSxJQUFNRSxrQkFBa0IsR0FBRyxTQUFyQkEsa0JBQXFCLE9BQTRCO0FBQUEsTUFBekJDLGtCQUF5QixRQUF6QkEsa0JBQXlCO0FBRXZELHNCQUVFO0FBQUEsMkJBQ0k7QUFBQSxnQkFDR0MsTUFBTSxDQUFDQyxJQUFQLENBQVlGLGtCQUFaLEVBQWdDRyxHQUFoQyxDQUFvQyxVQUFDQyxLQUFELEVBQVFDLEtBQVI7QUFBQSw0QkFDakM7QUFBQSxpQ0FDQTtBQUFBLG1DQU1BLHFFQUFDLGdEQUFEO0FBQU0sa0JBQUksWUFBS0wsa0JBQWtCLENBQUNLLEtBQUQsQ0FBbEIsQ0FBMEIsV0FBMUIsQ0FBTCxDQUFWO0FBQXlELGdCQUFFLFlBQUtMLGtCQUFrQixDQUFDSyxLQUFELENBQWxCLENBQTBCLFdBQTFCLENBQUwsQ0FBM0Q7QUFBQSxxQ0FDQTtBQUFHLHNCQUFNLEVBQUMsUUFBVjtBQUFBLG9DQUNJTCxrQkFBa0IsQ0FBQ0ssS0FBRCxDQUFsQixDQUEwQixXQUExQixDQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFOQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFEaUM7QUFBQSxPQUFwQztBQURIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRkY7QUF3QkMsQ0ExQkQ7O0tBQU1OLGtCOztBQStCTixJQUFNTyxjQUFjLEdBQUcsU0FBakJBLGNBQWlCLENBQUNDLEtBQUQsRUFBVztBQUNoQyxzQkFDRTtBQUFBLDJCQUNFLHFFQUFDLGtCQUFEO0FBQW9CLHdCQUFrQixFQUFFQSxLQUFLLENBQUNDO0FBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBREY7QUFLRCxDQU5EOztNQUFNRixjOztBQW1CU0EsNkVBQWYiLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvY2F0ZWdvcmllcy5jYWI3MWI1ZTE1NzI1NmZmNzZkYi5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IENvbXBvbmVudCB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tIFwibmV4dC9yb3V0ZXJcIjtcclxuaW1wb3J0IEdldFNlcnZlclNpZGVQcm9wcyBmcm9tIFwibmV4dFwiO1xyXG5pbXBvcnQgTmV4dFBhZ2UgZnJvbSBcIm5leHRcIjtcclxuaW1wb3J0IExpbmsgZnJvbSBcIm5leHQvbGlua1wiO1xyXG5pbXBvcnQgYXhpb3MgZnJvbSBcImF4aW9zXCI7XHJcbmltcG9ydCBfIGZyb20gXCJsb2Rhc2hcIjtcclxuaW1wb3J0IFByb2R1Y3RzUGFnZUNvbnRlbnQgZnJvbSBcIi4uL2NvbXBvbmVudHMvUHJvZHVjdHNQYWdlQ29udGVudFwiO1xyXG52YXIgUGFwYSA9IHJlcXVpcmUoXCJwYXBhcGFyc2VcIik7XHJcbnZhciBzbHVnID0gcmVxdWlyZSgnc2x1ZycpXHJcblxyXG5cclxuY29uc3QgRmxpcGthcnRDYXRlZ29yaWVzID0gKHsgZmxpcGthcnRDYXRlZ29yaWVzIH0pID0+IHtcclxuIFxyXG5yZXR1cm4oXHJcblxyXG4gIDxkaXY+XHJcbiAgICAgIDx1bD5cclxuICAgICAgICB7T2JqZWN0LmtleXMoZmxpcGthcnRDYXRlZ29yaWVzKS5tYXAoKHZhbHVlLCBpbmRleCk9PihcclxuICAgICAgICAgICAgPGxpPiAgXHJcbiAgICAgICAgICAgIDxoNj4gIFxyXG4gICAgICAgICAgICB7LyogPExpbmsgaHJlZj17YGNhdGVnb3JpZXMvJHtmbGlwa2FydENhdGVnb3JpZXNbaW5kZXhdWydjYXRfX25hbWUnXS5yZXBsYWNlKFwiIFwiLCBcIi1cIil9YH0gYXM9e2BjYXRlZ29yaWVzLyR7ZmxpcGthcnRDYXRlZ29yaWVzW2luZGV4XVsnY2F0X19uYW1lJ10ucmVwbGFjZShcIiBcIiwgXCItXCIpfWB9PlxyXG4gICAgICAgICAgICA8YSB0YXJnZXQ9XCJfYmxhbmtcIj5cclxuICAgICAgICAgICAge2Ake2ZsaXBrYXJ0Q2F0ZWdvcmllc1tpbmRleF1bJ2NhdF9fbmFtZSddfWB9XHJcbiAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgPC9MaW5rPiAqL31cclxuICAgICAgICAgICAgPExpbmsgaHJlZj17YCR7ZmxpcGthcnRDYXRlZ29yaWVzW2luZGV4XVsnY2F0X19saW5rJ119YH0gYXM9e2Ake2ZsaXBrYXJ0Q2F0ZWdvcmllc1tpbmRleF1bJ2NhdF9fbmFtZSddfWB9PlxyXG4gICAgICAgICAgICA8YSB0YXJnZXQ9XCJfYmxhbmtcIj5cclxuICAgICAgICAgICAge2Ake2ZsaXBrYXJ0Q2F0ZWdvcmllc1tpbmRleF1bJ2NhdF9fbmFtZSddfWB9XHJcbiAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICA8L2g2PlxyXG4gICAgICAgICAgICA8L2xpPlxyXG4gICAgICApKX1cclxuICAgICAgPC91bD5cclxuXHJcbiAgPC9kaXY+XHJcbilcclxufVxyXG5cclxuXHJcblxyXG5cclxuY29uc3QgQ2F0ZWdvcmllc1BhZ2UgPSAocHJvcHMpID0+IHsgIFxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2PlxyXG4gICAgICA8RmxpcGthcnRDYXRlZ29yaWVzIGZsaXBrYXJ0Q2F0ZWdvcmllcz17cHJvcHMuZ2V0Q2F0ZWdvcmllc30gLz5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0U2VydmVyU2lkZVByb3BzKHsgcGFyYW1zIH0pIHtcclxuICBsZXQgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChgaHR0cHM6Ly9vZmNjb2RlLWFwaS1naXQtbWFpbi1zcG9ydHlicnVoMTk5MC52ZXJjZWwuYXBwL2FwaS9mcm9udC9kaXJlY3RQYXJ0bmVycy9mbGlwa2FydF9fb2ZmZXJzP3E9Z2V0Q2F0ZWdvcnlGZWVkYCk7XHJcbiAgbGV0IGdldENhdGVnb3JpZXNEYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xyXG5cclxuICByZXR1cm4ge1xyXG4gICAgcHJvcHM6IHtcclxuICAgICAgZ2V0Q2F0ZWdvcmllczogZ2V0Q2F0ZWdvcmllc0RhdGEuY2F0RGF0YSxcclxuICAgIH0sXHJcbiAgfTtcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgQ2F0ZWdvcmllc1BhZ2U7XHJcbiJdLCJzb3VyY2VSb290IjoiIn0=