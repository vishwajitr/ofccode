webpackHotUpdate_N_E("pages/store/[slug]",{

/***/ "./pages/store/[slug]/index.js":
/*!*************************************!*\
  !*** ./pages/store/[slug]/index.js ***!
  \*************************************/
/*! exports provided: __N_SSP, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__N_SSP", function() { return __N_SSP; });
/* harmony import */ var C_xampp_htdocs_ReactTuts_NextJS_ofccode_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/router */ "./node_modules/next/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! next */ "next");
/* harmony import */ var next__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! lodash */ "./node_modules/lodash/lodash.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _components_Content__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../components/Content */ "./pages/components/Content.js");
/* harmony import */ var _components_OffersPageContent__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../components/OffersPageContent */ "./pages/components/OffersPageContent.js");



var _jsxFileName = "C:\\xampp\\htdocs\\ReactTuts\\NextJS\\ofccode\\pages\\store\\[slug]\\index.js",
    _this = undefined;

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { Object(C_xampp_htdocs_ReactTuts_NextJS_ofccode_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }










var getParsedDate = function getParsedDate() {
  var d = new Date();
  var month = new Array();
  month[0] = "January";
  month[1] = "February";
  month[2] = "March";
  month[3] = "April";
  month[4] = "May";
  month[5] = "June";
  month[6] = "July";
  month[7] = "August";
  month[8] = "September";
  month[9] = "October";
  month[10] = "November";
  month[11] = "December";
  return month[d.getMonth()];
};

var StorePage = function StorePage(props) {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("div", {
    children: props.cuelinksOffers.length > 0 ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("div", {
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(_components_OffersPageContent__WEBPACK_IMPORTED_MODULE_8__["default"], _objectSpread(_objectSpread({}, props), {}, {
        headerTag1: "Trending Offers from Top Stores ",
        description: 'We are please to provide some trending offers from other stores if you have habbit of saving while doing online shopping this is best place for you'
      }), void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 51,
        columnNumber: 10
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 50,
      columnNumber: 8
    }, _this) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("div", {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 59,
      columnNumber: 10
    }, _this)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 32,
    columnNumber: 5
  }, _this);
};

_c = StorePage;
var __N_SSP = true;
/* harmony default export */ __webpack_exports__["default"] = (StorePage);

var _c;

$RefreshReg$(_c, "StorePage");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvc3RvcmUvW3NsdWddL2luZGV4LmpzIl0sIm5hbWVzIjpbImdldFBhcnNlZERhdGUiLCJkIiwiRGF0ZSIsIm1vbnRoIiwiQXJyYXkiLCJnZXRNb250aCIsIlN0b3JlUGFnZSIsInByb3BzIiwiY3VlbGlua3NPZmZlcnMiLCJsZW5ndGgiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBOztBQUdBLElBQU1BLGFBQWEsR0FBRyxTQUFoQkEsYUFBZ0IsR0FBTTtBQUMxQixNQUFJQyxDQUFDLEdBQUcsSUFBSUMsSUFBSixFQUFSO0FBQ0EsTUFBSUMsS0FBSyxHQUFHLElBQUlDLEtBQUosRUFBWjtBQUNBRCxPQUFLLENBQUMsQ0FBRCxDQUFMLEdBQVcsU0FBWDtBQUNBQSxPQUFLLENBQUMsQ0FBRCxDQUFMLEdBQVcsVUFBWDtBQUNBQSxPQUFLLENBQUMsQ0FBRCxDQUFMLEdBQVcsT0FBWDtBQUNBQSxPQUFLLENBQUMsQ0FBRCxDQUFMLEdBQVcsT0FBWDtBQUNBQSxPQUFLLENBQUMsQ0FBRCxDQUFMLEdBQVcsS0FBWDtBQUNBQSxPQUFLLENBQUMsQ0FBRCxDQUFMLEdBQVcsTUFBWDtBQUNBQSxPQUFLLENBQUMsQ0FBRCxDQUFMLEdBQVcsTUFBWDtBQUNBQSxPQUFLLENBQUMsQ0FBRCxDQUFMLEdBQVcsUUFBWDtBQUNBQSxPQUFLLENBQUMsQ0FBRCxDQUFMLEdBQVcsV0FBWDtBQUNBQSxPQUFLLENBQUMsQ0FBRCxDQUFMLEdBQVcsU0FBWDtBQUNBQSxPQUFLLENBQUMsRUFBRCxDQUFMLEdBQVksVUFBWjtBQUNBQSxPQUFLLENBQUMsRUFBRCxDQUFMLEdBQVksVUFBWjtBQUNBLFNBQU9BLEtBQUssQ0FBQ0YsQ0FBQyxDQUFDSSxRQUFGLEVBQUQsQ0FBWjtBQUNELENBaEJEOztBQWtCQSxJQUFNQyxTQUFTLEdBQUcsU0FBWkEsU0FBWSxDQUFDQyxLQUFELEVBQVc7QUFDM0Isc0JBQ0U7QUFBQSxjQWlCS0EsS0FBSyxDQUFDQyxjQUFOLENBQXFCQyxNQUFyQixHQUE4QixDQUEvQixnQkFDRDtBQUFBLDZCQUNFLHFFQUFDLHFFQUFELGtDQUNLRixLQURMO0FBRUMsa0JBQVUsRUFDUixrQ0FISDtBQUtDLG1CQUFXLEVBQUU7QUFMZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQURDLGdCQVVDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUEzQkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQURGO0FBZ0NELENBakNEOztLQUFNRCxTOztBQXVFU0Esd0VBQWYiLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvc3RvcmUvW3NsdWddLjkyYzIzOGUzMTBhYzE0MDM1MjlhLmhvdC11cGRhdGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgQ29tcG9uZW50IH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gXCJuZXh0L3JvdXRlclwiO1xyXG5pbXBvcnQgR2V0U2VydmVyU2lkZVByb3BzIGZyb20gXCJuZXh0XCI7XHJcbmltcG9ydCBOZXh0UGFnZSBmcm9tIFwibmV4dFwiO1xyXG5pbXBvcnQgTGluayBmcm9tIFwibmV4dC9saW5rXCI7XHJcbmltcG9ydCBheGlvcyBmcm9tIFwiYXhpb3NcIjtcclxuaW1wb3J0IF8gZnJvbSBcImxvZGFzaFwiO1xyXG5pbXBvcnQgQ29udGVudCBmcm9tIFwiLi4vLi4vY29tcG9uZW50cy9Db250ZW50XCI7XHJcbmltcG9ydCBPZmZlcnNQYWdlQ29udGVudCBmcm9tICcuLi8uLi9jb21wb25lbnRzL09mZmVyc1BhZ2VDb250ZW50J1xyXG52YXIgUGFwYSA9IHJlcXVpcmUoXCJwYXBhcGFyc2VcIik7XHJcblxyXG5jb25zdCBnZXRQYXJzZWREYXRlID0gKCkgPT4ge1xyXG4gIHZhciBkID0gbmV3IERhdGUoKTtcclxuICB2YXIgbW9udGggPSBuZXcgQXJyYXkoKTtcclxuICBtb250aFswXSA9IFwiSmFudWFyeVwiO1xyXG4gIG1vbnRoWzFdID0gXCJGZWJydWFyeVwiO1xyXG4gIG1vbnRoWzJdID0gXCJNYXJjaFwiO1xyXG4gIG1vbnRoWzNdID0gXCJBcHJpbFwiO1xyXG4gIG1vbnRoWzRdID0gXCJNYXlcIjtcclxuICBtb250aFs1XSA9IFwiSnVuZVwiO1xyXG4gIG1vbnRoWzZdID0gXCJKdWx5XCI7XHJcbiAgbW9udGhbN10gPSBcIkF1Z3VzdFwiO1xyXG4gIG1vbnRoWzhdID0gXCJTZXB0ZW1iZXJcIjtcclxuICBtb250aFs5XSA9IFwiT2N0b2JlclwiO1xyXG4gIG1vbnRoWzEwXSA9IFwiTm92ZW1iZXJcIjtcclxuICBtb250aFsxMV0gPSBcIkRlY2VtYmVyXCI7XHJcbiAgcmV0dXJuIG1vbnRoW2QuZ2V0TW9udGgoKV07XHJcbn07XHJcblxyXG5jb25zdCBTdG9yZVBhZ2UgPSAocHJvcHMpID0+IHsgIFxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2PlxyXG4gICAgICB7LyogPENvbnRlbnRcclxuICAgICAgICB7Li4ucHJvcHN9XHJcbiAgICAgICAgaGVhZGVyVGFnMT17XHJcbiAgICAgICAgICBwcm9wcy5zdG9yZUluZm8uZm9ybWF0dGVkX25hbWUgK1xyXG4gICAgICAgICAgXCIgQ291cG9ucyBBbmQgRGlzY291bnQgQ29kZXMgRm9yIFwiICtcclxuICAgICAgICAgIGdldFBhcnNlZERhdGUoKSArXHJcbiAgICAgICAgICBcIiAyMDIxXCJcclxuICAgICAgICB9XHJcbiAgICAgICAgaGVhZGVyVGFnMj17XHJcbiAgICAgICAgICBcIkxhdGVzdCBcIiArXHJcbiAgICAgICAgICBwcm9wcy5zdG9yZUluZm8uZm9ybWF0dGVkX25hbWUgK1xyXG4gICAgICAgICAgXCIgQ291cG9uIENvZGVzLCBEaXNjb3VudCBPZmZlcnMgJiBQcm9tb3Rpb25hbCBEZWFsc1wiXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGRlc2NyaXB0aW9uPXtwcm9wcy5zdG9yZUluZm8ubWV0YUluZm9fX2Rlc2N9XHJcbiAgICAgIC8+ICovfVxyXG4gICAgICAgIFxyXG4gICAgICAgeyhwcm9wcy5jdWVsaW5rc09mZmVycy5sZW5ndGggPiAwICkgPyBcclxuICAgICAgIDxkaXY+XHJcbiAgICAgICAgIDxPZmZlcnNQYWdlQ29udGVudFxyXG4gICAgICAgICAgey4uLnByb3BzfVxyXG4gICAgICAgICAgaGVhZGVyVGFnMT17XHJcbiAgICAgICAgICAgIFwiVHJlbmRpbmcgT2ZmZXJzIGZyb20gVG9wIFN0b3JlcyBcIlxyXG4gICAgICAgICAgfSAgICAgICBcclxuICAgICAgICAgIGRlc2NyaXB0aW9uPXsnV2UgYXJlIHBsZWFzZSB0byBwcm92aWRlIHNvbWUgdHJlbmRpbmcgb2ZmZXJzIGZyb20gb3RoZXIgc3RvcmVzIGlmIHlvdSBoYXZlIGhhYmJpdCBvZiBzYXZpbmcgd2hpbGUgZG9pbmcgb25saW5lIHNob3BwaW5nIHRoaXMgaXMgYmVzdCBwbGFjZSBmb3IgeW91J31cclxuICAgICAgICAvPlxyXG4gICAgICAgPC9kaXY+XHJcbiAgICAgICA6IDxkaXY+PC9kaXY+fSBcclxuICAgICAgIFxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRTZXJ2ZXJTaWRlUHJvcHMoeyBwYXJhbXMgfSkge1xyXG4gIGNvbnN0IHN0b3JlU2x1ZyA9IHBhcmFtcy5zbHVnO1xyXG4gIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goXHJcbiAgICBgaHR0cHM6Ly9vZmNjb2RlLWFwaS1naXQtbWFpbi1zcG9ydHlicnVoMTk5MC52ZXJjZWwuYXBwL2FwaS9mcm9udC9zZWFyY2gvc3RvcmVfX2J5X19zbHVnP3E9JHtzdG9yZVNsdWd9YFxyXG4gICk7XHJcbiAgY29uc3QgZ2V0U3RvcmVJZFJlcyA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcclxuICAvLyBjb25zb2xlLmxvZyhnZXRTdG9yZUlkUmVzKVxyXG4gIGNvbnN0IHN0b3JlSWQgPSBnZXRTdG9yZUlkUmVzLmFmZkluZm9fX1N0b3JlSWQ7XHJcbiAgY29uc3QgZGF0YVVybCA9XHJcbiAgICBcImh0dHBzOi8vZXhwb3J0LmFkbWl0YWQuY29tL2VuL3dlYm1hc3Rlci93ZWJzaXRlcy8xNzc3MDUyL2NvdXBvbnMvZXhwb3J0Lz93ZWJzaXRlPTE3NzcwNTImYWR2Y2FtcGFpZ25zPVwiICtcclxuICAgIHN0b3JlSWQgK1xyXG4gICAgXCImcmVnaW9uPTAwJmNvZGU9ZXlxNDh3NjJiaiZ1c2VyPXZpc2h3YWppdDgyJmZvcm1hdD1jc3Ymdj00XCI7XHJcbiAgY29uc3QgcmVzID0gYXdhaXQgYXhpb3MuZ2V0KGRhdGFVcmwpO1xyXG4gIGNvbnN0IGRhdGEgPSBQYXBhLnBhcnNlKHJlcy5kYXRhKTtcclxuXHJcblxyXG4gIC8vIGxldCBjbGlua3NSZXMgPSBhd2FpdCBmZXRjaChcclxuICAvLyAgIGBodHRwczovL29mY2NvZGUtYXBpLWdpdC1tYWluLXNwb3J0eWJydWgxOTkwLnZlcmNlbC5hcHAvYXBpL2Zyb250L2N1ZWxzL29mZmVyc2BcclxuICAvLyApO1xyXG4gIC8vIGxldCBjdWVsaW5rc09mZmVycyA9IGF3YWl0IGNsaW5rc1Jlcy5qc29uKCk7ICBcclxuXHJcbiAgbGV0IGNsaW5rc1JlcyA9IGF3YWl0IGZldGNoKFxyXG4gICAgYGh0dHA6Ly9sb2NhbGhvc3Q6MzAwMi9hcGkvZnJvbnQvc2VhcmNoL29mZmVyc19fYnlfX3F1ZXJ5P3E9JHtzdG9yZVNsdWd9YFxyXG4gICk7XHJcbiAgbGV0IGN1ZWxpbmtzT2ZmZXJzID0gYXdhaXQgY2xpbmtzUmVzLmpzb24oKTsgIFxyXG4gICAgXHJcblxyXG4gIHJldHVybiB7XHJcbiAgICBwcm9wczoge1xyXG4gICAgICBzdG9yZUluZm86IGdldFN0b3JlSWRSZXMsXHJcbiAgICAgIGNvdXBvbnNEYXRhMTogZGF0YSxcclxuICAgICAgY3VlbGlua3NPZmZlcnM6IGN1ZWxpbmtzT2ZmZXJzLnJlc3VsdHMsXHJcbiAgICB9LFxyXG4gIH07XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IFN0b3JlUGFnZTtcclxuIl0sInNvdXJjZVJvb3QiOiIifQ==