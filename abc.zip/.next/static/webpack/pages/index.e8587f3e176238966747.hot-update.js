webpackHotUpdate_N_E("pages/index",{

/***/ "./pages/index.js":
/*!************************!*\
  !*** ./pages/index.js ***!
  \************************/
/*! exports provided: __N_SSP, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__N_SSP", function() { return __N_SSP; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _search_searchBox__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./search/searchBox */ "./pages/search/searchBox.js");
/* harmony import */ var _components_Store_topStores__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./components/Store/topStores */ "./pages/components/Store/topStores.js");
/* harmony import */ var _components_OffersPageContent__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./components/OffersPageContent */ "./pages/components/OffersPageContent.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-lazy-load-image-component */ "./node_modules/react-lazy-load-image-component/build/index.js");
/* harmony import */ var react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_lazy_load_image_component_src_effects_blur_css__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react-lazy-load-image-component/src/effects/blur.css */ "./node_modules/react-lazy-load-image-component/src/effects/blur.css");
/* harmony import */ var react_lazy_load_image_component_src_effects_blur_css__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_lazy_load_image_component_src_effects_blur_css__WEBPACK_IMPORTED_MODULE_7__);


var _jsxFileName = "C:\\xampp\\htdocs\\ReactTuts\\NextJS\\ofccode\\pages\\index.js",
    _this = undefined;









var slug = __webpack_require__(/*! slug */ "./node_modules/slug/slug.js");

var convertToSlug = function convertToSlug(Text) {
  return Text.toLowerCase().replace(/ /g, '-').replace(/[^\w-]+/g, '');
};

var FlipkartOffers = function FlipkartOffers(_ref) {
  var flipkartOffers = _ref.flipkartOffers;

  // console.log(flipkartOffers)
  for (var i = 0; i < flipkartOffers.length; i++) {
    var LiElements = flipkartOffers.map(function (offer, index) {
      return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
        className: "offerCard-Col",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "offerCard offerCard-small",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_5___default.a, {
            href: "".concat(offer.url + "&affor=flipkart&affid=vishwajit8"),
            as: "".concat(offer.url + "&affor=flipkart&affid=vishwajit8"),
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
              target: "_blank",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
                src: "".concat(offer.image_url[0].url),
                onError: function onError(e) {
                  e.target.onerror = null;
                  e.target.src = "/img-notfound.jpg";
                }
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 27,
                columnNumber: 15
              }, _this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 26,
              columnNumber: 13
            }, _this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 25,
            columnNumber: 11
          }, _this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 24,
          columnNumber: 9
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h5", {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_5___default.a, {
            href: "".concat(offer.url + "&afffor=flipkart&affid=vishwajit8"),
            as: "".concat(offer.url + "&afffor=flipkart&affid=vishwajit8"),
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
              target: "_blank",
              children: offer.title
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 40,
              columnNumber: 13
            }, _this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 39,
            columnNumber: 11
          }, _this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 38,
          columnNumber: 9
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
          children: [" ", offer.name]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 45,
          columnNumber: 9
        }, _this)]
      }, index, true, {
        fileName: _jsxFileName,
        lineNumber: 23,
        columnNumber: 7
      }, _this);
    });
    return LiElements;
  }
};

_c = FlipkartOffers;

var Index = function Index(props) {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: "container",
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "search__wrapper",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_search_searchBox__WEBPACK_IMPORTED_MODULE_2__["default"], {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 58,
        columnNumber: 9
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 57,
      columnNumber: 7
    }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "topStores__wrapper",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h3", {
        children: "Top Stores"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 64,
        columnNumber: 9
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("ul", {
        className: "topStores__Ul",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_Store_topStores__WEBPACK_IMPORTED_MODULE_3__["default"], {
          storeInfo: props.storeInfo
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 66,
          columnNumber: 11
        }, _this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 65,
        columnNumber: 9
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 68,
        columnNumber: 9
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 69,
        columnNumber: 9
      }, _this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 63,
      columnNumber: 7
    }, _this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 56,
    columnNumber: 5
  }, _this);
};

_c2 = Index;
var __N_SSP = true;
/* harmony default export */ __webpack_exports__["default"] = (Index);

var _c, _c2;

$RefreshReg$(_c, "FlipkartOffers");
$RefreshReg$(_c2, "Index");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvaW5kZXguanMiXSwibmFtZXMiOlsic2x1ZyIsInJlcXVpcmUiLCJjb252ZXJ0VG9TbHVnIiwiVGV4dCIsInRvTG93ZXJDYXNlIiwicmVwbGFjZSIsIkZsaXBrYXJ0T2ZmZXJzIiwiZmxpcGthcnRPZmZlcnMiLCJpIiwibGVuZ3RoIiwiTGlFbGVtZW50cyIsIm1hcCIsIm9mZmVyIiwiaW5kZXgiLCJ1cmwiLCJpbWFnZV91cmwiLCJlIiwidGFyZ2V0Iiwib25lcnJvciIsInNyYyIsInRpdGxlIiwibmFtZSIsIkluZGV4IiwicHJvcHMiLCJzdG9yZUluZm8iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBLElBQUlBLElBQUksR0FBR0MsbUJBQU8sQ0FBQyx5Q0FBRCxDQUFsQjs7QUFFQSxJQUFNQyxhQUFhLEdBQUcsU0FBaEJBLGFBQWdCLENBQUNDLElBQUQsRUFBUztBQUMzQixTQUFPQSxJQUFJLENBQ05DLFdBREUsR0FFRkMsT0FGRSxDQUVNLElBRk4sRUFFVyxHQUZYLEVBR0ZBLE9BSEUsQ0FHTSxVQUhOLEVBR2lCLEVBSGpCLENBQVA7QUFLSCxDQU5EOztBQVFBLElBQU1DLGNBQWMsR0FBRyxTQUFqQkEsY0FBaUIsT0FBd0I7QUFBQSxNQUFyQkMsY0FBcUIsUUFBckJBLGNBQXFCOztBQUM3QztBQUNBLE9BQUssSUFBSUMsQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBR0QsY0FBYyxDQUFDRSxNQUFuQyxFQUEyQ0QsQ0FBQyxFQUE1QyxFQUFpRDtBQUMvQyxRQUFNRSxVQUFVLEdBQUdILGNBQWMsQ0FBQ0ksR0FBZixDQUFtQixVQUFDQyxLQUFELEVBQVFDLEtBQVI7QUFBQSwwQkFDcEM7QUFBSSxpQkFBUyxFQUFDLGVBQWQ7QUFBQSxnQ0FDRTtBQUFLLG1CQUFTLEVBQUMsMkJBQWY7QUFBQSxpQ0FDRSxxRUFBQyxnREFBRDtBQUFNLGdCQUFJLFlBQUtELEtBQUssQ0FBQ0UsR0FBTixHQUFZLGtDQUFqQixDQUFWO0FBQWtFLGNBQUUsWUFBS0YsS0FBSyxDQUFDRSxHQUFOLEdBQWEsa0NBQWxCLENBQXBFO0FBQUEsbUNBQ0U7QUFBRyxvQkFBTSxFQUFDLFFBQVY7QUFBQSxxQ0FDRTtBQUNFLG1CQUFHLFlBQUtGLEtBQUssQ0FBQ0csU0FBTixDQUFnQixDQUFoQixFQUFtQkQsR0FBeEIsQ0FETDtBQUVFLHVCQUFPLEVBQUUsaUJBQUNFLENBQUQsRUFBTztBQUNkQSxtQkFBQyxDQUFDQyxNQUFGLENBQVNDLE9BQVQsR0FBbUIsSUFBbkI7QUFDQUYsbUJBQUMsQ0FBQ0MsTUFBRixDQUFTRSxHQUFULEdBQWUsbUJBQWY7QUFDRDtBQUxIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREYsZUFlRTtBQUFBLGlDQUNFLHFFQUFDLGdEQUFEO0FBQU0sZ0JBQUksWUFBS1AsS0FBSyxDQUFDRSxHQUFOLEdBQWEsbUNBQWxCLENBQVY7QUFBb0UsY0FBRSxZQUFLRixLQUFLLENBQUNFLEdBQU4sR0FBYSxtQ0FBbEIsQ0FBdEU7QUFBQSxtQ0FDRTtBQUFHLG9CQUFNLEVBQUMsUUFBVjtBQUFBLHdCQUNHRixLQUFLLENBQUNRO0FBRFQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWZGLGVBc0JFO0FBQUEsMEJBQUtSLEtBQUssQ0FBQ1MsSUFBWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBdEJGO0FBQUEsU0FBbUNSLEtBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFEb0M7QUFBQSxLQUFuQixDQUFuQjtBQTBCQSxXQUFPSCxVQUFQO0FBQ0Q7QUFDRixDQS9CRDs7S0FBTUosYzs7QUFtQ04sSUFBTWdCLEtBQUssR0FBRyxTQUFSQSxLQUFRLENBQUNDLEtBQUQsRUFBVztBQUN2QixzQkFDRTtBQUFLLGFBQVMsRUFBQyxXQUFmO0FBQUEsNEJBQ0U7QUFBSyxlQUFTLEVBQUMsaUJBQWY7QUFBQSw2QkFDRSxxRUFBQyx5REFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQURGLGVBT0U7QUFBSyxlQUFTLEVBQUMsb0JBQWY7QUFBQSw4QkFDRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGLGVBRUU7QUFBSSxpQkFBUyxFQUFDLGVBQWQ7QUFBQSwrQkFDRSxxRUFBQyxtRUFBRDtBQUFXLG1CQUFTLEVBQUVBLEtBQUssQ0FBQ0M7QUFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFGRixlQUtFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFMRixlQU1FO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FERjtBQWdDRCxDQWpDRDs7TUFBTUYsSzs7QUFxRlNBLG9FQUFmIiwiZmlsZSI6InN0YXRpYy93ZWJwYWNrL3BhZ2VzL2luZGV4LmU4NTg3ZjNlMTc2MjM4OTY2NzQ3LmhvdC11cGRhdGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgYXhpb3MgZnJvbSBcImF4aW9zXCI7XHJcbmltcG9ydCBfIGZyb20gXCJsb2Rhc2hcIjtcclxuaW1wb3J0IFNlYXJjaCBmcm9tIFwiLi9zZWFyY2gvc2VhcmNoQm94XCI7XHJcbmltcG9ydCBUb3BTdG9yZXMgZnJvbSBcIi4vY29tcG9uZW50cy9TdG9yZS90b3BTdG9yZXNcIjtcclxuaW1wb3J0IE9mZmVyc1BhZ2VDb250ZW50IGZyb20gXCIuL2NvbXBvbmVudHMvT2ZmZXJzUGFnZUNvbnRlbnRcIjtcclxuaW1wb3J0IExpbmsgZnJvbSBcIm5leHQvbGlua1wiO1xyXG5pbXBvcnQgeyBMYXp5TG9hZEltYWdlIH0gZnJvbSAncmVhY3QtbGF6eS1sb2FkLWltYWdlLWNvbXBvbmVudCc7XHJcbmltcG9ydCAncmVhY3QtbGF6eS1sb2FkLWltYWdlLWNvbXBvbmVudC9zcmMvZWZmZWN0cy9ibHVyLmNzcyc7XHJcbnZhciBzbHVnID0gcmVxdWlyZSgnc2x1ZycpXHJcblxyXG5jb25zdCBjb252ZXJ0VG9TbHVnID0gKFRleHQpID0+e1xyXG4gICAgcmV0dXJuIFRleHRcclxuICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgIC5yZXBsYWNlKC8gL2csJy0nKVxyXG4gICAgICAgIC5yZXBsYWNlKC9bXlxcdy1dKy9nLCcnKVxyXG4gICAgICAgIDtcclxufVxyXG5cclxuY29uc3QgRmxpcGthcnRPZmZlcnMgPSAoeyBmbGlwa2FydE9mZmVycyB9KSA9PiB7XHJcbiAgLy8gY29uc29sZS5sb2coZmxpcGthcnRPZmZlcnMpXHJcbiAgZm9yICh2YXIgaSA9IDA7IGkgPCBmbGlwa2FydE9mZmVycy5sZW5ndGg7IGkrKyApIHtcclxuICAgIGNvbnN0IExpRWxlbWVudHMgPSBmbGlwa2FydE9mZmVycy5tYXAoKG9mZmVyLCBpbmRleCkgPT4gKFxyXG4gICAgICA8bGkgY2xhc3NOYW1lPVwib2ZmZXJDYXJkLUNvbFwiIGtleT17aW5kZXh9PlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwib2ZmZXJDYXJkIG9mZmVyQ2FyZC1zbWFsbFwiPlxyXG4gICAgICAgICAgPExpbmsgaHJlZj17YCR7b2ZmZXIudXJsICsgXCImYWZmb3I9ZmxpcGthcnQmYWZmaWQ9dmlzaHdhaml0OFwiIH1gfSBhcz17YCR7b2ZmZXIudXJsICArIFwiJmFmZm9yPWZsaXBrYXJ0JmFmZmlkPXZpc2h3YWppdDhcIiB9YH0+XHJcbiAgICAgICAgICAgIDxhIHRhcmdldD1cIl9ibGFua1wiPlxyXG4gICAgICAgICAgICAgIDxpbWdcclxuICAgICAgICAgICAgICAgIHNyYz17YCR7b2ZmZXIuaW1hZ2VfdXJsWzBdLnVybH1gfVxyXG4gICAgICAgICAgICAgICAgb25FcnJvcj17KGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgZS50YXJnZXQub25lcnJvciA9IG51bGw7XHJcbiAgICAgICAgICAgICAgICAgIGUudGFyZ2V0LnNyYyA9IFwiL2ltZy1ub3Rmb3VuZC5qcGdcIjtcclxuICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9hPlxyXG4gICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIFxyXG4gICAgICAgIDxoNT5cclxuICAgICAgICAgIDxMaW5rIGhyZWY9e2Ake29mZmVyLnVybCAgKyBcIiZhZmZmb3I9ZmxpcGthcnQmYWZmaWQ9dmlzaHdhaml0OFwiIH1gfSBhcz17YCR7b2ZmZXIudXJsICArIFwiJmFmZmZvcj1mbGlwa2FydCZhZmZpZD12aXNod2FqaXQ4XCIgfWB9PlxyXG4gICAgICAgICAgICA8YSB0YXJnZXQ9XCJfYmxhbmtcIj5cclxuICAgICAgICAgICAgICB7b2ZmZXIudGl0bGV9XHJcbiAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICA8L2g1PlxyXG4gICAgICAgIDxwPiB7b2ZmZXIubmFtZX08L3A+XHJcbiAgICAgIDwvbGk+XHJcbiAgICApKTtcclxuICAgIHJldHVybiBMaUVsZW1lbnRzO1xyXG4gIH1cclxufTtcclxuXHJcblxyXG5cclxuY29uc3QgSW5kZXggPSAocHJvcHMpID0+IHtcclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJjb250YWluZXJcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZWFyY2hfX3dyYXBwZXJcIj5cclxuICAgICAgICA8U2VhcmNoIC8+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICBcclxuICAgICBcclxuXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwidG9wU3RvcmVzX193cmFwcGVyXCI+XHJcbiAgICAgICAgPGgzPlRvcCBTdG9yZXM8L2gzPlxyXG4gICAgICAgIDx1bCBjbGFzc05hbWU9XCJ0b3BTdG9yZXNfX1VsXCI+XHJcbiAgICAgICAgICA8VG9wU3RvcmVzIHN0b3JlSW5mbz17cHJvcHMuc3RvcmVJbmZvfSAvPlxyXG4gICAgICAgIDwvdWw+XHJcbiAgICAgICAgPGJyIC8+XHJcbiAgICAgICAgPGJyIC8+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgey8qIDxoMz5GbGlwa2FydCBEZWFsIE9mIFRoZSBEYXkgT2ZmZXJzIChGbGFzaCBPZmZlcnMpPC9oMz5cclxuICAgICAgPHVsIGNsYXNzTmFtZT1cIkZsaXBrYXJ0T2ZmZXJzX1VsXCI+XHJcbiAgICAgICAgPEZsaXBrYXJ0T2ZmZXJzIGZsaXBrYXJ0T2ZmZXJzPXtwcm9wcy5mbGlwa2FydEZsYXNoT2ZmZXJzfSAvPlxyXG4gICAgICA8L3VsPiAqL31cclxuICAgICAgXHJcbiAgICAgIHsvKiA8aDM+RmxpcGthcnQgTGl2ZSBPZmZlcnM8L2gzPiAqL31cclxuICAgICAgey8qIDx1bCBjbGFzc05hbWU9XCJGbGlwa2FydE9mZmVyc19VbFwiPiAqL31cclxuICAgICAgICB7LyogPEZsaXBrYXJ0T2ZmZXJzIGZsaXBrYXJ0T2ZmZXJzPXtwcm9wcy5mbGlwa2FydE9mZmVyc30gLz4gKi99XHJcbiAgICAgIHsvKiA8L3VsPiAqL31cclxuXHJcbiAgICAgIFxyXG4gICAgICB7LyogPGgzPlRyZW5kaW5nIE9mZmVyczwvaDM+ICovfVxyXG4gICAgICB7LyogPE9mZmVyc1BhZ2VDb250ZW50IHsuLi5wcm9wc30gbGltaXQ9ezEwfSAvPiAqL31cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0U2VydmVyU2lkZVByb3BzKCkge1xyXG4gIGxldCByZXNwb25zZSA9IGF3YWl0IGZldGNoKGBodHRwczovL29mY2NvZGUtYXBpLWdpdC1tYWluLXNwb3J0eWJydWgxOTkwLnZlcmNlbC5hcHAvYXBpL2Zyb250L3N0b3Jlcy9gKTtcclxuICBsZXQgZ2V0U3RvcmVJZFJlcyA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcclxuICBsZXQgc2VsZWN0ZWRTdG9yZXNBcnIgPSBbXHJcbiAgICAxMDAxLFxyXG4gICAgMTAwMixcclxuICAgIDE1NDgxLFxyXG4gICAgLy8gMTU0ODEsXHJcbiAgICAvLyAxNTU0MixcclxuICAgIC8vIDE0NzE5LFxyXG4gICAgLy8gMjM5NjEsXHJcbiAgICAvLyAyMzgyNSxcclxuICAgIC8vIDE1NTkxLFxyXG4gICAgLy8gMjEzNjFcclxuICBdO1xyXG4gIGxldCBGaW5hbERhdGEgPSBbXTtcclxuICB2YXIgc2VsZWN0ZWRTdG9yZXMgPSBfLm1hcChzZWxlY3RlZFN0b3Jlc0FyciwgZnVuY3Rpb24gKHN0b3JlSWQsIEluZGV4KSB7XHJcbiAgICBsZXQgZmlsdGVyZWREYXRhID0gZ2V0U3RvcmVJZFJlcy5maWx0ZXIoXHJcbiAgICAgIChzdG9yZSkgPT4gc3RvcmUuYWZmSW5mb19fU3RvcmVJZCA9PSBzdG9yZUlkXHJcbiAgICApO1xyXG4gICAgRmluYWxEYXRhW0luZGV4XSA9IGZpbHRlcmVkRGF0YVswXTtcclxuICB9KTtcclxuXHJcbiAgZ2V0U3RvcmVJZFJlcyA9IEZpbmFsRGF0YS5maWx0ZXIoKHN0b3JlKSA9PiBzdG9yZS5zaXRlX19TdG9yZUVuYWJsZWQgPT0gMSk7XHJcblxyXG4gIC8vIGxldCBjbGlua3NSZXMgPSBhd2FpdCBmZXRjaChgaHR0cHM6Ly9vZmNjb2RlLWFwaS1naXQtbWFpbi1zcG9ydHlicnVoMTk5MC52ZXJjZWwuYXBwL2FwaS9mcm9udC9vZmZlcnNgKTtcclxuICAvLyBsZXQgY3VlbGlua3NPZmZlcnMgPSBhd2FpdCBjbGlua3NSZXMuanNvbigpO1xyXG5cclxuICBsZXQgZmxpcGthcnRPZmZlcnNSZXMgPSBhd2FpdCBmZXRjaChcclxuICAgIGBodHRwczovL29mY2NvZGUtYXBpLWdpdC1tYWluLXNwb3J0eWJydWgxOTkwLnZlcmNlbC5hcHAvYXBpL2Zyb250L2RpcmVjdFBhcnRuZXJzL2ZsaXBrYXJ0X19vZmZlcnNgXHJcbiAgKTtcclxuICBsZXQgZ2V0ZmxpcGthcnRPZmZlcnMgPSBhd2FpdCBmbGlwa2FydE9mZmVyc1Jlcy5qc29uKCk7XHJcbiAgLy8gY29uc29sZS5sb2coZ2V0ZmxpcGthcnRPZmZlcnMpO1xyXG5cclxuICBsZXQgZmxpcGthcnRGbGFzaE9mZmVyc1JlcyA9IGF3YWl0IGZldGNoKFxyXG4gICAgYGh0dHBzOi8vb2ZjY29kZS1hcGktZ2l0LW1haW4tc3BvcnR5YnJ1aDE5OTAudmVyY2VsLmFwcC9hcGkvZnJvbnQvZGlyZWN0UGFydG5lcnMvZmxpcGthcnRfX29mZmVycz9xPWRvdGRgXHJcbiAgKTtcclxuICBsZXQgZ2V0ZmxpcGthcnRGbGFzaE9mZmVycyA9IGF3YWl0IGZsaXBrYXJ0Rmxhc2hPZmZlcnNSZXMuanNvbigpO1xyXG5cclxuXHJcbiAgcmV0dXJuIHtcclxuICAgIHByb3BzOiB7XHJcbiAgICAgIHN0b3JlSW5mbzogZ2V0U3RvcmVJZFJlcyxcclxuICAgICAgLy8gY3VlbGlua3NPZmZlcnM6IGN1ZWxpbmtzT2ZmZXJzLFxyXG4gICAgICBmbGlwa2FydE9mZmVyczogZ2V0ZmxpcGthcnRPZmZlcnMsXHJcbiAgICAgIGZsaXBrYXJ0Rmxhc2hPZmZlcnM6IGdldGZsaXBrYXJ0Rmxhc2hPZmZlcnMsXHJcbiAgICB9LFxyXG4gIH07XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IEluZGV4O1xyXG4iXSwic291cmNlUm9vdCI6IiJ9