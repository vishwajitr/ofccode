webpackHotUpdate_N_E("pages/index",{

/***/ "./pages/components/Offer/offerCards.js":
/*!**********************************************!*\
  !*** ./pages/components/Offer/offerCards.js ***!
  \**********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/router */ "./node_modules/next/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! lodash */ "./node_modules/lodash/lodash.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_5__);


var _jsxFileName = "C:\\xampp\\htdocs\\ReactTuts\\NextJS\\ofccode\\pages\\components\\Offer\\offerCards.js",
    _this = undefined,
    _s = $RefreshSig$();







var slug = __webpack_require__(/*! slug */ "./node_modules/slug/slug.js");

var getParsedDate = function getParsedDate(date) {
  return moment__WEBPACK_IMPORTED_MODULE_4___default()(date).startOf("hour").fromNow();
}; // const clickUrl = (target) => {
//   // http://localhost:3000/offers
//     if (typeof window !== "undefined") {
//     window.location.href = target;
//     }
// };


var Card = function Card(props) {
  _s();

  var router = Object(next_router__WEBPACK_IMPORTED_MODULE_2__["useRouter"])();
  var slug = router.query.slug; // Similar to componentDidMount and componentDidUpdate:

  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(function () {
    // <!-- other head elements from your page -->
    (function (g, o) {
      g[o] = g[o] || function () {
        (g[o]["q"] = g[o]["q"] || []).push(arguments);
      }, g[o]["t"] = 1 * new Date();
    })(window, "_googCsa");

    var pageOptions = {
      pubId: "pub-9616389000213823",
      // Make sure this the correct client ID!
      query: slug,
      adPage: 10,
      channel: "searchchnm"
    };
    var adblock1 = {
      container: "afscontainer1",
      linkTarget: "_blank",
      type: "ads",
      columns: 1,
      horizontalAlignment: "left",
      resultsPageQueryParam: "query",
      styleId: "6940738649",
      adLoadedCallback: null
    };
    var adblock2 = {
      container: "afscontainer2",
      linkTarget: "_blank",
      type: "ads",
      columns: 1,
      horizontalAlignment: "left",
      resultsPageQueryParam: "query",
      styleId: "6940738649",
      adLoadedCallback: null
    };

    _googCsa("ads", pageOptions, adblock1, adblock2);
  });
  var cuelinksOffers = props.cuelinksOffers ? props.cuelinksOffers : {};
  var store__logo = props.storeInfo ? props.storeInfo.slug : {};
  var store__name = props.storeInfo ? props.storeInfo.name : {};
  var limit = props.limit ? props.limit : {};

  if (cuelinksOffers) {
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("section", {
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(Head, {
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("script", {
          async: "async",
          src: "https://www.google.com/adsense/search/ads.js"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 76,
          columnNumber: 11
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("script", {
          async: true,
          src: "https://cse.google.com/cse.js?cx=39bed8f3de88a4885"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 80,
          columnNumber: 11
        }, _this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 75,
        columnNumber: 9
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "clearfix",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          id: "afscontainer1"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 87,
          columnNumber: 11
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 88,
          columnNumber: 11
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "clearfix",
          children: lodash__WEBPACK_IMPORTED_MODULE_3___default.a.map(cuelinksOffers, function (value, key) {
            var promocodeCard = false;
            var cuelOffers = {};
            cuelOffers["title"] = value["title"];
            cuelOffers["merchant"] = value["merchant"];
            cuelOffers["id"] = value["id"];
            cuelOffers["categories"] = value["categories"];
            cuelOffers["description"] = value["description"];
            cuelOffers["coupon_code"] = value["coupon_code"];
            cuelOffers["url"] = value["url"];
            cuelOffers["start_date"] = value["start_date"];
            cuelOffers["end_date"] = value["end_date"];
            cuelOffers["offer_added_at"] = value["offer_added_at"];
            cuelOffers["image_url"] = value["image_url"];
            cuelOffers["campaign_name"] = value["campaign_name"];

            if (value["title"] !== "") {
              if (cuelOffers["coupon_code"] != "") {
                promocodeCard = true;
              }

              return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: key,
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "row",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                    className: "deal__card",
                    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                      className: "deal__discount",
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                        className: "deal__info",
                        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
                            src: "/stores__logo/" + cuelOffers["merchant"] + "-logo-small.jpg",
                            onError: function onError(e) {
                              e.target.onerror = null;
                              e.target.src = "/img-notfound.jpg";
                            },
                            alt: cuelOffers["title"]
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 118,
                            columnNumber: 31
                          }, _this), " "]
                        }, void 0, true, {
                          fileName: _jsxFileName,
                          lineNumber: 117,
                          columnNumber: 29
                        }, _this)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 116,
                        columnNumber: 27
                      }, _this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 115,
                      columnNumber: 25
                    }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                      className: "deal__desc",
                      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                        className: "deal__desc-type"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 134,
                        columnNumber: 27
                      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                        className: "deal__desc-title",
                        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h3", {
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_5___default.a, {
                            href: "/product/" + slug(cuelOffers["title"]),
                            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                              "data-url": "/product/" + slug(cuelOffers["title"]),
                              "data-promolink": "/product/" + slug(cuelOffers["title"]),
                              "data-func": "getPromoCode",
                              className: "getPromoCode",
                              target: "_blank",
                              title: "OffersCode.in - Promo code for " + cuelOffers["campaign_name"] + " deal " + cuelOffers["title"],
                              rel: "nofollow",
                              children: [cuelOffers["merchant"], " :", " ", cuelOffers["title"]]
                            }, void 0, true, {
                              fileName: _jsxFileName,
                              lineNumber: 140,
                              columnNumber: 33
                            }, _this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 137,
                            columnNumber: 31
                          }, _this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 136,
                          columnNumber: 29
                        }, _this)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 135,
                        columnNumber: 27
                      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                        className: "deal__desc-meta",
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                          className: "deal__desc-meta-lastused",
                          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
                            className: "fa fa-users"
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 166,
                            columnNumber: 31
                          }, _this), "\xA0", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("b", {
                            children: Math.floor(Math.random() * 200) + 11
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 167,
                            columnNumber: 31
                          }, _this), " ", "People Used Today"]
                        }, void 0, true, {
                          fileName: _jsxFileName,
                          lineNumber: 165,
                          columnNumber: 29
                        }, _this), "\xA0|\xA0", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                          className: "deal__desc-meta-lastused",
                          children: cuelOffers["categories"]
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 171,
                          columnNumber: 29
                        }, _this)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 164,
                        columnNumber: 27
                      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                        className: "deal__cta",
                        children: promocodeCard ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_5___default.a, {
                            href: "/product/" + slug(cuelOffers["title"]),
                            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                              "data-url": "/product/" + slug(cuelOffers["title"]) // data-promocode={''}
                              // data-species={''}
                              ,
                              "data-promolink": "/product/" + slug(cuelOffers["title"]),
                              "data-func": "getPromoCode",
                              className: "getPromoCode" // data-website={''}
                              ,
                              target: "_blank",
                              title: "OffersCode.in - Promo code for " + cuelOffers["campaign_name"] + " deal " + cuelOffers["title"],
                              rel: "nofollow",
                              children: "Get This Deal"
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 182,
                              columnNumber: 35
                            }, _this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 179,
                            columnNumber: 33
                          }, _this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 178,
                          columnNumber: 31
                        }, _this) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_5___default.a, {
                            href: "/product/" + slug(cuelOffers["title"]),
                            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                              // href={`/goto`}
                              "data-url": "/product/" + slug(cuelOffers["title"]) // data-promocode={}
                              // data-species={}
                              // data-promolink={}
                              ,
                              "data-func": "getDeal",
                              className: "getDeal" // data-website={}
                              ,
                              target: "_blank" // gotoLink = {value[11]}
                              ,
                              rel: "nofollow",
                              children: "Get This Deal"
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 212,
                              columnNumber: 35
                            }, _this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 209,
                            columnNumber: 33
                          }, _this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 208,
                          columnNumber: 31
                        }, _this)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 176,
                        columnNumber: 27
                      }, _this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 133,
                      columnNumber: 25
                    }, _this)]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 114,
                    columnNumber: 23
                  }, _this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 113,
                  columnNumber: 21
                }, _this)
              }, key, false, {
                fileName: _jsxFileName,
                lineNumber: 112,
                columnNumber: 19
              }, _this);
            }
          })
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 90,
          columnNumber: 11
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 241,
          columnNumber: 11
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          id: "afscontainer1"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 242,
          columnNumber: 11
        }, _this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 86,
        columnNumber: 9
      }, _this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 74,
      columnNumber: 7
    }, _this);
  } else {
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 249,
        columnNumber: 9
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 250,
        columnNumber: 9
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 251,
        columnNumber: 9
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h3", {
        children: "No New Deals Or Coupons Found"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 252,
        columnNumber: 9
      }, _this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 248,
      columnNumber: 7
    }, _this);
  }
};

_s(Card, "vQduR7x+OPXj6PSmJyFnf+hU7bg=", false, function () {
  return [next_router__WEBPACK_IMPORTED_MODULE_2__["useRouter"]];
});

_c = Card;
/* harmony default export */ __webpack_exports__["default"] = (Card);

var _c;

$RefreshReg$(_c, "Card");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvY29tcG9uZW50cy9PZmZlci9vZmZlckNhcmRzLmpzIl0sIm5hbWVzIjpbInNsdWciLCJyZXF1aXJlIiwiZ2V0UGFyc2VkRGF0ZSIsImRhdGUiLCJNb21lbnQiLCJzdGFydE9mIiwiZnJvbU5vdyIsIkNhcmQiLCJwcm9wcyIsInJvdXRlciIsInVzZVJvdXRlciIsInF1ZXJ5IiwidXNlRWZmZWN0IiwiZyIsIm8iLCJwdXNoIiwiYXJndW1lbnRzIiwiRGF0ZSIsIndpbmRvdyIsInBhZ2VPcHRpb25zIiwicHViSWQiLCJhZFBhZ2UiLCJjaGFubmVsIiwiYWRibG9jazEiLCJjb250YWluZXIiLCJsaW5rVGFyZ2V0IiwidHlwZSIsImNvbHVtbnMiLCJob3Jpem9udGFsQWxpZ25tZW50IiwicmVzdWx0c1BhZ2VRdWVyeVBhcmFtIiwic3R5bGVJZCIsImFkTG9hZGVkQ2FsbGJhY2siLCJhZGJsb2NrMiIsIl9nb29nQ3NhIiwiY3VlbGlua3NPZmZlcnMiLCJzdG9yZV9fbG9nbyIsInN0b3JlSW5mbyIsInN0b3JlX19uYW1lIiwibmFtZSIsImxpbWl0IiwiXyIsIm1hcCIsInZhbHVlIiwia2V5IiwicHJvbW9jb2RlQ2FyZCIsImN1ZWxPZmZlcnMiLCJlIiwidGFyZ2V0Iiwib25lcnJvciIsInNyYyIsIk1hdGgiLCJmbG9vciIsInJhbmRvbSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBLElBQUlBLElBQUksR0FBR0MsbUJBQU8sQ0FBQyx5Q0FBRCxDQUFsQjs7QUFFQSxJQUFNQyxhQUFhLEdBQUcsU0FBaEJBLGFBQWdCLENBQUNDLElBQUQsRUFBVTtBQUM5QixTQUFPQyw2Q0FBTSxDQUFDRCxJQUFELENBQU4sQ0FBYUUsT0FBYixDQUFxQixNQUFyQixFQUE2QkMsT0FBN0IsRUFBUDtBQUNELENBRkQsQyxDQUlBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBRUEsSUFBTUMsSUFBSSxHQUFHLFNBQVBBLElBQU8sQ0FBQ0MsS0FBRCxFQUFXO0FBQUE7O0FBQ3RCLE1BQU1DLE1BQU0sR0FBR0MsNkRBQVMsRUFBeEI7QUFEc0IsTUFFZFYsSUFGYyxHQUVMUyxNQUFNLENBQUNFLEtBRkYsQ0FFZFgsSUFGYyxFQUd0Qjs7QUFDQVkseURBQVMsQ0FBQyxZQUFNO0FBQ2Q7QUFFQSxLQUFDLFVBQVVDLENBQVYsRUFBYUMsQ0FBYixFQUFnQjtBQUNkRCxPQUFDLENBQUNDLENBQUQsQ0FBRCxHQUNDRCxDQUFDLENBQUNDLENBQUQsQ0FBRCxJQUNBLFlBQVk7QUFDVixTQUFDRCxDQUFDLENBQUNDLENBQUQsQ0FBRCxDQUFLLEdBQUwsSUFBWUQsQ0FBQyxDQUFDQyxDQUFELENBQUQsQ0FBSyxHQUFMLEtBQWEsRUFBMUIsRUFBOEJDLElBQTlCLENBQW1DQyxTQUFuQztBQUNELE9BSkgsRUFLR0gsQ0FBQyxDQUFDQyxDQUFELENBQUQsQ0FBSyxHQUFMLElBQVksSUFBSSxJQUFJRyxJQUFKLEVBTG5CO0FBTUQsS0FQRCxFQU9HQyxNQVBILEVBT1csVUFQWDs7QUFTQSxRQUFJQyxXQUFXLEdBQUc7QUFDaEJDLFdBQUssRUFBRSxzQkFEUztBQUNlO0FBQy9CVCxXQUFLLEVBQUVYLElBRlM7QUFHaEJxQixZQUFNLEVBQUUsRUFIUTtBQUloQkMsYUFBTyxFQUFFO0FBSk8sS0FBbEI7QUFPQSxRQUFJQyxRQUFRLEdBQUc7QUFDYkMsZUFBUyxFQUFFLGVBREU7QUFFYkMsZ0JBQVUsRUFBRSxRQUZDO0FBR2JDLFVBQUksRUFBRSxLQUhPO0FBSWJDLGFBQU8sRUFBRSxDQUpJO0FBS2JDLHlCQUFtQixFQUFFLE1BTFI7QUFNYkMsMkJBQXFCLEVBQUUsT0FOVjtBQU9iQyxhQUFPLEVBQUUsWUFQSTtBQVFiQyxzQkFBZ0IsRUFBRTtBQVJMLEtBQWY7QUFXQSxRQUFJQyxRQUFRLEdBQUc7QUFDYlIsZUFBUyxFQUFFLGVBREU7QUFFYkMsZ0JBQVUsRUFBRSxRQUZDO0FBR2JDLFVBQUksRUFBRSxLQUhPO0FBSWJDLGFBQU8sRUFBRSxDQUpJO0FBS2JDLHlCQUFtQixFQUFFLE1BTFI7QUFNYkMsMkJBQXFCLEVBQUUsT0FOVjtBQU9iQyxhQUFPLEVBQUUsWUFQSTtBQVFiQyxzQkFBZ0IsRUFBRTtBQVJMLEtBQWY7O0FBV0FFLFlBQVEsQ0FBQyxLQUFELEVBQVFkLFdBQVIsRUFBcUJJLFFBQXJCLEVBQStCUyxRQUEvQixDQUFSO0FBQ0QsR0ExQ1EsQ0FBVDtBQTRDQSxNQUFNRSxjQUFjLEdBQUcxQixLQUFLLENBQUMwQixjQUFOLEdBQXVCMUIsS0FBSyxDQUFDMEIsY0FBN0IsR0FBOEMsRUFBckU7QUFDQSxNQUFNQyxXQUFXLEdBQUczQixLQUFLLENBQUM0QixTQUFOLEdBQWtCNUIsS0FBSyxDQUFDNEIsU0FBTixDQUFnQnBDLElBQWxDLEdBQXlDLEVBQTdEO0FBQ0EsTUFBTXFDLFdBQVcsR0FBRzdCLEtBQUssQ0FBQzRCLFNBQU4sR0FBa0I1QixLQUFLLENBQUM0QixTQUFOLENBQWdCRSxJQUFsQyxHQUF5QyxFQUE3RDtBQUNBLE1BQU1DLEtBQUssR0FBRy9CLEtBQUssQ0FBQytCLEtBQU4sR0FBYy9CLEtBQUssQ0FBQytCLEtBQXBCLEdBQTRCLEVBQTFDOztBQUVBLE1BQUlMLGNBQUosRUFBb0I7QUFDbEIsd0JBQ0U7QUFBQSw4QkFDRSxxRUFBQyxJQUFEO0FBQUEsZ0NBQ0U7QUFDRSxlQUFLLEVBQUMsT0FEUjtBQUVFLGFBQUcsRUFBQztBQUZOO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREYsZUFLRTtBQUNFLGVBQUssTUFEUDtBQUVFLGFBQUcsRUFBQztBQUZOO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREYsZUFZRTtBQUFLLGlCQUFTLEVBQUMsVUFBZjtBQUFBLGdDQUNFO0FBQUssWUFBRSxFQUFDO0FBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFERixlQUVFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRkYsZUFJRTtBQUFLLG1CQUFTLEVBQUMsVUFBZjtBQUFBLG9CQUNHTSw2Q0FBQyxDQUFDQyxHQUFGLENBQU1QLGNBQU4sRUFBc0IsVUFBQ1EsS0FBRCxFQUFRQyxHQUFSLEVBQWdCO0FBQ3JDLGdCQUFJQyxhQUFhLEdBQUcsS0FBcEI7QUFDQSxnQkFBSUMsVUFBVSxHQUFHLEVBQWpCO0FBQ0FBLHNCQUFVLENBQUMsT0FBRCxDQUFWLEdBQXNCSCxLQUFLLENBQUMsT0FBRCxDQUEzQjtBQUNBRyxzQkFBVSxDQUFDLFVBQUQsQ0FBVixHQUF5QkgsS0FBSyxDQUFDLFVBQUQsQ0FBOUI7QUFDQUcsc0JBQVUsQ0FBQyxJQUFELENBQVYsR0FBbUJILEtBQUssQ0FBQyxJQUFELENBQXhCO0FBQ0FHLHNCQUFVLENBQUMsWUFBRCxDQUFWLEdBQTJCSCxLQUFLLENBQUMsWUFBRCxDQUFoQztBQUNBRyxzQkFBVSxDQUFDLGFBQUQsQ0FBVixHQUE0QkgsS0FBSyxDQUFDLGFBQUQsQ0FBakM7QUFDQUcsc0JBQVUsQ0FBQyxhQUFELENBQVYsR0FBNEJILEtBQUssQ0FBQyxhQUFELENBQWpDO0FBQ0FHLHNCQUFVLENBQUMsS0FBRCxDQUFWLEdBQW9CSCxLQUFLLENBQUMsS0FBRCxDQUF6QjtBQUNBRyxzQkFBVSxDQUFDLFlBQUQsQ0FBVixHQUEyQkgsS0FBSyxDQUFDLFlBQUQsQ0FBaEM7QUFDQUcsc0JBQVUsQ0FBQyxVQUFELENBQVYsR0FBeUJILEtBQUssQ0FBQyxVQUFELENBQTlCO0FBQ0FHLHNCQUFVLENBQUMsZ0JBQUQsQ0FBVixHQUErQkgsS0FBSyxDQUFDLGdCQUFELENBQXBDO0FBQ0FHLHNCQUFVLENBQUMsV0FBRCxDQUFWLEdBQTBCSCxLQUFLLENBQUMsV0FBRCxDQUEvQjtBQUNBRyxzQkFBVSxDQUFDLGVBQUQsQ0FBVixHQUE4QkgsS0FBSyxDQUFDLGVBQUQsQ0FBbkM7O0FBRUEsZ0JBQUlBLEtBQUssQ0FBQyxPQUFELENBQUwsS0FBbUIsRUFBdkIsRUFBMkI7QUFDekIsa0JBQUlHLFVBQVUsQ0FBQyxhQUFELENBQVYsSUFBNkIsRUFBakMsRUFBcUM7QUFDbkNELDZCQUFhLEdBQUcsSUFBaEI7QUFDRDs7QUFDRCxrQ0FDRTtBQUFlLHlCQUFTLEVBQUVELEdBQTFCO0FBQUEsdUNBQ0U7QUFBSywyQkFBUyxFQUFDLEtBQWY7QUFBQSx5Q0FDRTtBQUFLLDZCQUFTLEVBQUMsWUFBZjtBQUFBLDRDQUNFO0FBQUssK0JBQVMsRUFBQyxnQkFBZjtBQUFBLDZDQUNFO0FBQUssaUNBQVMsRUFBQyxZQUFmO0FBQUEsK0NBQ0U7QUFBQSxrREFDRTtBQUNFLCtCQUFHLEVBQ0QsbUJBQ0FFLFVBQVUsQ0FBQyxVQUFELENBRFYsb0JBRko7QUFNRSxtQ0FBTyxFQUFFLGlCQUFDQyxDQUFELEVBQU87QUFDZEEsK0JBQUMsQ0FBQ0MsTUFBRixDQUFTQyxPQUFULEdBQW1CLElBQW5CO0FBQ0FGLCtCQUFDLENBQUNDLE1BQUYsQ0FBU0UsR0FBVCxHQUFlLG1CQUFmO0FBQ0QsNkJBVEg7QUFVRSwrQkFBRyxFQUFFSixVQUFVLENBQUMsT0FBRDtBQVZqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQURGLEVBWUssR0FaTDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFERixlQW1CRTtBQUFLLCtCQUFTLEVBQUMsWUFBZjtBQUFBLDhDQUNFO0FBQUssaUNBQVMsRUFBQztBQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBREYsZUFFRTtBQUFLLGlDQUFTLEVBQUMsa0JBQWY7QUFBQSwrQ0FDRTtBQUFBLGlEQUNFLHFFQUFDLGdEQUFEO0FBQ0UsZ0NBQUksRUFBRSxjQUFjN0MsSUFBSSxDQUFDNkMsVUFBVSxDQUFDLE9BQUQsQ0FBWCxDQUQxQjtBQUFBLG1EQUdFO0FBQ0UsMENBQ0UsY0FBYzdDLElBQUksQ0FBQzZDLFVBQVUsQ0FBQyxPQUFELENBQVgsQ0FGdEI7QUFJRSxnREFDRSxjQUFjN0MsSUFBSSxDQUFDNkMsVUFBVSxDQUFDLE9BQUQsQ0FBWCxDQUx0QjtBQU9FLDJDQUFVLGNBUFo7QUFRRSx1Q0FBUyxFQUFDLGNBUlo7QUFTRSxvQ0FBTSxFQUFDLFFBVFQ7QUFVRSxtQ0FBSyxFQUNILG9DQUNBQSxVQUFVLENBQUMsZUFBRCxDQURWLGNBR0FBLFVBQVUsQ0FBQyxPQUFELENBZGQ7QUFnQkUsaUNBQUcsRUFBQyxVQWhCTjtBQUFBLHlDQWtCR0EsVUFBVSxDQUFDLFVBQUQsQ0FsQmIsUUFrQjZCLEdBbEI3QixFQW1CR0EsVUFBVSxDQUFDLE9BQUQsQ0FuQmI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUZGLGVBK0JFO0FBQUssaUNBQVMsRUFBQyxpQkFBZjtBQUFBLGdEQUNFO0FBQU0sbUNBQVMsRUFBQywwQkFBaEI7QUFBQSxrREFDRTtBQUFHLHFDQUFTLEVBQUM7QUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQURGLHVCQUVFO0FBQUEsc0NBQUlLLElBQUksQ0FBQ0MsS0FBTCxDQUFXRCxJQUFJLENBQUNFLE1BQUwsS0FBZ0IsR0FBM0IsSUFBa0M7QUFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FGRixFQUVnRCxHQUZoRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBREYsNEJBT0U7QUFBTSxtQ0FBUyxFQUFDLDBCQUFoQjtBQUFBLG9DQUNHUCxVQUFVLENBQUMsWUFBRDtBQURiO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQS9CRixlQTJDRTtBQUFLLGlDQUFTLEVBQUMsV0FBZjtBQUFBLGtDQUNHRCxhQUFhLGdCQUNaO0FBQUEsaURBQ0UscUVBQUMsZ0RBQUQ7QUFDRSxnQ0FBSSxFQUFFLGNBQWM1QyxJQUFJLENBQUM2QyxVQUFVLENBQUMsT0FBRCxDQUFYLENBRDFCO0FBQUEsbURBR0U7QUFDRSwwQ0FDRSxjQUFjN0MsSUFBSSxDQUFDNkMsVUFBVSxDQUFDLE9BQUQsQ0FBWCxDQUZ0QixDQUlFO0FBQ0E7QUFMRjtBQU1FLGdEQUNFLGNBQWM3QyxJQUFJLENBQUM2QyxVQUFVLENBQUMsT0FBRCxDQUFYLENBUHRCO0FBU0UsMkNBQVUsY0FUWjtBQVVFLHVDQUFTLEVBQUMsY0FWWixDQVdFO0FBWEY7QUFZRSxvQ0FBTSxFQUFDLFFBWlQ7QUFhRSxtQ0FBSyxFQUNILG9DQUNBQSxVQUFVLENBQUMsZUFBRCxDQURWLGNBR0FBLFVBQVUsQ0FBQyxPQUFELENBakJkO0FBbUJFLGlDQUFHLEVBQUMsVUFuQk47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFIRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FEWSxnQkErQlo7QUFBQSxpREFDRSxxRUFBQyxnREFBRDtBQUNFLGdDQUFJLEVBQUUsY0FBYzdDLElBQUksQ0FBQzZDLFVBQVUsQ0FBQyxPQUFELENBQVgsQ0FEMUI7QUFBQSxtREFHRTtBQUNFO0FBQ0EsMENBQ0UsY0FBYzdDLElBQUksQ0FBQzZDLFVBQVUsQ0FBQyxPQUFELENBQVgsQ0FIdEIsQ0FLRTtBQUNBO0FBQ0E7QUFQRjtBQVFFLDJDQUFVLFNBUlo7QUFTRSx1Q0FBUyxFQUFDLFNBVFosQ0FVRTtBQVZGO0FBV0Usb0NBQU0sRUFBQyxRQVhULENBWUU7QUFaRjtBQWFFLGlDQUFHLEVBQUMsVUFiTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBaENKO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBM0NGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFuQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGLGlCQUFVRixHQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBREY7QUErSEQ7QUFDRixXQXBKQTtBQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSkYsZUEySkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkEzSkYsZUE0SkU7QUFBSyxZQUFFLEVBQUM7QUFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTVKRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFERjtBQTZLRCxHQTlLRCxNQThLTztBQUNMLHdCQUNFO0FBQUEsOEJBQ0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGLGVBRUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUZGLGVBR0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUhGLGVBSUU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFERjtBQVFEO0FBQ0YsQ0E3T0Q7O0dBQU1wQyxJO1VBQ1dHLHFEOzs7S0FEWEgsSTtBQStPU0EsbUVBQWYiLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvaW5kZXguY2I4MDhhZWZhZThhMGQ3YWQ2ZTIuaG90LXVwZGF0ZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyBDb21wb25lbnQsIHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSBcIm5leHQvcm91dGVyXCI7XHJcbmltcG9ydCBfIGZyb20gXCJsb2Rhc2hcIjtcclxuaW1wb3J0IE1vbWVudCBmcm9tIFwibW9tZW50XCI7XHJcbmltcG9ydCBMaW5rIGZyb20gXCJuZXh0L2xpbmtcIjtcclxudmFyIHNsdWcgPSByZXF1aXJlKFwic2x1Z1wiKTtcclxuXHJcbmNvbnN0IGdldFBhcnNlZERhdGUgPSAoZGF0ZSkgPT4ge1xyXG4gIHJldHVybiBNb21lbnQoZGF0ZSkuc3RhcnRPZihcImhvdXJcIikuZnJvbU5vdygpO1xyXG59O1xyXG5cclxuLy8gY29uc3QgY2xpY2tVcmwgPSAodGFyZ2V0KSA9PiB7XHJcbi8vICAgLy8gaHR0cDovL2xvY2FsaG9zdDozMDAwL29mZmVyc1xyXG4vLyAgICAgaWYgKHR5cGVvZiB3aW5kb3cgIT09IFwidW5kZWZpbmVkXCIpIHtcclxuLy8gICAgIHdpbmRvdy5sb2NhdGlvbi5ocmVmID0gdGFyZ2V0O1xyXG4vLyAgICAgfVxyXG4vLyB9O1xyXG5cclxuY29uc3QgQ2FyZCA9IChwcm9wcykgPT4ge1xyXG4gIGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpO1xyXG4gIGNvbnN0IHsgc2x1ZyB9ID0gcm91dGVyLnF1ZXJ5O1xyXG4gIC8vIFNpbWlsYXIgdG8gY29tcG9uZW50RGlkTW91bnQgYW5kIGNvbXBvbmVudERpZFVwZGF0ZTpcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgLy8gPCEtLSBvdGhlciBoZWFkIGVsZW1lbnRzIGZyb20geW91ciBwYWdlIC0tPlxyXG5cclxuICAgIChmdW5jdGlvbiAoZywgbykge1xyXG4gICAgICAoZ1tvXSA9XHJcbiAgICAgICAgZ1tvXSB8fFxyXG4gICAgICAgIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgIChnW29dW1wicVwiXSA9IGdbb11bXCJxXCJdIHx8IFtdKS5wdXNoKGFyZ3VtZW50cyk7XHJcbiAgICAgICAgfSksXHJcbiAgICAgICAgKGdbb11bXCJ0XCJdID0gMSAqIG5ldyBEYXRlKCkpO1xyXG4gICAgfSkod2luZG93LCBcIl9nb29nQ3NhXCIpO1xyXG5cclxuICAgIHZhciBwYWdlT3B0aW9ucyA9IHtcclxuICAgICAgcHViSWQ6IFwicHViLTk2MTYzODkwMDAyMTM4MjNcIiwgLy8gTWFrZSBzdXJlIHRoaXMgdGhlIGNvcnJlY3QgY2xpZW50IElEIVxyXG4gICAgICBxdWVyeTogc2x1ZyxcclxuICAgICAgYWRQYWdlOiAxMCxcclxuICAgICAgY2hhbm5lbDogXCJzZWFyY2hjaG5tXCIsXHJcbiAgICB9O1xyXG5cclxuICAgIHZhciBhZGJsb2NrMSA9IHtcclxuICAgICAgY29udGFpbmVyOiBcImFmc2NvbnRhaW5lcjFcIixcclxuICAgICAgbGlua1RhcmdldDogXCJfYmxhbmtcIixcclxuICAgICAgdHlwZTogXCJhZHNcIixcclxuICAgICAgY29sdW1uczogMSxcclxuICAgICAgaG9yaXpvbnRhbEFsaWdubWVudDogXCJsZWZ0XCIsXHJcbiAgICAgIHJlc3VsdHNQYWdlUXVlcnlQYXJhbTogXCJxdWVyeVwiLFxyXG4gICAgICBzdHlsZUlkOiBcIjY5NDA3Mzg2NDlcIixcclxuICAgICAgYWRMb2FkZWRDYWxsYmFjazogbnVsbCxcclxuICAgIH07XHJcblxyXG4gICAgdmFyIGFkYmxvY2syID0ge1xyXG4gICAgICBjb250YWluZXI6IFwiYWZzY29udGFpbmVyMlwiLFxyXG4gICAgICBsaW5rVGFyZ2V0OiBcIl9ibGFua1wiLFxyXG4gICAgICB0eXBlOiBcImFkc1wiLFxyXG4gICAgICBjb2x1bW5zOiAxLFxyXG4gICAgICBob3Jpem9udGFsQWxpZ25tZW50OiBcImxlZnRcIixcclxuICAgICAgcmVzdWx0c1BhZ2VRdWVyeVBhcmFtOiBcInF1ZXJ5XCIsXHJcbiAgICAgIHN0eWxlSWQ6IFwiNjk0MDczODY0OVwiLFxyXG4gICAgICBhZExvYWRlZENhbGxiYWNrOiBudWxsLFxyXG4gICAgfTtcclxuXHJcbiAgICBfZ29vZ0NzYShcImFkc1wiLCBwYWdlT3B0aW9ucywgYWRibG9jazEsIGFkYmxvY2syKTtcclxuICB9KTtcclxuXHJcbiAgY29uc3QgY3VlbGlua3NPZmZlcnMgPSBwcm9wcy5jdWVsaW5rc09mZmVycyA/IHByb3BzLmN1ZWxpbmtzT2ZmZXJzIDoge307XHJcbiAgY29uc3Qgc3RvcmVfX2xvZ28gPSBwcm9wcy5zdG9yZUluZm8gPyBwcm9wcy5zdG9yZUluZm8uc2x1ZyA6IHt9O1xyXG4gIGNvbnN0IHN0b3JlX19uYW1lID0gcHJvcHMuc3RvcmVJbmZvID8gcHJvcHMuc3RvcmVJbmZvLm5hbWUgOiB7fTtcclxuICBjb25zdCBsaW1pdCA9IHByb3BzLmxpbWl0ID8gcHJvcHMubGltaXQgOiB7fTtcclxuXHJcbiAgaWYgKGN1ZWxpbmtzT2ZmZXJzKSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8c2VjdGlvbj5cclxuICAgICAgICA8SGVhZD5cclxuICAgICAgICAgIDxzY3JpcHRcclxuICAgICAgICAgICAgYXN5bmM9XCJhc3luY1wiXHJcbiAgICAgICAgICAgIHNyYz1cImh0dHBzOi8vd3d3Lmdvb2dsZS5jb20vYWRzZW5zZS9zZWFyY2gvYWRzLmpzXCJcclxuICAgICAgICAgID48L3NjcmlwdD5cclxuICAgICAgICAgIDxzY3JpcHRcclxuICAgICAgICAgICAgYXN5bmNcclxuICAgICAgICAgICAgc3JjPVwiaHR0cHM6Ly9jc2UuZ29vZ2xlLmNvbS9jc2UuanM/Y3g9MzliZWQ4ZjNkZTg4YTQ4ODVcIlxyXG4gICAgICAgICAgPjwvc2NyaXB0PlxyXG4gICAgICAgIDwvSGVhZD5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjbGVhcmZpeFwiPlxyXG4gICAgICAgICAgPGRpdiBpZD1cImFmc2NvbnRhaW5lcjFcIj48L2Rpdj5cclxuICAgICAgICAgIDxiciAvPlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2xlYXJmaXhcIj5cclxuICAgICAgICAgICAge18ubWFwKGN1ZWxpbmtzT2ZmZXJzLCAodmFsdWUsIGtleSkgPT4ge1xyXG4gICAgICAgICAgICAgIGxldCBwcm9tb2NvZGVDYXJkID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgbGV0IGN1ZWxPZmZlcnMgPSB7fTtcclxuICAgICAgICAgICAgICBjdWVsT2ZmZXJzW1widGl0bGVcIl0gPSB2YWx1ZVtcInRpdGxlXCJdO1xyXG4gICAgICAgICAgICAgIGN1ZWxPZmZlcnNbXCJtZXJjaGFudFwiXSA9IHZhbHVlW1wibWVyY2hhbnRcIl07XHJcbiAgICAgICAgICAgICAgY3VlbE9mZmVyc1tcImlkXCJdID0gdmFsdWVbXCJpZFwiXTtcclxuICAgICAgICAgICAgICBjdWVsT2ZmZXJzW1wiY2F0ZWdvcmllc1wiXSA9IHZhbHVlW1wiY2F0ZWdvcmllc1wiXTtcclxuICAgICAgICAgICAgICBjdWVsT2ZmZXJzW1wiZGVzY3JpcHRpb25cIl0gPSB2YWx1ZVtcImRlc2NyaXB0aW9uXCJdO1xyXG4gICAgICAgICAgICAgIGN1ZWxPZmZlcnNbXCJjb3Vwb25fY29kZVwiXSA9IHZhbHVlW1wiY291cG9uX2NvZGVcIl07XHJcbiAgICAgICAgICAgICAgY3VlbE9mZmVyc1tcInVybFwiXSA9IHZhbHVlW1widXJsXCJdO1xyXG4gICAgICAgICAgICAgIGN1ZWxPZmZlcnNbXCJzdGFydF9kYXRlXCJdID0gdmFsdWVbXCJzdGFydF9kYXRlXCJdO1xyXG4gICAgICAgICAgICAgIGN1ZWxPZmZlcnNbXCJlbmRfZGF0ZVwiXSA9IHZhbHVlW1wiZW5kX2RhdGVcIl07XHJcbiAgICAgICAgICAgICAgY3VlbE9mZmVyc1tcIm9mZmVyX2FkZGVkX2F0XCJdID0gdmFsdWVbXCJvZmZlcl9hZGRlZF9hdFwiXTtcclxuICAgICAgICAgICAgICBjdWVsT2ZmZXJzW1wiaW1hZ2VfdXJsXCJdID0gdmFsdWVbXCJpbWFnZV91cmxcIl07XHJcbiAgICAgICAgICAgICAgY3VlbE9mZmVyc1tcImNhbXBhaWduX25hbWVcIl0gPSB2YWx1ZVtcImNhbXBhaWduX25hbWVcIl07XHJcblxyXG4gICAgICAgICAgICAgIGlmICh2YWx1ZVtcInRpdGxlXCJdICE9PSBcIlwiKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoY3VlbE9mZmVyc1tcImNvdXBvbl9jb2RlXCJdICE9IFwiXCIpIHtcclxuICAgICAgICAgICAgICAgICAgcHJvbW9jb2RlQ2FyZCA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGtleT17a2V5fSBjbGFzc05hbWU9e2tleX0+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3dcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZGVhbF9fY2FyZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRlYWxfX2Rpc2NvdW50XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkZWFsX19pbmZvXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW1nXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3JjPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGAvc3RvcmVzX19sb2dvL2AgK1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY3VlbE9mZmVyc1tcIm1lcmNoYW50XCJdICtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGAtbG9nby1zbWFsbC5qcGdgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uRXJyb3I9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlLnRhcmdldC5vbmVycm9yID0gbnVsbDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGUudGFyZ2V0LnNyYyA9IFwiL2ltZy1ub3Rmb3VuZC5qcGdcIjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFsdD17Y3VlbE9mZmVyc1tcInRpdGxlXCJdfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkZWFsX19kZXNjXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkZWFsX19kZXNjLXR5cGVcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRlYWxfX2Rlc2MtdGl0bGVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBocmVmPXtcIi9wcm9kdWN0L1wiICsgc2x1ZyhjdWVsT2ZmZXJzW1widGl0bGVcIl0pfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGFcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGEtdXJsPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCIvcHJvZHVjdC9cIiArIHNsdWcoY3VlbE9mZmVyc1tcInRpdGxlXCJdKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YS1wcm9tb2xpbms9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIi9wcm9kdWN0L1wiICsgc2x1ZyhjdWVsT2ZmZXJzW1widGl0bGVcIl0pXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhLWZ1bmM9XCJnZXRQcm9tb0NvZGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZ2V0UHJvbW9Db2RlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRhcmdldD1cIl9ibGFua1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGBPZmZlcnNDb2RlLmluIC0gUHJvbW8gY29kZSBmb3IgYCArXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGN1ZWxPZmZlcnNbXCJjYW1wYWlnbl9uYW1lXCJdICtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYCBkZWFsIGAgK1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjdWVsT2ZmZXJzW1widGl0bGVcIl1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlbD1cIm5vZm9sbG93XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y3VlbE9mZmVyc1tcIm1lcmNoYW50XCJdfSA6e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2N1ZWxPZmZlcnNbXCJ0aXRsZVwiXX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkZWFsX19kZXNjLW1ldGFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImRlYWxfX2Rlc2MtbWV0YS1sYXN0dXNlZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aSBjbGFzc05hbWU9XCJmYSBmYS11c2Vyc1wiPjwvaT4mbmJzcDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGI+e01hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIDIwMCkgKyAxMX08L2I+e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBQZW9wbGUgVXNlZCBUb2RheVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgJm5ic3A7fCZuYnNwO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZGVhbF9fZGVzYy1tZXRhLWxhc3R1c2VkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjdWVsT2ZmZXJzW1wiY2F0ZWdvcmllc1wiXX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkZWFsX19jdGFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtwcm9tb2NvZGVDYXJkID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBocmVmPXtcIi9wcm9kdWN0L1wiICsgc2x1ZyhjdWVsT2ZmZXJzW1widGl0bGVcIl0pfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxhXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGEtdXJsPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIi9wcm9kdWN0L1wiICsgc2x1ZyhjdWVsT2ZmZXJzW1widGl0bGVcIl0pXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gZGF0YS1wcm9tb2NvZGU9eycnfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBkYXRhLXNwZWNpZXM9eycnfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhLXByb21vbGluaz17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCIvcHJvZHVjdC9cIiArIHNsdWcoY3VlbE9mZmVyc1tcInRpdGxlXCJdKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGEtZnVuYz1cImdldFByb21vQ29kZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImdldFByb21vQ29kZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGRhdGEtd2Vic2l0ZT17Jyd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRhcmdldD1cIl9ibGFua1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBgT2ZmZXJzQ29kZS5pbiAtIFByb21vIGNvZGUgZm9yIGAgK1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGN1ZWxPZmZlcnNbXCJjYW1wYWlnbl9uYW1lXCJdICtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBgIGRlYWwgYCArXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY3VlbE9mZmVyc1tcInRpdGxlXCJdXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVsPVwibm9mb2xsb3dcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBHZXQgVGhpcyBEZWFsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhyZWY9e1wiL3Byb2R1Y3QvXCIgKyBzbHVnKGN1ZWxPZmZlcnNbXCJ0aXRsZVwiXSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGFcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gaHJlZj17YC9nb3RvYH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YS11cmw9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiL3Byb2R1Y3QvXCIgKyBzbHVnKGN1ZWxPZmZlcnNbXCJ0aXRsZVwiXSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBkYXRhLXByb21vY29kZT17fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBkYXRhLXNwZWNpZXM9e31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gZGF0YS1wcm9tb2xpbms9e31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YS1mdW5jPVwiZ2V0RGVhbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImdldERlYWxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBkYXRhLXdlYnNpdGU9e31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGFyZ2V0PVwiX2JsYW5rXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gZ290b0xpbmsgPSB7dmFsdWVbMTFdfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWw9XCJub2ZvbGxvd1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEdldCBUaGlzIERlYWxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxiciAvPlxyXG4gICAgICAgICAgPGRpdiBpZD1cImFmc2NvbnRhaW5lcjFcIj48L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9zZWN0aW9uPlxyXG4gICAgKTtcclxuICB9IGVsc2Uge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPGRpdj5cclxuICAgICAgICA8YnIgLz5cclxuICAgICAgICA8YnIgLz5cclxuICAgICAgICA8YnIgLz5cclxuICAgICAgICA8aDM+Tm8gTmV3IERlYWxzIE9yIENvdXBvbnMgRm91bmQ8L2gzPlxyXG4gICAgICA8L2Rpdj5cclxuICAgICk7XHJcbiAgfVxyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgQ2FyZDtcclxuIl0sInNvdXJjZVJvb3QiOiIifQ==