webpackHotUpdate_N_E("pages/store/[slug]",{

/***/ "./pages/components/Offer/offerCards.js":
/*!**********************************************!*\
  !*** ./pages/components/Offer/offerCards.js ***!
  \**********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/head */ "./node_modules/next/head.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/router */ "./node_modules/next/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! lodash */ "./node_modules/lodash/lodash.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_6__);


var _jsxFileName = "C:\\xampp\\htdocs\\ReactTuts\\NextJS\\ofccode\\pages\\components\\Offer\\offerCards.js",
    _this = undefined,
    _s = $RefreshSig$();








var slug = __webpack_require__(/*! slug */ "./node_modules/slug/slug.js");

var getParsedDate = function getParsedDate(date) {
  return moment__WEBPACK_IMPORTED_MODULE_5___default()(date).startOf("hour").fromNow();
}; // const clickUrl = (target) => {
//   // http://localhost:3000/offers
//     if (typeof window !== "undefined") {
//     window.location.href = target;
//     }
// };


var Card = function Card(props) {
  _s();

  var router = Object(next_router__WEBPACK_IMPORTED_MODULE_3__["useRouter"])();
  var slug = router.query.slug; // Similar to componentDidMount and componentDidUpdate:

  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(function () {
    // <!-- other head elements from your page -->
    (function (g, o) {
      g[o] = g[o] || function () {
        (g[o]["q"] = g[o]["q"] || []).push(arguments);
      }, g[o]["t"] = 1 * new Date();
    })(window, "_googCsa");

    var pageOptions = {
      pubId: "pub-9616389000213823",
      // Make sure this the correct client ID!
      query: slug,
      adPage: 10,
      channel: "searchchnm"
    };
    var adblock1 = {
      container: "afscontainer1",
      linkTarget: "_blank",
      type: "ads",
      columns: 1,
      horizontalAlignment: "left",
      resultsPageQueryParam: "query",
      styleId: "6940738649",
      adLoadedCallback: null
    };
    var adblock2 = {
      container: "afscontainer2",
      linkTarget: "_blank",
      type: "ads",
      columns: 1,
      horizontalAlignment: "left",
      resultsPageQueryParam: "query",
      styleId: "6940738649",
      adLoadedCallback: null
    };

    _googCsa("ads", pageOptions, adblock1, adblock2);
  });
  var cuelinksOffers = props.cuelinksOffers ? props.cuelinksOffers : {};
  var store__logo = props.storeInfo ? props.storeInfo.slug : {};
  var store__name = props.storeInfo ? props.storeInfo.name : {};
  var limit = props.limit ? props.limit : {};

  if (cuelinksOffers) {
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("section", {
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_head__WEBPACK_IMPORTED_MODULE_2___default.a, {
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("script", {
          async: "async",
          src: "https://www.google.com/adsense/search/ads.js"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 77,
          columnNumber: 11
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("script", {
          async: true,
          src: "https://cse.google.com/cse.js?cx=39bed8f3de88a4885"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 81,
          columnNumber: 11
        }, _this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 76,
        columnNumber: 9
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "clearfix",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          id: "afscontainer1"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 88,
          columnNumber: 11
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 89,
          columnNumber: 11
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "clearfix",
          children: lodash__WEBPACK_IMPORTED_MODULE_4___default.a.map(cuelinksOffers, function (value, key) {
            var promocodeCard = false;
            var cuelOffers = {};
            cuelOffers["title"] = value["title"];
            cuelOffers["merchant"] = value["merchant"];
            cuelOffers["id"] = value["id"];
            cuelOffers["categories"] = value["categories"];
            cuelOffers["description"] = value["description"];
            cuelOffers["coupon_code"] = value["coupon_code"];
            cuelOffers["url"] = value["url"];
            cuelOffers["start_date"] = value["start_date"];
            cuelOffers["end_date"] = value["end_date"];
            cuelOffers["offer_added_at"] = value["offer_added_at"];
            cuelOffers["image_url"] = value["image_url"];
            cuelOffers["campaign_name"] = value["campaign_name"];

            if (value["title"] !== "") {
              if (cuelOffers["coupon_code"] != "") {
                promocodeCard = true;
              }

              return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: key,
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "row",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                    className: "deal__card",
                    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                      className: "deal__discount",
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                        className: "deal__info",
                        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
                            src: "/stores__logo/" + cuelOffers["merchant"] + "-logo-small.jpg",
                            onError: function onError(e) {
                              e.target.onerror = null;
                              e.target.src = "/img-notfound.jpg";
                            },
                            alt: cuelOffers["title"]
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 119,
                            columnNumber: 31
                          }, _this), " "]
                        }, void 0, true, {
                          fileName: _jsxFileName,
                          lineNumber: 118,
                          columnNumber: 29
                        }, _this)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 117,
                        columnNumber: 27
                      }, _this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 116,
                      columnNumber: 25
                    }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                      className: "deal__desc",
                      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                        className: "deal__desc-type"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 135,
                        columnNumber: 27
                      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                        className: "deal__desc-title",
                        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h3", {
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_6___default.a, {
                            href: "/product/" + slug(cuelOffers["title"]),
                            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                              "data-url": "/product/" + slug(cuelOffers["title"]),
                              "data-promolink": "/product/" + slug(cuelOffers["title"]),
                              "data-func": "getPromoCode",
                              className: "getPromoCode",
                              target: "_blank",
                              title: "OffersCode.in - Promo code for " + cuelOffers["campaign_name"] + " deal " + cuelOffers["title"],
                              rel: "nofollow",
                              children: [cuelOffers["merchant"], " :", " ", cuelOffers["title"]]
                            }, void 0, true, {
                              fileName: _jsxFileName,
                              lineNumber: 141,
                              columnNumber: 33
                            }, _this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 138,
                            columnNumber: 31
                          }, _this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 137,
                          columnNumber: 29
                        }, _this)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 136,
                        columnNumber: 27
                      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                        className: "deal__desc-meta",
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                          className: "deal__desc-meta-lastused",
                          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
                            className: "fa fa-users"
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 167,
                            columnNumber: 31
                          }, _this), "\xA0", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("b", {
                            children: Math.floor(Math.random() * 200) + 11
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 168,
                            columnNumber: 31
                          }, _this), " ", "People Used Today"]
                        }, void 0, true, {
                          fileName: _jsxFileName,
                          lineNumber: 166,
                          columnNumber: 29
                        }, _this), "\xA0|\xA0", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                          className: "deal__desc-meta-lastused",
                          children: cuelOffers["categories"]
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 172,
                          columnNumber: 29
                        }, _this)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 165,
                        columnNumber: 27
                      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                        className: "deal__cta",
                        children: promocodeCard ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_6___default.a, {
                            href: "/product/" + slug(cuelOffers["title"]),
                            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                              "data-url": "/product/" + slug(cuelOffers["title"]) // data-promocode={''}
                              // data-species={''}
                              ,
                              "data-promolink": "/product/" + slug(cuelOffers["title"]),
                              "data-func": "getPromoCode",
                              className: "getPromoCode" // data-website={''}
                              ,
                              target: "_blank",
                              title: "OffersCode.in - Promo code for " + cuelOffers["campaign_name"] + " deal " + cuelOffers["title"],
                              rel: "nofollow",
                              children: "Get This Deal"
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 183,
                              columnNumber: 35
                            }, _this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 180,
                            columnNumber: 33
                          }, _this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 179,
                          columnNumber: 31
                        }, _this) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_6___default.a, {
                            href: "/product/" + slug(cuelOffers["title"]),
                            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                              // href={`/goto`}
                              "data-url": "/product/" + slug(cuelOffers["title"]) // data-promocode={}
                              // data-species={}
                              // data-promolink={}
                              ,
                              "data-func": "getDeal",
                              className: "getDeal" // data-website={}
                              ,
                              target: "_blank" // gotoLink = {value[11]}
                              ,
                              rel: "nofollow",
                              children: "Get This Deal"
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 213,
                              columnNumber: 35
                            }, _this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 210,
                            columnNumber: 33
                          }, _this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 209,
                          columnNumber: 31
                        }, _this)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 177,
                        columnNumber: 27
                      }, _this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 134,
                      columnNumber: 25
                    }, _this)]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 115,
                    columnNumber: 23
                  }, _this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 114,
                  columnNumber: 21
                }, _this)
              }, key, false, {
                fileName: _jsxFileName,
                lineNumber: 113,
                columnNumber: 19
              }, _this);
            }
          })
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 91,
          columnNumber: 11
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 242,
          columnNumber: 11
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          id: "afscontainer1"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 243,
          columnNumber: 11
        }, _this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 87,
        columnNumber: 9
      }, _this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 75,
      columnNumber: 7
    }, _this);
  } else {
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 250,
        columnNumber: 9
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 251,
        columnNumber: 9
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 252,
        columnNumber: 9
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h3", {
        children: "No New Deals Or Coupons Found"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 253,
        columnNumber: 9
      }, _this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 249,
      columnNumber: 7
    }, _this);
  }
};

_s(Card, "vQduR7x+OPXj6PSmJyFnf+hU7bg=", false, function () {
  return [next_router__WEBPACK_IMPORTED_MODULE_3__["useRouter"]];
});

_c = Card;
/* harmony default export */ __webpack_exports__["default"] = (Card);

var _c;

$RefreshReg$(_c, "Card");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvY29tcG9uZW50cy9PZmZlci9vZmZlckNhcmRzLmpzIl0sIm5hbWVzIjpbInNsdWciLCJyZXF1aXJlIiwiZ2V0UGFyc2VkRGF0ZSIsImRhdGUiLCJNb21lbnQiLCJzdGFydE9mIiwiZnJvbU5vdyIsIkNhcmQiLCJwcm9wcyIsInJvdXRlciIsInVzZVJvdXRlciIsInF1ZXJ5IiwidXNlRWZmZWN0IiwiZyIsIm8iLCJwdXNoIiwiYXJndW1lbnRzIiwiRGF0ZSIsIndpbmRvdyIsInBhZ2VPcHRpb25zIiwicHViSWQiLCJhZFBhZ2UiLCJjaGFubmVsIiwiYWRibG9jazEiLCJjb250YWluZXIiLCJsaW5rVGFyZ2V0IiwidHlwZSIsImNvbHVtbnMiLCJob3Jpem9udGFsQWxpZ25tZW50IiwicmVzdWx0c1BhZ2VRdWVyeVBhcmFtIiwic3R5bGVJZCIsImFkTG9hZGVkQ2FsbGJhY2siLCJhZGJsb2NrMiIsIl9nb29nQ3NhIiwiY3VlbGlua3NPZmZlcnMiLCJzdG9yZV9fbG9nbyIsInN0b3JlSW5mbyIsInN0b3JlX19uYW1lIiwibmFtZSIsImxpbWl0IiwiXyIsIm1hcCIsInZhbHVlIiwia2V5IiwicHJvbW9jb2RlQ2FyZCIsImN1ZWxPZmZlcnMiLCJlIiwidGFyZ2V0Iiwib25lcnJvciIsInNyYyIsIk1hdGgiLCJmbG9vciIsInJhbmRvbSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQSxJQUFJQSxJQUFJLEdBQUdDLG1CQUFPLENBQUMseUNBQUQsQ0FBbEI7O0FBRUEsSUFBTUMsYUFBYSxHQUFHLFNBQWhCQSxhQUFnQixDQUFDQyxJQUFELEVBQVU7QUFDOUIsU0FBT0MsNkNBQU0sQ0FBQ0QsSUFBRCxDQUFOLENBQWFFLE9BQWIsQ0FBcUIsTUFBckIsRUFBNkJDLE9BQTdCLEVBQVA7QUFDRCxDQUZELEMsQ0FJQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUVBLElBQU1DLElBQUksR0FBRyxTQUFQQSxJQUFPLENBQUNDLEtBQUQsRUFBVztBQUFBOztBQUN0QixNQUFNQyxNQUFNLEdBQUdDLDZEQUFTLEVBQXhCO0FBRHNCLE1BRWRWLElBRmMsR0FFTFMsTUFBTSxDQUFDRSxLQUZGLENBRWRYLElBRmMsRUFHdEI7O0FBQ0FZLHlEQUFTLENBQUMsWUFBTTtBQUNkO0FBRUEsS0FBQyxVQUFVQyxDQUFWLEVBQWFDLENBQWIsRUFBZ0I7QUFDZEQsT0FBQyxDQUFDQyxDQUFELENBQUQsR0FDQ0QsQ0FBQyxDQUFDQyxDQUFELENBQUQsSUFDQSxZQUFZO0FBQ1YsU0FBQ0QsQ0FBQyxDQUFDQyxDQUFELENBQUQsQ0FBSyxHQUFMLElBQVlELENBQUMsQ0FBQ0MsQ0FBRCxDQUFELENBQUssR0FBTCxLQUFhLEVBQTFCLEVBQThCQyxJQUE5QixDQUFtQ0MsU0FBbkM7QUFDRCxPQUpILEVBS0dILENBQUMsQ0FBQ0MsQ0FBRCxDQUFELENBQUssR0FBTCxJQUFZLElBQUksSUFBSUcsSUFBSixFQUxuQjtBQU1ELEtBUEQsRUFPR0MsTUFQSCxFQU9XLFVBUFg7O0FBU0EsUUFBSUMsV0FBVyxHQUFHO0FBQ2hCQyxXQUFLLEVBQUUsc0JBRFM7QUFDZTtBQUMvQlQsV0FBSyxFQUFFWCxJQUZTO0FBR2hCcUIsWUFBTSxFQUFFLEVBSFE7QUFJaEJDLGFBQU8sRUFBRTtBQUpPLEtBQWxCO0FBT0EsUUFBSUMsUUFBUSxHQUFHO0FBQ2JDLGVBQVMsRUFBRSxlQURFO0FBRWJDLGdCQUFVLEVBQUUsUUFGQztBQUdiQyxVQUFJLEVBQUUsS0FITztBQUliQyxhQUFPLEVBQUUsQ0FKSTtBQUtiQyx5QkFBbUIsRUFBRSxNQUxSO0FBTWJDLDJCQUFxQixFQUFFLE9BTlY7QUFPYkMsYUFBTyxFQUFFLFlBUEk7QUFRYkMsc0JBQWdCLEVBQUU7QUFSTCxLQUFmO0FBV0EsUUFBSUMsUUFBUSxHQUFHO0FBQ2JSLGVBQVMsRUFBRSxlQURFO0FBRWJDLGdCQUFVLEVBQUUsUUFGQztBQUdiQyxVQUFJLEVBQUUsS0FITztBQUliQyxhQUFPLEVBQUUsQ0FKSTtBQUtiQyx5QkFBbUIsRUFBRSxNQUxSO0FBTWJDLDJCQUFxQixFQUFFLE9BTlY7QUFPYkMsYUFBTyxFQUFFLFlBUEk7QUFRYkMsc0JBQWdCLEVBQUU7QUFSTCxLQUFmOztBQVdBRSxZQUFRLENBQUMsS0FBRCxFQUFRZCxXQUFSLEVBQXFCSSxRQUFyQixFQUErQlMsUUFBL0IsQ0FBUjtBQUNELEdBMUNRLENBQVQ7QUE0Q0EsTUFBTUUsY0FBYyxHQUFHMUIsS0FBSyxDQUFDMEIsY0FBTixHQUF1QjFCLEtBQUssQ0FBQzBCLGNBQTdCLEdBQThDLEVBQXJFO0FBQ0EsTUFBTUMsV0FBVyxHQUFHM0IsS0FBSyxDQUFDNEIsU0FBTixHQUFrQjVCLEtBQUssQ0FBQzRCLFNBQU4sQ0FBZ0JwQyxJQUFsQyxHQUF5QyxFQUE3RDtBQUNBLE1BQU1xQyxXQUFXLEdBQUc3QixLQUFLLENBQUM0QixTQUFOLEdBQWtCNUIsS0FBSyxDQUFDNEIsU0FBTixDQUFnQkUsSUFBbEMsR0FBeUMsRUFBN0Q7QUFDQSxNQUFNQyxLQUFLLEdBQUcvQixLQUFLLENBQUMrQixLQUFOLEdBQWMvQixLQUFLLENBQUMrQixLQUFwQixHQUE0QixFQUExQzs7QUFFQSxNQUFJTCxjQUFKLEVBQW9CO0FBQ2xCLHdCQUNFO0FBQUEsOEJBQ0UscUVBQUMsZ0RBQUQ7QUFBQSxnQ0FDRTtBQUNFLGVBQUssRUFBQyxPQURSO0FBRUUsYUFBRyxFQUFDO0FBRk47QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFERixlQUtFO0FBQ0UsZUFBSyxNQURQO0FBRUUsYUFBRyxFQUFDO0FBRk47QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERixlQVlFO0FBQUssaUJBQVMsRUFBQyxVQUFmO0FBQUEsZ0NBQ0U7QUFBSyxZQUFFLEVBQUM7QUFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURGLGVBRUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFGRixlQUlFO0FBQUssbUJBQVMsRUFBQyxVQUFmO0FBQUEsb0JBQ0dNLDZDQUFDLENBQUNDLEdBQUYsQ0FBTVAsY0FBTixFQUFzQixVQUFDUSxLQUFELEVBQVFDLEdBQVIsRUFBZ0I7QUFDckMsZ0JBQUlDLGFBQWEsR0FBRyxLQUFwQjtBQUNBLGdCQUFJQyxVQUFVLEdBQUcsRUFBakI7QUFDQUEsc0JBQVUsQ0FBQyxPQUFELENBQVYsR0FBc0JILEtBQUssQ0FBQyxPQUFELENBQTNCO0FBQ0FHLHNCQUFVLENBQUMsVUFBRCxDQUFWLEdBQXlCSCxLQUFLLENBQUMsVUFBRCxDQUE5QjtBQUNBRyxzQkFBVSxDQUFDLElBQUQsQ0FBVixHQUFtQkgsS0FBSyxDQUFDLElBQUQsQ0FBeEI7QUFDQUcsc0JBQVUsQ0FBQyxZQUFELENBQVYsR0FBMkJILEtBQUssQ0FBQyxZQUFELENBQWhDO0FBQ0FHLHNCQUFVLENBQUMsYUFBRCxDQUFWLEdBQTRCSCxLQUFLLENBQUMsYUFBRCxDQUFqQztBQUNBRyxzQkFBVSxDQUFDLGFBQUQsQ0FBVixHQUE0QkgsS0FBSyxDQUFDLGFBQUQsQ0FBakM7QUFDQUcsc0JBQVUsQ0FBQyxLQUFELENBQVYsR0FBb0JILEtBQUssQ0FBQyxLQUFELENBQXpCO0FBQ0FHLHNCQUFVLENBQUMsWUFBRCxDQUFWLEdBQTJCSCxLQUFLLENBQUMsWUFBRCxDQUFoQztBQUNBRyxzQkFBVSxDQUFDLFVBQUQsQ0FBVixHQUF5QkgsS0FBSyxDQUFDLFVBQUQsQ0FBOUI7QUFDQUcsc0JBQVUsQ0FBQyxnQkFBRCxDQUFWLEdBQStCSCxLQUFLLENBQUMsZ0JBQUQsQ0FBcEM7QUFDQUcsc0JBQVUsQ0FBQyxXQUFELENBQVYsR0FBMEJILEtBQUssQ0FBQyxXQUFELENBQS9CO0FBQ0FHLHNCQUFVLENBQUMsZUFBRCxDQUFWLEdBQThCSCxLQUFLLENBQUMsZUFBRCxDQUFuQzs7QUFFQSxnQkFBSUEsS0FBSyxDQUFDLE9BQUQsQ0FBTCxLQUFtQixFQUF2QixFQUEyQjtBQUN6QixrQkFBSUcsVUFBVSxDQUFDLGFBQUQsQ0FBVixJQUE2QixFQUFqQyxFQUFxQztBQUNuQ0QsNkJBQWEsR0FBRyxJQUFoQjtBQUNEOztBQUNELGtDQUNFO0FBQWUseUJBQVMsRUFBRUQsR0FBMUI7QUFBQSx1Q0FDRTtBQUFLLDJCQUFTLEVBQUMsS0FBZjtBQUFBLHlDQUNFO0FBQUssNkJBQVMsRUFBQyxZQUFmO0FBQUEsNENBQ0U7QUFBSywrQkFBUyxFQUFDLGdCQUFmO0FBQUEsNkNBQ0U7QUFBSyxpQ0FBUyxFQUFDLFlBQWY7QUFBQSwrQ0FDRTtBQUFBLGtEQUNFO0FBQ0UsK0JBQUcsRUFDRCxtQkFDQUUsVUFBVSxDQUFDLFVBQUQsQ0FEVixvQkFGSjtBQU1FLG1DQUFPLEVBQUUsaUJBQUNDLENBQUQsRUFBTztBQUNkQSwrQkFBQyxDQUFDQyxNQUFGLENBQVNDLE9BQVQsR0FBbUIsSUFBbkI7QUFDQUYsK0JBQUMsQ0FBQ0MsTUFBRixDQUFTRSxHQUFULEdBQWUsbUJBQWY7QUFDRCw2QkFUSDtBQVVFLCtCQUFHLEVBQUVKLFVBQVUsQ0FBQyxPQUFEO0FBVmpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBREYsRUFZSyxHQVpMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQURGLGVBbUJFO0FBQUssK0JBQVMsRUFBQyxZQUFmO0FBQUEsOENBQ0U7QUFBSyxpQ0FBUyxFQUFDO0FBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFERixlQUVFO0FBQUssaUNBQVMsRUFBQyxrQkFBZjtBQUFBLCtDQUNFO0FBQUEsaURBQ0UscUVBQUMsZ0RBQUQ7QUFDRSxnQ0FBSSxFQUFFLGNBQWM3QyxJQUFJLENBQUM2QyxVQUFVLENBQUMsT0FBRCxDQUFYLENBRDFCO0FBQUEsbURBR0U7QUFDRSwwQ0FDRSxjQUFjN0MsSUFBSSxDQUFDNkMsVUFBVSxDQUFDLE9BQUQsQ0FBWCxDQUZ0QjtBQUlFLGdEQUNFLGNBQWM3QyxJQUFJLENBQUM2QyxVQUFVLENBQUMsT0FBRCxDQUFYLENBTHRCO0FBT0UsMkNBQVUsY0FQWjtBQVFFLHVDQUFTLEVBQUMsY0FSWjtBQVNFLG9DQUFNLEVBQUMsUUFUVDtBQVVFLG1DQUFLLEVBQ0gsb0NBQ0FBLFVBQVUsQ0FBQyxlQUFELENBRFYsY0FHQUEsVUFBVSxDQUFDLE9BQUQsQ0FkZDtBQWdCRSxpQ0FBRyxFQUFDLFVBaEJOO0FBQUEseUNBa0JHQSxVQUFVLENBQUMsVUFBRCxDQWxCYixRQWtCNkIsR0FsQjdCLEVBbUJHQSxVQUFVLENBQUMsT0FBRCxDQW5CYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFIRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBRkYsZUErQkU7QUFBSyxpQ0FBUyxFQUFDLGlCQUFmO0FBQUEsZ0RBQ0U7QUFBTSxtQ0FBUyxFQUFDLDBCQUFoQjtBQUFBLGtEQUNFO0FBQUcscUNBQVMsRUFBQztBQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBREYsdUJBRUU7QUFBQSxzQ0FBSUssSUFBSSxDQUFDQyxLQUFMLENBQVdELElBQUksQ0FBQ0UsTUFBTCxLQUFnQixHQUEzQixJQUFrQztBQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQUZGLEVBRWdELEdBRmhEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FERiw0QkFPRTtBQUFNLG1DQUFTLEVBQUMsMEJBQWhCO0FBQUEsb0NBQ0dQLFVBQVUsQ0FBQyxZQUFEO0FBRGI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBL0JGLGVBMkNFO0FBQUssaUNBQVMsRUFBQyxXQUFmO0FBQUEsa0NBQ0dELGFBQWEsZ0JBQ1o7QUFBQSxpREFDRSxxRUFBQyxnREFBRDtBQUNFLGdDQUFJLEVBQUUsY0FBYzVDLElBQUksQ0FBQzZDLFVBQVUsQ0FBQyxPQUFELENBQVgsQ0FEMUI7QUFBQSxtREFHRTtBQUNFLDBDQUNFLGNBQWM3QyxJQUFJLENBQUM2QyxVQUFVLENBQUMsT0FBRCxDQUFYLENBRnRCLENBSUU7QUFDQTtBQUxGO0FBTUUsZ0RBQ0UsY0FBYzdDLElBQUksQ0FBQzZDLFVBQVUsQ0FBQyxPQUFELENBQVgsQ0FQdEI7QUFTRSwyQ0FBVSxjQVRaO0FBVUUsdUNBQVMsRUFBQyxjQVZaLENBV0U7QUFYRjtBQVlFLG9DQUFNLEVBQUMsUUFaVDtBQWFFLG1DQUFLLEVBQ0gsb0NBQ0FBLFVBQVUsQ0FBQyxlQUFELENBRFYsY0FHQUEsVUFBVSxDQUFDLE9BQUQsQ0FqQmQ7QUFtQkUsaUNBQUcsRUFBQyxVQW5CTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQURZLGdCQStCWjtBQUFBLGlEQUNFLHFFQUFDLGdEQUFEO0FBQ0UsZ0NBQUksRUFBRSxjQUFjN0MsSUFBSSxDQUFDNkMsVUFBVSxDQUFDLE9BQUQsQ0FBWCxDQUQxQjtBQUFBLG1EQUdFO0FBQ0U7QUFDQSwwQ0FDRSxjQUFjN0MsSUFBSSxDQUFDNkMsVUFBVSxDQUFDLE9BQUQsQ0FBWCxDQUh0QixDQUtFO0FBQ0E7QUFDQTtBQVBGO0FBUUUsMkNBQVUsU0FSWjtBQVNFLHVDQUFTLEVBQUMsU0FUWixDQVVFO0FBVkY7QUFXRSxvQ0FBTSxFQUFDLFFBWFQsQ0FZRTtBQVpGO0FBYUUsaUNBQUcsRUFBQyxVQWJOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFoQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkEzQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREYsaUJBQVVGLEdBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFERjtBQStIRDtBQUNGLFdBcEpBO0FBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFKRixlQTJKRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTNKRixlQTRKRTtBQUFLLFlBQUUsRUFBQztBQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBNUpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQURGO0FBNktELEdBOUtELE1BOEtPO0FBQ0wsd0JBQ0U7QUFBQSw4QkFDRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREYsZUFFRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRkYsZUFHRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBSEYsZUFJRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQURGO0FBUUQ7QUFDRixDQTdPRDs7R0FBTXBDLEk7VUFDV0cscUQ7OztLQURYSCxJO0FBK09TQSxtRUFBZiIsImZpbGUiOiJzdGF0aWMvd2VicGFjay9wYWdlcy9zdG9yZS9bc2x1Z10uODc0NDUwZmRhM2I4NDUzYmZjZWEuaG90LXVwZGF0ZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyBDb21wb25lbnQsIHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IEhlYWQgZnJvbSBcIm5leHQvaGVhZFwiO1xyXG5pbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tIFwibmV4dC9yb3V0ZXJcIjtcclxuaW1wb3J0IF8gZnJvbSBcImxvZGFzaFwiO1xyXG5pbXBvcnQgTW9tZW50IGZyb20gXCJtb21lbnRcIjtcclxuaW1wb3J0IExpbmsgZnJvbSBcIm5leHQvbGlua1wiO1xyXG52YXIgc2x1ZyA9IHJlcXVpcmUoXCJzbHVnXCIpO1xyXG5cclxuY29uc3QgZ2V0UGFyc2VkRGF0ZSA9IChkYXRlKSA9PiB7XHJcbiAgcmV0dXJuIE1vbWVudChkYXRlKS5zdGFydE9mKFwiaG91clwiKS5mcm9tTm93KCk7XHJcbn07XHJcblxyXG4vLyBjb25zdCBjbGlja1VybCA9ICh0YXJnZXQpID0+IHtcclxuLy8gICAvLyBodHRwOi8vbG9jYWxob3N0OjMwMDAvb2ZmZXJzXHJcbi8vICAgICBpZiAodHlwZW9mIHdpbmRvdyAhPT0gXCJ1bmRlZmluZWRcIikge1xyXG4vLyAgICAgd2luZG93LmxvY2F0aW9uLmhyZWYgPSB0YXJnZXQ7XHJcbi8vICAgICB9XHJcbi8vIH07XHJcblxyXG5jb25zdCBDYXJkID0gKHByb3BzKSA9PiB7XHJcbiAgY29uc3Qgcm91dGVyID0gdXNlUm91dGVyKCk7XHJcbiAgY29uc3QgeyBzbHVnIH0gPSByb3V0ZXIucXVlcnk7XHJcbiAgLy8gU2ltaWxhciB0byBjb21wb25lbnREaWRNb3VudCBhbmQgY29tcG9uZW50RGlkVXBkYXRlOlxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICAvLyA8IS0tIG90aGVyIGhlYWQgZWxlbWVudHMgZnJvbSB5b3VyIHBhZ2UgLS0+XHJcblxyXG4gICAgKGZ1bmN0aW9uIChnLCBvKSB7XHJcbiAgICAgIChnW29dID1cclxuICAgICAgICBnW29dIHx8XHJcbiAgICAgICAgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgKGdbb11bXCJxXCJdID0gZ1tvXVtcInFcIl0gfHwgW10pLnB1c2goYXJndW1lbnRzKTtcclxuICAgICAgICB9KSxcclxuICAgICAgICAoZ1tvXVtcInRcIl0gPSAxICogbmV3IERhdGUoKSk7XHJcbiAgICB9KSh3aW5kb3csIFwiX2dvb2dDc2FcIik7XHJcblxyXG4gICAgdmFyIHBhZ2VPcHRpb25zID0ge1xyXG4gICAgICBwdWJJZDogXCJwdWItOTYxNjM4OTAwMDIxMzgyM1wiLCAvLyBNYWtlIHN1cmUgdGhpcyB0aGUgY29ycmVjdCBjbGllbnQgSUQhXHJcbiAgICAgIHF1ZXJ5OiBzbHVnLFxyXG4gICAgICBhZFBhZ2U6IDEwLFxyXG4gICAgICBjaGFubmVsOiBcInNlYXJjaGNobm1cIixcclxuICAgIH07XHJcblxyXG4gICAgdmFyIGFkYmxvY2sxID0ge1xyXG4gICAgICBjb250YWluZXI6IFwiYWZzY29udGFpbmVyMVwiLFxyXG4gICAgICBsaW5rVGFyZ2V0OiBcIl9ibGFua1wiLFxyXG4gICAgICB0eXBlOiBcImFkc1wiLFxyXG4gICAgICBjb2x1bW5zOiAxLFxyXG4gICAgICBob3Jpem9udGFsQWxpZ25tZW50OiBcImxlZnRcIixcclxuICAgICAgcmVzdWx0c1BhZ2VRdWVyeVBhcmFtOiBcInF1ZXJ5XCIsXHJcbiAgICAgIHN0eWxlSWQ6IFwiNjk0MDczODY0OVwiLFxyXG4gICAgICBhZExvYWRlZENhbGxiYWNrOiBudWxsLFxyXG4gICAgfTtcclxuXHJcbiAgICB2YXIgYWRibG9jazIgPSB7XHJcbiAgICAgIGNvbnRhaW5lcjogXCJhZnNjb250YWluZXIyXCIsXHJcbiAgICAgIGxpbmtUYXJnZXQ6IFwiX2JsYW5rXCIsXHJcbiAgICAgIHR5cGU6IFwiYWRzXCIsXHJcbiAgICAgIGNvbHVtbnM6IDEsXHJcbiAgICAgIGhvcml6b250YWxBbGlnbm1lbnQ6IFwibGVmdFwiLFxyXG4gICAgICByZXN1bHRzUGFnZVF1ZXJ5UGFyYW06IFwicXVlcnlcIixcclxuICAgICAgc3R5bGVJZDogXCI2OTQwNzM4NjQ5XCIsXHJcbiAgICAgIGFkTG9hZGVkQ2FsbGJhY2s6IG51bGwsXHJcbiAgICB9O1xyXG5cclxuICAgIF9nb29nQ3NhKFwiYWRzXCIsIHBhZ2VPcHRpb25zLCBhZGJsb2NrMSwgYWRibG9jazIpO1xyXG4gIH0pO1xyXG5cclxuICBjb25zdCBjdWVsaW5rc09mZmVycyA9IHByb3BzLmN1ZWxpbmtzT2ZmZXJzID8gcHJvcHMuY3VlbGlua3NPZmZlcnMgOiB7fTtcclxuICBjb25zdCBzdG9yZV9fbG9nbyA9IHByb3BzLnN0b3JlSW5mbyA/IHByb3BzLnN0b3JlSW5mby5zbHVnIDoge307XHJcbiAgY29uc3Qgc3RvcmVfX25hbWUgPSBwcm9wcy5zdG9yZUluZm8gPyBwcm9wcy5zdG9yZUluZm8ubmFtZSA6IHt9O1xyXG4gIGNvbnN0IGxpbWl0ID0gcHJvcHMubGltaXQgPyBwcm9wcy5saW1pdCA6IHt9O1xyXG5cclxuICBpZiAoY3VlbGlua3NPZmZlcnMpIHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxzZWN0aW9uPlxyXG4gICAgICAgIDxIZWFkPlxyXG4gICAgICAgICAgPHNjcmlwdFxyXG4gICAgICAgICAgICBhc3luYz1cImFzeW5jXCJcclxuICAgICAgICAgICAgc3JjPVwiaHR0cHM6Ly93d3cuZ29vZ2xlLmNvbS9hZHNlbnNlL3NlYXJjaC9hZHMuanNcIlxyXG4gICAgICAgICAgPjwvc2NyaXB0PlxyXG4gICAgICAgICAgPHNjcmlwdFxyXG4gICAgICAgICAgICBhc3luY1xyXG4gICAgICAgICAgICBzcmM9XCJodHRwczovL2NzZS5nb29nbGUuY29tL2NzZS5qcz9jeD0zOWJlZDhmM2RlODhhNDg4NVwiXHJcbiAgICAgICAgICA+PC9zY3JpcHQ+XHJcbiAgICAgICAgPC9IZWFkPlxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNsZWFyZml4XCI+XHJcbiAgICAgICAgICA8ZGl2IGlkPVwiYWZzY29udGFpbmVyMVwiPjwvZGl2PlxyXG4gICAgICAgICAgPGJyIC8+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjbGVhcmZpeFwiPlxyXG4gICAgICAgICAgICB7Xy5tYXAoY3VlbGlua3NPZmZlcnMsICh2YWx1ZSwga2V5KSA9PiB7XHJcbiAgICAgICAgICAgICAgbGV0IHByb21vY29kZUNhcmQgPSBmYWxzZTtcclxuICAgICAgICAgICAgICBsZXQgY3VlbE9mZmVycyA9IHt9O1xyXG4gICAgICAgICAgICAgIGN1ZWxPZmZlcnNbXCJ0aXRsZVwiXSA9IHZhbHVlW1widGl0bGVcIl07XHJcbiAgICAgICAgICAgICAgY3VlbE9mZmVyc1tcIm1lcmNoYW50XCJdID0gdmFsdWVbXCJtZXJjaGFudFwiXTtcclxuICAgICAgICAgICAgICBjdWVsT2ZmZXJzW1wiaWRcIl0gPSB2YWx1ZVtcImlkXCJdO1xyXG4gICAgICAgICAgICAgIGN1ZWxPZmZlcnNbXCJjYXRlZ29yaWVzXCJdID0gdmFsdWVbXCJjYXRlZ29yaWVzXCJdO1xyXG4gICAgICAgICAgICAgIGN1ZWxPZmZlcnNbXCJkZXNjcmlwdGlvblwiXSA9IHZhbHVlW1wiZGVzY3JpcHRpb25cIl07XHJcbiAgICAgICAgICAgICAgY3VlbE9mZmVyc1tcImNvdXBvbl9jb2RlXCJdID0gdmFsdWVbXCJjb3Vwb25fY29kZVwiXTtcclxuICAgICAgICAgICAgICBjdWVsT2ZmZXJzW1widXJsXCJdID0gdmFsdWVbXCJ1cmxcIl07XHJcbiAgICAgICAgICAgICAgY3VlbE9mZmVyc1tcInN0YXJ0X2RhdGVcIl0gPSB2YWx1ZVtcInN0YXJ0X2RhdGVcIl07XHJcbiAgICAgICAgICAgICAgY3VlbE9mZmVyc1tcImVuZF9kYXRlXCJdID0gdmFsdWVbXCJlbmRfZGF0ZVwiXTtcclxuICAgICAgICAgICAgICBjdWVsT2ZmZXJzW1wib2ZmZXJfYWRkZWRfYXRcIl0gPSB2YWx1ZVtcIm9mZmVyX2FkZGVkX2F0XCJdO1xyXG4gICAgICAgICAgICAgIGN1ZWxPZmZlcnNbXCJpbWFnZV91cmxcIl0gPSB2YWx1ZVtcImltYWdlX3VybFwiXTtcclxuICAgICAgICAgICAgICBjdWVsT2ZmZXJzW1wiY2FtcGFpZ25fbmFtZVwiXSA9IHZhbHVlW1wiY2FtcGFpZ25fbmFtZVwiXTtcclxuXHJcbiAgICAgICAgICAgICAgaWYgKHZhbHVlW1widGl0bGVcIl0gIT09IFwiXCIpIHtcclxuICAgICAgICAgICAgICAgIGlmIChjdWVsT2ZmZXJzW1wiY291cG9uX2NvZGVcIl0gIT0gXCJcIikge1xyXG4gICAgICAgICAgICAgICAgICBwcm9tb2NvZGVDYXJkID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtrZXl9IGNsYXNzTmFtZT17a2V5fT5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvd1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkZWFsX19jYXJkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZGVhbF9fZGlzY291bnRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRlYWxfX2luZm9cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbWdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzcmM9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYC9zdG9yZXNfX2xvZ28vYCArXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjdWVsT2ZmZXJzW1wibWVyY2hhbnRcIl0gK1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYC1sb2dvLXNtYWxsLmpwZ2BcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25FcnJvcj17KGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGUudGFyZ2V0Lm9uZXJyb3IgPSBudWxsO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZS50YXJnZXQuc3JjID0gXCIvaW1nLW5vdGZvdW5kLmpwZ1wiO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWx0PXtjdWVsT2ZmZXJzW1widGl0bGVcIl19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRlYWxfX2Rlc2NcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRlYWxfX2Rlc2MtdHlwZVwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZGVhbF9fZGVzYy10aXRsZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgzPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhyZWY9e1wiL3Byb2R1Y3QvXCIgKyBzbHVnKGN1ZWxPZmZlcnNbXCJ0aXRsZVwiXSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YS11cmw9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIi9wcm9kdWN0L1wiICsgc2x1ZyhjdWVsT2ZmZXJzW1widGl0bGVcIl0pXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhLXByb21vbGluaz17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiL3Byb2R1Y3QvXCIgKyBzbHVnKGN1ZWxPZmZlcnNbXCJ0aXRsZVwiXSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGEtZnVuYz1cImdldFByb21vQ29kZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJnZXRQcm9tb0NvZGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGFyZ2V0PVwiX2JsYW5rXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYE9mZmVyc0NvZGUuaW4gLSBQcm9tbyBjb2RlIGZvciBgICtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY3VlbE9mZmVyc1tcImNhbXBhaWduX25hbWVcIl0gK1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBgIGRlYWwgYCArXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGN1ZWxPZmZlcnNbXCJ0aXRsZVwiXVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVsPVwibm9mb2xsb3dcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjdWVsT2ZmZXJzW1wibWVyY2hhbnRcIl19IDp7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y3VlbE9mZmVyc1tcInRpdGxlXCJdfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRlYWxfX2Rlc2MtbWV0YVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZGVhbF9fZGVzYy1tZXRhLWxhc3R1c2VkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpIGNsYXNzTmFtZT1cImZhIGZhLXVzZXJzXCI+PC9pPiZuYnNwO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Yj57TWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogMjAwKSArIDExfTwvYj57XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFBlb3BsZSBVc2VkIFRvZGF5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAmbmJzcDt8Jm5ic3A7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJkZWFsX19kZXNjLW1ldGEtbGFzdHVzZWRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2N1ZWxPZmZlcnNbXCJjYXRlZ29yaWVzXCJdfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRlYWxfX2N0YVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3Byb21vY29kZUNhcmQgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhyZWY9e1wiL3Byb2R1Y3QvXCIgKyBzbHVnKGN1ZWxPZmZlcnNbXCJ0aXRsZVwiXSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGFcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YS11cmw9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiL3Byb2R1Y3QvXCIgKyBzbHVnKGN1ZWxPZmZlcnNbXCJ0aXRsZVwiXSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBkYXRhLXByb21vY29kZT17Jyd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGRhdGEtc3BlY2llcz17Jyd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGEtcHJvbW9saW5rPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIi9wcm9kdWN0L1wiICsgc2x1ZyhjdWVsT2ZmZXJzW1widGl0bGVcIl0pXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YS1mdW5jPVwiZ2V0UHJvbW9Db2RlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZ2V0UHJvbW9Db2RlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gZGF0YS13ZWJzaXRlPXsnJ31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGFyZ2V0PVwiX2JsYW5rXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGBPZmZlcnNDb2RlLmluIC0gUHJvbW8gY29kZSBmb3IgYCArXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY3VlbE9mZmVyc1tcImNhbXBhaWduX25hbWVcIl0gK1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGAgZGVhbCBgICtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjdWVsT2ZmZXJzW1widGl0bGVcIl1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWw9XCJub2ZvbGxvd1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEdldCBUaGlzIERlYWxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaHJlZj17XCIvcHJvZHVjdC9cIiArIHNsdWcoY3VlbE9mZmVyc1tcInRpdGxlXCJdKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBocmVmPXtgL2dvdG9gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhLXVybD17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCIvcHJvZHVjdC9cIiArIHNsdWcoY3VlbE9mZmVyc1tcInRpdGxlXCJdKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGRhdGEtcHJvbW9jb2RlPXt9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGRhdGEtc3BlY2llcz17fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBkYXRhLXByb21vbGluaz17fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhLWZ1bmM9XCJnZXREZWFsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZ2V0RGVhbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGRhdGEtd2Vic2l0ZT17fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0YXJnZXQ9XCJfYmxhbmtcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBnb3RvTGluayA9IHt2YWx1ZVsxMV19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlbD1cIm5vZm9sbG93XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgR2V0IFRoaXMgRGVhbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9hPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGJyIC8+XHJcbiAgICAgICAgICA8ZGl2IGlkPVwiYWZzY29udGFpbmVyMVwiPjwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L3NlY3Rpb24+XHJcbiAgICApO1xyXG4gIH0gZWxzZSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8ZGl2PlxyXG4gICAgICAgIDxiciAvPlxyXG4gICAgICAgIDxiciAvPlxyXG4gICAgICAgIDxiciAvPlxyXG4gICAgICAgIDxoMz5ObyBOZXcgRGVhbHMgT3IgQ291cG9ucyBGb3VuZDwvaDM+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgKTtcclxuICB9XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBDYXJkO1xyXG4iXSwic291cmNlUm9vdCI6IiJ9