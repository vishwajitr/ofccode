webpackHotUpdate_N_E("pages/index",{

/***/ "./pages/components/Offer/offerCards.js":
/*!**********************************************!*\
  !*** ./pages/components/Offer/offerCards.js ***!
  \**********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/head */ "./node_modules/next/head.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/router */ "./node_modules/next/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! lodash */ "./node_modules/lodash/lodash.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_6__);


var _jsxFileName = "C:\\xampp\\htdocs\\ReactTuts\\NextJS\\ofccode\\pages\\components\\Offer\\offerCards.js",
    _this = undefined,
    _s = $RefreshSig$();








var slug = __webpack_require__(/*! slug */ "./node_modules/slug/slug.js");

var getParsedDate = function getParsedDate(date) {
  return moment__WEBPACK_IMPORTED_MODULE_5___default()(date).startOf("hour").fromNow();
}; // const clickUrl = (target) => {
//   // http://localhost:3000/offers
//     if (typeof window !== "undefined") {
//     window.location.href = target;
//     }
// };


var Card = function Card(props) {
  _s();

  var router = Object(next_router__WEBPACK_IMPORTED_MODULE_3__["useRouter"])();
  var slug = router.query.slug; // Similar to componentDidMount and componentDidUpdate:

  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(function () {
    // <!-- other head elements from your page -->
    (function (g, o) {
      g[o] = g[o] || function () {
        (g[o]["q"] = g[o]["q"] || []).push(arguments);
      }, g[o]["t"] = 1 * new Date();
    })(window, "_googCsa");

    var pageOptions = {
      pubId: "pub-9616389000213823",
      // Make sure this the correct client ID!
      query: slug,
      adPage: 10,
      channel: "searchchnm"
    };
    var adblock1 = {
      container: "afscontainer1",
      linkTarget: "_blank",
      type: "ads",
      columns: 1,
      horizontalAlignment: "left",
      resultsPageQueryParam: "query",
      styleId: "6940738649",
      adLoadedCallback: null
    };
    var adblock2 = {
      container: "afscontainer2",
      linkTarget: "_blank",
      type: "ads",
      columns: 1,
      horizontalAlignment: "left",
      resultsPageQueryParam: "query",
      styleId: "6940738649",
      adLoadedCallback: null
    };

    _googCsa("ads", pageOptions, adblock1, adblock2);
  });
  var cuelinksOffers = props.cuelinksOffers ? props.cuelinksOffers : {};
  var store__logo = props.storeInfo ? props.storeInfo.slug : {};
  var store__name = props.storeInfo ? props.storeInfo.name : {};
  var limit = props.limit ? props.limit : {};

  if (cuelinksOffers) {
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("section", {
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_head__WEBPACK_IMPORTED_MODULE_2___default.a, {
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("script", {
          async: "async",
          src: "https://www.google.com/adsense/search/ads.js"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 77,
          columnNumber: 11
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("script", {
          async: true,
          src: "https://cse.google.com/cse.js?cx=39bed8f3de88a4885"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 81,
          columnNumber: 11
        }, _this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 76,
        columnNumber: 9
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "clearfix",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          id: "afscontainer1"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 88,
          columnNumber: 11
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 89,
          columnNumber: 11
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "clearfix",
          children: lodash__WEBPACK_IMPORTED_MODULE_4___default.a.map(cuelinksOffers, function (value, key) {
            var promocodeCard = false;
            var cuelOffers = {};
            cuelOffers["title"] = value["title"];
            cuelOffers["merchant"] = value["merchant"];
            cuelOffers["id"] = value["id"];
            cuelOffers["categories"] = value["categories"];
            cuelOffers["description"] = value["description"];
            cuelOffers["coupon_code"] = value["coupon_code"];
            cuelOffers["url"] = value["url"];
            cuelOffers["start_date"] = value["start_date"];
            cuelOffers["end_date"] = value["end_date"];
            cuelOffers["offer_added_at"] = value["offer_added_at"];
            cuelOffers["image_url"] = value["image_url"];
            cuelOffers["campaign_name"] = value["campaign_name"];

            if (value["title"] !== "") {
              if (cuelOffers["coupon_code"] != "") {
                promocodeCard = true;
              }

              return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: key,
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "row",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                    className: "deal__card",
                    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                      className: "deal__discount",
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                        className: "deal__info",
                        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
                            src: "/stores__logo/" + cuelOffers["merchant"] + "-logo-small.jpg",
                            onError: function onError(e) {
                              e.target.onerror = null;
                              e.target.src = "/img-notfound.jpg";
                            },
                            alt: cuelOffers["title"]
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 119,
                            columnNumber: 31
                          }, _this), " "]
                        }, void 0, true, {
                          fileName: _jsxFileName,
                          lineNumber: 118,
                          columnNumber: 29
                        }, _this)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 117,
                        columnNumber: 27
                      }, _this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 116,
                      columnNumber: 25
                    }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                      className: "deal__desc",
                      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                        className: "deal__desc-type"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 135,
                        columnNumber: 27
                      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                        className: "deal__desc-title",
                        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h3", {
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_6___default.a, {
                            href: "/product/" + slug(cuelOffers["title"]),
                            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                              "data-url": "/product/" + slug(cuelOffers["title"]),
                              "data-promolink": "/product/" + slug(cuelOffers["title"]),
                              "data-func": "getPromoCode",
                              className: "getPromoCode",
                              target: "_blank",
                              title: "OffersCode.in - Promo code for " + cuelOffers["campaign_name"] + " deal " + cuelOffers["title"],
                              rel: "nofollow",
                              children: [cuelOffers["merchant"], " :", " ", cuelOffers["title"]]
                            }, void 0, true, {
                              fileName: _jsxFileName,
                              lineNumber: 141,
                              columnNumber: 33
                            }, _this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 138,
                            columnNumber: 31
                          }, _this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 137,
                          columnNumber: 29
                        }, _this)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 136,
                        columnNumber: 27
                      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                        className: "deal__desc-meta",
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                          className: "deal__desc-meta-lastused",
                          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
                            className: "fa fa-users"
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 167,
                            columnNumber: 31
                          }, _this), "\xA0", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("b", {
                            children: Math.floor(Math.random() * 200) + 11
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 168,
                            columnNumber: 31
                          }, _this), " ", "People Used Today"]
                        }, void 0, true, {
                          fileName: _jsxFileName,
                          lineNumber: 166,
                          columnNumber: 29
                        }, _this), "\xA0|\xA0", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                          className: "deal__desc-meta-lastused",
                          children: cuelOffers["categories"]
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 172,
                          columnNumber: 29
                        }, _this)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 165,
                        columnNumber: 27
                      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                        className: "deal__cta",
                        children: promocodeCard ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_6___default.a, {
                            href: "/product/" + slug(cuelOffers["title"]),
                            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                              "data-url": "/product/" + slug(cuelOffers["title"]) // data-promocode={''}
                              // data-species={''}
                              ,
                              "data-promolink": "/product/" + slug(cuelOffers["title"]),
                              "data-func": "getPromoCode",
                              className: "getPromoCode" // data-website={''}
                              ,
                              target: "_blank",
                              title: "OffersCode.in - Promo code for " + cuelOffers["campaign_name"] + " deal " + cuelOffers["title"],
                              rel: "nofollow",
                              children: "Get This Deal"
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 183,
                              columnNumber: 35
                            }, _this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 180,
                            columnNumber: 33
                          }, _this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 179,
                          columnNumber: 31
                        }, _this) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_6___default.a, {
                            href: "/product/" + slug(cuelOffers["title"]),
                            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                              // href={`/goto`}
                              "data-url": "/product/" + slug(cuelOffers["title"]) // data-promocode={}
                              // data-species={}
                              // data-promolink={}
                              ,
                              "data-func": "getDeal",
                              className: "getDeal" // data-website={}
                              ,
                              target: "_blank" // gotoLink = {value[11]}
                              ,
                              rel: "nofollow",
                              children: "Get This Deal"
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 213,
                              columnNumber: 35
                            }, _this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 210,
                            columnNumber: 33
                          }, _this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 209,
                          columnNumber: 31
                        }, _this)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 177,
                        columnNumber: 27
                      }, _this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 134,
                      columnNumber: 25
                    }, _this)]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 115,
                    columnNumber: 23
                  }, _this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 114,
                  columnNumber: 21
                }, _this)
              }, key, false, {
                fileName: _jsxFileName,
                lineNumber: 113,
                columnNumber: 19
              }, _this);
            }
          })
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 91,
          columnNumber: 11
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 242,
          columnNumber: 11
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          id: "afscontainer1"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 243,
          columnNumber: 11
        }, _this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 87,
        columnNumber: 9
      }, _this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 75,
      columnNumber: 7
    }, _this);
  } else {
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 250,
        columnNumber: 9
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 251,
        columnNumber: 9
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 252,
        columnNumber: 9
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h3", {
        children: "No New Deals Or Coupons Found"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 253,
        columnNumber: 9
      }, _this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 249,
      columnNumber: 7
    }, _this);
  }
};

_s(Card, "vQduR7x+OPXj6PSmJyFnf+hU7bg=", false, function () {
  return [next_router__WEBPACK_IMPORTED_MODULE_3__["useRouter"]];
});

_c = Card;
/* harmony default export */ __webpack_exports__["default"] = (Card);

var _c;

$RefreshReg$(_c, "Card");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvY29tcG9uZW50cy9PZmZlci9vZmZlckNhcmRzLmpzIl0sIm5hbWVzIjpbInNsdWciLCJyZXF1aXJlIiwiZ2V0UGFyc2VkRGF0ZSIsImRhdGUiLCJNb21lbnQiLCJzdGFydE9mIiwiZnJvbU5vdyIsIkNhcmQiLCJwcm9wcyIsInJvdXRlciIsInVzZVJvdXRlciIsInF1ZXJ5IiwidXNlRWZmZWN0IiwiZyIsIm8iLCJwdXNoIiwiYXJndW1lbnRzIiwiRGF0ZSIsIndpbmRvdyIsInBhZ2VPcHRpb25zIiwicHViSWQiLCJhZFBhZ2UiLCJjaGFubmVsIiwiYWRibG9jazEiLCJjb250YWluZXIiLCJsaW5rVGFyZ2V0IiwidHlwZSIsImNvbHVtbnMiLCJob3Jpem9udGFsQWxpZ25tZW50IiwicmVzdWx0c1BhZ2VRdWVyeVBhcmFtIiwic3R5bGVJZCIsImFkTG9hZGVkQ2FsbGJhY2siLCJhZGJsb2NrMiIsIl9nb29nQ3NhIiwiY3VlbGlua3NPZmZlcnMiLCJzdG9yZV9fbG9nbyIsInN0b3JlSW5mbyIsInN0b3JlX19uYW1lIiwibmFtZSIsImxpbWl0IiwiXyIsIm1hcCIsInZhbHVlIiwia2V5IiwicHJvbW9jb2RlQ2FyZCIsImN1ZWxPZmZlcnMiLCJlIiwidGFyZ2V0Iiwib25lcnJvciIsInNyYyIsIk1hdGgiLCJmbG9vciIsInJhbmRvbSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQSxJQUFJQSxJQUFJLEdBQUdDLG1CQUFPLENBQUMseUNBQUQsQ0FBbEI7O0FBRUEsSUFBTUMsYUFBYSxHQUFHLFNBQWhCQSxhQUFnQixDQUFDQyxJQUFELEVBQVU7QUFDOUIsU0FBT0MsNkNBQU0sQ0FBQ0QsSUFBRCxDQUFOLENBQWFFLE9BQWIsQ0FBcUIsTUFBckIsRUFBNkJDLE9BQTdCLEVBQVA7QUFDRCxDQUZELEMsQ0FJQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUVBLElBQU1DLElBQUksR0FBRyxTQUFQQSxJQUFPLENBQUNDLEtBQUQsRUFBVztBQUFBOztBQUN0QixNQUFNQyxNQUFNLEdBQUdDLDZEQUFTLEVBQXhCO0FBRHNCLE1BRWRWLElBRmMsR0FFTFMsTUFBTSxDQUFDRSxLQUZGLENBRWRYLElBRmMsRUFHdEI7O0FBQ0FZLHlEQUFTLENBQUMsWUFBTTtBQUNkO0FBRUEsS0FBQyxVQUFVQyxDQUFWLEVBQWFDLENBQWIsRUFBZ0I7QUFDZEQsT0FBQyxDQUFDQyxDQUFELENBQUQsR0FDQ0QsQ0FBQyxDQUFDQyxDQUFELENBQUQsSUFDQSxZQUFZO0FBQ1YsU0FBQ0QsQ0FBQyxDQUFDQyxDQUFELENBQUQsQ0FBSyxHQUFMLElBQVlELENBQUMsQ0FBQ0MsQ0FBRCxDQUFELENBQUssR0FBTCxLQUFhLEVBQTFCLEVBQThCQyxJQUE5QixDQUFtQ0MsU0FBbkM7QUFDRCxPQUpILEVBS0dILENBQUMsQ0FBQ0MsQ0FBRCxDQUFELENBQUssR0FBTCxJQUFZLElBQUksSUFBSUcsSUFBSixFQUxuQjtBQU1ELEtBUEQsRUFPR0MsTUFQSCxFQU9XLFVBUFg7O0FBU0EsUUFBSUMsV0FBVyxHQUFHO0FBQ2hCQyxXQUFLLEVBQUUsc0JBRFM7QUFDZTtBQUMvQlQsV0FBSyxFQUFFWCxJQUZTO0FBR2hCcUIsWUFBTSxFQUFFLEVBSFE7QUFJaEJDLGFBQU8sRUFBRTtBQUpPLEtBQWxCO0FBT0EsUUFBSUMsUUFBUSxHQUFHO0FBQ2JDLGVBQVMsRUFBRSxlQURFO0FBRWJDLGdCQUFVLEVBQUUsUUFGQztBQUdiQyxVQUFJLEVBQUUsS0FITztBQUliQyxhQUFPLEVBQUUsQ0FKSTtBQUtiQyx5QkFBbUIsRUFBRSxNQUxSO0FBTWJDLDJCQUFxQixFQUFFLE9BTlY7QUFPYkMsYUFBTyxFQUFFLFlBUEk7QUFRYkMsc0JBQWdCLEVBQUU7QUFSTCxLQUFmO0FBV0EsUUFBSUMsUUFBUSxHQUFHO0FBQ2JSLGVBQVMsRUFBRSxlQURFO0FBRWJDLGdCQUFVLEVBQUUsUUFGQztBQUdiQyxVQUFJLEVBQUUsS0FITztBQUliQyxhQUFPLEVBQUUsQ0FKSTtBQUtiQyx5QkFBbUIsRUFBRSxNQUxSO0FBTWJDLDJCQUFxQixFQUFFLE9BTlY7QUFPYkMsYUFBTyxFQUFFLFlBUEk7QUFRYkMsc0JBQWdCLEVBQUU7QUFSTCxLQUFmOztBQVdBRSxZQUFRLENBQUMsS0FBRCxFQUFRZCxXQUFSLEVBQXFCSSxRQUFyQixFQUErQlMsUUFBL0IsQ0FBUjtBQUNELEdBMUNRLENBQVQ7QUE0Q0EsTUFBTUUsY0FBYyxHQUFHMUIsS0FBSyxDQUFDMEIsY0FBTixHQUF1QjFCLEtBQUssQ0FBQzBCLGNBQTdCLEdBQThDLEVBQXJFO0FBQ0EsTUFBTUMsV0FBVyxHQUFHM0IsS0FBSyxDQUFDNEIsU0FBTixHQUFrQjVCLEtBQUssQ0FBQzRCLFNBQU4sQ0FBZ0JwQyxJQUFsQyxHQUF5QyxFQUE3RDtBQUNBLE1BQU1xQyxXQUFXLEdBQUc3QixLQUFLLENBQUM0QixTQUFOLEdBQWtCNUIsS0FBSyxDQUFDNEIsU0FBTixDQUFnQkUsSUFBbEMsR0FBeUMsRUFBN0Q7QUFDQSxNQUFNQyxLQUFLLEdBQUcvQixLQUFLLENBQUMrQixLQUFOLEdBQWMvQixLQUFLLENBQUMrQixLQUFwQixHQUE0QixFQUExQzs7QUFFQSxNQUFJTCxjQUFKLEVBQW9CO0FBQ2xCLHdCQUNFO0FBQUEsOEJBQ0UscUVBQUMsZ0RBQUQ7QUFBQSxnQ0FDRTtBQUNFLGVBQUssRUFBQyxPQURSO0FBRUUsYUFBRyxFQUFDO0FBRk47QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFERixlQUtFO0FBQ0UsZUFBSyxNQURQO0FBRUUsYUFBRyxFQUFDO0FBRk47QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERixlQVlFO0FBQUssaUJBQVMsRUFBQyxVQUFmO0FBQUEsZ0NBQ0U7QUFBSyxZQUFFLEVBQUM7QUFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURGLGVBRUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFGRixlQUlFO0FBQUssbUJBQVMsRUFBQyxVQUFmO0FBQUEsb0JBQ0dNLDZDQUFDLENBQUNDLEdBQUYsQ0FBTVAsY0FBTixFQUFzQixVQUFDUSxLQUFELEVBQVFDLEdBQVIsRUFBZ0I7QUFDckMsZ0JBQUlDLGFBQWEsR0FBRyxLQUFwQjtBQUNBLGdCQUFJQyxVQUFVLEdBQUcsRUFBakI7QUFDQUEsc0JBQVUsQ0FBQyxPQUFELENBQVYsR0FBc0JILEtBQUssQ0FBQyxPQUFELENBQTNCO0FBQ0FHLHNCQUFVLENBQUMsVUFBRCxDQUFWLEdBQXlCSCxLQUFLLENBQUMsVUFBRCxDQUE5QjtBQUNBRyxzQkFBVSxDQUFDLElBQUQsQ0FBVixHQUFtQkgsS0FBSyxDQUFDLElBQUQsQ0FBeEI7QUFDQUcsc0JBQVUsQ0FBQyxZQUFELENBQVYsR0FBMkJILEtBQUssQ0FBQyxZQUFELENBQWhDO0FBQ0FHLHNCQUFVLENBQUMsYUFBRCxDQUFWLEdBQTRCSCxLQUFLLENBQUMsYUFBRCxDQUFqQztBQUNBRyxzQkFBVSxDQUFDLGFBQUQsQ0FBVixHQUE0QkgsS0FBSyxDQUFDLGFBQUQsQ0FBakM7QUFDQUcsc0JBQVUsQ0FBQyxLQUFELENBQVYsR0FBb0JILEtBQUssQ0FBQyxLQUFELENBQXpCO0FBQ0FHLHNCQUFVLENBQUMsWUFBRCxDQUFWLEdBQTJCSCxLQUFLLENBQUMsWUFBRCxDQUFoQztBQUNBRyxzQkFBVSxDQUFDLFVBQUQsQ0FBVixHQUF5QkgsS0FBSyxDQUFDLFVBQUQsQ0FBOUI7QUFDQUcsc0JBQVUsQ0FBQyxnQkFBRCxDQUFWLEdBQStCSCxLQUFLLENBQUMsZ0JBQUQsQ0FBcEM7QUFDQUcsc0JBQVUsQ0FBQyxXQUFELENBQVYsR0FBMEJILEtBQUssQ0FBQyxXQUFELENBQS9CO0FBQ0FHLHNCQUFVLENBQUMsZUFBRCxDQUFWLEdBQThCSCxLQUFLLENBQUMsZUFBRCxDQUFuQzs7QUFFQSxnQkFBSUEsS0FBSyxDQUFDLE9BQUQsQ0FBTCxLQUFtQixFQUF2QixFQUEyQjtBQUN6QixrQkFBSUcsVUFBVSxDQUFDLGFBQUQsQ0FBVixJQUE2QixFQUFqQyxFQUFxQztBQUNuQ0QsNkJBQWEsR0FBRyxJQUFoQjtBQUNEOztBQUNELGtDQUNFO0FBQWUseUJBQVMsRUFBRUQsR0FBMUI7QUFBQSx1Q0FDRTtBQUFLLDJCQUFTLEVBQUMsS0FBZjtBQUFBLHlDQUNFO0FBQUssNkJBQVMsRUFBQyxZQUFmO0FBQUEsNENBQ0U7QUFBSywrQkFBUyxFQUFDLGdCQUFmO0FBQUEsNkNBQ0U7QUFBSyxpQ0FBUyxFQUFDLFlBQWY7QUFBQSwrQ0FDRTtBQUFBLGtEQUNFO0FBQ0UsK0JBQUcsRUFDRCxtQkFDQUUsVUFBVSxDQUFDLFVBQUQsQ0FEVixvQkFGSjtBQU1FLG1DQUFPLEVBQUUsaUJBQUNDLENBQUQsRUFBTztBQUNkQSwrQkFBQyxDQUFDQyxNQUFGLENBQVNDLE9BQVQsR0FBbUIsSUFBbkI7QUFDQUYsK0JBQUMsQ0FBQ0MsTUFBRixDQUFTRSxHQUFULEdBQWUsbUJBQWY7QUFDRCw2QkFUSDtBQVVFLCtCQUFHLEVBQUVKLFVBQVUsQ0FBQyxPQUFEO0FBVmpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBREYsRUFZSyxHQVpMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQURGLGVBbUJFO0FBQUssK0JBQVMsRUFBQyxZQUFmO0FBQUEsOENBQ0U7QUFBSyxpQ0FBUyxFQUFDO0FBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFERixlQUVFO0FBQUssaUNBQVMsRUFBQyxrQkFBZjtBQUFBLCtDQUNFO0FBQUEsaURBQ0UscUVBQUMsZ0RBQUQ7QUFDRSxnQ0FBSSxFQUFFLGNBQWM3QyxJQUFJLENBQUM2QyxVQUFVLENBQUMsT0FBRCxDQUFYLENBRDFCO0FBQUEsbURBR0U7QUFDRSwwQ0FDRSxjQUFjN0MsSUFBSSxDQUFDNkMsVUFBVSxDQUFDLE9BQUQsQ0FBWCxDQUZ0QjtBQUlFLGdEQUNFLGNBQWM3QyxJQUFJLENBQUM2QyxVQUFVLENBQUMsT0FBRCxDQUFYLENBTHRCO0FBT0UsMkNBQVUsY0FQWjtBQVFFLHVDQUFTLEVBQUMsY0FSWjtBQVNFLG9DQUFNLEVBQUMsUUFUVDtBQVVFLG1DQUFLLEVBQ0gsb0NBQ0FBLFVBQVUsQ0FBQyxlQUFELENBRFYsY0FHQUEsVUFBVSxDQUFDLE9BQUQsQ0FkZDtBQWdCRSxpQ0FBRyxFQUFDLFVBaEJOO0FBQUEseUNBa0JHQSxVQUFVLENBQUMsVUFBRCxDQWxCYixRQWtCNkIsR0FsQjdCLEVBbUJHQSxVQUFVLENBQUMsT0FBRCxDQW5CYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFIRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBRkYsZUErQkU7QUFBSyxpQ0FBUyxFQUFDLGlCQUFmO0FBQUEsZ0RBQ0U7QUFBTSxtQ0FBUyxFQUFDLDBCQUFoQjtBQUFBLGtEQUNFO0FBQUcscUNBQVMsRUFBQztBQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBREYsdUJBRUU7QUFBQSxzQ0FBSUssSUFBSSxDQUFDQyxLQUFMLENBQVdELElBQUksQ0FBQ0UsTUFBTCxLQUFnQixHQUEzQixJQUFrQztBQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQUZGLEVBRWdELEdBRmhEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FERiw0QkFPRTtBQUFNLG1DQUFTLEVBQUMsMEJBQWhCO0FBQUEsb0NBQ0dQLFVBQVUsQ0FBQyxZQUFEO0FBRGI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBL0JGLGVBMkNFO0FBQUssaUNBQVMsRUFBQyxXQUFmO0FBQUEsa0NBQ0dELGFBQWEsZ0JBQ1o7QUFBQSxpREFDRSxxRUFBQyxnREFBRDtBQUNFLGdDQUFJLEVBQUUsY0FBYzVDLElBQUksQ0FBQzZDLFVBQVUsQ0FBQyxPQUFELENBQVgsQ0FEMUI7QUFBQSxtREFHRTtBQUNFLDBDQUNFLGNBQWM3QyxJQUFJLENBQUM2QyxVQUFVLENBQUMsT0FBRCxDQUFYLENBRnRCLENBSUU7QUFDQTtBQUxGO0FBTUUsZ0RBQ0UsY0FBYzdDLElBQUksQ0FBQzZDLFVBQVUsQ0FBQyxPQUFELENBQVgsQ0FQdEI7QUFTRSwyQ0FBVSxjQVRaO0FBVUUsdUNBQVMsRUFBQyxjQVZaLENBV0U7QUFYRjtBQVlFLG9DQUFNLEVBQUMsUUFaVDtBQWFFLG1DQUFLLEVBQ0gsb0NBQ0FBLFVBQVUsQ0FBQyxlQUFELENBRFYsY0FHQUEsVUFBVSxDQUFDLE9BQUQsQ0FqQmQ7QUFtQkUsaUNBQUcsRUFBQyxVQW5CTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQURZLGdCQStCWjtBQUFBLGlEQUNFLHFFQUFDLGdEQUFEO0FBQ0UsZ0NBQUksRUFBRSxjQUFjN0MsSUFBSSxDQUFDNkMsVUFBVSxDQUFDLE9BQUQsQ0FBWCxDQUQxQjtBQUFBLG1EQUdFO0FBQ0U7QUFDQSwwQ0FDRSxjQUFjN0MsSUFBSSxDQUFDNkMsVUFBVSxDQUFDLE9BQUQsQ0FBWCxDQUh0QixDQUtFO0FBQ0E7QUFDQTtBQVBGO0FBUUUsMkNBQVUsU0FSWjtBQVNFLHVDQUFTLEVBQUMsU0FUWixDQVVFO0FBVkY7QUFXRSxvQ0FBTSxFQUFDLFFBWFQsQ0FZRTtBQVpGO0FBYUUsaUNBQUcsRUFBQyxVQWJOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFoQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkEzQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREYsaUJBQVVGLEdBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFERjtBQStIRDtBQUNGLFdBcEpBO0FBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFKRixlQTJKRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTNKRixlQTRKRTtBQUFLLFlBQUUsRUFBQztBQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBNUpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQURGO0FBNktELEdBOUtELE1BOEtPO0FBQ0wsd0JBQ0U7QUFBQSw4QkFDRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREYsZUFFRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRkYsZUFHRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBSEYsZUFJRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQURGO0FBUUQ7QUFDRixDQTdPRDs7R0FBTXBDLEk7VUFDV0cscUQ7OztLQURYSCxJO0FBK09TQSxtRUFBZiIsImZpbGUiOiJzdGF0aWMvd2VicGFjay9wYWdlcy9pbmRleC44NzQ0NTBmZGEzYjg0NTNiZmNlYS5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IENvbXBvbmVudCwgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgSGVhZCBmcm9tIFwibmV4dC9oZWFkXCI7XHJcbmltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gXCJuZXh0L3JvdXRlclwiO1xyXG5pbXBvcnQgXyBmcm9tIFwibG9kYXNoXCI7XHJcbmltcG9ydCBNb21lbnQgZnJvbSBcIm1vbWVudFwiO1xyXG5pbXBvcnQgTGluayBmcm9tIFwibmV4dC9saW5rXCI7XHJcbnZhciBzbHVnID0gcmVxdWlyZShcInNsdWdcIik7XHJcblxyXG5jb25zdCBnZXRQYXJzZWREYXRlID0gKGRhdGUpID0+IHtcclxuICByZXR1cm4gTW9tZW50KGRhdGUpLnN0YXJ0T2YoXCJob3VyXCIpLmZyb21Ob3coKTtcclxufTtcclxuXHJcbi8vIGNvbnN0IGNsaWNrVXJsID0gKHRhcmdldCkgPT4ge1xyXG4vLyAgIC8vIGh0dHA6Ly9sb2NhbGhvc3Q6MzAwMC9vZmZlcnNcclxuLy8gICAgIGlmICh0eXBlb2Ygd2luZG93ICE9PSBcInVuZGVmaW5lZFwiKSB7XHJcbi8vICAgICB3aW5kb3cubG9jYXRpb24uaHJlZiA9IHRhcmdldDtcclxuLy8gICAgIH1cclxuLy8gfTtcclxuXHJcbmNvbnN0IENhcmQgPSAocHJvcHMpID0+IHtcclxuICBjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKTtcclxuICBjb25zdCB7IHNsdWcgfSA9IHJvdXRlci5xdWVyeTtcclxuICAvLyBTaW1pbGFyIHRvIGNvbXBvbmVudERpZE1vdW50IGFuZCBjb21wb25lbnREaWRVcGRhdGU6XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIC8vIDwhLS0gb3RoZXIgaGVhZCBlbGVtZW50cyBmcm9tIHlvdXIgcGFnZSAtLT5cclxuXHJcbiAgICAoZnVuY3Rpb24gKGcsIG8pIHtcclxuICAgICAgKGdbb10gPVxyXG4gICAgICAgIGdbb10gfHxcclxuICAgICAgICBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAoZ1tvXVtcInFcIl0gPSBnW29dW1wicVwiXSB8fCBbXSkucHVzaChhcmd1bWVudHMpO1xyXG4gICAgICAgIH0pLFxyXG4gICAgICAgIChnW29dW1widFwiXSA9IDEgKiBuZXcgRGF0ZSgpKTtcclxuICAgIH0pKHdpbmRvdywgXCJfZ29vZ0NzYVwiKTtcclxuXHJcbiAgICB2YXIgcGFnZU9wdGlvbnMgPSB7XHJcbiAgICAgIHB1YklkOiBcInB1Yi05NjE2Mzg5MDAwMjEzODIzXCIsIC8vIE1ha2Ugc3VyZSB0aGlzIHRoZSBjb3JyZWN0IGNsaWVudCBJRCFcclxuICAgICAgcXVlcnk6IHNsdWcsXHJcbiAgICAgIGFkUGFnZTogMTAsXHJcbiAgICAgIGNoYW5uZWw6IFwic2VhcmNoY2hubVwiLFxyXG4gICAgfTtcclxuXHJcbiAgICB2YXIgYWRibG9jazEgPSB7XHJcbiAgICAgIGNvbnRhaW5lcjogXCJhZnNjb250YWluZXIxXCIsXHJcbiAgICAgIGxpbmtUYXJnZXQ6IFwiX2JsYW5rXCIsXHJcbiAgICAgIHR5cGU6IFwiYWRzXCIsXHJcbiAgICAgIGNvbHVtbnM6IDEsXHJcbiAgICAgIGhvcml6b250YWxBbGlnbm1lbnQ6IFwibGVmdFwiLFxyXG4gICAgICByZXN1bHRzUGFnZVF1ZXJ5UGFyYW06IFwicXVlcnlcIixcclxuICAgICAgc3R5bGVJZDogXCI2OTQwNzM4NjQ5XCIsXHJcbiAgICAgIGFkTG9hZGVkQ2FsbGJhY2s6IG51bGwsXHJcbiAgICB9O1xyXG5cclxuICAgIHZhciBhZGJsb2NrMiA9IHtcclxuICAgICAgY29udGFpbmVyOiBcImFmc2NvbnRhaW5lcjJcIixcclxuICAgICAgbGlua1RhcmdldDogXCJfYmxhbmtcIixcclxuICAgICAgdHlwZTogXCJhZHNcIixcclxuICAgICAgY29sdW1uczogMSxcclxuICAgICAgaG9yaXpvbnRhbEFsaWdubWVudDogXCJsZWZ0XCIsXHJcbiAgICAgIHJlc3VsdHNQYWdlUXVlcnlQYXJhbTogXCJxdWVyeVwiLFxyXG4gICAgICBzdHlsZUlkOiBcIjY5NDA3Mzg2NDlcIixcclxuICAgICAgYWRMb2FkZWRDYWxsYmFjazogbnVsbCxcclxuICAgIH07XHJcblxyXG4gICAgX2dvb2dDc2EoXCJhZHNcIiwgcGFnZU9wdGlvbnMsIGFkYmxvY2sxLCBhZGJsb2NrMik7XHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IGN1ZWxpbmtzT2ZmZXJzID0gcHJvcHMuY3VlbGlua3NPZmZlcnMgPyBwcm9wcy5jdWVsaW5rc09mZmVycyA6IHt9O1xyXG4gIGNvbnN0IHN0b3JlX19sb2dvID0gcHJvcHMuc3RvcmVJbmZvID8gcHJvcHMuc3RvcmVJbmZvLnNsdWcgOiB7fTtcclxuICBjb25zdCBzdG9yZV9fbmFtZSA9IHByb3BzLnN0b3JlSW5mbyA/IHByb3BzLnN0b3JlSW5mby5uYW1lIDoge307XHJcbiAgY29uc3QgbGltaXQgPSBwcm9wcy5saW1pdCA/IHByb3BzLmxpbWl0IDoge307XHJcblxyXG4gIGlmIChjdWVsaW5rc09mZmVycykge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPHNlY3Rpb24+XHJcbiAgICAgICAgPEhlYWQ+XHJcbiAgICAgICAgICA8c2NyaXB0XHJcbiAgICAgICAgICAgIGFzeW5jPVwiYXN5bmNcIlxyXG4gICAgICAgICAgICBzcmM9XCJodHRwczovL3d3dy5nb29nbGUuY29tL2Fkc2Vuc2Uvc2VhcmNoL2Fkcy5qc1wiXHJcbiAgICAgICAgICA+PC9zY3JpcHQ+XHJcbiAgICAgICAgICA8c2NyaXB0XHJcbiAgICAgICAgICAgIGFzeW5jXHJcbiAgICAgICAgICAgIHNyYz1cImh0dHBzOi8vY3NlLmdvb2dsZS5jb20vY3NlLmpzP2N4PTM5YmVkOGYzZGU4OGE0ODg1XCJcclxuICAgICAgICAgID48L3NjcmlwdD5cclxuICAgICAgICA8L0hlYWQ+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2xlYXJmaXhcIj5cclxuICAgICAgICAgIDxkaXYgaWQ9XCJhZnNjb250YWluZXIxXCI+PC9kaXY+XHJcbiAgICAgICAgICA8YnIgLz5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNsZWFyZml4XCI+XHJcbiAgICAgICAgICAgIHtfLm1hcChjdWVsaW5rc09mZmVycywgKHZhbHVlLCBrZXkpID0+IHtcclxuICAgICAgICAgICAgICBsZXQgcHJvbW9jb2RlQ2FyZCA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgIGxldCBjdWVsT2ZmZXJzID0ge307XHJcbiAgICAgICAgICAgICAgY3VlbE9mZmVyc1tcInRpdGxlXCJdID0gdmFsdWVbXCJ0aXRsZVwiXTtcclxuICAgICAgICAgICAgICBjdWVsT2ZmZXJzW1wibWVyY2hhbnRcIl0gPSB2YWx1ZVtcIm1lcmNoYW50XCJdO1xyXG4gICAgICAgICAgICAgIGN1ZWxPZmZlcnNbXCJpZFwiXSA9IHZhbHVlW1wiaWRcIl07XHJcbiAgICAgICAgICAgICAgY3VlbE9mZmVyc1tcImNhdGVnb3JpZXNcIl0gPSB2YWx1ZVtcImNhdGVnb3JpZXNcIl07XHJcbiAgICAgICAgICAgICAgY3VlbE9mZmVyc1tcImRlc2NyaXB0aW9uXCJdID0gdmFsdWVbXCJkZXNjcmlwdGlvblwiXTtcclxuICAgICAgICAgICAgICBjdWVsT2ZmZXJzW1wiY291cG9uX2NvZGVcIl0gPSB2YWx1ZVtcImNvdXBvbl9jb2RlXCJdO1xyXG4gICAgICAgICAgICAgIGN1ZWxPZmZlcnNbXCJ1cmxcIl0gPSB2YWx1ZVtcInVybFwiXTtcclxuICAgICAgICAgICAgICBjdWVsT2ZmZXJzW1wic3RhcnRfZGF0ZVwiXSA9IHZhbHVlW1wic3RhcnRfZGF0ZVwiXTtcclxuICAgICAgICAgICAgICBjdWVsT2ZmZXJzW1wiZW5kX2RhdGVcIl0gPSB2YWx1ZVtcImVuZF9kYXRlXCJdO1xyXG4gICAgICAgICAgICAgIGN1ZWxPZmZlcnNbXCJvZmZlcl9hZGRlZF9hdFwiXSA9IHZhbHVlW1wib2ZmZXJfYWRkZWRfYXRcIl07XHJcbiAgICAgICAgICAgICAgY3VlbE9mZmVyc1tcImltYWdlX3VybFwiXSA9IHZhbHVlW1wiaW1hZ2VfdXJsXCJdO1xyXG4gICAgICAgICAgICAgIGN1ZWxPZmZlcnNbXCJjYW1wYWlnbl9uYW1lXCJdID0gdmFsdWVbXCJjYW1wYWlnbl9uYW1lXCJdO1xyXG5cclxuICAgICAgICAgICAgICBpZiAodmFsdWVbXCJ0aXRsZVwiXSAhPT0gXCJcIikge1xyXG4gICAgICAgICAgICAgICAgaWYgKGN1ZWxPZmZlcnNbXCJjb3Vwb25fY29kZVwiXSAhPSBcIlwiKSB7XHJcbiAgICAgICAgICAgICAgICAgIHByb21vY29kZUNhcmQgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e2tleX0gY2xhc3NOYW1lPXtrZXl9PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRlYWxfX2NhcmRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkZWFsX19kaXNjb3VudFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZGVhbF9faW5mb1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGltZ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNyYz17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBgL3N0b3Jlc19fbG9nby9gICtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGN1ZWxPZmZlcnNbXCJtZXJjaGFudFwiXSArXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBgLWxvZ28tc21hbGwuanBnYFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkVycm9yPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZS50YXJnZXQub25lcnJvciA9IG51bGw7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlLnRhcmdldC5zcmMgPSBcIi9pbWctbm90Zm91bmQuanBnXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbHQ9e2N1ZWxPZmZlcnNbXCJ0aXRsZVwiXX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz57XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZGVhbF9fZGVzY1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZGVhbF9fZGVzYy10eXBlXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkZWFsX19kZXNjLXRpdGxlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDM+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaHJlZj17XCIvcHJvZHVjdC9cIiArIHNsdWcoY3VlbE9mZmVyc1tcInRpdGxlXCJdKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxhXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhLXVybD17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiL3Byb2R1Y3QvXCIgKyBzbHVnKGN1ZWxPZmZlcnNbXCJ0aXRsZVwiXSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGEtcHJvbW9saW5rPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCIvcHJvZHVjdC9cIiArIHNsdWcoY3VlbE9mZmVyc1tcInRpdGxlXCJdKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YS1mdW5jPVwiZ2V0UHJvbW9Db2RlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImdldFByb21vQ29kZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0YXJnZXQ9XCJfYmxhbmtcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBgT2ZmZXJzQ29kZS5pbiAtIFByb21vIGNvZGUgZm9yIGAgK1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjdWVsT2ZmZXJzW1wiY2FtcGFpZ25fbmFtZVwiXSArXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGAgZGVhbCBgICtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY3VlbE9mZmVyc1tcInRpdGxlXCJdXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWw9XCJub2ZvbGxvd1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2N1ZWxPZmZlcnNbXCJtZXJjaGFudFwiXX0gOntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjdWVsT2ZmZXJzW1widGl0bGVcIl19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9hPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZGVhbF9fZGVzYy1tZXRhXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJkZWFsX19kZXNjLW1ldGEtbGFzdHVzZWRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGkgY2xhc3NOYW1lPVwiZmEgZmEtdXNlcnNcIj48L2k+Jm5ic3A7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxiPntNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiAyMDApICsgMTF9PC9iPntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUGVvcGxlIFVzZWQgVG9kYXlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICZuYnNwO3wmbmJzcDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImRlYWxfX2Rlc2MtbWV0YS1sYXN0dXNlZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y3VlbE9mZmVyc1tcImNhdGVnb3JpZXNcIl19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZGVhbF9fY3RhXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cHJvbW9jb2RlQ2FyZCA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaHJlZj17XCIvcHJvZHVjdC9cIiArIHNsdWcoY3VlbE9mZmVyc1tcInRpdGxlXCJdKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhLXVybD17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCIvcHJvZHVjdC9cIiArIHNsdWcoY3VlbE9mZmVyc1tcInRpdGxlXCJdKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGRhdGEtcHJvbW9jb2RlPXsnJ31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gZGF0YS1zcGVjaWVzPXsnJ31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YS1wcm9tb2xpbms9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiL3Byb2R1Y3QvXCIgKyBzbHVnKGN1ZWxPZmZlcnNbXCJ0aXRsZVwiXSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhLWZ1bmM9XCJnZXRQcm9tb0NvZGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJnZXRQcm9tb0NvZGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBkYXRhLXdlYnNpdGU9eycnfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0YXJnZXQ9XCJfYmxhbmtcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYE9mZmVyc0NvZGUuaW4gLSBQcm9tbyBjb2RlIGZvciBgICtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjdWVsT2ZmZXJzW1wiY2FtcGFpZ25fbmFtZVwiXSArXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYCBkZWFsIGAgK1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGN1ZWxPZmZlcnNbXCJ0aXRsZVwiXVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlbD1cIm5vZm9sbG93XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgR2V0IFRoaXMgRGVhbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9hPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBocmVmPXtcIi9wcm9kdWN0L1wiICsgc2x1ZyhjdWVsT2ZmZXJzW1widGl0bGVcIl0pfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxhXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGhyZWY9e2AvZ290b2B9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGEtdXJsPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIi9wcm9kdWN0L1wiICsgc2x1ZyhjdWVsT2ZmZXJzW1widGl0bGVcIl0pXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gZGF0YS1wcm9tb2NvZGU9e31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gZGF0YS1zcGVjaWVzPXt9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGRhdGEtcHJvbW9saW5rPXt9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGEtZnVuYz1cImdldERlYWxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJnZXREZWFsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gZGF0YS13ZWJzaXRlPXt9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRhcmdldD1cIl9ibGFua1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGdvdG9MaW5rID0ge3ZhbHVlWzExXX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVsPVwibm9mb2xsb3dcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBHZXQgVGhpcyBEZWFsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8YnIgLz5cclxuICAgICAgICAgIDxkaXYgaWQ9XCJhZnNjb250YWluZXIxXCI+PC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvc2VjdGlvbj5cclxuICAgICk7XHJcbiAgfSBlbHNlIHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxkaXY+XHJcbiAgICAgICAgPGJyIC8+XHJcbiAgICAgICAgPGJyIC8+XHJcbiAgICAgICAgPGJyIC8+XHJcbiAgICAgICAgPGgzPk5vIE5ldyBEZWFscyBPciBDb3Vwb25zIEZvdW5kPC9oMz5cclxuICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG4gIH1cclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IENhcmQ7XHJcbiJdLCJzb3VyY2VSb290IjoiIn0=