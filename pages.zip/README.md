This is a starter template for [Learn Next.js](https://nextjs.org/learn).






1. meta tags
2. ratings & code on store page or offers
3. http://localhost:3000/categories/food-nutrition - done
4. redesign page cat parent - http://localhost:3000/categories
5. flipkart
6. cat prod page link to be work
7. product/cat-prod1


