import admitad from './pages/api/front/admitadStores';

export const store = [  
  ...admitad
];
